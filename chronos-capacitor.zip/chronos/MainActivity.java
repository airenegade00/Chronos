package com.chronos.app;

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.concurrent.Executor;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Natív biometria bridge regisztrálása
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );
    }

    // ── Biometria bridge ──────────────────────────────────────────────────
    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                int result = bm.canAuthenticate(
                    BiometricManager.Authenticators.BIOMETRIC_WEAK |
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
                );
                return result == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](true, null);",
                                    null
                                )
                            );
                        }

                        @Override
                        public void onAuthenticationFailed() {
                            // Nem hívjuk vissza – a user próbálkozhat újra
                        }

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            final String safe = errString.toString()
                                .replace("\\", "\\\\")
                                .replace("'", "\\'");
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](false, '" + safe + "');",
                                    null
                                )
                            );
                        }
                    }
                );

                BiometricPrompt.PromptInfo info =
                    new BiometricPrompt.PromptInfo.Builder()
                        .setTitle(title)
                        .setSubtitle(subtitle)
                        .setAllowedAuthenticators(
                            BiometricManager.Authenticators.BIOMETRIC_WEAK |
                            BiometricManager.Authenticators.DEVICE_CREDENTIAL
                        )
                        .build();

                prompt.authenticate(info);
            });
        }
    }
}
