package com.chronos.app;

import android.accounts.Account;
import android.app.Activity;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends BridgeActivity {

    // Folyamatban lévő mentés: callback-név + várakozó adat, amíg a felhasználó
    // a "Mentés másként" dialógusban kiválasztja a célt.
    private String pendingSaveCallback = null;
    private byte[] pendingSaveBytes = null;

    private ActivityResultLauncher<Intent> saveFileLauncher;

    // Folyamatban lévő Gmail OAuth-engedélyezés: a kérés visszatérése aszinkron
    // érkezik, amíg a felhasználó a Google fiókválasztó / hozzájárulás
    // dialógusban dönt (csak az ELSŐ alkalommal jelenik meg, utána a Play
    // Services csendben ad új access tokent ugyanezen a metóduson keresztül).
    private String pendingGmailAuthCallback = null;

    private ActivityResultLauncher<IntentSenderRequest> gmailAuthLauncher;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );

        // Regisztráljuk a "Mentés másként" dialógus eredmény-kezelőjét.
        saveFileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    handleSaveFileResult(result);
                }
            }
        );

        // Regisztráljuk a Gmail OAuth-hozzájárulás dialógus eredmény-kezelőjét.
        gmailAuthLauncher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    handleGmailAuthResult(result);
                }
            }
        );
    }

    private void notifyJs(final String callbackName, final boolean success, final String message) {
        final String safeMsg = (message == null ? "" : message)
            .replace("\\", "\\\\")
            .replace("'", "\\'");
        runOnUiThread(() ->
            getBridge().getWebView().evaluateJavascript(
                "window['" + callbackName + "'] && window['" + callbackName + "'](" +
                (success ? "true" : "false") + ", '" + safeMsg + "');",
                null
            )
        );
    }

    private void handleSaveFileResult(ActivityResult result) {
        final String callbackName = pendingSaveCallback;
        final byte[] bytes = pendingSaveBytes;
        pendingSaveCallback = null;
        pendingSaveBytes = null;

        if (callbackName == null) return;

        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            // Felhasználó megszakította a mentést (pl. "Mégse")
            notifyJs(callbackName, false, "cancelled");
            return;
        }

        Uri targetUri = result.getData().getData();
        if (targetUri == null) {
            notifyJs(callbackName, false, "no_uri");
            return;
        }

        try (OutputStream os = getContentResolver().openOutputStream(targetUri)) {
            if (os == null) throw new Exception("openOutputStream returned null");
            os.write(bytes);
            os.flush();
            notifyJs(callbackName, true, null);
        } catch (Exception e) {
            notifyJs(callbackName, false, e.getMessage());
        }
    }

    // Eredmény a Gmail OAuth-hozzájárulás dialógusból (csak akkor fut, ha
    // requestGmailAuth() "resolution"-t igényelt, tehát hozzájárulás kellett).
    private void handleGmailAuthResult(ActivityResult result) {
        final String callbackName = pendingGmailAuthCallback;
        pendingGmailAuthCallback = null;
        if (callbackName == null) return;

        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            notifyJs(callbackName, false, "cancelled");
            return;
        }

        try {
            AuthorizationResult authResult =
                Identity.getAuthorizationClient(this)
                    .getAuthorizationResultFromIntent(result.getData());
            notifyJs(callbackName, true, authResult.getAccessToken());
        } catch (ApiException e) {
            notifyJs(callbackName, false, "ApiException " + e.getStatusCode());
        } catch (Exception e) {
            notifyJs(callbackName, false, e.getMessage());
        }
    }

    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        // ─── Biometria: elérhető-e? ────────────────────────────────────────
        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    int r = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                    if (r == BiometricManager.BIOMETRIC_SUCCESS) return true;
                }
                int r2 = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r2 == BiometricManager.BIOMETRIC_SUCCESS) return true;
                @SuppressWarnings("deprecation")
                int r3 = bm.canAuthenticate();
                return r3 == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        // ─── Biometria: prompt megjelenítése ───────────────────────────────
        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.notifyJs(callbackName, true, null);
                        }

                        @Override
                        public void onAuthenticationFailed() {}

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            act.notifyJs(callbackName, false, errString.toString());
                        }
                    }
                );

                try {
                    BiometricPrompt.PromptInfo info;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setAllowedAuthenticators(
                                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                            )
                            .build();
                    } else {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setNegativeButtonText("Mégse")
                            .build();
                    }
                    prompt.authenticate(info);
                } catch (Exception e) {
                    try {
                        BiometricPrompt.PromptInfo fallback =
                            new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setNegativeButtonText("Mégse")
                                .build();
                        prompt.authenticate(fallback);
                    } catch (Exception e2) {
                        act.notifyJs(callbackName, false, "unavailable");
                    }
                }
            });
        }

        // ─── Fájl megosztása: Base64 JSON → cache → Android Share Intent ──
        // Visszatér: "ok" ha sikerült, "error: <üzenet>" ha nem.
        // (Ez a "Küldés" útvonal — más alkalmazásnak adja át a fájlt.)
        @JavascriptInterface
        public String shareFile(final String filename, final String base64data) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                File cacheDir = act.getCacheDir();
                File outFile = new File(cacheDir, filename);
                FileOutputStream fos = new FileOutputStream(outFile);
                fos.write(bytes);
                fos.close();

                Uri fileUri = FileProvider.getUriForFile(
                    act,
                    act.getPackageName() + ".fileprovider",
                    outFile
                );

                final Uri shareUri = fileUri;
                act.runOnUiThread(() -> {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("application/json");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, filename);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(shareIntent, filename));
                });

                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        // ─── Fájl mentése "Mentés másként" dialógussal ─────────────────────
        // Megnyitja az Android natív fájlmentő dialógust (Storage Access
        // Framework), ahol a felhasználó kiválasztja a mappát és a fájlnevet,
        // pontosan úgy, mint PC-n. Az eredmény aszinkron érkezik a callback-en.
        @JavascriptInterface
        public void saveFileWithPicker(
                final String filename,
                final String base64data,
                final String callbackName) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                act.pendingSaveCallback = callbackName;
                act.pendingSaveBytes = bytes;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);

                act.runOnUiThread(() -> act.saveFileLauncher.launch(intent));
            } catch (Exception e) {
                act.notifyJs(callbackName, false, e.getMessage());
            }
        }

        // ─── Gmail OAuth access token kérése ────────────────────────────────
        // Első hívásnál megjelenik a Google fiókválasztó + hozzájárulás
        // dialógus (csak a "gmail.readonly" scope-ra, a TELJES postafiókra,
        // NEM csak bizonyos levelekre). Utána a Play Services a fiók
        // eszköz-szintű bejelentkezése alapján csendben, dialógus nélkül ad
        // friss (kb. 1 órás) access tokent — ezért ugyanezt a metódust kell
        // hívni a manuális szinkronnál ÉS a háttér-időzítőnél is.
        // A callback(success, accessTokenVagyHibaüzenet) formában tér vissza.
        // A Zeus Monatsjournal mindig ugyanarra a fix Gmail-fiókra érkezik,
        // ezért az AuthorizationRequest-et erre a fiókra pin-eljük. Így
        // SOHA nem jelenik meg a teljes fiókválasztó lista — legfeljebb
        // (első alkalommal) egy hozzájárulás-dialógus magára erre a fiókra.
        // FONTOS: a fiókot fel kell vinni a készülék Beállítások > Fiókok
        // listájába, különben az authorize() hibát ad.
        private static final String FIXED_GMAIL_ACCOUNT = "chronoseht@gmail.com";

        // ─── OTA Update: új app HTML letöltése és www/-be írása ──────────
        // A WebView file:// context-ben marad → minden natív plugin működik.
        // A callbackName(success, message) formában tér vissza.
        @JavascriptInterface
        public void downloadAndInstallUpdate(final String downloadUrl, final String callbackName) {
            new Thread(() -> {
                try {
                    // 1. Letöltés
                    URL url = new URL(downloadUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(60000);
                    conn.connect();

                    // Google Drive redirect kezelése
                    int status = conn.getResponseCode();
                    if (status == HttpURLConnection.HTTP_MOVED_TEMP ||
                        status == HttpURLConnection.HTTP_MOVED_PERM ||
                        status == 307 || status == 308) {
                        String newUrl = conn.getHeaderField("Location");
                        conn.disconnect();
                        conn = (HttpURLConnection) new URL(newUrl).openConnection();
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(60000);
                        conn.connect();
                    }

                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }
                    reader.close();
                    conn.disconnect();

                    String html = sb.toString();
                    if (html.trim().isEmpty()) throw new Exception("Empty response");

                    // 2. Fájlba írás: assets/www/index.html
                    // A Capacitor a getFilesDir()/public/ mappából tölti be
                    java.io.File wwwDir = new java.io.File(
                        act.getFilesDir(), "public");
                    if (!wwwDir.exists()) wwwDir.mkdirs();
                    java.io.File indexFile = new java.io.File(wwwDir, "index.html");
                    java.io.FileWriter fw = new java.io.FileWriter(indexFile, false);
                    fw.write(html);
                    fw.flush();
                    fw.close();

                    // 3. WebView újratöltése UI szálon
                    act.runOnUiThread(() -> {
                        act.notifyJs(callbackName, true, "installed");
                        // Rövid delay után reload
                        act.getBridge().getWebView().postDelayed(() -> {
                            act.getBridge().getWebView().reload();
                        }, 500);
                    });

                } catch (Exception e) {
                    act.runOnUiThread(() ->
                        act.notifyJs(callbackName, false, e.getMessage())
                    );
                }
            }).start();
        }

        @JavascriptInterface
        public void requestGmailAuth(final String callbackName) {
            try {
                Scope gmailScope = new Scope("https://www.googleapis.com/auth/gmail.readonly");
                Account fixedAccount = new Account(FIXED_GMAIL_ACCOUNT, "com.google");
                AuthorizationRequest authRequest = AuthorizationRequest.builder()
                    .setRequestedScopes(Collections.singletonList(gmailScope))
                    .setAccount(fixedAccount)
                    .build();

                Identity.getAuthorizationClient(act)
                    .authorize(authRequest)
                    .addOnSuccessListener(authResult -> {
                        if (authResult.hasResolution()) {
                            // Még nincs hozzájárulás (vagy lejárt) → dialógus kell
                            act.pendingGmailAuthCallback = callbackName;
                            try {
                                IntentSenderRequest senderRequest =
                                    new IntentSenderRequest.Builder(
                                        authResult.getPendingIntent().getIntentSender()
                                    ).build();
                                act.runOnUiThread(() -> act.gmailAuthLauncher.launch(senderRequest));
                            } catch (Exception e) {
                                act.pendingGmailAuthCallback = null;
                                act.notifyJs(callbackName, false, e.getMessage());
                            }
                        } else {
                            // Már jóváhagyott fiók → token azonnal, dialógus nélkül
                            act.notifyJs(callbackName, true, authResult.getAccessToken());
                        }
                    })
                    .addOnFailureListener(e ->
                        act.notifyJs(callbackName, false, e.getMessage())
                    );
            } catch (Exception e) {
                act.notifyJs(callbackName, false, e.getMessage());
            }
        }
    }
}
