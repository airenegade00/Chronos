package com.chronos.app;

import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.concurrent.Executor;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );
    }

    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                // Android 11+ (API 30+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    int r = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                    if (r == BiometricManager.BIOMETRIC_SUCCESS) return true;
                }
                // Android 9-10: csak BIOMETRIC_WEAK
                int r2 = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r2 == BiometricManager.BIOMETRIC_SUCCESS) return true;
                // Legacy
                @SuppressWarnings("deprecation")
                int r3 = bm.canAuthenticate();
                return r3 == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](true, null);",
                                    null
                                )
                            );
                        }

                        @Override
                        public void onAuthenticationFailed() {}

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            final String safe = errString.toString()
                                .replace("\\", "\\\\")
                                .replace("'", "\\'");
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](false, '" + safe + "');",
                                    null
                                )
                            );
                        }
                    }
                );

                try {
                    BiometricPrompt.PromptInfo info;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setAllowedAuthenticators(
                                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                            )
                            .build();
                    } else {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setNegativeButtonText("Mégse")
                            .build();
                    }
                    prompt.authenticate(info);
                } catch (Exception e) {
                    try {
                        BiometricPrompt.PromptInfo fallback =
                            new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setNegativeButtonText("Mégse")
                                .build();
                        prompt.authenticate(fallback);
                    } catch (Exception e2) {
                        act.getBridge().getWebView().post(() ->
                            act.getBridge().getWebView().evaluateJavascript(
                                "window['" + callbackName + "'] && " +
                                "window['" + callbackName + "'](false, 'unavailable');",
                                null
                            )
                        );
                    }
                }
            });
        }
    }
}
