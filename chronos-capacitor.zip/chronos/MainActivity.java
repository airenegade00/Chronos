package com.chronos.app;

import android.accounts.Account;
import android.app.Activity;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.content.Context;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.HapticFeedbackConstants;

public class MainActivity extends BridgeActivity {

    // Folyamatban lévő mentés: callback-név + várakozó adat, amíg a felhasználó
    // a "Mentés másként" dialógusban kiválasztja a célt.
    private String pendingSaveCallback = null;
    private byte[] pendingSaveBytes = null;

    private ActivityResultLauncher<Intent> saveFileLauncher;

    // Folyamatban lévő Gmail OAuth-engedélyezés: a kérés visszatérése aszinkron
    // érkezik, amíg a felhasználó a Google fiókválasztó / hozzájárulás
    // dialógusban dönt (csak az ELSŐ alkalommal jelenik meg, utána a Play
    // Services csendben ad új access tokent ugyanezen a metóduson keresztül).
    private String pendingGmailAuthCallback = null;

    private ActivityResultLauncher<IntentSenderRequest> gmailAuthLauncher;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );

        // ── OTA frissítés betöltése (HA VAN) ──────────────────────────────
        // Ha downloadAndInstallUpdate() korábban már kiírt egy frissített
        // www-mappát az app belső tárolójába, a WebView innen szolgáljon ki
        // tartalmat az APK-ba sütött (statikus) assets helyett.
        // Capacitor API: Bridge.setServerBasePath() + reload().
        File updatedWww = new File(getFilesDir(), "chronos_www");
        File updatedIndex = new File(updatedWww, "bootloader.html");
        if (updatedWww.exists() && updatedIndex.exists()) {
            getBridge().setServerBasePath(updatedWww.getAbsolutePath());
        }

        // Első indításkor bootloader.html (OTA-ellenőrzés + onboarding),
        // minden további indításkor bootloader2.html (PIN / biometria).
        boolean bootSeen = getSharedPreferences("chronos_prefs", MODE_PRIVATE)
                               .getBoolean("boot_seen", false);
        final String startPage = bootSeen ? "bootloader2.html" : "bootloader.html";
        final String baseUrl = getBridge().getLocalUrl();
        getBridge().getWebView().post(() ->
            getBridge().getWebView().loadUrl(baseUrl + "/" + startPage)
        );

        // Regisztráljuk a "Mentés másként" dialógus eredmény-kezelőjét.
        saveFileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    handleSaveFileResult(result);
                }
            }
        );

        // Regisztráljuk a Gmail OAuth-hozzájárulás dialógus eredmény-kezelőjét.
        gmailAuthLauncher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    handleGmailAuthResult(result);
                }
            }
        );
    }

    // ── Google Drive letöltés vírusszűrő bypass ───────────────────────────
    // Nagy fájloknál (~500 KB+) a Drive vírusszűrő egy HTML figyelmeztető
    // oldalt küld vissza a közvetlen letöltés helyett.
    // Megoldás: az első válaszból kiolvassuk a confirm token-t / uuid-t,
    // majd újra lekérjük a fájlt azzal a cookie-val / query paraméterrel.
    private String driveDownload(String downloadUrl) throws Exception {
        // 1. kísérlet: közvetlen letöltés
        String html = httpGet(downloadUrl, null);

        // Ha már érvényes Chronos tartalom → kész
        if (html != null && html.contains("CHRONOS-VALID")) return html;

        // Ha vírusszűrő oldalt kaptunk: keressük a confirm token-t
        if (html != null && (html.contains("drive.google.com") || html.contains("Google Drive"))) {
            String confirmUrl = null;

            // Új Drive formátum: action form URL-ben
            java.util.regex.Matcher m1 = java.util.regex.Pattern
                .compile("action=\"(https://drive\\.google\\.com/download[^\"]+)\"")
                .matcher(html);
            if (m1.find()) {
                confirmUrl = m1.group(1).replace("&amp;", "&");
            }

            // Régi confirm= formátum
            if (confirmUrl == null) {
                java.util.regex.Matcher m2 = java.util.regex.Pattern
                    .compile("confirm=([^&\"&lt;]+)")
                    .matcher(html);
                if (m2.find()) {
                    String token = m2.group(1);
                    confirmUrl = downloadUrl + "&confirm=" + token;
                }
            }

            if (confirmUrl != null) {
                String confirmed = httpGet(confirmUrl, null);
                if (confirmed != null) return confirmed;
            }
        }

        return html;
    }

    private String httpGet(String urlStr, String cookie) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        conn.setRequestProperty("User-Agent",
            "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        if (cookie != null) conn.setRequestProperty("Cookie", cookie);
        conn.connect();

        int status = conn.getResponseCode();
        if (status == HttpURLConnection.HTTP_MOVED_TEMP ||
            status == HttpURLConnection.HTTP_MOVED_PERM ||
            status == 307 || status == 308) {
            String newUrl = conn.getHeaderField("Location");
            conn.disconnect();
            if (newUrl == null) return null;
            return httpGet(newUrl, cookie);
        }

        if (status != 200) { conn.disconnect(); return null; }

        BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line).append("\n");
        reader.close();
        conn.disconnect();
        return sb.toString();
    }
    // ─────────────────────────────────────────────────────────────────────

    private void notifyJs(final String callbackName, final boolean success, final String message) {
        final String safeMsg = (message == null ? "" : message)
            .replace("\\", "\\\\")
            .replace("'", "\\'");
        runOnUiThread(() ->
            getBridge().getWebView().evaluateJavascript(
                "window['" + callbackName + "'] && window['" + callbackName + "'](" +
                (success ? "true" : "false") + ", '" + safeMsg + "');",
                null
            )
        );
    }

    private void handleSaveFileResult(ActivityResult result) {
        final String callbackName = pendingSaveCallback;
        final byte[] bytes = pendingSaveBytes;
        pendingSaveCallback = null;
        pendingSaveBytes = null;

        if (callbackName == null) return;

        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            // Felhasználó megszakította a mentést (pl. "Mégse")
            notifyJs(callbackName, false, "cancelled");
            return;
        }

        Uri targetUri = result.getData().getData();
        if (targetUri == null) {
            notifyJs(callbackName, false, "no_uri");
            return;
        }

        try (OutputStream os = getContentResolver().openOutputStream(targetUri)) {
            if (os == null) throw new Exception("openOutputStream returned null");
            os.write(bytes);
            os.flush();
            notifyJs(callbackName, true, null);
        } catch (Exception e) {
            notifyJs(callbackName, false, e.getMessage());
        }
    }

    // Eredmény a Gmail OAuth-hozzájárulás dialógusból (csak akkor fut, ha
    // requestGmailAuth() "resolution"-t igényelt, tehát hozzájárulás kellett).
    private void handleGmailAuthResult(ActivityResult result) {
        final String callbackName = pendingGmailAuthCallback;
        pendingGmailAuthCallback = null;
        if (callbackName == null) return;

        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            notifyJs(callbackName, false, "cancelled");
            return;
        }

        try {
            AuthorizationResult authResult =
                Identity.getAuthorizationClient(this)
                    .getAuthorizationResultFromIntent(result.getData());
            notifyJs(callbackName, true, authResult.getAccessToken());
        } catch (ApiException e) {
            notifyJs(callbackName, false, "ApiException " + e.getStatusCode());
        } catch (Exception e) {
            notifyJs(callbackName, false, e.getMessage());
        }
    }

    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        // ─── Biometria: elérhető-e? ────────────────────────────────────────
        // ── Boot seen flag mentése SharedPreferences-be ───────────────────
        // Az onboarding végén (obFinish) hívja az index.html, hogy a következő
        // indításkor a MainActivity bootloader2.html-t töltsön be.
        @JavascriptInterface
        public void setBootSeen() {
            try {
                act.getSharedPreferences("chronos_prefs", android.content.Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("boot_seen", true)
                    .apply();
            } catch (Exception e) { /* ignore */ }
        }

        // ─── Haptikus visszajelzés: natív Android vibráció ──────────────
        // String paraméter: JS number → String konverzió elkerüli az int/double
        // típuskonverziós problémát @JavascriptInterface hívásoknál.
        // Boolean visszatérés: a JS oldal ez alapján tud továbbesni a
        // Capacitor Haptics / navigator.vibrate fallbackre, ha itt valami
        // miatt nem sikerült (pl. hiányzó android.permission.VIBRATE).
        @JavascriptInterface
        public boolean vibrate(final String msStr) {
            try {
                long ms = Long.parseLong(msStr.trim());
                if (ms <= 0 || ms > 1000) ms = 20;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    VibratorManager vm = (VibratorManager) act.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                    if (vm != null) {
                        Vibrator v = vm.getDefaultVibrator();
                        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                        return true;
                    }
                }
                @SuppressWarnings("deprecation")
                Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(ms);
                    }
                    return true;
                }
                android.util.Log.w("ChronosHaptic", "Vibrator service nem elérhető ezen az eszközön.");
                return false;
            } catch (Exception e) {
                // A leggyakoribb ok: hiányzik az android.permission.VIBRATE az
                // AndroidManifest.xml-ből → SecurityException itt, amit korábban
                // ez a catch ág csendben elnyelt (a JS pedig sikert feltételezett).
                android.util.Log.w("ChronosHaptic", "vibrate() hiba (ellenőrizd a VIBRATE permission-t a manifestben): " + e.getMessage());
                return false;
            }
        }

        // ─── Haptikus visszajelzés VIBRATE permission nélkül ──────────────
        // performHapticFeedback() a system haptic engine-t használja,
        // nem igényel android.permission.VIBRATE deklarációt az appban.
        // Kötelező UI szálon futni → runOnUiThread().
        @JavascriptInterface
        public void hapticFeedback(final String style) {
            act.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        android.view.View wv = act.getBridge().getWebView();
                        int fb;
                        if ("heavy".equals(style)) {
                            fb = HapticFeedbackConstants.LONG_PRESS;
                        } else if ("medium".equals(style)) {
                            // KEYBOARD_PRESS (API 27+) ha elérhető, különben LONG_PRESS
                            fb = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1)
                                 ? HapticFeedbackConstants.KEYBOARD_PRESS
                                 : HapticFeedbackConstants.LONG_PRESS;
                        } else {
                            fb = HapticFeedbackConstants.VIRTUAL_KEY; // light
                        }
                        wv.performHapticFeedback(fb,
                            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                    } catch (Exception e) {
                        android.util.Log.w("ChronosHaptic",
                            "hapticFeedback() hiba: " + e.getMessage());
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    int r = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                    if (r == BiometricManager.BIOMETRIC_SUCCESS) return true;
                }
                int r2 = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r2 == BiometricManager.BIOMETRIC_SUCCESS) return true;
                @SuppressWarnings("deprecation")
                int r3 = bm.canAuthenticate();
                return r3 == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        // ─── Biometria: prompt megjelenítése ───────────────────────────────
        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.notifyJs(callbackName, true, null);
                        }

                        @Override
                        public void onAuthenticationFailed() {}

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            act.notifyJs(callbackName, false, errString.toString());
                        }
                    }
                );

                try {
                    BiometricPrompt.PromptInfo info;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setAllowedAuthenticators(
                                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                            )
                            .build();
                    } else {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setNegativeButtonText("Mégse")
                            .build();
                    }
                    prompt.authenticate(info);
                } catch (Exception e) {
                    try {
                        BiometricPrompt.PromptInfo fallback =
                            new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setNegativeButtonText("Mégse")
                                .build();
                        prompt.authenticate(fallback);
                    } catch (Exception e2) {
                        act.notifyJs(callbackName, false, "unavailable");
                    }
                }
            });
        }

        // ─── Fájl megosztása: Base64 JSON → cache → Android Share Intent ──
        // Visszatér: "ok" ha sikerült, "error: <üzenet>" ha nem.
        // (Ez a "Küldés" útvonal — más alkalmazásnak adja át a fájlt.)
        @JavascriptInterface
        public String shareFile(final String filename, final String base64data) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                File cacheDir = act.getCacheDir();
                File outFile = new File(cacheDir, filename);
                FileOutputStream fos = new FileOutputStream(outFile);
                fos.write(bytes);
                fos.close();

                Uri fileUri = FileProvider.getUriForFile(
                    act,
                    act.getPackageName() + ".fileprovider",
                    outFile
                );

                final Uri shareUri = fileUri;
                act.runOnUiThread(() -> {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("application/json");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, filename);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(shareIntent, filename));
                });

                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        // ─── Fájl mentése "Mentés másként" dialógussal ─────────────────────
        // Megnyitja az Android natív fájlmentő dialógust (Storage Access
        // Framework), ahol a felhasználó kiválasztja a mappát és a fájlnevet,
        // pontosan úgy, mint PC-n. Az eredmény aszinkron érkezik a callback-en.
        @JavascriptInterface
        public void saveFileWithPicker(
                final String filename,
                final String base64data,
                final String callbackName) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                act.pendingSaveCallback = callbackName;
                act.pendingSaveBytes = bytes;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);

                act.runOnUiThread(() -> act.saveFileLauncher.launch(intent));
            } catch (Exception e) {
                act.notifyJs(callbackName, false, e.getMessage());
            }
        }

        // ─── Gmail OAuth access token kérése ────────────────────────────────
        // Első hívásnál megjelenik a Google fiókválasztó + hozzájárulás
        // dialógus (csak a "gmail.readonly" scope-ra, a TELJES postafiókra,
        // NEM csak bizonyos levelekre). Utána a Play Services a fiók
        // eszköz-szintű bejelentkezése alapján csendben, dialógus nélkül ad
        // friss (kb. 1 órás) access tokent — ezért ugyanezt a metódust kell
        // hívni a manuális szinkronnál ÉS a háttér-időzítőnél is.
        // A callback(success, accessTokenVagyHibaüzenet) formában tér vissza.
        // A Zeus Monatsjournal mindig ugyanarra a fix Gmail-fiókra érkezik,
        // ezért az AuthorizationRequest-et erre a fiókra pin-eljük. Így
        // SOHA nem jelenik meg a teljes fiókválasztó lista — legfeljebb
        // (első alkalommal) egy hozzájárulás-dialógus magára erre a fiókra.
        // FONTOS: a fiókot fel kell vinni a készülék Beállítások > Fiókok
        // listájába, különben az authorize() hibát ad.
        private static final String FIXED_GMAIL_ACCOUNT = "chronoseht@gmail.com";

        // ─── OTA Update: új app HTML letöltése és frissített www-mappa létrehozása ──
        // Ez a mappa (getFilesDir()/chronos_www) lesz a Capacitor WebView
        // következő induláskori gyökere (lásd onCreate() -> setServerBasePath()).
        // A bootloader.html-t is bemásoljuk ide az assets-ből, hogy a mappa
        // önállóan, az APK-tól függetlenül is teljes legyen induláskor.
        // A callbackName(success, message) formában tér vissza.

        // ── Verzió JSON lekérése Java-ból (megkerüli a CORS/auth problémát) ──
        // A bootloader ezt hívja a VERSION_URL lekéréséhez.
        // Visszatér: a fájl tartalma (JSON string), vagy hiba esetén null.
        // FONTOS: JavascriptInterface metódus – nem a főszálon hívjuk,
        // hanem a WebView JS szálán, ezért Thread-safe megvalósítás kell.
        @JavascriptInterface
        public String fetchVersionJson(final String url) {
            // Szinkron hívás – a JS engine saját szálán fut, nem a UI szálon,
            // ezért itt blokkolóan hívhatjuk a httpGet-et.
            try {
                String result = httpGet(url, null);
                if (result == null) return null;
                result = result.trim();
                // Ha JSON → kész
                if (result.startsWith("{") || result.startsWith("[")) return result;
                // Ha HTML → confirm token keresés
                java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("confirm=([^&\"<\\s]+)")
                    .matcher(result);
                if (m.find()) {
                    String sep = url.contains("?") ? "&" : "?";
                    String confirmUrl = url + sep + "confirm=" + m.group(1);
                    String confirmed = httpGet(confirmUrl, null);
                    if (confirmed != null && confirmed.trim().startsWith("{")) return confirmed.trim();
                }
                return null; // Auth hiba vagy ismeretlen válasz
            } catch (Exception e) {
                return null;
            }
        }

        @JavascriptInterface
        public void downloadAndInstallUpdate(final String downloadUrl, final String callbackName) {
            new Thread(() -> {
                try {
                    // 1. Letöltés – Google Drive vírusszűrő bypass
                    // Nagy fájloknál (~500KB+) a Drive nem adja vissza közvetlenül
                    // a tartalmat, hanem egy figyelmeztető HTML oldalt küld.
                    // A bypass: az első válaszból kiolvassuk a confirm token-t
                    // (vagy uuid-t), majd újra lekérjük a fájlt azzal a paraméterrel.
                    String html = driveDownload(downloadUrl);

                    if (html == null || html.trim().isEmpty()) throw new Exception("Empty response");
                    if (!html.contains("CHRONOS-VALID")) throw new Exception("A letöltött fájl nem érvényes Chronos HTML (hiányzó aláírás)");

                    // 2. Fájlba írás: getFilesDir()/chronos_www/index.html
                    //    (ugyanaz a mappa, amit onCreate() a setServerBasePath()-hoz használ)
                    java.io.File wwwDir = new java.io.File(act.getFilesDir(), "chronos_www");
                    if (!wwwDir.exists()) wwwDir.mkdirs();

                    java.io.File indexFile = new java.io.File(wwwDir, "index.html");
                    java.io.File tmpFile = new java.io.File(wwwDir, "index.html.tmp");
                    java.io.FileWriter fw = new java.io.FileWriter(tmpFile, false);
                    fw.write(html);
                    fw.flush();
                    fw.close();
                    // Atomikus csere: ha félbeszakadna az írás, a régi index.html érintetlen marad.
                    if (indexFile.exists()) indexFile.delete();
                    tmpFile.renameTo(indexFile);

                    // 3. bootloader.html + bootloader2.html bemásolása az assets-ből, ha még nincs ott
                    //    (csak első OTA frissítésnél kell, utána már a mappában van).
                    for (String blName : new String[]{"bootloader.html", "bootloader2.html"}) {
                        java.io.File blFile = new java.io.File(wwwDir, blName);
                        if (!blFile.exists()) {
                            try {
                                java.io.InputStream is = act.getAssets().open("public/" + blName);
                                java.io.FileOutputStream fos = new java.io.FileOutputStream(blFile);
                                byte[] buf = new byte[4096];
                                int n;
                                while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
                                is.close();
                                fos.close();
                            } catch (Exception copyErr) {
                                // Ha az assets útvonal eltér, az APK-ba sütött verzióból fut - nem blokkoló hiba.
                            }
                        }
                    }

                    // 4. Aktiváljuk a friss mappát: setServerBasePath() + Activity újraindítás.
                    //    A puszta reload() nem elég, mert a Bridge útvonal-felbontása
                    //    csak Activity (re)create-kor frissül megbízhatóan.
                    act.runOnUiThread(() -> {
                        act.notifyJs(callbackName, true, "installed");
                        act.getBridge().getWebView().postDelayed(() -> {
                            act.getBridge().setServerBasePath(wwwDir.getAbsolutePath());
                            act.recreate();
                        }, 500);
                    });

                } catch (Exception e) {
                    act.runOnUiThread(() ->
                        act.notifyJs(callbackName, false, e.getMessage())
                    );
                }
            }).start();
        }

        // ─── APK letöltése és telepítési intent indítása ─────────────────
        // A Drive-ról letölti az APK-t a cache-be, majd Android telepítő
        // intentet indít. A felhasználónak el kell fogadni a telepítést
        // (ez Android biztonsági követelmény, nem kerülhető meg).
        // Előfeltétel: AndroidManifest-ben REQUEST_INSTALL_PACKAGES engedély
        // és FileProvider bejegyezve (már megvan a shareFile()-hoz).
        // callbackName(false, hibaüzenet) ha letöltés sikertelen;
        // ha sikeres, az Android telepítő átveszi az irányítást.
        @JavascriptInterface
        public void downloadAndInstallApk(final String downloadUrl, final String callbackName) {
            new Thread(() -> {
                HttpURLConnection conn = null;
                java.io.InputStream inputStream = null;
                java.io.FileOutputStream fos = null;
                try {
                    // 1. Letöltés – Drive redirect kezelésével
                    URL url = new URL(downloadUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(120000);
                    conn.connect();

                    // Google Drive confirm redirect (nagy fájlok esetén)
                    int status = conn.getResponseCode();
                    if (status == HttpURLConnection.HTTP_MOVED_TEMP ||
                        status == HttpURLConnection.HTTP_MOVED_PERM ||
                        status == 307 || status == 308) {
                        String newUrl = conn.getHeaderField("Location");
                        conn.disconnect();
                        conn = (HttpURLConnection) new URL(newUrl).openConnection();
                        conn.setConnectTimeout(30000);
                        conn.setReadTimeout(120000);
                        conn.connect();
                    }

                    // 2. APK mentése cache-be
                    java.io.File cacheDir = act.getCacheDir();
                    java.io.File apkFile = new java.io.File(cacheDir, "chronos_update.apk");
                    if (apkFile.exists()) apkFile.delete();

                    inputStream = conn.getInputStream();
                    fos = new java.io.FileOutputStream(apkFile);
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                    }
                    fos.flush();
                    fos.close();
                    inputStream.close();
                    conn.disconnect();

                    if (apkFile.length() < 1000) {
                        throw new Exception("Letöltött fájl túl kicsi: " + apkFile.length() + " byte");
                    }

                    // 3. Telepítési intent indítása UI szálon
                    final java.io.File finalApk = apkFile;
                    act.runOnUiThread(() -> {
                        try {
                            Uri apkUri = FileProvider.getUriForFile(
                                act,
                                act.getPackageName() + ".fileprovider",
                                finalApk
                            );
                            Intent installIntent = new Intent(Intent.ACTION_VIEW);
                            installIntent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                            installIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            installIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            act.startActivity(installIntent);
                            // Callback: letöltés OK, telepítő elindul
                            act.notifyJs(callbackName, true, "installer_started");
                        } catch (Exception e) {
                            act.notifyJs(callbackName, false, "intent_error: " + e.getMessage());
                        }
                    });

                } catch (Exception e) {
                    if (fos != null) try { fos.close(); } catch (Exception ignored) {}
                    if (inputStream != null) try { inputStream.close(); } catch (Exception ignored) {}
                    if (conn != null) conn.disconnect();
                    act.runOnUiThread(() ->
                        act.notifyJs(callbackName, false, e.getMessage())
                    );
                }
            }).start();
        }

        @JavascriptInterface
        public void requestGmailAuth(final String callbackName) {
            try {
                Scope gmailScope = new Scope("https://www.googleapis.com/auth/gmail.readonly");
                Account fixedAccount = new Account(FIXED_GMAIL_ACCOUNT, "com.google");
                AuthorizationRequest authRequest = AuthorizationRequest.builder()
                    .setRequestedScopes(Collections.singletonList(gmailScope))
                    .setAccount(fixedAccount)
                    .build();

                Identity.getAuthorizationClient(act)
                    .authorize(authRequest)
                    .addOnSuccessListener(authResult -> {
                        if (authResult.hasResolution()) {
                            // Még nincs hozzájárulás (vagy lejárt) → dialógus kell
                            act.pendingGmailAuthCallback = callbackName;
                            try {
                                IntentSenderRequest senderRequest =
                                    new IntentSenderRequest.Builder(
                                        authResult.getPendingIntent().getIntentSender()
                                    ).build();
                                act.runOnUiThread(() -> act.gmailAuthLauncher.launch(senderRequest));
                            } catch (Exception e) {
                                act.pendingGmailAuthCallback = null;
                                act.notifyJs(callbackName, false, e.getMessage());
                            }
                        } else {
                            // Már jóváhagyott fiók → token azonnal, dialógus nélkül
                            act.notifyJs(callbackName, true, authResult.getAccessToken());
                        }
                    })
                    .addOnFailureListener(e ->
                        act.notifyJs(callbackName, false, e.getMessage())
                    );
            } catch (Exception e) {
                act.notifyJs(callbackName, false, e.getMessage());
            }
        }
    }
}
