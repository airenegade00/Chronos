package com.chronos.app;

import android.app.Activity;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

public class MainActivity extends BridgeActivity {

    // Folyamatban lévő mentés: callback-név + várakozó adat, amíg a felhasználó
    // a "Mentés másként" dialógusban kiválasztja a célt.
    private String pendingSaveCallback = null;
    private byte[] pendingSaveBytes = null;

    private ActivityResultLauncher<Intent> saveFileLauncher;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );

        // Regisztráljuk a "Mentés másként" dialógus eredmény-kezelőjét.
        saveFileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    handleSaveFileResult(result);
                }
            }
        );
    }

    private void notifyJs(final String callbackName, final boolean success, final String message) {
        final String safeMsg = (message == null ? "" : message)
            .replace("\\", "\\\\")
            .replace("'", "\\'");
        runOnUiThread(() ->
            getBridge().getWebView().evaluateJavascript(
                "window['" + callbackName + "'] && window['" + callbackName + "'](" +
                (success ? "true" : "false") + ", '" + safeMsg + "');",
                null
            )
        );
    }

    private void handleSaveFileResult(ActivityResult result) {
        final String callbackName = pendingSaveCallback;
        final byte[] bytes = pendingSaveBytes;
        pendingSaveCallback = null;
        pendingSaveBytes = null;

        if (callbackName == null) return;

        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            // Felhasználó megszakította a mentést (pl. "Mégse")
            notifyJs(callbackName, false, "cancelled");
            return;
        }

        Uri targetUri = result.getData().getData();
        if (targetUri == null) {
            notifyJs(callbackName, false, "no_uri");
            return;
        }

        try (OutputStream os = getContentResolver().openOutputStream(targetUri)) {
            if (os == null) throw new Exception("openOutputStream returned null");
            os.write(bytes);
            os.flush();
            notifyJs(callbackName, true, null);
        } catch (Exception e) {
            notifyJs(callbackName, false, e.getMessage());
        }
    }

    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        // ─── Biometria: elérhető-e? ────────────────────────────────────────
        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    int r = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                    if (r == BiometricManager.BIOMETRIC_SUCCESS) return true;
                }
                int r2 = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r2 == BiometricManager.BIOMETRIC_SUCCESS) return true;
                @SuppressWarnings("deprecation")
                int r3 = bm.canAuthenticate();
                return r3 == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        // ─── Biometria: prompt megjelenítése ───────────────────────────────
        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.notifyJs(callbackName, true, null);
                        }

                        @Override
                        public void onAuthenticationFailed() {}

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            act.notifyJs(callbackName, false, errString.toString());
                        }
                    }
                );

                try {
                    BiometricPrompt.PromptInfo info;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setAllowedAuthenticators(
                                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                            )
                            .build();
                    } else {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setNegativeButtonText("Mégse")
                            .build();
                    }
                    prompt.authenticate(info);
                } catch (Exception e) {
                    try {
                        BiometricPrompt.PromptInfo fallback =
                            new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setNegativeButtonText("Mégse")
                                .build();
                        prompt.authenticate(fallback);
                    } catch (Exception e2) {
                        act.notifyJs(callbackName, false, "unavailable");
                    }
                }
            });
        }

        // ─── Fájl megosztása: Base64 JSON → cache → Android Share Intent ──
        // Visszatér: "ok" ha sikerült, "error: <üzenet>" ha nem.
        // (Ez a "Küldés" útvonal — más alkalmazásnak adja át a fájlt.)
        @JavascriptInterface
        public String shareFile(final String filename, final String base64data) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                File cacheDir = act.getCacheDir();
                File outFile = new File(cacheDir, filename);
                FileOutputStream fos = new FileOutputStream(outFile);
                fos.write(bytes);
                fos.close();

                Uri fileUri = FileProvider.getUriForFile(
                    act,
                    act.getPackageName() + ".fileprovider",
                    outFile
                );

                final Uri shareUri = fileUri;
                act.runOnUiThread(() -> {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("application/json");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, filename);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(shareIntent, filename));
                });

                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        // ─── Fájl mentése "Mentés másként" dialógussal ─────────────────────
        // Megnyitja az Android natív fájlmentő dialógust (Storage Access
        // Framework), ahol a felhasználó kiválasztja a mappát és a fájlnevet,
        // pontosan úgy, mint PC-n. Az eredmény aszinkron érkezik a callback-en.
        @JavascriptInterface
        public void saveFileWithPicker(
                final String filename,
                final String base64data,
                final String callbackName) {
            try {
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                act.pendingSaveCallback = callbackName;
                act.pendingSaveBytes = bytes;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);

                act.runOnUiThread(() -> act.saveFileLauncher.launch(intent));
            } catch (Exception e) {
                act.notifyJs(callbackName, false, e.getMessage());
            }
        }
    }
}
