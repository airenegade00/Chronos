package com.chronos.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.Executor;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(
            new ChronosBioBridge(this), "AndroidBridge"
        );
    }

    public class ChronosBioBridge {
        private final MainActivity act;

        ChronosBioBridge(MainActivity a) { act = a; }

        // ─── Biometria: elérhető-e? ────────────────────────────────────────
        @JavascriptInterface
        public boolean isBiometricAvailable() {
            try {
                BiometricManager bm = BiometricManager.from(act);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    int r = bm.canAuthenticate(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK |
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    );
                    if (r == BiometricManager.BIOMETRIC_SUCCESS) return true;
                }
                int r2 = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (r2 == BiometricManager.BIOMETRIC_SUCCESS) return true;
                @SuppressWarnings("deprecation")
                int r3 = bm.canAuthenticate();
                return r3 == BiometricManager.BIOMETRIC_SUCCESS;
            } catch (Exception e) {
                return false;
            }
        }

        // ─── Biometria: prompt megjelenítése ───────────────────────────────
        @JavascriptInterface
        public void showBiometricPrompt(
                final String title,
                final String subtitle,
                final String callbackName) {

            act.runOnUiThread(() -> {
                Executor executor = ContextCompat.getMainExecutor(act);

                BiometricPrompt prompt = new BiometricPrompt(act, executor,
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(
                                BiometricPrompt.AuthenticationResult result) {
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](true, null);",
                                    null
                                )
                            );
                        }

                        @Override
                        public void onAuthenticationFailed() {}

                        @Override
                        public void onAuthenticationError(
                                int errorCode, CharSequence errString) {
                            final String safe = errString.toString()
                                .replace("\\", "\\\\")
                                .replace("'", "\\'");
                            act.getBridge().getWebView().post(() ->
                                act.getBridge().getWebView().evaluateJavascript(
                                    "window['" + callbackName + "'] && " +
                                    "window['" + callbackName + "'](false, '" + safe + "');",
                                    null
                                )
                            );
                        }
                    }
                );

                try {
                    BiometricPrompt.PromptInfo info;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setAllowedAuthenticators(
                                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                                BiometricManager.Authenticators.DEVICE_CREDENTIAL
                            )
                            .build();
                    } else {
                        info = new BiometricPrompt.PromptInfo.Builder()
                            .setTitle(title)
                            .setSubtitle(subtitle)
                            .setNegativeButtonText("Mégse")
                            .build();
                    }
                    prompt.authenticate(info);
                } catch (Exception e) {
                    try {
                        BiometricPrompt.PromptInfo fallback =
                            new BiometricPrompt.PromptInfo.Builder()
                                .setTitle(title)
                                .setNegativeButtonText("Mégse")
                                .build();
                        prompt.authenticate(fallback);
                    } catch (Exception e2) {
                        act.getBridge().getWebView().post(() ->
                            act.getBridge().getWebView().evaluateJavascript(
                                "window['" + callbackName + "'] && " +
                                "window['" + callbackName + "'](false, 'unavailable');",
                                null
                            )
                        );
                    }
                }
            });
        }

        // ─── Fájl megosztása: Base64 JSON → cache → Android Share Intent ──
        // Visszatér: "ok" ha sikerült, "error: <üzenet>" ha nem.
        @JavascriptInterface
        public String shareFile(final String filename, final String base64data) {
            try {
                // 1. Base64 dekódolás
                byte[] bytes = Base64.decode(base64data, Base64.DEFAULT);

                // 2. Fájl írása az app cache könyvtárába
                File cacheDir = act.getCacheDir();
                File outFile = new File(cacheDir, filename);
                FileOutputStream fos = new FileOutputStream(outFile);
                fos.write(bytes);
                fos.close();

                // 3. FileProvider URI létrehozása (Android 7+ biztonságos fájl-megosztás)
                Uri fileUri = FileProvider.getUriForFile(
                    act,
                    act.getPackageName() + ".fileprovider",
                    outFile
                );

                // 4. Share Intent indítása a UI szálon
                final Uri shareUri = fileUri;
                act.runOnUiThread(() -> {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("application/json");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, shareUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, filename);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(shareIntent, filename));
                });

                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }
    }
}
