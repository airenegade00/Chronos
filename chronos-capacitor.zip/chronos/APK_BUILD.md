# Chronos APK (Capacitor) — build útmutató

## Mi változott (v1.0.1.8+)

A webapp **moduláris**: `www/index.html` + `www/css/` + `www/js/`.
Ezért **új APK build** kell; a régi „csak index.html OTA” nem elég a CSS/JS fájlokhoz.

## Könyvtár

```
chronos/
  www/
    index.html          ← fő app (script src → js/)
    css/chronos.css
    css/chronos-zeuswidget.css
    js/chronos-*.js
    bootloader.html     ← indulás + OTA check
    bootloader2.html    ← PIN/bio indítás
    splash.html
    version.json
  MainActivity.java
  capacitor.config.json
  ...
```

## Build lépések

1. Másold a `www/` tartalmát a Capacitor Android projekt `android/app/src/main/assets/public/` (vagy `npx cap sync`) alá.
2. Android Studio → Build → Generate Signed Bundle / APK.
3. Az APK-t töltsd fel (Drive / Hosting), és írd be a Firebase `version.json`-ba:

```json
{
  "version": "1.0.1.8",
  "pwaUrl": "https://chronos-b8002.web.app/",
  "url": "https://chronos-b8002.web.app/",
  "apkUrl": "https://...közvetlen-apk-link..."
}
```

## Fontos URL-ek

| Cél | URL |
|-----|-----|
| PWA / version.json | `https://chronos-b8002.web.app/version.json` |
| Bootloader VERSION_URL | ugyanez (már beállítva) |
| Firebase Auth domain | `chronos-b8002.firebaseapp.com` |

## Szinkron APK ↔ PWA

Mindkettő Firebase Auth + Firestore (`chronos_users/{uid}`).
Ugyanazzal a fiókkal kell bejelentkezni. Az APK mentés azonnali flush-t használ.

## OTA megjegyzés

A `MainActivity.downloadAndInstallUpdate` jelenleg **egy** `index.html` fájlt ír.
Moduláris appnál frissítéshez **új APK** ajánlott (vagy bővítsd a Java-t zip kicsomagolásra).

A bootloader a `version.json` `htmlUrl` / `url` mezőjét használja HTML OTA-hoz — ezt hagyd üresen, ha csak APK-frissítést akarsz (`apkUrl`).
