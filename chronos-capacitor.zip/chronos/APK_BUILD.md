# Chronos APK (Capacitor) — build útmutató

## Mi változott (v1.0.1.8+)

A webapp **moduláris**: `www/index.html` + `www/css/` + `www/js/`.
Ezért **új APK build** kell; a régi „csak index.html OTA” nem elég a CSS/JS fájlokhoz.

## Könyvtár

```
chronos/
  www/
    index.html          ← fő app (script src → js/)
    css/chronos.css
    css/chronos-zeuswidget.css
    js/chronos-*.js
    bootloader.html     ← indulás + OTA check
    bootloader2.html    ← PIN/bio indítás
    splash.html
    version.json
  MainActivity.java
  capacitor.config.json
  ...
```

## Build lépések

1. Másold a `www/` tartalmát a Capacitor Android projekt `android/app/src/main/assets/public/` (vagy `npx cap sync`) alá.
2. Android Studio → Build → Generate Signed Bundle / APK.
3. Az APK-t töltsd fel (Drive / Hosting), és írd be a Firebase `version.json`-ba:

```json
{
  "version": "1.0.1.8",
  "pwaUrl": "https://chronos-b8002.web.app/",
  "url": "https://chronos-b8002.web.app/",
  "apkUrl": "https://...közvetlen-apk-link..."
}
```

## Fontos URL-ek

| Cél | URL |
|-----|-----|
| PWA / version.json | `https://chronos-b8002.web.app/version.json` |
| Bootloader VERSION_URL | ugyanez (már beállítva) |
| Firebase Auth domain | `chronos-b8002.firebaseapp.com` |

## Szinkron APK ↔ PWA

Mindkettő Firebase Auth + Firestore (`chronos_users/{uid}`).
Ugyanazzal a fiókkal kell bejelentkezni. Az APK mentés azonnali flush-t használ.

## OTA megjegyzés

A `MainActivity.downloadAndInstallUpdate` jelenleg **egy** `index.html` fájlt ír.
Moduláris appnál frissítéshez **új APK** ajánlott (vagy bővítsd a Java-t zip kicsomagolásra).

A bootloader a `version.json` `htmlUrl` / `url` mezőjét használja HTML OTA-hoz — ezt hagyd üresen, ha csak APK-frissítést akarsz (`apkUrl`).

## Stílus nélküli / "szétesett" app javítása (v1.0.1.9+)

Ok: egy korábbi OTA a belső tárolóba (`files/chronos_www/`) csak egy `index.html`-t írt,
és a WebView onnan szolgált ki → a `css/` és `js/` hiányzott.
`MainActivity.java` most:
- új APK telepítésekor törli a régi `chronos_www` mappát,
- az OTA-mappát csak akkor használja, ha `css/chronos.css` és `js/chronos-app.js` is benne van.

Az új APK-t a régire lehet telepíteni, adattörlés nem kell (a mentett adatok a WebView tárolóban maradnak).

## Google belépés az APK-ban (natív, v1.0.1.9+)

Az Android WebView-ban (`https://app` origin) a `signInWithPopup` nem működik
("The requested action is invalid."), ezért APK-ban a natív
`@capacitor-firebase/authentication` plugin adja a Google ID tokent, a web SDK pedig
`signInWithCredential`-lel lép be (`www/js/chronos-cloud.js`). Az Apple gomb APK-ban rejtett.

Egyszeri beállítás:
1. Firebase Console → Android app `com.chronos.app` → add hozzá az APK aláíró kulcs
   **SHA-1 + SHA-256** ujjlenyomatát (debug és release), töltsd le az **új** `google-services.json`-t
   → `android/app/google-services.json`. Authentication → Google: Enabled.
2. `npm install` → `npx cap sync android` → új APK (OTA-val nem megy, natív plugin).
3. Hibakeresés: a Google gomb hibája a piros hibaüzenet végén szögletes zárójelben jelenik meg:
   `auth/native-plugin-missing` = a Capacitor bridge nem elérhető;
   `UNIMPLEMENTED ... not implemented on android` = a plugin nincs az APK-ban (npm install + cap sync + új build);
   `12501` / `DEVELOPER_ERROR` / "canceled" / "no credential" = hiányzó vagy rossz SHA-1,
   vagy a `google-services.json` az SHA hozzáadása előtti.
