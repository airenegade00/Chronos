/* Chronos.Onboarding — első-indítás varázsló (Fázis 1)
   window.ob*, window._ob*
*/
'use strict';

(function() {
  var _obStep = 0;
  var _obSelectedLang = null;

  function obGetLang() {
    try {
      const raw = localStorage.getItem('chronos_10');
      if (raw) return JSON.parse(raw).currentLang || 'hu';
    } catch(e) {}
    return (navigator.language || 'hu').substring(0, 2);
  }

  window.obSelectLang = function(lang) {
    _obSelectedLang = lang;
    // Highlight selected
    document.querySelectorAll('.ob-lang-btn').forEach(b => b.classList.remove('ob-sel'));
    const btn = document.getElementById('oblang_' + lang);
    if (btn) btn.classList.add('ob-sel');
    // Enable next button
    const nextBtn = document.getElementById('obLangNextBtn');
    if (nextBtn) {
      nextBtn.style.opacity = '1';
      nextBtn.style.pointerEvents = 'auto';
      // Update button text
      const texts = {de:'Weiter →',hu:'Tovább →',en:'Next →',ro:'Înainte →',tr:'İleri →',bs:'Dalje →',ru:'Далее →',uk:'Далі →',el:'Επόμενο →',ar:'التالي ←'};
      nextBtn.textContent = texts[lang] || 'Next →';
    }
    // Apply language immediately to rest of onboarding + mentés azonnal
    if (typeof setLanguage === 'function') {
      setLanguage(lang);
      if (typeof saveState === 'function') saveState();
    }
    obApplyStrings(lang);
  };

  var OB_STRINGS = {
    hu: { langTitle:'Válassz nyelvet', langSubtitle:'Válassz nyelvet a folytatáshoz', splashIntro:'Ennyit kell tudnod a kezdéshez – a többit elintézi az app.', splashTag:'Műszak · Bér · Statisztika', startBtn:'Kezdjük el →', f1t:'Műszakok & Naptár', f1d:'Rögzítsd a műszakjaidat a naptárban, állíts be ismétlődő mintát, és exportáld bármikor egy érintéssel.', f2t:'Automatikus bérszámítás', f2d:'A felvitt műszakokból automatikusan számolja a bért, az éjszakai és hétvégi pótlékkal együtt — neked nem kell.', f3t:'Havi statisztikák', f3d:'Egy pillantás, és látod az órákat, a bevételt és a havi trendeket — grafikonon, számolás nélkül.', profileTitle:'Alapadatok', profileSubtitle:'Opcionális – bármikor megváltoztatható a beállításokban', nameLabel:'Neved (ahogy a beosztáson szerepel)', salaryLabel:'Alapbér / hó', groupLabel:'Műszak csoport (rotáció)', groupPlaceholder:'Csoport azonosító (pl. 1.1_H9G2, 210)', personalNrLabel:'Personal Nr. (opcionális, Zeus Monatsjournalból)', personalNrPlaceholder:'pl. 9876', skipBtn:'Kihagyás', nextBtn:'Tovább →', pinTitle:'Adatvédelem', pinText:'Védd a bér- és műszakadataidat', pinOpt1T:'PIN védelem', pinOpt1D:'4 jegyű kód indításkor', pinOpt2T:'Biometria', pinOpt2D:'Ujjlenyomat / arcfelismerés', pinOpt3T:'Nincs védelem', pinOpt3D:'Közvetlen belépés az appba', finishBtn:'Kész – App indítása 🚀', nextLang:'Tovább →', accountTitle:'Fiók létrehozása', accountSubtitle:'A felhő-szinkronhoz kell — csak te férsz hozzá az adataidhoz', emailLabel:'E-mail cím', emailPlaceholder:'nev@example.com', passwordLabel:'Jelszó', passwordPlaceholder:'min. 6 karakter', accountRegisterBtn:'Regisztráció', accountLoginBtn:'Bejelentkezés', accountToggleToLogin:'Már van fiókom – Bejelentkezés', accountToggleToRegister:'Nincs még fiókom – Regisztráció', accountErrMissing:'Add meg az e-mail címet és a jelszót.', accountErrInUse:'Ez az e-mail cím már regisztrálva van – váltás Bejelentkezésre?', accountErrInvalidEmail:'Érvénytelen e-mail cím.', accountErrWeakPw:'A jelszónak legalább 6 karakteresnek kell lennie.', accountErrWrongPw:'Hibás e-mail cím vagy jelszó.', accountErrNotFound:'Nincs ilyen fiók – váltás Regisztrációra?', accountErrTooMany:'Túl sok próbálkozás, próbáld később.', accountErrGeneric:'Hiba történt, próbáld újra.', passwordLabel2:'Jelszó megerősítése', accountErrPwMismatch:'A két jelszó nem egyezik.', accountOrDivider:'vagy', accountGoogleBtn:'Folytatás Google-lel', accountAppleBtn:'Folytatás Apple ID-val' },
    de: { langTitle:'Sprache wählen', langSubtitle:'Wähle eine Sprache, um fortzufahren', splashIntro:'Das ist alles, was du für den Start wissen musst – den Rest erledigt die App.', splashTag:'Schicht · Gehalt · Statistik', startBtn:'Los geht\'s →', f1t:'Schichten & Kalender', f1d:'Erfasse deine Schichten im Kalender, richte wiederkehrende Muster ein und exportiere sie jederzeit mit einem Tippen.', f2t:'Automatische Lohnberechnung', f2d:'Aus den eingetragenen Schichten berechnet die App automatisch den Lohn – mit Nacht- und Wochenendzuschlägen, ohne dass du etwas tun musst.', f3t:'Monatsstatistiken', f3d:'Auf einen Blick siehst du Stunden, Einnahmen und monatliche Trends – im Diagramm, ohne zu rechnen.', profileTitle:'Grunddaten', profileSubtitle:'Optional – jederzeit in den Einstellungen änderbar', nameLabel:'Dein Name (wie im Dienstplan)', salaryLabel:'Grundlohn / Monat', groupLabel:'Schichtgruppe (Rotation)', groupPlaceholder:'Gruppen-ID (z.B. 1.1_H9G2, 210)', personalNrLabel:'Personal Nr. (optional, aus Zeus Monatsjournal)', personalNrPlaceholder:'z.B. 9876', skipBtn:'Überspringen', nextBtn:'Weiter →', pinTitle:'Datenschutz', pinText:'Schütze deine Lohn- und Schichtdaten', pinOpt1T:'PIN-Schutz', pinOpt1D:'4-stelliger Code beim Start', pinOpt2T:'Biometrie', pinOpt2D:'Fingerabdruck / Gesichtserkennung', pinOpt3T:'Kein Schutz', pinOpt3D:'Direkt zur App', finishBtn:'Fertig – App starten 🚀', nextLang:'Weiter →', accountTitle:'Konto erstellen', accountSubtitle:'Für die Cloud-Synchronisation nötig — nur du hast Zugriff auf deine Daten', emailLabel:'E-Mail-Adresse', emailPlaceholder:'name@beispiel.de', passwordLabel:'Passwort', passwordPlaceholder:'min. 6 Zeichen', accountRegisterBtn:'Registrieren', accountLoginBtn:'Anmelden', accountToggleToLogin:'Ich habe schon ein Konto – Anmelden', accountToggleToRegister:'Noch kein Konto – Registrieren', accountErrMissing:'Bitte E-Mail-Adresse und Passwort eingeben.', accountErrInUse:'Diese E-Mail ist bereits registriert – zur Anmeldung wechseln?', accountErrInvalidEmail:'Ungültige E-Mail-Adresse.', accountErrWeakPw:'Das Passwort muss mindestens 6 Zeichen haben.', accountErrWrongPw:'Falsche E-Mail-Adresse oder falsches Passwort.', accountErrNotFound:'Kein Konto gefunden – zur Registrierung wechseln?', accountErrTooMany:'Zu viele Versuche, bitte später erneut versuchen.', accountErrGeneric:'Ein Fehler ist aufgetreten, bitte erneut versuchen.', passwordLabel2:'Passwort bestätigen', accountErrPwMismatch:'Die beiden Passwörter stimmen nicht überein.', accountOrDivider:'oder', accountGoogleBtn:'Weiter mit Google', accountAppleBtn:'Weiter mit Apple' },
    en: { langTitle:'Choose language', langSubtitle:'Choose a language to continue', splashIntro:'This is all you need to know to get started – the app handles the rest.', splashTag:'Shift · Salary · Stats', startBtn:'Let\'s start →', f1t:'Shifts & Calendar', f1d:'Log your shifts in the calendar, set a recurring pattern, and export anytime with a single tap.', f2t:'Automatic Salary Calculation', f2d:'The app automatically calculates your salary from entered shifts – including night and weekend bonuses, no manual work needed.', f3t:'Monthly Statistics', f3d:'At a glance you see hours, income and monthly trends – on a chart, without any calculations.', profileTitle:'Basic Info', profileSubtitle:'Optional – changeable anytime in Settings', nameLabel:'Your name (as on the schedule)', salaryLabel:'Base salary / month', groupLabel:'Shift group (rotation)', groupPlaceholder:'Group ID (e.g. 1.1_H9G2, 210)', personalNrLabel:'Personal No. (optional, from Zeus monthly report)', personalNrPlaceholder:'e.g. 9876', skipBtn:'Skip', nextBtn:'Next →', pinTitle:'Privacy', pinText:'Protect your salary and shift data', pinOpt1T:'PIN protection', pinOpt1D:'4-digit code on start', pinOpt2T:'Biometrics', pinOpt2D:'Fingerprint / face recognition', pinOpt3T:'No protection', pinOpt3D:'Open app directly', finishBtn:'Done – Start app 🚀', nextLang:'Next →', accountTitle:'Create account', accountSubtitle:'Needed for cloud sync — only you can access your data', emailLabel:'Email address', emailPlaceholder:'name@example.com', passwordLabel:'Password', passwordPlaceholder:'min. 6 characters', accountRegisterBtn:'Register', accountLoginBtn:'Log in', accountToggleToLogin:'Already have an account – Log in', accountToggleToRegister:'No account yet – Register', accountErrMissing:'Please enter an email address and password.', accountErrInUse:'This email is already registered – switch to login?', accountErrInvalidEmail:'Invalid email address.', accountErrWeakPw:'Password must be at least 6 characters.', accountErrWrongPw:'Wrong email address or password.', accountErrNotFound:'No such account found – switch to register?', accountErrTooMany:'Too many attempts, please try again later.', accountErrGeneric:'An error occurred, please try again.', passwordLabel2:'Confirm password', accountErrPwMismatch:'The passwords do not match.', accountOrDivider:'or', accountGoogleBtn:'Continue with Google', accountAppleBtn:'Continue with Apple' },
    ro: { langTitle:'Alege limba', langSubtitle:'Alege o limbă pentru a continua', splashIntro:'Asta e tot ce trebuie să știi pentru start – restul îl face aplicația.', splashTag:'Tură · Salariu · Statistici', startBtn:'Să începem →', f1t:'Ture & Calendar', f1d:'Înregistrează turele în calendar, setează un model recurent și exportă oricând cu o singură atingere.', f2t:'Calcul automat salariu', f2d:'Aplicația calculează automat salariul din turele introduse – cu sporuri de noapte și weekend, fără efort din partea ta.', f3t:'Statistici lunare', f3d:'Dintr-o privire vezi ore, venituri și tendințe lunare – pe grafic, fără calcule.', profileTitle:'Date de bază', profileSubtitle:'Opțional – modificabil oricând în Setări', nameLabel:'Numele tău (ca în program)', salaryLabel:'Salariu de bază / lună', groupLabel:'Grupă de tură (rotație)', groupPlaceholder:'ID grupă (ex. 1.1_H9G2, 210)', personalNrLabel:'Nr. Personal (opțional, din Zeus jurnal lunar)', personalNrPlaceholder:'ex. 9876', skipBtn:'Omite', nextBtn:'Înainte →', pinTitle:'Confidențialitate', pinText:'Protejează datele tale de salariu și ture', pinOpt1T:'Protecție PIN', pinOpt1D:'Cod 4 cifre la pornire', pinOpt2T:'Biometric', pinOpt2D:'Amprentă / recunoaștere facială', pinOpt3T:'Fără protecție', pinOpt3D:'Acces direct la aplicație', finishBtn:'Gata – Pornire aplicație 🚀', nextLang:'Înainte →', accountTitle:'Creează cont', accountSubtitle:'Necesar pentru sincronizarea cloud — doar tu ai acces la datele tale', emailLabel:'Adresă de e-mail', emailPlaceholder:'nume@exemplu.ro', passwordLabel:'Parolă', passwordPlaceholder:'min. 6 caractere', accountRegisterBtn:'Înregistrare', accountLoginBtn:'Autentificare', accountToggleToLogin:'Am deja un cont – Autentificare', accountToggleToRegister:'Nu am cont – Înregistrare', accountErrMissing:'Introdu adresa de e-mail și parola.', accountErrInUse:'Acest e-mail este deja înregistrat – treci la autentificare?', accountErrInvalidEmail:'Adresă de e-mail nevalidă.', accountErrWeakPw:'Parola trebuie să aibă minim 6 caractere.', accountErrWrongPw:'E-mail sau parolă greșită.', accountErrNotFound:'Nu există un astfel de cont – treci la înregistrare?', accountErrTooMany:'Prea multe încercări, încearcă mai târziu.', accountErrGeneric:'A apărut o eroare, încearcă din nou.', passwordLabel2:'Confirmă parola', accountErrPwMismatch:'Parolele nu coincid.', accountOrDivider:'sau', accountGoogleBtn:'Continuă cu Google', accountAppleBtn:'Continuă cu Apple' },
    tr: { langTitle:'Dil seçin', langSubtitle:'Devam etmek için bir dil seçin', splashIntro:'Başlamak için bilmen gereken tek şey bu – gerisini uygulama halleder.', splashTag:'Vardiya · Maaş · İstatistik', startBtn:'Başlayalım →', f1t:'Vardiyalar & Takvim', f1d:'Vardiyalarını takvime kaydet, tekrarlayan bir düzen oluştur ve tek dokunuşla istediğinde dışa aktar.', f2t:'Otomatik Maaş Hesaplama', f2d:'Uygulama, girilen vardiyalardan maaşı otomatik hesaplar – gece ve hafta sonu primleriyle birlikte, hiçbir şey yapman gerekmez.', f3t:'Aylık İstatistikler', f3d:'Bir bakışta saatleri, geliri ve aylık trendleri görürsün – grafikte, hesap yapmadan.', profileTitle:'Temel Bilgiler', profileSubtitle:'İsteğe bağlı – Ayarlardan her zaman değiştirilebilir', nameLabel:'Adınız (programda göründüğü gibi)', salaryLabel:'Temel maaş / ay', groupLabel:'Vardiya grubu (rotasyon)', groupPlaceholder:'Grup kimliği (örn. 1.1_H9G2, 210)', personalNrLabel:'Personel No. (isteğe bağlı, Zeus aylık raporundan)', personalNrPlaceholder:'örn. 9876', skipBtn:'Atla', nextBtn:'İleri →', pinTitle:'Gizlilik', pinText:'Maaş ve vardiya verilerinizi koruyun', pinOpt1T:'PIN koruması', pinOpt1D:'Başlangıçta 4 haneli kod', pinOpt2T:'Biyometrik', pinOpt2D:'Parmak izi / yüz tanıma', pinOpt3T:'Koruma yok', pinOpt3D:'Doğrudan uygulamaya gir', finishBtn:'Tamam – Uygulamayı başlat 🚀', nextLang:'İleri →', accountTitle:'Hesap oluştur', accountSubtitle:'Bulut senkronizasyonu için gerekli — verilerine yalnızca sen erişebilirsin', emailLabel:'E-posta adresi', emailPlaceholder:'isim@ornek.com', passwordLabel:'Şifre', passwordPlaceholder:'en az 6 karakter', accountRegisterBtn:'Kayıt ol', accountLoginBtn:'Giriş yap', accountToggleToLogin:'Zaten hesabım var – Giriş yap', accountToggleToRegister:'Hesabım yok – Kayıt ol', accountErrMissing:'Lütfen e-posta adresi ve şifre girin.', accountErrInUse:'Bu e-posta zaten kayıtlı – girişe geçilsin mi?', accountErrInvalidEmail:'Geçersiz e-posta adresi.', accountErrWeakPw:'Şifre en az 6 karakter olmalı.', accountErrWrongPw:'Yanlış e-posta veya şifre.', accountErrNotFound:'Böyle bir hesap yok – kayda geçilsin mi?', accountErrTooMany:'Çok fazla deneme, lütfen daha sonra tekrar dene.', accountErrGeneric:'Bir hata oluştu, lütfen tekrar dene.', passwordLabel2:'Şifreyi onayla', accountErrPwMismatch:'Şifreler eşleşmiyor.', accountOrDivider:'veya', accountGoogleBtn:'Google ile devam et', accountAppleBtn:'Apple ile devam et' },
    el: { langTitle:'Επιλογή γλώσσας', langSubtitle:'Επιλέξτε γλώσσα για να συνεχίσετε', splashIntro:'Αυτό είναι το μόνο που χρειάζεται να ξέρεις για αρχή – τα υπόλοιπα τα αναλαμβάνει η εφαρμογή.', splashTag:'Βάρδια · Μισθός · Στατιστικά', startBtn:'Ας ξεκινήσουμε →', f1t:'Βάρδιες & Ημερολόγιο', f1d:'Καταγράψτε τις βάρδιές σας στο ημερολόγιο, ορίστε επαναλαμβανόμενο μοτίβο και εξαγάγετε ανά πάσα στιγμή με ένα άγγιγμα.', f2t:'Αυτόματος υπολογισμός μισθού', f2d:'Η εφαρμογή υπολογίζει αυτόματα τον μισθό από τις καταχωρημένες βάρδιες – με επιδόματα νύχτας και Σαββατοκύριακου, χωρίς καμία ενέργεια.', f3t:'Μηνιαία στατιστικά', f3d:'Με μια ματιά βλέπετε ώρες, έσοδα και μηνιαίες τάσεις – σε γράφημα, χωρίς υπολογισμούς.', profileTitle:'Βασικά στοιχεία', profileSubtitle:'Προαιρετικό – μπορεί να αλλάξει στις Ρυθμίσεις', nameLabel:'Το όνομά σας (όπως στο πρόγραμμα)', salaryLabel:'Βασικός μισθός / μήνα', groupLabel:'Ομάδα βάρδιας (εναλλαγή)', groupPlaceholder:'ID ομάδας (π.χ. 1.1_H9G2, 210)', personalNrLabel:'Αρ. Προσωπικού (προαιρετικό, από Zeus μηνιαία κατάσταση)', personalNrPlaceholder:'π.χ. 9876', skipBtn:'Παράλειψη', nextBtn:'Επόμενο →', pinTitle:'Απόρρητο', pinText:'Προστατέψτε τα δεδομένα μισθού και βάρδιας', pinOpt1T:'Προστασία PIN', pinOpt1D:'4ψήφιος κωδικός κατά την εκκίνηση', pinOpt2T:'Βιομετρικό', pinOpt2D:'Δακτυλικό αποτύπωμα / αναγνώριση προσώπου', pinOpt3T:'Χωρίς προστασία', pinOpt3D:'Άμεση πρόσβαση στην εφαρμογή', finishBtn:'Τέλος – Εκκίνηση εφαρμογής 🚀', nextLang:'Επόμενο →', accountTitle:'Δημιουργία λογαριασμού', accountSubtitle:'Απαραίτητο για τον συγχρονισμό στο cloud — μόνο εσύ έχεις πρόσβαση στα δεδομένα σου', emailLabel:'Διεύθυνση e-mail', emailPlaceholder:'name@example.com', passwordLabel:'Κωδικός πρόσβασης', passwordPlaceholder:'τουλ. 6 χαρακτήρες', accountRegisterBtn:'Εγγραφή', accountLoginBtn:'Σύνδεση', accountToggleToLogin:'Έχω ήδη λογαριασμό – Σύνδεση', accountToggleToRegister:'Δεν έχω λογαριασμό – Εγγραφή', accountErrMissing:'Συμπλήρωσε το e-mail και τον κωδικό.', accountErrInUse:'Αυτό το e-mail είναι ήδη καταχωρημένο – μετάβαση σε Σύνδεση;', accountErrInvalidEmail:'Μη έγκυρη διεύθυνση e-mail.', accountErrWeakPw:'Ο κωδικός πρέπει να έχει τουλάχιστον 6 χαρακτήρες.', accountErrWrongPw:'Λάθος e-mail ή κωδικός.', accountErrNotFound:'Δεν βρέθηκε τέτοιος λογαριασμός – μετάβαση σε Εγγραφή;', accountErrTooMany:'Πολλές προσπάθειες, δοκίμασε αργότερα.', accountErrGeneric:'Παρουσιάστηκε σφάλμα, δοκίμασε ξανά.', passwordLabel2:'Επιβεβαίωση κωδικού', accountErrPwMismatch:'Οι κωδικοί πρόσβασης δεν ταιριάζουν.', accountOrDivider:'ή', accountGoogleBtn:'Συνέχεια με Google', accountAppleBtn:'Συνέχεια με Apple' },
    ru: { langTitle:'Выбор языка', langSubtitle:'Выберите язык для продолжения', splashIntro:'Это всё, что нужно знать для начала – остальное сделает приложение.', splashTag:'Смены · Зарплата · Статистика', startBtn:'Начнём →', f1t:'Смены и календарь', f1d:'Записывайте смены в календарь, настройте повторяющийся шаблон и экспортируйте в любой момент одним нажатием.', f2t:'Автоматический расчёт зарплаты', f2d:'Приложение автоматически рассчитывает зарплату по введённым сменам – с ночными и выходными надбавками, без ручного труда.', f3t:'Ежемесячная статистика', f3d:'С одного взгляда видите часы, доход и месячные тренды – на графике, без расчётов.', profileTitle:'Основные данные', profileSubtitle:'Необязательно – можно изменить в настройках', nameLabel:'Ваше имя (как в расписании)', salaryLabel:'Базовая зарплата / мес', groupLabel:'Группа смен (ротация)', groupPlaceholder:'ID группы (напр. 1.1_H9G2, 210)', personalNrLabel:'Личный номер (необязательно, из Zeus ежемесячного отчёта)', personalNrPlaceholder:'напр. 9876', skipBtn:'Пропустить', nextBtn:'Далее →', pinTitle:'Конфиденциальность', pinText:'Защитите данные о зарплате и сменах', pinOpt1T:'PIN-защита', pinOpt1D:'4-значный код при запуске', pinOpt2T:'Биометрия', pinOpt2D:'Отпечаток пальца / распознавание лица', pinOpt3T:'Без защиты', pinOpt3D:'Прямой вход в приложение', finishBtn:'Готово – Запустить приложение 🚀', nextLang:'Далее →', accountTitle:'Создать аккаунт', accountSubtitle:'Нужен для облачной синхронизации — доступ к данным есть только у вас', emailLabel:'Адрес эл. почты', emailPlaceholder:'name@example.com', passwordLabel:'Пароль', passwordPlaceholder:'мин. 6 символов', accountRegisterBtn:'Регистрация', accountLoginBtn:'Войти', accountToggleToLogin:'У меня уже есть аккаунт – Войти', accountToggleToRegister:'Ещё нет аккаунта – Регистрация', accountErrMissing:'Введите адрес эл. почты и пароль.', accountErrInUse:'Этот email уже зарегистрирован – перейти ко входу?', accountErrInvalidEmail:'Неверный адрес эл. почты.', accountErrWeakPw:'Пароль должен содержать не менее 6 символов.', accountErrWrongPw:'Неверный email или пароль.', accountErrNotFound:'Такой аккаунт не найден – перейти к регистрации?', accountErrTooMany:'Слишком много попыток, попробуйте позже.', accountErrGeneric:'Произошла ошибка, попробуйте снова.', passwordLabel2:'Подтвердите пароль', accountErrPwMismatch:'Пароли не совпадают.', accountOrDivider:'или', accountGoogleBtn:'Продолжить с Google', accountAppleBtn:'Продолжить с Apple' },
    uk: { langTitle:'Вибір мови', langSubtitle:'Виберіть мову для продовження', splashIntro:'Це все, що потрібно знати для початку – решту зробить застосунок.', splashTag:'Зміни · Зарплата · Статистика', startBtn:'Починаємо →', f1t:'Зміни та календар', f1d:'Записуйте зміни в календар, налаштуйте повторюваний шаблон і експортуйте в будь-який момент одним дотиком.', f2t:'Автоматичний розрахунок зарплати', f2d:'Застосунок автоматично розраховує зарплату з введених змін – з нічними та вихідними надбавками, без зайвих зусиль.', f3t:'Щомісячна статистика', f3d:'З одного погляду бачите години, дохід і місячні тренди – на графіку, без обчислень.', profileTitle:'Основні дані', profileSubtitle:"Необов'язково – можна змінити в налаштуваннях", nameLabel:"Ваше ім'я (як у розкладі)", salaryLabel:'Базова зарплата / міс', groupLabel:'Група змін (ротація)', groupPlaceholder:'ID групи (напр. 1.1_H9G2, 210)', personalNrLabel:'Особистий номер (необов\'язково, із Zeus щомісячного звіту)', personalNrPlaceholder:'напр. 9876', skipBtn:'Пропустити', nextBtn:'Далі →', pinTitle:'Конфіденційність', pinText:'Захистіть дані про зарплату та зміни', pinOpt1T:'PIN-захист', pinOpt1D:'4-значний код при запуску', pinOpt2T:'Біометрія', pinOpt2D:'Відбиток пальця / розпізнавання обличчя', pinOpt3T:'Без захисту', pinOpt3D:'Прямий вхід до застосунку', finishBtn:'Готово – Запустити застосунок 🚀', nextLang:'Далі →', accountTitle:'Створити акаунт', accountSubtitle:"Потрібен для хмарної синхронізації — доступ до даних маєте лише ви", emailLabel:'Адреса ел. пошти', emailPlaceholder:'name@example.com', passwordLabel:'Пароль', passwordPlaceholder:'мін. 6 символів', accountRegisterBtn:'Реєстрація', accountLoginBtn:'Увійти', accountToggleToLogin:'У мене вже є акаунт – Увійти', accountToggleToRegister:'Ще немає акаунта – Реєстрація', accountErrMissing:'Введіть адресу ел. пошти та пароль.', accountErrInUse:'Ця адреса вже зареєстрована – перейти до входу?', accountErrInvalidEmail:'Недійсна адреса ел. пошти.', accountErrWeakPw:'Пароль має містити щонайменше 6 символів.', accountErrWrongPw:'Невірна адреса ел. пошти або пароль.', accountErrNotFound:'Такого акаунта не знайдено – перейти до реєстрації?', accountErrTooMany:'Забагато спроб, спробуйте пізніше.', accountErrGeneric:'Сталася помилка, спробуйте ще раз.', passwordLabel2:'Підтвердіть пароль', accountErrPwMismatch:'Паролі не збігаються.', accountOrDivider:'або', accountGoogleBtn:'Продовжити з Google', accountAppleBtn:'Продовжити з Apple' },
    ar: { langTitle:'اختر اللغة', langSubtitle:'اختر لغة للمتابعة', splashIntro:'هذا كل ما تحتاج معرفته للبدء – التطبيق يتولى الباقي.', splashTag:'وردية · راتب · إحصائيات', startBtn:'لنبدأ ←', f1t:'الورديات والتقويم', f1d:'سجّل ورديّاتك في التقويم، وضع نمطاً متكرراً، وصدّرها في أي وقت بلمسة واحدة.', f2t:'حساب الراتب التلقائي', f2d:'يحسب التطبيق راتبك تلقائياً من الورديات المدخلة – مع بدلات الليل وعطلة نهاية الأسبوع، دون أي جهد منك.', f3t:'إحصائيات شهرية', f3d:'بنظرة واحدة ترى الساعات والدخل والاتجاهات الشهرية – في مخطط بياني، بدون حسابات.', profileTitle:'البيانات الأساسية', profileSubtitle:'اختياري – قابل للتغيير في الإعدادات', nameLabel:'اسمك (كما يظهر في الجدول)', salaryLabel:'الراتب الأساسي / شهر', groupLabel:'مجموعة الوردية (دوران)', groupPlaceholder:'معرّف المجموعة (مثلاً 1.1_H9G2)', personalNrLabel:'الرقم الشخصي (اختياري، من تقرير Zeus الشهري)', personalNrPlaceholder:'مثلاً 9876', skipBtn:'تخطي', nextBtn:'التالي ←', pinTitle:'الخصوصية', pinText:'احمِ بيانات راتبك وورديتك', pinOpt1T:'حماية PIN', pinOpt1D:'رمز 4 أرقام عند البدء', pinOpt2T:'بيومتري', pinOpt2D:'بصمة الإصبع / التعرف على الوجه', pinOpt3T:'بدون حماية', pinOpt3D:'الدخول المباشر للتطبيق', finishBtn:'تم – تشغيل التطبيق 🚀', nextLang:'التالي ←', accountTitle:'إنشاء حساب', accountSubtitle:'مطلوب للمزامنة السحابية — أنت فقط من يمكنه الوصول إلى بياناتك', emailLabel:'البريد الإلكتروني', emailPlaceholder:'name@example.com', passwordLabel:'كلمة المرور', passwordPlaceholder:'6 أحرف على الأقل', accountRegisterBtn:'تسجيل', accountLoginBtn:'تسجيل الدخول', accountToggleToLogin:'لدي حساب بالفعل – تسجيل الدخول', accountToggleToRegister:'ليس لدي حساب – تسجيل', accountErrMissing:'أدخل البريد الإلكتروني وكلمة المرور.', accountErrInUse:'هذا البريد الإلكتروني مسجل بالفعل – الانتقال لتسجيل الدخول؟', accountErrInvalidEmail:'بريد إلكتروني غير صالح.', accountErrWeakPw:'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.', accountErrWrongPw:'بريد إلكتروني أو كلمة مرور خاطئة.', accountErrNotFound:'لا يوجد حساب كهذا – الانتقال للتسجيل؟', accountErrTooMany:'محاولات كثيرة جداً، حاول لاحقاً.', accountErrGeneric:'حدث خطأ، حاول مرة أخرى.', passwordLabel2:'تأكيد كلمة المرور', accountErrPwMismatch:'كلمتا المرور غير متطابقتين.', accountOrDivider:'أو', accountGoogleBtn:'المتابعة عبر Google', accountAppleBtn:'المتابعة عبر Apple' },
    bs: { langTitle:'Odaberi jezik', langSubtitle:'Odaberi jezik za nastavak', splashIntro:'To je sve što trebaš znati za početak – ostalo preuzima aplikacija.', splashTag:'Smjena · Plaća · Statistika', startBtn:'Počnimo →', f1t:'Smjene & Kalendar', f1d:'Unesite smjene u kalendar, podesite obrazac koji se ponavlja i izvezite ih u bilo kom trenutku jednim dodirom.', f2t:'Automatski obračun plaće', f2d:'Aplikacija automatski obračunava plaću na osnovu unesenih smjena – s noćnim i vikendom dodacima, bez ikakvog truda.', f3t:'Mjesečne statistike', f3d:'Na prvi pogled vidite sate, prihode i mjesečne trendove – na grafikonu, bez računanja.', profileTitle:'Osnovni podaci', profileSubtitle:'Opcionalno – može se promijeniti u postavkama', nameLabel:'Vaše ime (kao u rasporedu)', salaryLabel:'Osnovna plaća / mjes', groupLabel:'Smjenska grupa (rotacija)', groupPlaceholder:'ID grupe (npr. 1.1_H9G2, 210)', personalNrLabel:'Osobni br. (opcionalno, iz Zeus mjesečnog izvještaja)', personalNrPlaceholder:'npr. 9876', skipBtn:'Preskoči', nextBtn:'Dalje →', pinTitle:'Privatnost', pinText:'Zaštitite svoje podatke o plaći i smjenama', pinOpt1T:'PIN zaštita', pinOpt1D:'4-znamenkasti kod pri pokretanju', pinOpt2T:'Biometrija', pinOpt2D:'Otisak prsta / prepoznavanje lica', pinOpt3T:'Bez zaštite', pinOpt3D:'Direktan pristup aplikaciji', finishBtn:'Gotovo – Pokreni aplikaciju 🚀', nextLang:'Dalje →', accountTitle:'Kreiraj račun', accountSubtitle:'Potrebno za sinhronizaciju u oblaku — samo ti imaš pristup svojim podacima', emailLabel:'E-mail adresa', emailPlaceholder:'ime@primjer.com', passwordLabel:'Lozinka', passwordPlaceholder:'min. 6 znakova', accountRegisterBtn:'Registracija', accountLoginBtn:'Prijava', accountToggleToLogin:'Već imam račun – Prijava', accountToggleToRegister:'Nemam račun – Registracija', accountErrMissing:'Unesite e-mail adresu i lozinku.', accountErrInUse:'Ovaj e-mail je već registrovan – prijeći na prijavu?', accountErrInvalidEmail:'Nevažeća e-mail adresa.', accountErrWeakPw:'Lozinka mora imati najmanje 6 znakova.', accountErrWrongPw:'Pogrešan e-mail ili lozinka.', accountErrNotFound:'Takav račun ne postoji – prijeći na registraciju?', accountErrTooMany:'Previše pokušaja, pokušaj kasnije.', accountErrGeneric:'Došlo je do greške, pokušaj ponovo.', passwordLabel2:'Potvrdi lozinku', accountErrPwMismatch:'Lozinke se ne podudaraju.', accountOrDivider:'ili', accountGoogleBtn:'Nastavi sa Google', accountAppleBtn:'Nastavi sa Apple' }
  };

  var _obPinChoice = 'pin';

  window.obSetPinChoice = function(choice) {
    _obPinChoice = choice;
    var opts = ['pin','bio','none'];
    opts.forEach(function(o) {
      var optEl = document.getElementById('obPinOpt' + o.charAt(0).toUpperCase() + o.slice(1));
      var radioEl = document.getElementById('obRadio' + o.charAt(0).toUpperCase() + o.slice(1));
      if (!optEl || !radioEl) return;
      if (o === choice) {
        optEl.classList.add('ob-opt-sel');
        radioEl.classList.add('ob-opt-radio-sel');
      } else {
        optEl.classList.remove('ob-opt-sel');
        radioEl.classList.remove('ob-opt-radio-sel');
      }
    });
  };

  window.obFinishNew = function() {
    // PIN és Bio esetén is PIN setup indul kötelezően.
    var setupPin = (_obPinChoice === 'pin' || _obPinChoice === 'bio');
    // Bio választásnál jelezzük, hogy PIN után bio felajánlás is kell
    window._obWantsBio = (_obPinChoice === 'bio');
    obFinish(setupPin);
  };

  var _obAccountMode = 'register'; // 'register' | 'login'

  window.obAccountToggleMode = function() {
    _obAccountMode = (_obAccountMode === 'register') ? 'login' : 'register';
    var errEl = document.getElementById('obAccountError');
    if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
    var pwField2 = document.getElementById('obPasswordField2');
    var pwIn2 = document.getElementById('obPasswordInput2');
    if (pwField2) pwField2.style.display = (_obAccountMode === 'register') ? '' : 'none';
    if (pwIn2 && _obAccountMode !== 'register') pwIn2.value = '';
    obApplyAccountStrings(_obSelectedLang || obGetLang());
  };

  function obAccountErrText(e, lang) {
    var s = OB_STRINGS[lang] || OB_STRINGS.de;
    var code = (e && e.code) || '';
    var msgs = {
      'auth/email-already-in-use': s.accountErrInUse,
      'auth/invalid-email':        s.accountErrInvalidEmail,
      'auth/weak-password':        s.accountErrWeakPw,
      'auth/wrong-password':       s.accountErrWrongPw,
      'auth/invalid-credential':   s.accountErrWrongPw,
      'auth/user-not-found':       s.accountErrNotFound,
      'auth/too-many-requests':    s.accountErrTooMany
    };
    return (msgs[code] || s.accountErrGeneric) + (e && e.nativeDetail ? ' [' + e.nativeDetail + ']' : '');
  }

  // Fázis 2 (terv): jelszó 2x regisztrációnál — közös ellenőrző függvény,
  // amit az onboarding (obAccountSubmit) és a Settings Fiók dialógus
  // (acctSubmit) is használ.
  function passwordsMatch(pw, pw2) {
    return pw === pw2;
  }

  window.obAccountSubmit = async function() {
    var lang = _obSelectedLang || obGetLang();
    var errEl = document.getElementById('obAccountError');
    var btn = document.getElementById('obAccountSubmitBtn');
    var email = (document.getElementById('obEmailInput').value || '').trim();
    var pw = document.getElementById('obPasswordInput').value || '';
    var pw2 = document.getElementById('obPasswordInput2') ? (document.getElementById('obPasswordInput2').value || '') : '';
    if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
    if (!email || !pw) {
      if (errEl) { errEl.textContent = (OB_STRINGS[lang] || OB_STRINGS.de).accountErrMissing; errEl.style.display = 'block'; }
      return;
    }
    if (_obAccountMode === 'register' && !passwordsMatch(pw, pw2)) {
      if (errEl) { errEl.textContent = (OB_STRINGS[lang] || OB_STRINGS.de).accountErrPwMismatch; errEl.style.display = 'block'; }
      return;
    }
    // Ha időközben elérhetetlenné vált a felhő (pl. config hiba), ne blokkoljuk a varázslót
    if (!window.ChronosCloud || !window.ChronosCloud.isConfigured()) { obNext(); return; }
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '…';
    try {
      if (_obAccountMode === 'register') {
        await window.ChronosCloud.register(email, pw);
      } else {
        await window.ChronosCloud.login(email, pw);
      }
      obNext();
    } catch (e) {
      console.warn('Chronos onboarding account hiba:', e);
      if (errEl) { errEl.textContent = obAccountErrText(e, lang); errEl.style.display = 'block'; }
      btn.disabled = false;
      btn.textContent = origText;
    }
  };

  window.obLoginGoogle = function() { return _obSocialLogin(function() { return window.ChronosCloud.loginWithGoogle(); }); };
  window.obLoginApple  = function() { return _obSocialLogin(function() { return window.ChronosCloud.loginWithApple(); }); };

  async function _obSocialLogin(fn) {
    var errEl = document.getElementById('obAccountError');
    if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
    if (!window.ChronosCloud || !window.ChronosCloud.isConfigured()) { obNext(); return; }
    try {
      var user = await fn();
      if (user) obNext(); // null = signInWithRedirect folyamatban, az oldal navigál el
    } catch (e) {
      console.warn('Chronos onboarding social login hiba:', e);
      var lang = _obSelectedLang || obGetLang();
      if (errEl) { errEl.textContent = obAccountErrText(e, lang); errEl.style.display = 'block'; }
    }
  }

  function obApplyAccountStrings(lang) {
    lang = lang || obGetLang();
    var s = OB_STRINGS[lang] || OB_STRINGS.de;
    var set = function(id, txt) { var el = document.getElementById(id); if (el && txt !== undefined) el.textContent = txt; };
    set('obAccountTitle', s.accountTitle);
    set('obAccountSubtitle', s.accountSubtitle);
    set('obEmailLabel', s.emailLabel);
    set('obPasswordLabel', s.passwordLabel);
    set('obAccountSkipBtn', s.skipBtn);
    set('obAccountSubmitBtn', _obAccountMode === 'register' ? s.accountRegisterBtn : s.accountLoginBtn);
    set('obAccountToggleBtn', _obAccountMode === 'register' ? s.accountToggleToLogin : s.accountToggleToRegister);
    var emailIn = document.getElementById('obEmailInput');
    if (emailIn && s.emailPlaceholder) emailIn.placeholder = s.emailPlaceholder;
    var pwIn = document.getElementById('obPasswordInput');
    if (pwIn && s.passwordPlaceholder) pwIn.placeholder = s.passwordPlaceholder;
    set('obPasswordLabel2', s.passwordLabel2);
    var pwIn2 = document.getElementById('obPasswordInput2');
    if (pwIn2 && s.passwordPlaceholder) pwIn2.placeholder = s.passwordPlaceholder;
    set('obAccountOrDivider', s.accountOrDivider);
    set('obGoogleBtnLabel', s.accountGoogleBtn);
    set('obAppleBtnLabel', s.accountAppleBtn);
  }

  function obApplyStrings(lang) {
    lang = lang || obGetLang();
    const s = OB_STRINGS[lang] || OB_STRINGS.de;
    const set = (id, txt) => { const el = document.getElementById(id); if (el && txt !== undefined) el.textContent = txt; };
    set('obLangTitle', s.langTitle);
    if (s.langSubtitle) set('obLangSubtitle', s.langSubtitle);
    set('obSplashTag', s.splashTag);
    if (s.splashIntro) set('obSplashIntro', s.splashIntro);
    set('obStartBtn', s.startBtn);
    set('obF1Title', s.f1t);
    set('obF1Desc', s.f1d);
    set('obF2Title', s.f2t);
    set('obF2Desc', s.f2d);
    set('obF3Title', s.f3t);
    set('obF3Desc', s.f3d);
    set('obProfileTitle', s.profileTitle);
    set('obProfileSubtitle', s.profileSubtitle);
    set('obNameLabel', s.nameLabel);
    set('obSalaryLabel', s.salaryLabel);
    if (s.groupLabel) set('obGroupLabel', s.groupLabel);
    const obGrInput = document.getElementById('obGroupInput');
    if (obGrInput && s.groupPlaceholder) obGrInput.placeholder = s.groupPlaceholder;
    if (s.personalNrLabel) set('obPersonalNrLabel', s.personalNrLabel);
    const obPnrInput = document.getElementById('obPersonalNrInput');
    if (obPnrInput && s.personalNrPlaceholder) obPnrInput.placeholder = s.personalNrPlaceholder;
    set('obSkipBtn', s.skipBtn);
    set('obNextBtn', s.nextBtn);
    set('obPinTitle', s.pinTitle);
    set('obPinText', s.pinText);
    set('obPinOpt1T', s.pinOpt1T);
    set('obPinOpt1D', s.pinOpt1D);
    set('obPinOpt2T', s.pinOpt2T);
    set('obPinOpt2D', s.pinOpt2D);
    // Bio megjegyzés: PIN kötelező, bio opcionális utána
    const noteEl = document.getElementById('obPinOpt2Note');
    if (noteEl) {
      const notes = {
        hu: '🔢 Először PIN beállítás, utána bio opcionális',
        de: '🔢 PIN zuerst erforderlich, dann Biometrie optional',
        en: '🔢 PIN required first, then biometrics optional',
        ro: '🔢 PIN obligatoriu mai întâi, apoi biometric opțional',
        tr: '🔢 Önce PIN zorunlu, sonra biyometrik isteğe bağlı',
        el: '🔢 Πρώτα PIN υποχρεωτικό, μετά βιομετρικό προαιρετικό',
        ru: '🔢 Сначала PIN обязателен, потом биометрия опционально',
        uk: '🔢 Спочатку PIN обов\'язковий, потім біометрія за бажанням',
        ar: '🔢 PIN مطلوب أولاً، ثم البيومتري اختياري',
        bs: '🔢 PIN obavezan prvo, zatim biometrija opcionalna'
      };
      noteEl.textContent = notes[lang] || notes.de;
    }
    set('obPinOpt3T', s.pinOpt3T);
    set('obPinOpt3D', s.pinOpt3D);
    set('obFinishBtn', s.finishBtn);
    const nextBtn = document.getElementById('obLangNextBtn');
    if (nextBtn && nextBtn.style.opacity !== '0.4') nextBtn.textContent = s.nextLang;

    // sgHint popup fordítása az onboarding nyelvéhez
    var OB_SGHINT = {
      hu: {
        sgHintTitle: '📋 Hol találom a csoportszámomat?',
        sgHintDesc: 'Nyisd meg a Zeus-ban a <strong>Dienstplanliste</strong>-t (Bereich 1 vagy 2). A lista bal szélén, <strong>minden sor elején</strong>, a neved előtt áll a <strong>csoportszámod</strong>. Ez a szám azonosítja a rotációs csoportodat.',
        sgHintColGrp: 'Csoport', sgHintColName: 'Név', sgHintYourRow: '← a te sorod',
        sgHintLegend: 'Jelmagyarázat:', sgHintF: 'Reggeli', sgHintS: 'Délutáni', sgHintN: 'Éjszakai', sgHintX: 'Szabad'
      },
      de: {
        sgHintTitle: '📋 Wo finde ich meine Gruppennummer?',
        sgHintDesc: 'Öffne im Zeus die <strong>Dienstplanliste</strong> (Bereich 1 oder 2). Ganz links, am <strong>Anfang jeder Zeile</strong>, steht deine <strong>Gruppennummer</strong> — noch vor deinem Namen. Diese Nummer identifiziert deine Rotationsgruppe.',
        sgHintColGrp: 'Gruppe', sgHintColName: 'Name', sgHintYourRow: '← deine Zeile',
        sgHintLegend: 'Legende:', sgHintF: 'Früh', sgHintS: 'Spät', sgHintN: 'Nacht', sgHintX: 'Frei'
      },
      en: {
        sgHintTitle: '📋 Where do I find my group number?',
        sgHintDesc: 'Open the <strong>shift schedule list</strong> in Zeus (Area 1 or 2). At the far left, at the <strong>beginning of each row</strong>, you\'ll find your <strong>group number</strong> — before your name. This number identifies your rotation group.',
        sgHintColGrp: 'Group', sgHintColName: 'Name', sgHintYourRow: '← your row',
        sgHintLegend: 'Legend:', sgHintF: 'Morning', sgHintS: 'Afternoon', sgHintN: 'Night', sgHintX: 'Off'
      },
      ro: {
        sgHintTitle: '📋 Unde găsesc numărul grupei mele?',
        sgHintDesc: 'Deschide în Zeus <strong>lista programului de tură</strong> (Zona 1 sau 2). Cel mai la stânga, la <strong>începutul fiecărui rând</strong>, se află <strong>numărul grupei tale</strong> — înaintea numelui tău. Acest număr îți identifică grupa de rotație.',
        sgHintColGrp: 'Grupă', sgHintColName: 'Nume', sgHintYourRow: '← rândul tău',
        sgHintLegend: 'Legendă:', sgHintF: 'Dimineață', sgHintS: 'După-amiază', sgHintN: 'Noapte', sgHintX: 'Liber'
      },
      tr: {
        sgHintTitle: '📋 Grup numaram nerede?',
        sgHintDesc: 'Zeus\'ta <strong>vardiya planı listesini</strong> açın (Alan 1 veya 2). En solda, <strong>her satırın başında</strong>, adınızdan önce <strong>grup numaranız</strong> yazar. Bu numara rotasyon grubunuzu tanımlar.',
        sgHintColGrp: 'Grup', sgHintColName: 'Ad', sgHintYourRow: '← senin satırın',
        sgHintLegend: 'Açıklama:', sgHintF: 'Sabah', sgHintS: 'Öğleden sonra', sgHintN: 'Gece', sgHintX: 'İzinli'
      },
      el: {
        sgHintTitle: '📋 Πού βρίσκω τον αριθμό της ομάδας μου;',
        sgHintDesc: 'Ανοίξτε στο Zeus τη <strong>λίστα βαρδιών</strong> (Περιοχή 1 ή 2). Στα αριστερά, στην <strong>αρχή κάθε σειράς</strong>, υπάρχει ο <strong>αριθμός ομάδας σας</strong> — πριν το όνομά σας. Αυτός ο αριθμός αναγνωρίζει την ομάδα ρότας σας.',
        sgHintColGrp: 'Ομάδα', sgHintColName: 'Όνομα', sgHintYourRow: '← η γραμμή σου',
        sgHintLegend: 'Υπόμνημα:', sgHintF: 'Πρωί', sgHintS: 'Απόγευμα', sgHintN: 'Νύχτα', sgHintX: 'Ελεύθερο'
      },
      ru: {
        sgHintTitle: '📋 Где найти номер моей группы?',
        sgHintDesc: 'Откройте в Zeus <strong>список графика смен</strong> (Область 1 или 2). В самом левом столбце, в <strong>начале каждой строки</strong>, перед вашим именем стоит <strong>номер вашей группы</strong>. Этот номер определяет вашу группу ротации.',
        sgHintColGrp: 'Группа', sgHintColName: 'Имя', sgHintYourRow: '← ваша строка',
        sgHintLegend: 'Обозначения:', sgHintF: 'Утро', sgHintS: 'День', sgHintN: 'Ночь', sgHintX: 'Выходной'
      },
      uk: {
        sgHintTitle: '📋 Де знайти номер моєї групи?',
        sgHintDesc: 'Відкрийте в Zeus <strong>список графіка змін</strong> (Область 1 або 2). У крайньому лівому стовпці, на <strong>початку кожного рядка</strong>, перед вашим іменем стоїть <strong>номер вашої групи</strong>. Цей номер визначає вашу групу ротації.',
        sgHintColGrp: 'Група', sgHintColName: 'Ім\'я', sgHintYourRow: '← ваш рядок',
        sgHintLegend: 'Позначення:', sgHintF: 'Ранок', sgHintS: 'День', sgHintN: 'Ніч', sgHintX: 'Вихідний'
      },
      ar: {
        sgHintTitle: '📋 أين أجد رقم مجموعتي؟',
        sgHintDesc: 'افتح في Zeus <strong>قائمة جدول الورديات</strong> (المنطقة 1 أو 2). في أقصى اليسار، في <strong>بداية كل صف</strong>، يظهر <strong>رقم مجموعتك</strong> — قبل اسمك. هذا الرقم يُعرِّف مجموعة دورانك.',
        sgHintColGrp: 'المجموعة', sgHintColName: 'الاسم', sgHintYourRow: 'صفك ←',
        sgHintLegend: 'المفتاح:', sgHintF: 'صباح', sgHintS: 'مساء', sgHintN: 'ليل', sgHintX: 'إجازة'
      },
      bs: {
        sgHintTitle: '📋 Gdje pronalazim broj moje grupe?',
        sgHintDesc: 'Otvorite u Zeusu <strong>listu rasporeda smjena</strong> (Područje 1 ili 2). Na krajnjoj lijevoj strani, na <strong>početku svakog reda</strong>, nalazi se <strong>broj vaše grupe</strong> — prije vašeg imena. Ovaj broj identificira vašu rotacijsku grupu.',
        sgHintColGrp: 'Grupa', sgHintColName: 'Ime', sgHintYourRow: '← vaš red',
        sgHintLegend: 'Legenda:', sgHintF: 'Jutro', sgHintS: 'Poslijepodne', sgHintN: 'Noć', sgHintX: 'Slobodno'
      }
    };
    var sh = OB_SGHINT[lang] || OB_SGHINT.de;
    if (!window._currentTranslations) window._currentTranslations = {};
    window._currentTranslations.sgHintTitle   = sh.sgHintTitle;
    window._currentTranslations.sgHintDesc    = sh.sgHintDesc;
    window._currentTranslations.sgHintColGrp  = sh.sgHintColGrp;
    window._currentTranslations.sgHintColName = sh.sgHintColName;
    window._currentTranslations.sgHintYourRow = sh.sgHintYourRow;
    window._currentTranslations.sgHintLegend  = sh.sgHintLegend;
    window._currentTranslations.sgHintF       = sh.sgHintF;
    window._currentTranslations.sgHintS       = sh.sgHintS;
    window._currentTranslations.sgHintN       = sh.sgHintN;
    window._currentTranslations.sgHintX       = sh.sgHintX;
    if (typeof window._updateSgHintLang === 'function') window._updateSgHintLang();
    obApplyAccountStrings(lang);
  }

  function obUpdateRing(step) {
    var total = 5;
    var current = step + 1;
    var inner = document.getElementById('obRingInner');
    if (inner) inner.textContent = current + '/' + total;
    var wrap = document.getElementById('obRingWrap');
    if (!wrap) return;
    // SVG alapú gyűrű - conic-gradient nem támogatott Samsung Browserben
    var r = 22, cx = 24, cy = 24, circ = 2 * Math.PI * r;
    var filled = (current / total) * circ;
    var svg = '<svg width="48" height="48" viewBox="0 0 48 48" style="position:absolute;inset:0;">'
      + '<circle cx="24" cy="24" r="' + r + '" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="3.5"/>'
      + '<circle cx="24" cy="24" r="' + r + '" fill="none" stroke="#4f8ef5" stroke-width="3.5"'
      + ' stroke-dasharray="' + filled.toFixed(2) + ' ' + circ.toFixed(2) + '"'
      + ' stroke-linecap="round" transform="rotate(-90 24 24)"/>'
      + '</svg>';
    wrap.style.background = 'none';
    var existingSvg = wrap.querySelector('svg');
    if (existingSvg) existingSvg.remove();
    wrap.insertAdjacentHTML('afterbegin', svg);
  }

  function obShowStep(newStep, dir) {
    // dir: 1 = forward, -1 = back
    var panels = document.querySelectorAll('.ob-step-panel');
    panels.forEach(function(p) {
      var s = parseInt(p.getAttribute('data-ob-step'), 10);
      p.classList.remove('ob-active', 'ob-prev');
      if (s === newStep) {
        p.classList.add('ob-active');
        p.scrollTop = 0; // lépésváltáskor mindig felülről indul
      }
      else if (s === newStep - 1) p.classList.add('ob-prev');
    });
    obUpdateRing(newStep);
    // Step 2 (Alapadatok): fókuszált mező legyen látható a gombsor felett
    if (newStep === 2 || newStep === 3) _obAttachStep2FocusScroll();
  }

  // A position:fixed modal NEM méretezodik újra a billentyűzettel Android
  // WebView/Chrome-ban. Ezért a visualViewport.resize eseményre a modalt
  // mindig a valódi látható területre (billentyűzet fölé) méretezzük.
  // Ezután a flex layout (panel -> body[overflow-y:auto] -> nav-row) natívan
  // görgeti be a fókuszált inputot – JS scroll-számítás nélkül.
  function _obAttachStep2FocusScroll() {
    if (window._obVpSyncAttached) return;
    window._obVpSyncAttached = true;

    function _syncModalToViewport() {
      if (!window.visualViewport) return;
      var modal = document.getElementById('onboardingModal');
      if (!modal || modal.style.display === 'none') return;
      var vv = window.visualViewport;
      modal.style.position = 'fixed';
      modal.style.top    = vv.offsetTop + 'px';
      modal.style.left   = vv.offsetLeft + 'px';
      modal.style.width  = vv.width + 'px';
      modal.style.height = vv.height + 'px';
      modal.style.bottom = 'auto';
      modal.style.right  = 'auto';
    }

    function _syncAndScroll() {
      _syncModalToViewport();
      // Viewport resize utan gorgessuk be az aktiv inputot.
      // Focus handler helyett itt csinalljuk, hogy ne zavarjuk a WebView
      // natív 'Tovabb' gombos mezővaltasat.
      setTimeout(function() {
        var el = document.activeElement;
        if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 80);
    }

    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', _syncAndScroll);
      window.visualViewport.addEventListener('scroll', _syncModalToViewport);
    }
    // Azonnali szinkron (ha a KB mar nyitva volt)
    _syncModalToViewport();
  }

  // A Fiók-lépés (Step 2) csak akkor jelenik meg, ha a felhő-backend aktív és
  // konfigurált (van valódi FIREBASE_CONFIG), és a felhasználó még nincs
  // bejelentkezve. Amíg CLOUD_BACKEND='drive' vagy a config PLACEHOLDER,
  // ez a lépés láthatatlan marad — nem törhet el semmit régi telepítéseken.
  function _obAccountStepEnabled() {
    return !!(window.CLOUD_BACKEND === 'firebase' && window.ChronosCloud &&
      window.ChronosCloud.isConfigured() && !window.ChronosCloud.isLoggedIn());
  }

  window.obNext = function() {
    document.getElementById('obStep' + _obStep).classList.remove('ob-active');
    _obStep++;
    if (_obStep === 2 && !_obAccountStepEnabled()) _obStep++;
    obShowStep(_obStep, 1);
  };

  window.obGoBack = function() {
    if (_obStep <= 0) return;
    document.getElementById('obStep' + _obStep).classList.remove('ob-active');
    _obStep--;
    if (_obStep === 2 && !_obAccountStepEnabled()) _obStep--;
    obShowStep(_obStep, -1);
  };

  window.obSkip = function() { obNext(); };

  // ── Névbeírás minden releváns mezőbe ──
  // Hívható az onboarding bármely pontjáról; biztonságosan kezeli a még nem létező elemeket
  window._applyObName = function(name) {
    if (!name) return;
    // 1. Fő PDF import névkereső
    const pdfIn = document.getElementById('pdfNameInput');
    if (pdfIn) pdfIn.value = name;
    // 2. Rotation widget névkereső (name-search) - korábban hibásan
    //    'rw-name-search'-re hivatkozott (3 helyen), ami soha nem
    //    létezett -> a tényleges id="name-search"-re javítva.
    const rwIn = document.getElementById('name-search');
    if (rwIn) {
      rwIn.value = name;
      if (typeof window._rwRenderGroupList === 'function') window._rwRenderGroupList(name);
      else rwIn.dispatchEvent(new Event('input', { bubbles: true }));
    }
    // 3. In-modal rotation névkereső (rotNameSearch)
    const rotIn = document.getElementById('rotNameSearch');
    if (rotIn) {
      rotIn.value = name;
      if (typeof window.rotRenderGroups === 'function') window.rotRenderGroups(name);
    }
    // 4. Rotation widget step-groups névkereső (name-search) + auto-szűrés + auto-select
    const nsIn = document.getElementById('name-search');
    if (nsIn) {
      // Ha step-groups még nem látható, mutassuk meg
      const sg = document.getElementById('step-groups');
      if (sg && sg.style.display === 'none') {
        var _DB = {};
        try { _DB = JSON.parse(localStorage.getItem('rotApp_cycles_v1') || '{}'); } catch(e) {}
        if (Object.keys(_DB).length > 0) {
          sg.style.display = 'block';
          const sq = document.getElementById('step-quick');
          if (sq) sq.style.display = 'none';
        }
      }
      nsIn.value = name;
      nsIn.dispatchEvent(new Event('input', { bubbles: true }));
      // Ha pontosan 1 találat → auto-select
      setTimeout(function() {
        const cards = document.querySelectorAll('#group-list .group-card');
        if (cards.length === 1) cards[0].click();
      }, 120);
    }
  };

  window.obSaveProfile = function() {
    const name   = document.getElementById('obNameInput').value.trim();
    const pnrEl  = document.getElementById('obPersonalNrInput');
    const pnr    = pnrEl ? pnrEl.value.trim() : '';
    const salary = parseFloat(document.getElementById('obSalaryInput').value) || null;
    const group  = (document.getElementById('obGroupInput') ? document.getElementById('obGroupInput').value.trim() : '') || '';
    // Mentés a Chronos state-be
    const doSave = function() {
      if (window._chronosState && window._chronosSaveState) {
        const st = window._chronosState();
        if (name) {
          st.workerName = name;
          const wnInput = document.getElementById('workerName');
          if (wnInput) wnInput.value = name;
        }
        if (pnr) {
          st.workerPersonalNr = pnr;
          const pnrInput = document.getElementById('settingsWorkerPersonalNrInput');
          if (pnrInput) pnrInput.value = pnr;
        }
        if (salary) {
          st.grundlohn = salary;
          const glInput = document.getElementById('grundlohn');
          if (glInput) glInput.value = salary;
          // Kezdő grundlohn mentése – ez az emelés-előzmények alapja
          var existing = localStorage.getItem('chronos_raise_initial_grundlohn');
          if (!existing) localStorage.setItem('chronos_raise_initial_grundlohn', salary);
        }
        if (group) {
          st.shiftGroup = group;
          localStorage.setItem('chronos_user_shiftGroup', group);
          const sgInput = document.getElementById('settingsShiftGroupInput');
          if (sgInput) sgInput.value = group;
        }
        if (name || pnr || salary || group) window._chronosSaveState();
      }
    };
    doSave();
    window._obPendingName  = name;
    window._obPendingSalary = salary;
    window._obPendingGroup  = group;
    // Azonnali feltöltés kísérlet (ha az elemek már léteznek)
    window._applyObName(name);
    obNext();
  };

  window.obFinish = function(setupPin) {
    document.getElementById('onboardingModal').style.display = 'none';
    localStorage.setItem('chronos_onboarding_done', '1');
    // FONTOS: a natív bootloader-routingnak is jeleznünk kell, hogy az onboarding
    // lezajlott, különben a MainActivity minden indításkor a bootloader.html-t
    // tölti be (boot_seen sosem válik true-ra) – lásd MainActivity.setBootSeen().
    try {
      if (window.AndroidBridge && typeof window.AndroidBridge.setBootSeen === 'function') {
        window.AndroidBridge.setBootSeen();
      }
    } catch(e) {}
    // Biztonsági feltöltés: onboarding bezárásakor az app már biztosan fut
    if (window._obPendingName) {
      setTimeout(function() { window._applyObName(window._obPendingName); }, TIMING.OB_APPLY_NAME);
    }
    // Nyelv mentése ha volt választás
    if (_obSelectedLang && typeof setLanguage === 'function') {
      setLanguage(_obSelectedLang);
      if (typeof saveState === 'function') saveState();
    }
    if (setupPin && typeof window.openPinSetup === 'function') {
      setTimeout(window.openPinSetup, TIMING.OB_OPEN_PIN);
    } else {
      // Nincs PIN setup → welcome screen rögtön (első indítás)
      setTimeout(function() { if (typeof window.showWelcomeScreen === 'function') window.showWelcomeScreen(true); }, 80);
    }
    // 600ms-mal a wizard bezárása után újra hívjuk a Drive-loadot a mentett personalNr-rel
    setTimeout(function() {
      try {
        var pnrEl = document.getElementById('obPersonalNrInput');
        var pnr = pnrEl ? pnrEl.value.trim() : '';
        if (pnr && window._chronosState && window._chronosSaveState) {
          var st = window._chronosState();
          if (!st.workerPersonalNr) { st.workerPersonalNr = pnr; window._chronosSaveState(); }
        }
      } catch(e) {}
      if (typeof loadStateFromDrive === 'function') loadStateFromDrive();
    }, 600);
  };

  window.checkOnboarding = function() {
    // Ha már van adat (backup visszaállítva), ugord át
    try {
      const raw = localStorage.getItem('chronos_10');
      if (raw) {
        const parsed = JSON.parse(raw);
        // Van már valami érdemi adat?
        const hasData = (parsed.grundlohn && parsed.grundlohn > 0) ||
                        (parsed.workerName && parsed.workerName.length > 0) ||
                        (Object.keys(parsed.schedules || {}).length > 0) ||
                        parsed.pinEnabled;
        if (hasData) {
          localStorage.setItem('chronos_onboarding_done', '1');
          try {
            if (window.AndroidBridge && typeof window.AndroidBridge.setBootSeen === 'function') {
              window.AndroidBridge.setBootSeen();
            }
          } catch(e) {}
          return;
        }
      }
    } catch(e) {}

    if (localStorage.getItem('chronos_onboarding_done') === '1') return;

    // Első indítás – onboarding megjelenítése
    setTimeout(function() {
      // Előre kijelöli a telefon nyelvét ha támogatott
      const supported = ['de','hu','en','ro','tr','bs','ru','uk','el','ar'];
      const devLang = (navigator.language || 'hu').substring(0,2).toLowerCase();
      const preselect = supported.includes(devLang) ? devLang : 'de';
      obSelectLang(preselect);

      obApplyStrings(preselect);
      const modal = document.getElementById('onboardingModal');
      modal.style.display = 'block';
      // Az első lépés aktiválása az animációs rendszerrel
      _obStep = 0;
      obShowStep(0, 1);
      // Ha jött pending adat (pl. obSaveProfile() korábban futott), alkalmazza
      // Csoport mező előtöltése ha már van mentve
    const _savedGroup = localStorage.getItem('chronos_user_shiftGroup') || '';
    const _obGrEl = document.getElementById('obGroupInput');
    if (_obGrEl && _savedGroup) _obGrEl.value = _savedGroup;
    if (window._obPendingGroup && _obGrEl) _obGrEl.value = window._obPendingGroup;
    if (window._obPendingName || window._obPendingSalary) {
        const st = window._chronosState && window._chronosState();
        if (st) {
          if (window._obPendingName) { st.workerName = window._obPendingName; const el = document.getElementById('workerName'); if (el) el.value = window._obPendingName; }
          if (window._obPendingSalary) { st.grundlohn = window._obPendingSalary; const el = document.getElementById('grundlohn'); if (el) el.value = window._obPendingSalary; }
          if (window._chronosSaveState) window._chronosSaveState();
        }
        // PDF + rotation névmezők feltöltése
        if (window._obPendingName && window._applyObName) window._applyObName(window._obPendingName);
      }
    }, 700);
  };

  // ── Beállítások: névszerkesztő mentés ──
  window.settingsWorkerNameSave = function() {
    const input = document.getElementById('settingsWorkerNameInput');
    if (!input) return;
    const name = input.value.trim();

    // State mentés
    if (window._chronosState && window._chronosSaveState) {
      const st = window._chronosState();
      st.workerName = name;
      window._chronosSaveState();
    }
    window._obPendingName = name;

    // PDF import + rotation widget mezők frissítése
    if (window._applyObName) window._applyObName(name);

    // Visszajelzés
    const fb = document.getElementById('settingsWorkerNameFeedback');
    if (fb) {
      const tr = window._currentTranslations || {};
      fb.textContent = name ? (tr.settingsSavedName || '✅ Név mentve') : (tr.settingsClearedName || '✅ Név törölve');
      fb.style.display = 'block';
      setTimeout(() => { fb.style.display = 'none'; }, TIMING.FEEDBACK_HIDE);
    }
    // Gomb vizuális visszajelzés
    const _nameBtn = document.getElementById('settingsWorkerNameBtn');
    if (_nameBtn) {
      const _origTxt = _nameBtn.textContent;
      _nameBtn.textContent = '✅ Mentve!';
      _nameBtn.style.background = 'rgba(74,222,128,0.15)';
      _nameBtn.style.color = '#4ade80';
      _nameBtn.style.borderColor = 'rgba(74,222,128,0.4)';
      setTimeout(() => {
        _nameBtn.textContent = _origTxt;
        _nameBtn.style.background = '';
        _nameBtn.style.color = '';
        _nameBtn.style.borderColor = '';
      }, 1500);
    }
    input.style.borderColor = 'var(--border)';
  };

  // ── Beállítások nézet megnyitásakor: névmező előtöltése ──
  window._syncSettingsNameInput = function() {
    const input = document.getElementById('settingsWorkerNameInput');
    if (!input) return;
    const name = (window._chronosState && window._chronosState().workerName)
                 || window._obPendingName || '';
    input.value = name;
  };

  // ── Beállítások: Personal Nr. mentés ──
  // (Opcionális, egyértelmű azonosító — lásd settingsWorkerPersonalNrInput
  // leírását a markupban. Csak a Gmail-szinkron name-matchingjét élesíti
  // a name-matching helyett/mellett, máshol nem használja az app.)
  window.settingsWorkerPersonalNrSave = function() {
    const input = document.getElementById('settingsWorkerPersonalNrInput');
    if (!input) return;
    const pnr = input.value.trim();

    if (window._chronosState && window._chronosSaveState) {
      const st = window._chronosState();
      st.workerPersonalNr = pnr;
      window._chronosSaveState();
    }

    const fb = document.getElementById('settingsWorkerPersonalNrFeedback');
    if (fb) {
      const tr = window._currentTranslations || {};
      fb.textContent = pnr ? (tr.settingsSavedNr || '✅ Personal Nr. mentve') : (tr.settingsClearedNr || '✅ Personal Nr. törölve');
      fb.style.display = 'block';
      setTimeout(() => { fb.style.display = 'none'; }, TIMING.FEEDBACK_HIDE);
    }
    // Gomb vizuális visszajelzés
    const _nrBtn = document.getElementById('settingsWorkerPersonalNrBtn');
    if (_nrBtn) {
      const _origTxt = _nrBtn.textContent;
      _nrBtn.textContent = '✅ Mentve!';
      _nrBtn.style.background = 'rgba(74,222,128,0.15)';
      _nrBtn.style.color = '#4ade80';
      _nrBtn.style.borderColor = 'rgba(74,222,128,0.4)';
      setTimeout(() => {
        _nrBtn.textContent = _origTxt;
        _nrBtn.style.background = '';
        _nrBtn.style.color = '';
        _nrBtn.style.borderColor = '';
      }, 1500);
    }
    input.style.borderColor = 'var(--border)';
  };

  // ── Beállítások nézet megnyitásakor: Personal Nr. mező előtöltése ──
  window._syncSettingsPersonalNrInput = function() {
    const input = document.getElementById('settingsWorkerPersonalNrInput');
    if (!input) return;
    input.value = (window._chronosState && window._chronosState().workerPersonalNr) || '';
  };

  // ── Műszak csoport mentése (Beállítások) ──
  window.settingsShiftGroupSave = function() {
    const input = document.getElementById('settingsShiftGroupInput');
    if (!input) return;
    const group = input.value.trim();
    if (window._chronosState && window._chronosSaveState) {
      const st = window._chronosState();
      st.shiftGroup = group;
      window._chronosSaveState();
    }
    localStorage.setItem('chronos_user_shiftGroup', group);
    window._obPendingGroup = group;
    // Visszajelzés
    const fb = document.getElementById('settingsShiftGroupFeedback');
    if (fb) {
      const tr = window._currentTranslations || {};
      fb.textContent = group ? (tr.settingsSavedGroup || '✅ Csoport mentve') : (tr.settingsClearedGroup || '✅ Csoport törölve');
      fb.style.display = 'block';
      setTimeout(() => { fb.style.display = 'none'; }, TIMING.FEEDBACK_HIDE);
    }
    // Gomb vizuális visszajelzés
    const _grpBtn = document.getElementById('settingsShiftGroupBtn');
    if (_grpBtn) {
      const _origTxt = _grpBtn.textContent;
      _grpBtn.textContent = '✅ Mentve!';
      _grpBtn.style.background = 'rgba(74,222,128,0.15)';
      _grpBtn.style.color = '#4ade80';
      _grpBtn.style.borderColor = 'rgba(74,222,128,0.4)';
      setTimeout(() => {
        _grpBtn.textContent = _origTxt;
        _grpBtn.style.background = '';
        _grpBtn.style.color = '';
        _grpBtn.style.borderColor = '';
      }, 1500);
    }
    input.style.borderColor = 'var(--border)';
  };

  // ── Beállítások nézet megnyitásakor: csoport mező előtöltése ──
  window._syncSettingsGroupInput = function() {
    const input = document.getElementById('settingsShiftGroupInput');
    if (!input) return;
    const group = (window._chronosState && window._chronosState().shiftGroup)
                  || localStorage.getItem('chronos_user_shiftGroup')
                  || window._obPendingGroup || '';
    input.value = group;
  };

  // ── Műszak csoport súgó popup ──
  window.openShiftGroupHint = function() {
    const popup = document.getElementById('sgHintPopup');
    if (!popup) return;
    // Frissíti a tartalmat az aktuális nyelvhez
    window._updateSgHintLang && window._updateSgHintLang();
    popup.classList.add('open');
    document.body.style.overflow = 'hidden';
  };
  window.closeShiftGroupHint = function() {
    const popup = document.getElementById('sgHintPopup');
    if (!popup) return;
    popup.classList.remove('open');
    document.body.style.overflow = '';
  };
  window.closeShiftGroupHintOnOverlay = function(e) {
    if (e.target === document.getElementById('sgHintPopup')) {
      window.closeShiftGroupHint();
    }
  };
  // Frissíti a popup szövegeit az aktuális nyelvhez (applyTranslations hívja)
  window._updateSgHintLang = function() {
    const tr = (window._currentTranslations) || {};
    const _s  = function(id, v) { const el = document.getElementById(id); if (el && v) el.textContent = v; };
    const _sh = function(id, v) { const el = document.getElementById(id); if (el && v) el.innerHTML = v; };
    _sh('sgHintTitle',   tr.sgHintTitle   || '📋 Hol találom a csoportszámomat?');
    _sh('sgHintDesc',    tr.sgHintDesc    || 'Nyisd meg a Zeus-ban a <strong>Dienstplanliste</strong>-t (Bereich 1 vagy 2). A lista bal szélén, <strong>minden sor elején</strong>, a neved előtt áll a <strong>csoportszámod</strong>. Ez a szám azonosítja a rotációs csoportodat.');
    _s('sgHintColGrp',   tr.sgHintColGrp  || 'Csoport');
    _s('sgHintColName',  tr.sgHintColName || 'Név');
    _s('sgHintYourRow',  tr.sgHintYourRow || '← a te sorod');
    _s('sgHintLegend',   tr.sgHintLegend  || 'Jelmagyarázat:');
    _s('sgHintF',        tr.sgHintF       || 'Reggeli');
    _s('sgHintS',        tr.sgHintS       || 'Délutáni');
    _s('sgHintN',        tr.sgHintN       || 'Éjszakai');
    _s('sgHintX',        tr.sgHintX       || 'Szabad');
  };

})();


(function() {
  'use strict';

  // ── Üdvözlő szövegek – 10 nyelv ──────────────────────────────────────────
  // back1: ha van worker neve → "Szia, NAME!" / különben általános köszöntés
  var WC_STRINGS = {
    hu: {
      tag:    'Műszak · Bér · Statisztika',
      first1: 'Üdvözöl a CHRONOS!',
      first2: 'Minden készen áll. Vágjunk bele!',
      back1:  function(n){ return n ? ('Szia, ' + n + '!') : 'Üdv vissza!'; },
      back2:  'Jó műszakot!'
    },
    de: {
      tag:    'Schicht · Gehalt · Statistik',
      first1: 'Willkommen bei CHRONOS!',
      first2: 'Alles bereit. Los geht\'s.',
      back1:  function(n){ return n ? ('Hallo, ' + n + '!') : 'Willkommen zurück!'; },
      back2:  'Gute Schicht!'
    },
    en: {
      tag:    'Shift · Salary · Stats',
      first1: 'Welcome to CHRONOS!',
      first2: 'Everything is ready. Let\'s go.',
      back1:  function(n){ return n ? ('Hey, ' + n + '!') : 'Welcome back!'; },
      back2:  'Have a great shift!'
    },
    ro: {
      tag:    'Tură · Salariu · Statistici',
      first1: 'Bun venit la CHRONOS!',
      first2: 'Totul e pregătit. Să începem.',
      back1:  function(n){ return n ? ('Salut, ' + n + '!') : 'Bine ai revenit!'; },
      back2:  'Tură ușoară!'
    },
    tr: {
      tag:    'Vardiya · Maaş · İstatistik',
      first1: 'CHRONOS\'a Hoş Geldin!',
      first2: 'Her şey hazır. Başlayalım.',
      back1:  function(n){ return n ? ('Merhaba, ' + n + '!') : 'Tekrar hoş geldin!'; },
      back2:  'İyi vardiyalar!'
    },
    el: {
      tag:    'Βάρδια · Μισθός · Στατιστικά',
      first1: 'Καλωσήλθες στο CHRONOS!',
      first2: 'Όλα είναι έτοιμα. Ας ξεκινήσουμε.',
      back1:  function(n){ return n ? ('Γεια, ' + n + '!') : 'Καλωσήλθες ξανά!'; },
      back2:  'Καλή βάρδια!'
    },
    ru: {
      tag:    'Смены · Зарплата · Статистика',
      first1: 'Добро пожаловать в CHRONOS!',
      first2: 'Всё готово. Начнём.',
      back1:  function(n){ return n ? ('Привет, ' + n + '!') : 'С возвращением!'; },
      back2:  'Хорошей смены!'
    },
    uk: {
      tag:    'Зміни · Зарплата · Статистика',
      first1: 'Ласкаво просимо до CHRONOS!',
      first2: 'Все готово. Почнемо.',
      back1:  function(n){ return n ? ('Привіт, ' + n + '!') : 'З поверненням!'; },
      back2:  'Гарної зміни!'
    },
    ar: {
      tag:    'وردية · راتب · إحصائيات',
      first1: '!مرحباً بك في CHRONOS',
      first2: '.كل شيء جاهز. لنبدأ',
      back1:  function(n){ return n ? ('!مرحباً، ' + n) : '!مرحباً بعودتك'; },
      back2:  '!وردية موفقة'
    },
    bs: {
      tag:    'Smjena · Plaća · Statistika',
      first1: 'Dobrodošao u CHRONOS!',
      first2: 'Sve je spremno. Krenimo.',
      back1:  function(n){ return n ? ('Zdravo, ' + n + '!') : 'Dobrodošao nazad!'; },
      back2:  'Sretna smjena!'
    }
  };

  // ── Helper: elem megjelenítése késleltetve ──────────────────────────────
  function _show(el, ms) {
    setTimeout(function(){ if (el) el.style.opacity = '1'; }, ms);
  }

  // ── showWelcomeScreen ───────────────────────────────────────────────────
  window.showWelcomeScreen = function(isFirstTime) {
    var overlay = document.getElementById('welcomeScreen');
    if (!overlay) return;

    // ── Nyelv ──
    var lang = 'de';
    try {
      var raw = localStorage.getItem('chronos_10');
      // FONTOS: a state-ben 'currentLang' a kulcs, NEM 'language'!
      if (raw) { var st = JSON.parse(raw); if (st.currentLang) lang = st.currentLang; }
    } catch(e) {}
    if (window._obSelectedLang && WC_STRINGS[window._obSelectedLang]) lang = window._obSelectedLang;
    var s = WC_STRINGS[lang] || WC_STRINGS.de;

    // ── Worker neve (visszatérésnél személyes köszöntés) ──
    var workerName = '';
    try {
      var raw2 = localStorage.getItem('chronos_10');
      if (raw2) { var st2 = JSON.parse(raw2); workerName = st2.workerName || ''; }
    } catch(e) {}
    if (!workerName) {
      var nameEl = document.getElementById('obNameInput');
      if (nameEl && nameEl.value) workerName = nameEl.value.trim();
    }
    var firstName = workerName ? workerName.trim().split(/\s+/)[0] : '';

    // ── Időzítés ──
    var DUR = isFirstTime ? 4200 : 2800;

    // ── Elemek ──
    var logoWrap = document.getElementById('wcLogoWrap');
    var ltEl     = document.getElementById('wcLogoText');
    var tagEl    = document.getElementById('wcTagline');
    var lineEl   = document.getElementById('wcLine');
    var l1El     = document.getElementById('wcGreetLine1');
    var l2El     = document.getElementById('wcGreetLine2');
    var bar      = document.getElementById('wcBar');

    // ── Reset ──
    if (ltEl)     { ltEl.textContent = ''; ltEl.style.opacity = '0'; ltEl.classList.remove('wc-shimmer-on'); }
    if (logoWrap) { logoWrap.style.opacity = '0'; logoWrap.style.transition = ''; }
    if (tagEl)    tagEl.style.opacity  = '0';
    if (lineEl)   lineEl.style.opacity = '0';
    if (l1El)     l1El.style.opacity   = '0';
    if (l2El)     l2El.style.opacity   = '0';
    if (bar)      { bar.style.transition = 'none'; bar.style.width = '0%'; }

    // ── Szövegek kitöltése ──
    if (tagEl) tagEl.textContent = s.tag;
    if (l1El)  l1El.textContent  = isFirstTime ? s.first1 : (typeof s.back1 === 'function' ? s.back1(firstName) : s.back1);
    if (l2El)  l2El.textContent  = isFirstTime ? s.first2 : s.back2;

    // ── Beam scan csíkok törlése (előző indításból) ──
    var oldBH = document.getElementById('wcBeamH');
    var oldBV = document.getElementById('wcBeamV');
    if (oldBH) oldBH.parentNode.removeChild(oldBH);
    if (oldBV) oldBV.parentNode.removeChild(oldBV);

    // ── Megjelenítés ──
    overlay.style.opacity    = '0';
    overlay.style.transition = 'opacity .3s ease';
    overlay.style.display    = 'flex';

    requestAnimationFrame(function() {
      overlay.style.opacity = '1';

      requestAnimationFrame(function() {

        // ── ELSŐ INDÍTÁS: beam scan csíkok ──
        if (isFirstTime) {
          var bH = document.createElement('div'); bH.id = 'wcBeamH';
          var bV = document.createElement('div'); bV.id = 'wcBeamV';
          overlay.insertBefore(bH, overlay.firstChild);
          overlay.insertBefore(bV, overlay.firstChild);
        }

        // ── Logó reveal ──
        var logoDelay = isFirstTime ? 900 : 150;
        setTimeout(function() {
          if (!logoWrap) return;
          logoWrap.style.transition = 'opacity .6s cubic-bezier(.22,1,.36,1)';
          logoWrap.style.opacity = '1';
        }, logoDelay);

        // ── CHRONOS szöveg ──
        if (isFirstTime) {
          // Typewriter: indul MIUTÁN a logó látható (logoDelay + 650ms)
          // opacity JS-ből vezérelt → nem csúszik el a .wc-shimmer-on override
          setTimeout(function() {
            if (!ltEl) return;
            ltEl.style.opacity = '1';
            var idx = 0;
            var iv = setInterval(function() {
              idx++;
              ltEl.textContent = 'CHRONOS'.substring(0, idx);
              if (idx >= 7) {
                clearInterval(iv);
                setTimeout(function() { ltEl.classList.add('wc-shimmer-on'); }, 320);
              }
            }, 110);
          }, logoDelay + 650);
        } else {
          // Visszatérés: CHRONOS azonnali + shimmer
          setTimeout(function() {
            if (!ltEl) return;
            ltEl.textContent = 'CHRONOS';
            ltEl.style.opacity = '1';
            setTimeout(function() { ltEl.classList.add('wc-shimmer-on'); }, 480);
          }, logoDelay + 250);
        }

        // ── Tagline, vonal, üdvözlők ──
        var baseDelay = isFirstTime ? 2200 : 700;
        _show(tagEl,  baseDelay);
        _show(lineEl, baseDelay + 180);
        _show(l1El,   baseDelay + 320);
        _show(l2El,   baseDelay + 460);

        // ── Sand progress bar ──
        setTimeout(function() {
          if (!bar) return;
          bar.style.transition = 'width ' + (DUR - 200) + 'ms cubic-bezier(.4,0,.6,1)';
          bar.style.width = '100%';
        }, 100);

      });
    });

    // ── Eltüntetés animáció vége után → app automatikusan látszik ──
    setTimeout(function() {
      overlay.style.transition = 'opacity .5s ease';
      overlay.style.opacity    = '0';
      setTimeout(function() {
        overlay.style.display    = 'none';
        overlay.style.transition = '';
        overlay.style.opacity    = '1';
        // Reset elemek (következő híváshoz)
        if (ltEl)     { ltEl.textContent = ''; ltEl.style.opacity = '0'; ltEl.classList.remove('wc-shimmer-on'); }
        if (logoWrap) { logoWrap.style.opacity = '0'; logoWrap.style.transition = ''; }
        if (tagEl)    tagEl.style.opacity  = '0';
        if (lineEl)   lineEl.style.opacity = '0';
        if (l1El)     l1El.style.opacity   = '0';
        if (l2El)     l2El.style.opacity   = '0';
        if (bar)      { bar.style.transition = 'none'; bar.style.width = '0%'; }
        var bH2 = document.getElementById('wcBeamH'); if (bH2) bH2.parentNode.removeChild(bH2);
        var bV2 = document.getElementById('wcBeamV'); if (bV2) bV2.parentNode.removeChild(bV2);
      }, 520);
    }, DUR);
  };

})();
