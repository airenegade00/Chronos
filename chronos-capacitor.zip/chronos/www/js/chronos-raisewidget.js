/* Chronos.RaiseWidget — fizetésemelés kalkulátor (Fázis 1)
   window.raise*
*/
'use strict';

// ══════════════════════════════════════════════
// ★  RAISE WIDGET v2  ★
//    localStorage struktúra:
//      chronos_raise_pending  : { grundlohn, pct, year, month }  (következő emelés)
//      chronos_raise_history  : [ { grundlohn, pct, year, month, prevGrundlohn }, ... ]
//
//    A régi raiseEnabled / DOM-input alapú megközelítés helyett
//    az adatok LocalStorage-ban élnek, DOM-tól függetlenül.
// ══════════════════════════════════════════════

(function() {

  // ── i18n helper ─────────────────────────────
  function tr() { return window._currentTranslations || {}; }

  // ── formázók ────────────────────────────────
  function fmt(v) {
    return v.toLocaleString('de-DE', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' €';
  }
  function fmtPct(p) {
    return (p >= 0 ? '+' : '') + p.toLocaleString('de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 2}) + '%';
  }

  // ── storage helpers ──────────────────────────
  var LS_PENDING = 'chronos_raise_pending';
  var LS_HISTORY = 'chronos_raise_history';

  function getPending() {
    try { return JSON.parse(localStorage.getItem(LS_PENDING)) || null; } catch(e) { return null; }
  }
  function setPending(obj) {
    if (obj) localStorage.setItem(LS_PENDING, JSON.stringify(obj));
    else localStorage.removeItem(LS_PENDING);
  }
  function getHistory() {
    try { return JSON.parse(localStorage.getItem(LS_HISTORY)) || []; } catch(e) { return []; }
  }
  function setHistory(arr) {
    localStorage.setItem(LS_HISTORY, JSON.stringify(arr || []));
  }

  // ── aktuális Grundlohn (state + DOM) ────────
  function getCurrentGrund() {
    var st = typeof window._chronosState === 'function' ? window._chronosState() : null;
    if (st && st.grundlohn) { var v = parseFloat(st.grundlohn); if (v > 0) return v; }
    var el = document.getElementById('grundlohn');
    var v2 = el ? parseFloat((el.value || '').replace(',', '.')) : 0;
    return v2 || 0;
  }

  // ── emelés alapja (előzménysor utolsó grundlohn-ja, vagy aktuális) ──
  function getRaiseBase() {
    var hist = getHistory();
    if (hist.length > 0) return parseFloat(hist[hist.length - 1].grundlohn) || getCurrentGrund();
    return getCurrentGrund();
  }

  // ── accordion toggle ─────────────────────────
  window.toggleRaiseAccordion = function() {
    var content = document.getElementById('raiseContent');
    var arrow   = document.getElementById('raiseArrow');
    if (!content) return;
    var isOpen = content.style.display !== 'none';
    content.style.display = isOpen ? 'none' : 'block';
    if (arrow) arrow.style.transform = isOpen ? '' : 'rotate(90deg)';
    if (!isOpen) raiseRefreshUI();
  };

  // stub – régi HTML onclick-ek miatt (toggle el lett távolítva, de más hívhatja)
  window.toggleRaiseEnabled = function() {};

  // ── év + hónap select feltöltése ─────────────
  function populateDateSelects() {
    var yearSel  = document.getElementById('raisePendingYear');
    var monthSel = document.getElementById('raisePendingMonth');
    if (!yearSel || !monthSel) return;

    var now = new Date();
    var curY = now.getFullYear();
    var curM = now.getMonth() + 1; // 1-alapú
    var t = tr();
    var mnames = t.monthNames || ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];

    // Megőrizzük az esetleges pending értéket
    var pending = getPending();
    var selY = pending ? pending.year : curY;
    var selM = pending ? pending.month : (curM < 12 ? curM + 1 : 1);

    // Évek: idei + következő 9 (összesen 10 év)
    yearSel.innerHTML = '';
    for (var y = curY; y <= curY + 9; y++) {
      var opt = document.createElement('option');
      opt.value = y;
      opt.textContent = y;
      if (y === selY) opt.selected = true;
      yearSel.appendChild(opt);
    }

    // Hónapok: mind a 12
    monthSel.innerHTML = '';
    for (var m = 1; m <= 12; m++) {
      var opt2 = document.createElement('option');
      opt2.value = m;
      opt2.textContent = mnames[m - 1];
      if (m === selM) opt2.selected = true;
      monthSel.appendChild(opt2);
    }
  }

  // ── form újraszámítás (dátum változás) ──────
  window.raiseFormRecalc = function() {
    // Ha pct ki van töltve → újraszámol grundlohnt
    var pctEl   = document.getElementById('raisePendingPct');
    var grundEl = document.getElementById('raisePendingGrund');
    if (!pctEl || !grundEl) return;
    var pctRaw = pctEl.value.replace(',', '.');
    var pct = parseFloat(pctRaw);
    // Dátumváltozáskor újraszámol (múlt/jövő logikával)
    if (pctEl && pctEl.value) {
      window.raiseFormRecalcFromPct();
    } else if (grundEl && grundEl.value) {
      window.raiseFormRecalcFromGrund();
    }
  };

  // ── % → Grundlohn ───────────────────────────
  // ── Megadott dátum múltbeli-e? ───────────────
  function isRaiseDatePast() {
    var yearSel  = document.getElementById('raisePendingYear');
    var monthSel = document.getElementById('raisePendingMonth');
    if (!yearSel || !monthSel) return false;
    var now = new Date();
    var todayIdx = now.getFullYear() * 12 + now.getMonth();
    var raiseIdx = parseInt(yearSel.value) * 12 + (parseInt(monthSel.value) - 1);
    return raiseIdx <= todayIdx;
  }

  window.raiseFormRecalcFromPct = function() {
    var pctEl   = document.getElementById('raisePendingPct');
    var grundEl = document.getElementById('raisePendingGrund');
    if (!pctEl || !grundEl) return;
    var pct  = parseFloat(pctEl.value.replace(',', '.'));
    var currentG = getRaiseBase();
    if (isNaN(pct) || pct <= 0 || !currentG) {
      grundEl.value = '';
      var pr = document.getElementById('raisePendingPreview');
      if (pr) pr.textContent = '';
      return;
    }
    if (isRaiseDatePast()) {
      // Visszafelé: prevG = currentG × (1 - pct/100), newG = currentG
      var prevG = Math.round(currentG * (1 - pct / 100) * 100) / 100;
      grundEl.value = currentG.toFixed(2).replace('.', ',');
      updatePendingPreview(prevG, currentG, pct);
    } else {
      var newG = Math.round(currentG * (1 + pct / 100) * 100) / 100;
      grundEl.value = newG.toFixed(2).replace('.', ',');
      updatePendingPreview(currentG, newG, pct);
    }
  };

  // ── Grundlohn → % ───────────────────────────
  window.raiseFormRecalcFromGrund = function() {
    var pctEl   = document.getElementById('raisePendingPct');
    var grundEl = document.getElementById('raisePendingGrund');
    if (!pctEl || !grundEl) return;
    var newG = parseFloat(grundEl.value.replace(',', '.'));
    var currentG = getRaiseBase();
    if (isNaN(newG) || newG <= 0 || !currentG) {
      pctEl.value = '';
      var pr = document.getElementById('raisePendingPreview');
      if (pr) pr.textContent = '';
      return;
    }
    if (isRaiseDatePast()) {
      // Visszafelé: a beírt érték az emelés UTÁNI grundlohn
      // prevG = newG / (1 + pct/100) — de pct ismeretlen, számoljuk fordítva:
      // pct = (currentG - newG) / newG * 100  (newG = prevG, currentG = postG)
      var pct = (currentG - newG) / newG * 100;
      pctEl.value = pct.toFixed(2).replace('.', ',');
      updatePendingPreview(newG, currentG, pct);
    } else {
      var pct2 = (newG - currentG) / currentG * 100;
      pctEl.value = pct2.toFixed(2).replace('.', ',');
      updatePendingPreview(currentG, newG, pct2);
    }
  };

  // Dátumváltozáskor is frissüljön a preview
  window.raiseFormRecalc = window.raiseFormRecalc || function() {};
  var _origRaiseFormRecalc = window.raiseFormRecalc;
  window.raiseFormRecalc = function() {
    _origRaiseFormRecalc();
    // Ha van már kitöltött pct, frissítsük a preview-t
    var pctEl = document.getElementById('raisePendingPct');
    if (pctEl && pctEl.value) window.raiseFormRecalcFromPct();
    var grundEl = document.getElementById('raisePendingGrund');
    if (grundEl && grundEl.value && !(pctEl && pctEl.value)) window.raiseFormRecalcFromGrund();
  };

  function updatePendingPreview(prevG, newG, pct) {
    var pr = document.getElementById('raisePendingPreview');
    if (!pr) return;
    var diff = newG - prevG;
    pr.innerHTML =
      '<span style="color:var(--text2);">' + fmt(prevG) + '</span>' +
      ' <span style="color:var(--text2);">→</span> ' +
      '<span style="color:var(--green);font-weight:700;">' + fmt(newG) + '</span>' +
      ' <span style="color:var(--yellow);font-size:10px;">(' + fmtPct(pct) + ', ' +
      (diff >= 0 ? '+' : '') + fmt(diff) + '/Monat)</span>';
  }

  // ── Pending mentése ──────────────────────────
  window.raiseSavePending = function() {
    var yearSel  = document.getElementById('raisePendingYear');
    var monthSel = document.getElementById('raisePendingMonth');
    var pctEl    = document.getElementById('raisePendingPct');
    var grundEl  = document.getElementById('raisePendingGrund');
    if (!yearSel || !monthSel || !grundEl) return;

    var year  = parseInt(yearSel.value);
    var month = parseInt(monthSel.value);
    var newG  = parseFloat((grundEl.value || '').replace(',', '.'));
    var pct   = parseFloat((pctEl ? pctEl.value : '').replace(',', '.'));
    var base  = getRaiseBase();

    if (isNaN(newG) || newG <= 0) {
      alert(tr().raiseSaveErrorNoGrund || 'Add meg az új Grundlohnt vagy a %-ot!');
      return;
    }
    if (isNaN(pct) || pct <= 0) pct = base > 0 ? (newG - base) / base * 100 : 0;
    newG = Math.round(newG * 100) / 100;

    // Ha a megadott dátum múltban van (vagy ez a hónap), azonnal history-ba kerül
    var now = new Date();
    var todayIdx  = now.getFullYear() * 12 + now.getMonth(); // 0-alapú hónap
    var raiseIdx  = year * 12 + (month - 1);                 // 0-alapú hónap
    var isPast = raiseIdx <= todayIdx;

    if (isPast) {
      // Közvetlen history-ba írás (mint auto-apply)
      var hist = getHistory();
      // Múltbeli emelés: prevG = base × (1 - pct/100)
      var prevG = pct > 0 ? Math.round(base * (1 - pct / 100) * 100) / 100 : base;
      // Az új Grundlohn maga a jelenlegi base (nem számolunk újra)
      newG = base;
      // Rendezzük be dátum szerint (időrend)
      var newEntry = { grundlohn: newG, pct: pct, year: year, month: month, prevGrundlohn: prevG };
      hist.push(newEntry);
      hist.sort(function(a, b) { return (a.year * 12 + a.month) - (b.year * 12 + b.month); });
      // Lánc-újraszámítás az emelés pozíciójától
      var insertedIdx = hist.indexOf(newEntry);
      recomputeChain(hist, insertedIdx);
      setHistory(hist);
      // Grundlohn frissítés az utolsó elem alapján
      syncGrundlohnFromHistory(hist);
    } else {
      // Jövőbeli dátum: pending-be
      setPending({ grundlohn: newG, pct: pct, year: year, month: month });
    }

    // Form clear
    if (pctEl) pctEl.value = '';
    if (grundEl) grundEl.value = '';
    var pr = document.getElementById('raisePendingPreview');
    if (pr) pr.textContent = '';

    // Badge + UI frissítés
    updateBadge();
    raiseRefreshUI();

    // Bérkiszámítás frissítése
    setTimeout(function() {
      if (typeof window.calculatePayroll === 'function') window.calculatePayroll();
    }, 50);

    // Visszajelzés a Save gombon
    var btn = document.getElementById('raiseSaveBtn');
    if (btn) {
      var orig = btn.textContent;
      btn.textContent = (window._currentTranslations&&window._currentTranslations.savedSuccessText)||'✅ Mentve!';
      btn.classList.add('applied');
      setTimeout(function() { btn.textContent = orig; btn.classList.remove('applied'); }, TIMING.FEEDBACK_SAVED);
    }
  };

  // ── Pending törlése ──────────────────────────
  window.raiseClearPending = function() {
    setPending(null);
    updateBadge();
    raiseRefreshUI();
    if (typeof window.calculatePayroll === 'function') window.calculatePayroll();
  };

  // ── Auto-apply (calculatePayroll hívja setTimeout-tal) ──────────────
  // Ha kifizetési hónap elérte a pending hónapját: beírja az Alapadatokba,
  // archiválja, pending törlése, újraszámítás.
  window.raiseDoAutoApply = function(raiseInfo) {
    var pending = getPending();
    if (!pending) return;
    // Ellenőrzés: a pending ugyanaz-e mint amit a calculatePayroll talált?
    var pFromMi = pending.month - 1;
    var pFromYi = pending.year;
    if (pFromMi !== raiseInfo.fromMi || pFromYi !== raiseInfo.fromYi) return;

    var newG = parseFloat(pending.grundlohn);
    var prevG = getCurrentGrund();

    // Előzmény archív
    var hist = getHistory();
    hist.push({
      grundlohn: newG,
      pct: pending.pct,
      year: pending.year,
      month: pending.month,
      prevGrundlohn: prevG
    });
    setHistory(hist);

    // Pending törlés
    setPending(null);

    // Grundlohn beírása az Alapadatokba
    var el = document.getElementById('grundlohn');
    if (el) {
      el.value = newG.toFixed(2);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (typeof window._chronosState === 'function') {
      window._chronosState().grundlohn = newG;
      if (typeof window._chronosSaveState === 'function') window._chronosSaveState();
    }

    updateBadge();
    raiseRefreshUI();
    if (typeof window.calculatePayroll === 'function') window.calculatePayroll();
  };

  // ── Előzmény törlés ──────────────────────────
  // ── Lánc-újraszámítás: idx-től kezdve frissíti az összes következő entry prevGrundlohn/grundlohn értékét ──
  function recomputeChain(hist, fromIdx) {
    for (var i = fromIdx; i < hist.length; i++) {
      var prevG;
      if (i === 0) {
        // Az első elem előtti alap: onboarding initial grundlohn
        prevG = getInitialGrundlohn();
      } else {
        prevG = parseFloat(hist[i - 1].grundlohn) || 0;
      }
      if (prevG > 0) {
        hist[i].prevGrundlohn = prevG;
        hist[i].grundlohn = Math.round(prevG * (1 + hist[i].pct / 100) * 100) / 100;
      }
    }
    return hist;
  }

  // ── Grundlohn visszaírása az Alapadatokba az előzmény utolsó értéke alapján ──
  // Kezdő grundlohn (onboarding) olvasása/írása
  function getInitialGrundlohn() {
    var v = parseFloat(localStorage.getItem('chronos_raise_initial_grundlohn')) || 0;
    if (v > 0) return v;
    // Fallback: ha onboarding előtt nem volt mentve, az aktuális state-ből vesszük
    return getCurrentGrund();
  }

  function syncGrundlohnFromHistory(hist) {
    var targetG = 0;
    if (hist.length > 0) {
      // Van előzmény: az utolsó emelés utáni grundlohn
      targetG = parseFloat(hist[hist.length - 1].grundlohn) || 0;
    } else {
      // Üres history: visszaállás az onboarding-ban megadott kezdő értékre
      targetG = getInitialGrundlohn();
    }
    if (targetG <= 0) return;
    // 1. State direkt írás
    if (typeof window._chronosState === 'function') {
      window._chronosState().grundlohn = targetG;
    }
    // 2. DOM input szinkronizálás + input event (ugyanúgy mint autoApply)
    var el = document.getElementById('grundlohn');
    if (el) {
      el.value = targetG.toFixed(2);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    // 3. Mentés
    if (typeof window._chronosSaveState === 'function') window._chronosSaveState();
  }

  // ── Lánc-újraszámítás: idx-től kezdve frissíti az összes következő entry prevGrundlohn/grundlohn értékét ──

  window.raiseDeleteHistory = function(idx) {
    var hist = getHistory();
    hist.splice(idx, 1);
    // Lánc-újraszámítás az idx-től (ha vannak még utána elemek)
    if (idx < hist.length) recomputeChain(hist, idx);
    setHistory(hist);
    // Grundlohn visszaírás: utolsó érvényes hist alapján
    syncGrundlohnFromHistory(hist);
    updateBadge();
    raiseRefreshUI();
    // setTimeout: várjuk meg hogy az input dispatchEvent tényleg lefusson
    setTimeout(function() {
      if (typeof window.calculatePayroll === 'function') window.calculatePayroll();
    }, 50);
  };

  // ── Előzmény szerkesztés (inline editáláshoz, alapverzió) ────────────
  window.raiseEditHistory = function(idx) {
    var hist = getHistory();
    var entry = hist[idx];
    if (!entry) return;
    var t = tr();
    var mnames = t.monthNames || ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
    var label = (mnames[entry.month - 1] || entry.month) + ' ' + entry.year;
    var newPct = prompt(label + ' – ' + (t.raiseEditPctPrompt || 'Új % (pl. 3,5):'), entry.pct ? entry.pct.toFixed(2).replace('.', ',') : '');
    if (!newPct) return;
    var pct = parseFloat(newPct.replace(',', '.'));
    if (isNaN(pct)) return;
    var prev = parseFloat(entry.prevGrundlohn) || 0;
    if (prev <= 0) { alert(t.raiseEditNoPrev || 'Nem szerkeszthető: nincs előző Grundlohn adat.'); return; }
    // Az adott entry újraszámítása
    hist[idx] = Object.assign({}, entry, { grundlohn: Math.round(prev * (1 + pct / 100) * 100) / 100, pct: pct });
    // Lánc-újraszámítás: az idx utáni összes entry frissítése
    recomputeChain(hist, idx + 1);
    setHistory(hist);
    // Grundlohn visszaírás az Alapadatokba az utolsó érvényes érték alapján
    syncGrundlohnFromHistory(hist);
    updateBadge();
    raiseRefreshUI();
    // setTimeout: várjuk meg hogy az input dispatchEvent tényleg lefusson
    setTimeout(function() {
      if (typeof window.calculatePayroll === 'function') window.calculatePayroll();
    }, 50);
  };

  // ── Badge frissítés ──────────────────────────
  function updateBadge() {
    var badge = document.getElementById('raiseBadge');
    if (!badge) return;
    var pending = getPending();
    var hist    = getHistory();
    if (pending) {
      var t = tr();
      var mnames = t.monthNames || ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
      badge.textContent = (mnames[pending.month - 1] || pending.month) + ': ' + fmtPct(pending.pct);
      badge.style.background = 'rgba(251,191,36,0.15)';
      badge.style.color = 'var(--yellow)';
    } else if (hist.length > 0) {
      var last = hist[hist.length - 1];
      badge.textContent = last.year + ': ' + fmtPct(last.pct);
      badge.style.background = 'rgba(95,158,247,0.15)';
      badge.style.color = 'var(--accent)';
    } else {
      badge.textContent = '';
    }
  }

  // ── Teljes UI frissítés ──────────────────────
  function raiseRefreshUI() {
    refreshCurrentGrundDisplay();
    renderPendingBanner();
    renderHistory();
    populateDateSelects();
    // data-i18n attribútumú statikus elemek frissítése (raiseNextTitle, stb.)
    // Csak ha az applyTranslations elérhető, és csak a saját accordion-on belül
    if (typeof window.applyTranslations === 'function') {
      var acc = document.getElementById('raiseAccordion');
      if (acc) {
        var t = tr();
        acc.querySelectorAll('[data-i18n]').forEach(function(el) {
          var key = el.getAttribute('data-i18n');
          if (t[key] !== undefined) el.textContent = t[key];
        });
      }
    }
  }

  function refreshCurrentGrundDisplay() {
    var el = document.getElementById('raiseCurrentGrundDisplay');
    if (!el) return;
    var g = getCurrentGrund();
    el.textContent = g > 0 ? fmt(g) : (tr().raiseNoGrund || '–');
  }

  function renderPendingBanner() {
    var banner = document.getElementById('raisePendingBanner');
    var txt    = document.getElementById('raisePendingBannerText');
    if (!banner) return;
    var pending = getPending();
    if (!pending) { banner.style.display = 'none'; return; }
    banner.style.display = 'block';
    var t = tr();
    var mnames = t.monthNames || ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
    var mLabel = (mnames[pending.month - 1] || pending.month) + ' ' + pending.year;
    if (txt) txt.textContent = mLabel + ' → ' + fmt(pending.grundlohn) + ' (' + fmtPct(pending.pct) + ')';
  }

  function renderHistory() {
    var section = document.getElementById('raiseHistorySection');
    var list    = document.getElementById('raiseHistoryList');
    if (!section || !list) return;
    var hist = getHistory();
    section.style.display = 'block';

    if (hist.length === 0) {
      list.innerHTML = '<div style="font-size:11px;color:var(--text2);padding:6px 0;text-align:center;">–</div>';
      return;
    }
    var t = tr();
    var mnames = t.monthNames || ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];

    list.innerHTML = '';

    // ── Lezárt előzmények (újabb elöl) ──
    for (var i = hist.length - 1; i >= 0; i--) {
      var entry = hist[i];
      var mLabel = (mnames[(entry.month || 1) - 1] || entry.month) + ' ' + (entry.year || '');
      var prevG  = entry.prevGrundlohn ? fmt(entry.prevGrundlohn) : '?';
      var newG   = fmt(entry.grundlohn);
      var pctStr = fmtPct(entry.pct || 0);
      var idx    = i; // closure

      var row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:7px 8px;border-radius:7px;background:rgba(255,255,255,0.04);margin-bottom:4px;gap:6px;';
      row.innerHTML =
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-size:11px;color:var(--text2);">' + mLabel + '</div>' +
          '<div style="font-size:12px;font-weight:700;color:var(--green);">' +
            prevG + ' → ' + newG +
            ' <span style="color:var(--yellow);font-weight:400;font-size:10px;">(' + pctStr + ')</span>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;gap:4px;flex-shrink:0;">' +
          '<button onclick="window.raiseEditHistory(' + idx + ')" style="background:none;border:1px solid rgba(255,255,255,0.12);border-radius:5px;color:var(--text2);font-size:12px;cursor:pointer;padding:2px 6px;" title="Szerkesztés">✏️</button>' +
          '<button onclick="window.raiseDeleteHistory(' + idx + ')" style="background:none;border:1px solid rgba(255,255,255,0.12);border-radius:5px;color:var(--text2);font-size:12px;cursor:pointer;padding:2px 6px;" title="Törlés">🗑️</button>' +
        '</div>';
      list.appendChild(row);
    }
  }

  // ── Nyelv-változás figyelése ─────────────────
  var _langWatcher = null;
  function watchLangChange() {
    var target = document.querySelector('[data-i18n="today"]');
    if (!target) return;
    _langWatcher = new MutationObserver(function() {
      populateDateSelects();
      // Accordion fejléc i18n frissítése
      var raiseSpan = document.querySelector('#raiseAccordion .accordion-header [data-i18n="raiseTitle"]');
      var t = tr();
      if (raiseSpan && t.raiseTitle) raiseSpan.textContent = t.raiseTitle;
    });
    _langWatcher.observe(target, { childList: true, characterData: true, subtree: true });
  }

  // ── Init ─────────────────────────────────────
  function raiseInit() {
    populateDateSelects();
    updateBadge();
    raiseRefreshUI();
    watchLangChange();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', raiseInit);
  } else {
    raiseInit();
  }

})();
