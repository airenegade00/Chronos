/* Chronos RotWidget — rotáció generátor (Fázis 1)
   window.RotWidget, rot*, rw*, openRotationCreator, ...
*/
'use strict';

(function(){
  if(typeof pdfjsLib === 'undefined') {
    var s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    document.head.appendChild(s);
  }
})();


(function(){
'use strict';

// ── PDF.js worker ──
if(window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc =
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// ══════════════════════════════════════════════════════
//  KONSTANSOK
// ══════════════════════════════════════════════════════
const MN_HU = ['Január','Február','Március','Április','Május','Június',
               'Július','Augusztus','Szeptember','Október','November','December'];
const DN_HU = ['H','K','Sz','Cs','P','Sz','V'];
const SHIFT_VALS = ['F','S','N','X'];
const MONTH_MAP = {
  januar:1,jänner:1,februar:2,märz:3,maerz:3,april:4,mai:5,juni:6,
  juli:7,august:8,september:9,oktober:10,november:11,dezember:12,
  január:1,február:2,március:3,április:4,május:5,június:6,július:7,
  augusztus:8,szeptember:9,október:10,december:12
};

// ══════════════════════════════════════════════════════
//  ÁLLAPOT
// ══════════════════════════════════════════════════════
// Tárolt ciklusok: {deptId -> {id, dept, names:[], blocks:[], pattern:[], sources:[]}}
// localStorage kulcs: 'rotApp_cycles_v1'
let DB = {};        // élő memória

// ══════════════════════════════════════════════════════
//  BEÉGETETT CIKLUSOK (Bereich 2 - 63 napos ciklus)
//  Referencia dátum: 2026-02-01 = a ciklus 1. napja
// ══════════════════════════════════════════════════════
const BEREICH2_REF_DATE = new Date('2026-02-01T00:00:00');
const KNOWN_CYCLES = window.KNOWN_CYCLES = {
  "210": { dept: "GL Bereich 2", pattern: ["N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X"] },
  "211": { dept: "Bereich 2", pattern: ["N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X"] },
  "212": { dept: "Bereich 2 (stl. GL)", pattern: ["F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F"] },
  "213": { dept: "Bereich 2", pattern: ["F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F"] },
  "220": { dept: "GL Bereich 2", pattern: ["S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X"] },
  "221": { dept: "Bereich 2", pattern: ["S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X"] },
  "222": { dept: "Bereich 2 (stl. GL)", pattern: ["X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X"] },
  "223": { dept: "Bereich 2", pattern: ["X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X"] },
  "224": { dept: "Bereich 2 (stl. GL)", pattern: ["X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N"] },
  "225": { dept: "Bereich 2", pattern: ["X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N"] },
  "230": { dept: "Bereich 2 (stl. GL)", pattern: ["X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X"] },
  "231": { dept: "Bereich 2", pattern: ["X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X"] },
  "232": { dept: "Bereich 2 (stl. GL)", pattern: ["X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X"] },
  "233": { dept: "Bereich 2", pattern: ["X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X"] },
  "234": { dept: "GL Bereich 2", pattern: ["X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S"] },
  "235": { dept: "Bereich 2", pattern: ["X","X","F","F","F","F","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","F","F","F","F","F","X","N","N","N","N","N","X","X","S","S","S","S","S","S","X","X","F","F","F","F","F","F","F","X","X","N","N","N","X","X","S","S","S","S","S","S"] },
  // 216-os csoport: 21 napos Zwischengruppe ciklus, cycleStart: 2026-01-01
  "216": { dept: "Bereich 2", pattern: ["F","F","F","X","F","F","X","N","N","N","X","N","N","X","X","S","S","S","S","S","X"], cycleStart: new Date('2026-01-01T00:00:00') },
  // 226-os csoport: 21 napos Zwischengruppe ciklus (216 + 7 nap eltolva), cycleStart: 2026-01-01
  "226": { dept: "Bereich 2", pattern: ["N","N","N","X","N","N","X","X","S","S","S","S","S","X","F","F","F","X","F","F","X"], cycleStart: new Date('2026-01-01T00:00:00') },
  // 236-os csoport: 21 napos Zwischengruppe ciklus (216 + 14 nap eltolva), cycleStart: 2026-01-01
  "236": { dept: "Bereich 2", pattern: ["X","S","S","S","S","S","X","F","F","F","X","F","F","X","N","N","N","X","N","N","X"], cycleStart: new Date('2026-01-01T00:00:00') },
  // ── Bereich 1 – GF 14 napos, H9/H10/H11 csoportok valós PDF-ből (2026.01-06) számolt
  //     hosszabb, eltérő munkanap-számú ciklusok (28 vagy 70 napos) ──
  "1.0_GF_S":  { dept: "GF Bereich 1 (S/N)",  pattern: ["S","S","S","S","S","X","X","N","N","N","N","N","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "1.0_GF_N":  { dept: "GF Bereich 1 (N/S)",  pattern: ["N","N","N","N","N","X","X","S","S","S","S","S","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "1.1_H9G1": { dept: "1.1 - H9/G1", pattern: ["X","F","F","F","F","F","F","F","X","X","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","F","F","X","X","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","F","F","X","X","F","F","F","X"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Erkaya, Ömer","Held, Michael","Saidu, Ibrahim","Trumic, Jasmin","Buga, Ariton"],       cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Munschau, Evgenij","Ciocia, Cornel","Lupu, Eugen","Manz, Thomas"],                      cycleStart: new Date('2026-01-25T00:00:00') },
      { names: ["Plesca, Andrei","Masch, Thomas","Snezhko, Alexej"],                                     cycleStart: new Date('2026-01-18T00:00:00') }
    ]
  },
  "1.1_H9G2": { dept: "1.1 - H9/G2", pattern: ["S","X","X","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Nanos, Athanasios","Raducanu, Vladimir","Alexiadis, Stavros","Banasiak, Daniel"],         cycleStart: new Date('2026-01-25T00:00:00') },
      { names: ["Boger, Vitali","Isikan, Malik","Horvath, Attila Tamas","Biro, Peter Pal"],                cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Alexiadis, Stavros","Banasiak, Daniel"],                                                  cycleStart: new Date('2026-02-08T00:00:00') }
    ]
  },
  "1.1_H9G3": { dept: "1.1 - H9/G3", pattern: ["X","S","S","S","S","S","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S","S","X","X","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Cesur, Harun","Fragkakis, Christos","Mihaiusi, Marin","Paripovic, Borislav"],             cycleStart: new Date('2026-01-25T00:00:00') },
      { names: ["Malaescu, Zaharia Ioan","Brojaj, Avdül","Ziogas, Michail"],                               cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Gani, Sanoh","Hadzic, Mustafa","Placintaru, Alexandru"],                                  cycleStart: new Date('2026-02-08T00:00:00') }
    ]
  },
  "1.3_H10G1": { dept: "1.3 - H10/G1", pattern: ["X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","X","X","X","X","F","F","F","F","X"], cycleStart: new Date('2026-02-01T00:00:00') }, // 70 napos ciklus, valós PDF-adatból
  "1.3_H10G2": { dept: "1.3 - H10/G2", pattern: ["N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S","S","X","X","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Avram, Tiberiu-Vasile","Knowlech, Sergej","Dragota, Mihai Gabriel"],                      cycleStart: new Date('2026-01-25T00:00:00') },
      { names: ["Kara Ali Chasan, Amet","Kostik, Roman"],                                                  cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Zead, Murad Gharbi"],                                                                     cycleStart: new Date('2026-02-08T00:00:00') }
    ]
  },
  "1.3_H10G3": { dept: "1.3 - H10/G3", pattern: ["S","S","S","S","S","S","S","X","N","N","N","X","X","X","S","S","S","S","S","X","N","N","N","N","N","X","X","X"], cycleStart: new Date('2026-01-19T00:00:00'),
    subVariants: [
      { names: ["Magyar, David","Magyar David"],   cycleStart: new Date('2026-01-19T00:00:00') },
      { names: ["Bernik, Olaf","Krupic, Refik"],   cycleStart: new Date('2026-01-12T00:00:00') },
      { names: ["Petronio, Fabio","Koc, Erkan"],   cycleStart: new Date('2026-01-26T00:00:00') }
    ]
  },
  "1.4_H11G1": { dept: "1.4 - H11/G1", pattern: ["X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","X","X","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","F","F","X","X","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","X","X","F","F","F","F","F","F"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Blessing, Tim","Buliga, Cristian-Florin"],                                                cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Agaj, Blendi","Groza, Mihail"],                                                           cycleStart: new Date('2026-01-25T00:00:00') },
      { names: ["Held, Michael","Lupu, Eugen"],                                                            cycleStart: new Date('2026-02-08T00:00:00') }
    ]
  },
  "1.4_H11G2": { dept: "1.4 - H11/G2", pattern: ["N","N","N","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S","S","X","X","N","N","N","X","X","S","S","S","S","S","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S"], cycleStart: new Date('2026-05-23T00:00:00') }, // 70 napos ciklus, valós PDF-adatból
  "1.4_H11G3": { dept: "1.4 - H11/G3", pattern: ["X","S","S","S","S","S","X","N","N","N","N","N","N","N","X","X","X","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X","X","S","S","S","S","S","S","S","X","X","N","N","N","X","X","S","S","S","S","S","X","X","N","N","N","N","N","X"], cycleStart: new Date('2026-02-01T00:00:00'),
    subVariants: [
      { names: ["Bajramovic, Jasminko","Chatzistamatis, Anastasio"],                                       cycleStart: new Date('2026-02-01T00:00:00') },
      { names: ["Alhalaqi, Mohamad"],                                                                      cycleStart: new Date('2026-02-08T00:00:00') },
      { names: ["Bobernaga, Grigorii","Soukouldanos, Eleftherios"],                                        cycleStart: new Date('2026-01-25T00:00:00') }
    ]
  },
  // ── Bereich 3 – 14 napos ciklus, referencia: 2026-02-02 ──
  "B3_Schr_N": { dept: "B3 Schrauben 900 (N/S)",    pattern: ["N","N","N","N","N","X","X","S","S","S","S","S","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "B3_Schr_F": { dept: "B3 Schrauben 900 (Früh)",   pattern: ["F","F","F","F","F","X","X","F","F","F","F","F","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "B3_A70":    { dept: "B3 Anlage 70 (Früh)",        pattern: ["F","F","F","F","F","X","X","F","F","F","F","F","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "B3_Str_S":  { dept: "B3 Strahlanlagen (S/N)",     pattern: ["S","S","S","S","S","X","X","N","N","N","N","N","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "B3_Str_FS": { dept: "B3 Strahlanlagen (F/S)",     pattern: ["F","F","F","F","F","X","X","S","S","S","S","S","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
  "B3_Str_F":  { dept: "B3 Strahlanlagen (Früh)",    pattern: ["F","F","F","F","F","X","X","F","F","F","F","F","X","X"], cycleStart: new Date('2026-02-02T00:00:00') },
};

// Bereich 2 csoportok betöltése az adatbázisba (ha még nincs)
function loadKnownCycles() {
  let changed = false;
  Object.entries(KNOWN_CYCLES).forEach(([id, data]) => {
    // Egyéni cycleStart ha van (pl. 236-os csoport), különben az általános ref dátum
    const refDate = data.cycleStart instanceof Date ? data.cycleStart : BEREICH2_REF_DATE;
    // Keresünk azonos id-jű bejegyzést (bármilyen dept névvel)
    const existingKey = Object.keys(DB).find(k => DB[k].id === id);
    if (!existingKey) {
      const key = data.dept + '_' + id;
      DB[key] = {
        id, dept: data.dept, names: [], blocks: rawToBlocks(data.pattern),
        pattern: data.pattern, sources: ['builtin'],
        _cycleStart: refDate
      };
      changed = true;
    } else {
      // Mindig visszaállítjuk a beégetett helyes mintát és a referencia dátumot,
      // hogy PDF feltöltés ne tudja felülírni a ciklust
      if (!DB[existingKey].sources) DB[existingKey].sources = [];
      if (!DB[existingKey].sources.includes('builtin')) {
        DB[existingKey].sources.push('builtin');
      }
      const patternDiff = JSON.stringify(DB[existingKey].pattern) !== JSON.stringify(data.pattern);
      const startDiff = !DB[existingKey]._cycleStart ||
        new Date(DB[existingKey]._cycleStart).getTime() !== refDate.getTime();
      if (patternDiff || startDiff) {
        DB[existingKey].pattern = data.pattern;
        DB[existingKey].blocks  = rawToBlocks(data.pattern);
        DB[existingKey]._cycleStart = refDate;
        changed = true;
      }
    }
  });
  // Duplikátumok törlése: ha ugyanaz az id kétszer szerepel, a másodikat töröljük
  const seenIds = new Map();
  Object.keys(DB).forEach(key => {
    const id = DB[key].id;
    if (seenIds.has(id)) {
      // Megtartjuk azt amelyiknek van _cycleStart, másképp az elsőt
      const firstKey = seenIds.get(id);
      const keepKey = DB[firstKey]._cycleStart ? firstKey : key;
      const dropKey = keepKey === firstKey ? key : firstKey;
      // Neveket és havi adatokat mergeljük a megmaradóba
      const nameSet = new Set([...DB[keepKey].names, ...DB[dropKey].names]);
      DB[keepKey].names = [...nameSet];
      if (DB[dropKey].monthlyData) Object.assign(DB[keepKey].monthlyData || {}, DB[dropKey].monthlyData);
      delete DB[dropKey];
      seenIds.set(id, keepKey);
      changed = true;
    } else {
      seenIds.set(id, key);
    }
  });
  if (changed) dbSave();
}
let selectedGroup = null;   // { id, dept, names, blocks, pattern }
let anchorDate = null;      // Date
let anchorShift = null;     // 'F'|'S'|'N'|'X'
let phaseOffset = null;     // number – a ciklus melyik indexén volt az anchorDate
let generatedData = [];     // [{year,month,days:[{day,shift,holiday}]}]

const _cal = { year: new Date().getFullYear(), month: new Date().getMonth(),
               startDate: null, endDate: null };

// ══════════════════════════════════════════════════════
//  STORAGE
// ══════════════════════════════════════════════════════
function dbLoad() {
  try { DB = JSON.parse(localStorage.getItem('rotApp_cycles_v1') || '{}'); } catch(e) { DB = {}; }
  // Régi DB-ben lehetnek null értékek a pattern-ben – tisztítjuk
  Object.values(DB).forEach(g => {
    if (Array.isArray(g.pattern)) {
      g.pattern = g.pattern.map(s => (s === null || s === undefined) ? 'X' : s);
    }
  });
}
function dbSave() {
  try { localStorage.setItem('rotApp_cycles_v1', JSON.stringify(DB)); } catch(e) {}
}
function dbMerge(groups) {
  // groups = [{id, dept, names, rawShifts, dateInfo, source}]
  let added = 0, updated = 0;

  // Segédfüggvény: keresi az első meglévő bejegyzést azonos id-vel
  function findExistingKey(id) {
    return Object.keys(DB).find(k => DB[k].id === id) || null;
  }

  groups.forEach(g => {
    // Normalizált kulcs: csak az id alapján keresünk egyezést
    const existingKey = findExistingKey(g.id);
    const key = existingKey || (g.dept.trim() + '_' + g.id);

    if (!DB[key]) {
      DB[key] = {
        id: g.id, dept: g.dept, names: g.names,
        blocks: g.blocks, pattern: g.pattern,
        sources: [g.source],
        monthlyData: g.monthlyData || {},
        _cycleStart: g._cycleStart || null,
        confidence: g.confidence || 0
      };
      added++;
    } else {
      // Nevek union
      const nameSet = new Set([...DB[key].names, ...g.names]);
      DB[key].names = [...nameSet];
      // Havi adat hozzáadása
      if (!DB[key].monthlyData) DB[key].monthlyData = {};
      if (g.monthlyData) {
        Object.assign(DB[key].monthlyData, g.monthlyData);
      }
      if (!DB[key].sources.includes(g.source)) DB[key].sources.push(g.source);
      // builtin csoportoknál NEM írjuk felül a beégetett ciklust
      // PDF feltöltés esetén a max. detektálható ciklushossz < 63, ami hibás mintát adna
      const isBuiltin = DB[key].sources && DB[key].sources.includes('builtin');
      if (!isBuiltin) {
        // Dátum-alapú ciklus detektálás – már 1 hónap esetén is fut
        const detectedDated = detectCycleFromMonthlyData(DB[key].monthlyData);
        if (detectedDated && detectedDated.confidence >= 88) {
          DB[key].blocks      = detectedDated.blocks;
          DB[key].pattern     = detectedDated.pattern;
          DB[key].confidence  = detectedDated.confidence;
          DB[key]._cycleStart = detectedDated._cycleStart;
        } else {
          // Fallback összefűzéses detektálás: csak egymás utáni hónapoknál!
          const combined = buildCombinedSequence(DB[key].monthlyData).filter(s => SHIFT_VALS.includes(s));
          if (areMonthsConsecutive(DB[key].monthlyData)) {
            const detected = detectCycle(combined);
            if (detected && detected.confidence >= 90) {
              DB[key].blocks   = detected.blocks;
              DB[key].pattern  = detected.pattern;
              DB[key].confidence = detected.confidence;
              DB[key]._cycleStart = getEarliestDate(DB[key].monthlyData);
            }
          }
          if (g.pattern && g.pattern.length > (DB[key].pattern || []).length) {
            DB[key].blocks  = g.blocks;
            DB[key].pattern = g.pattern;
          }
        }
        // cycleStart átvétele csak ha még nincs
        if (g._cycleStart && !DB[key]._cycleStart) DB[key]._cycleStart = g._cycleStart;
      }
      updated++;
    }
  });
  dbSave();
  return { added, updated };
}

// Ellenőrzi, hogy a havi adatok hézag nélkül egymás utáni hónapok-e
// pl. ["2026-02","2026-03","2026-04"] → true, ["2026-02","2026-04"] → false
function areMonthsConsecutive(monthlyData) {
  const months = Object.keys(monthlyData).sort();
  if (months.length <= 1) return true;
  for (let i = 1; i < months.length; i++) {
    const [y1, m1] = months[i-1].split('-').map(Number);
    const [y2, m2] = months[i].split('-').map(Number);
    if (y1 * 12 + m1 + 1 !== y2 * 12 + m2) return false;
  }
  return true;
}

// Összefűzi a havi adatokat kronológiai sorrendben (egyszerű, egy hónaphoz)
function buildCombinedSequence(monthlyData) {
  const sorted = Object.entries(monthlyData)
    .sort(([a],[b]) => a.localeCompare(b)); // YYYY-MM sorrend
  return sorted.flatMap(([,shifts]) => shifts);
}

// A legkorábbi havi adat első napja (Date objektum)
function getEarliestDate(monthlyData) {
  const keys = Object.keys(monthlyData).sort();
  if (!keys.length) return null;
  const [year, month] = keys[0].split('-').map(Number);
  return new Date(year, month-1, 1);
}

// Dátum-alapú kombinált sorozat: minden naphoz az epoch-naptól számított offset is szerepel
// SKIP napokat kihagyjuk, de a dayOffset a valódi naptárból jön → nem csúszik a ciklus
// Visszaad: [{dayOffset: number, shift: string}, ...]
function buildDatedSequence(monthlyData) {
  const epoch = new Date(2000, 0, 1); // referenciapont
  const sorted = Object.entries(monthlyData).sort(([a],[b]) => a.localeCompare(b));
  const result = [];
  for (const [ym, shifts] of sorted) {
    const [year, month] = ym.split('-').map(Number);
    for (let d = 0; d < shifts.length; d++) {
      const s = shifts[d];
      if (!SHIFT_VALS.includes(s)) continue; // SKIP és ismeretlen kihagyva
      const date = new Date(year, month-1, d+1);
      const dayOffset = Math.round((date - epoch) / 86400000);
      result.push({ dayOffset, shift: s });
    }
  }
  return result;
}

// Ciklusdetektálás dátumok alapján – figyelembe veszi a hónaphatárokat
// A sorozat nem összefűzve, hanem epoch-offsettel vizsgált
function detectCycleFromMonthlyData(monthlyData) {
  const dated = buildDatedSequence(monthlyData);
  const clean = dated.filter(e => SHIFT_VALS.includes(e.shift));
  if (clean.length < 8) return null;

  const presentShifts = ['F','S','N'].filter(s => clean.some(e => e.shift === s));
  if (presentShifts.length < 1) return null;

  const epoch = new Date(2000, 0, 1);
  let best = null, bestScore = -1;

  // Minden lehetséges ciklushosszt próbálunk (10..80)
  for (let clen = 10; clen <= 80; clen++) {
    // MINDEN fázis-eltolást kipróbálunk (startOff: 0..clen-1)
    // A ciklus indexe: (dayOffset + startOff) % clen
    for (let startOff = 0; startOff < clen; startOff++) {
      const pattern = new Array(clen).fill(null);
      let conflicts = 0;
      for (const e of clean) {
        const idx = ((e.dayOffset + startOff) % clen + clen) % clen;
        if (pattern[idx] === null) {
          pattern[idx] = e.shift;
        } else if (pattern[idx] !== e.shift) {
          conflicts++;
        }
      }
      const filled = pattern.filter(x => x !== null).length;
      if (filled < Math.min(clen, clean.length)) continue;
      if (conflicts > clean.length * 0.08) continue;
      if (!presentShifts.every(s => pattern.includes(s))) continue;

      let hits = 0;
      for (const e of clean) {
        const idx = ((e.dayOffset + startOff) % clen + clen) % clen;
        if (pattern[idx] === e.shift) hits++;
      }
      const pct = hits / clean.length;
      if (pct < 0.90) continue;

      const score = pct * clen;
      if (score > bestScore) {
        bestScore = score;
        // A ciklus valódi kezdőnapja: clean[0] a ciklus (phaseAtFirst). napján van
        const firstOff = clean[0].dayOffset;
        const phaseAtFirst = ((firstOff + startOff) % clen + clen) % clen;
        const cycleStartOffset = firstOff - phaseAtFirst;
        const cycleStartDate = new Date(epoch.getTime() + cycleStartOffset * 86400000);
        best = {
          pattern: pattern.map(s => s || 'X'),
          blocks: rawToBlocks(pattern.map(s => s || 'X')),
          confidence: Math.round(pct * 100),
          _cycleStart: cycleStartDate
        };
      }
    }
  }
  return best;
}

// ══════════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════════
function showStatus(msg, type='info') {
  const el = document.getElementById('status');
  el.textContent = msg; el.className = 'status ' + type; el.style.display = 'block';
  if(type==='ok') setTimeout(()=>el.style.display='none', TIMING.STATUS_OK_HIDE);
}
function showProg(pct, label) {
  document.getElementById('prog-wrap').style.display = 'block';
  document.getElementById('prog-fill').style.width = pct + '%';
  document.getElementById('prog-label').textContent = label;
}
function hideProg() { document.getElementById('prog-wrap').style.display = 'none'; }
function show(id) { document.getElementById(id).style.display = 'block'; }
function hide(id) { document.getElementById(id).style.display = 'none'; }

// ══════════════════════════════════════════════════════
//  PDF SZÖVEG KINYERÉS
// ══════════════════════════════════════════════════════
async function rotExtractPdfText(file) {
  const ab = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
  let allText = '';
  for (let p = 1; p <= pdf.numPages; p++) {
    showProg(10 + (p/pdf.numPages)*60, `Szöveg kinyerés: ${p}/${pdf.numPages}. oldal`);
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    // Soronkénti rendezés Y koordináta alapján
    const items = [...content.items].sort((a,b) => {
      const dy = b.transform[5] - a.transform[5];
      return Math.abs(dy) > 5 ? dy : a.transform[4] - b.transform[4];
    });
    let lastY = null;
    for (const item of items) {
      if (lastY !== null && Math.abs(item.transform[5] - lastY) > 5) allText += '\n';
      allText += item.str + ' ';
      lastY = item.transform[5];
    }
    allText += '\n';
  }
  return allText;
}

// ══════════════════════════════════════════════════════
//  HÓNAP/ÉV DETEKTÁLÁS
// ══════════════════════════════════════════════════════
function detectMonthYear(text) {
  // "So 01.02.26 - Sa 28.02.26" formátum
  const dm = text.match(/\b(\d{2})\.(\d{2})\.(\d{2})\b/);
  if (dm) {
    const year = 2000 + parseInt(dm[3]);
    const month = parseInt(dm[2]);
    if (month >= 1 && month <= 12) return { year, month };
  }
  // "März 2026" típus
  const m1 = text.match(/([A-Za-z\u00C0-\u024F]+)\s+(202\d)/);
  if (m1) {
    const mn = MONTH_MAP[m1[1].toLowerCase()] || 0;
    if (mn > 0) return { year: parseInt(m1[2]), month: mn };
  }
  // Szavanként
  let month = 0;
  for (const w of text.split(/\s+/)) {
    const mn = MONTH_MAP[w.toLowerCase().replace(/[^a-z\u00E0-\u024F]/g,'')];
    if (mn && !month) month = mn;
  }
  const ym = text.match(/\b(202\d)\b/);
  const year = ym ? parseInt(ym[1]) : new Date().getFullYear();
  return month ? { year, month } : null;
}

// ══════════════════════════════════════════════════════
//  CSOPORT + MŰSZAK SOROK KINYERÉSE A PDF SZÖVEGBŐL
// ══════════════════════════════════════════════════════
// Támogatott formátumok:
//  B2 (régi):  "210 - GL Bereich 2   Stuwe, Florian  S-I  X S S..."
//  B1 (új):    "1.1 - H9/G1  Erkaya, Ömer  S-I  X F F F..."
//              "Munschau, Evgenij  S-I  X F F F..."  (folytatás, nincs csoport-ID)
//
// Speciális kódok (URL=Urlaub, KOL=Kollektivurlaub, ZA=Zeitausgleich, ELZ, stb.)
// → X-ként kezeljük a ciklusdetektáláshoz

// Ismert speciális kódok → SKIP (kihagyjuk a ciklusdetektálásból)
// Szabadság, beteg, Elternzeit, fizetetlen, baleset, egyéb
const SPECIAL_CODES = new Set([
  'URL','URLA','U',          // Urlaub / szabadság
  'KOL','KOLU',              // Kollektivurlaub
  'KRA','KR','K',            // Krankenstand / beteg
  'EZ','ELZ','ELZ2','ELZ3','EL',  // Elternzeit
  'ZA','ZAV','ZAS','ZAU',    // Zeitausgleich
  'AU','AUF',                // Arbeitsunfall
  'UBE','UB','FU',           // Fizetetlen szabadság
  'WT','MA','ELT','REHA','MU','SU','BU','BE','BR'  // egyéb
]);

function normalizeShifts(shiftStr) {
  return shiftStr.trim().split(/\s+/).map(t => {
    if (SHIFT_VALS.includes(t)) return t;
    if (SPECIAL_CODES.has(t))   return 'SKIP'; // kihagyjuk, nem X!
    // Ismeretlen 2-6 betűs nagybetűs kód → valószínűleg speciális → SKIP
    if (/^[A-ZÄÖÜ]{2,6}$/.test(t)) return 'SKIP';
    return null;
  }).filter(t => t !== null);
}

// Szétválasztja "RÉSZLEG NÉV" → {dept, name} formátumra
// A név formátuma mindig: "Vezetéknév, Utónév..."  (van benne vessző)
function splitDeptAndName(str) {
  const commaIdx = str.indexOf(',');
  if (commaIdx < 0) return null;
  const beforeComma = str.substring(0, commaIdx);
  const lastSpace   = beforeComma.lastIndexOf(' ');
  if (lastSpace < 0) return { dept: '', name: str.trim() };
  return {
    dept: str.substring(0, lastSpace).trim(),
    name: str.substring(lastSpace + 1).trim()   // "Erkaya, Ömer"
  };
}

function parsePdfGroups(text, dateInfo, sourceName) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  // groups: csoport-szintű  (pl. H9/G2_1.1, 210)
  // persons: egyéni dolgozó (pl. __p__Erkaya_Ömer)
  const groups  = {};
  const persons = {};

  let currentGroupId   = null;
  let currentDept      = null;

  function addEntry(store, key, dept, name, shifts) {
    if (!store[key]) store[key] = { id: key, dept, names: [], rawShifts: [] };
    if (!store[key].names.includes(name)) store[key].names.push(name);
    // Clean (nem-SKIP) napok számát hasonlítjuk, hogy URL-teli sorok ne írják felül a tiszta adatot
    const newClean = shifts.filter(s => SHIFT_VALS.includes(s)).length;
    const oldClean = store[key].rawShifts.filter(s => SHIFT_VALS.includes(s)).length;
    if (newClean > oldClean) store[key].rawShifts = shifts;
  }

  function addPerson(name, shifts) {
    const pkey = '__p__' + name.replace(/[,\s\/]+/g,'_');
    addEntry(persons, pkey, (currentDept||'?') + ' | ' + name, name, shifts);
  }

  for (const line of lines) {
    // ── B1 önálló fejléc sor (pl. "1.1 - H9/G2") ────────────────
    const secOnly = line.match(/^(\d+\.\d+)\s*[-–]\s*([\w\/][\w\/\s]*)$/);
    if (secOnly && !secOnly[2].includes(',')) {
      const secId = secOnly[1];
      const dept  = secOnly[2].trim();
      currentGroupId = secId + '_' + dept.replace(/[\/\s]+/g,'_');
      currentDept    = dept;
      continue;
    }

    // ── S-I szétválasztás ─────────────────────────────────────────
    const siIdx = line.indexOf('S-I');
    if (siIdx < 0) continue;

    const header   = line.substring(0, siIdx).trim();
    const shiftStr = line.substring(siIdx + 3);
    const shifts   = normalizeShifts(shiftStr);
    // Legalább 5 valódi műszaknapot várunk (SKIP-ek nem számítanak)
    if (shifts.filter(s => SHIFT_VALS.includes(s)).length < 5) continue;

    // ── B1 formátum: "1.1 - H9/G1 Erkaya, Ömer S-I ..." ─────────
    const b1m = header.match(/^(\d+\.\d+)\s*[-–]\s*(.+)$/);
    if (b1m) {
      const secId = b1m[1];
      const rest  = b1m[2].trim();
      const dn    = splitDeptAndName(rest);
      if (!dn) continue;
      const groupId = secId + (dn.dept ? '_' + dn.dept.replace(/[\/\s]+/g,'_') : '');
      currentGroupId = groupId;
      currentDept    = dn.dept || secId;
      addEntry(groups, groupId, currentDept, dn.name, shifts);
      addPerson(dn.name, shifts);
      continue;
    }

    // ── B2 formátum: "210 - GL Bereich 2 Stuwe, Florian S-I ..." ──
    const b2m = header.match(/^(\d{3})\s*[-–]\s*(.+)$/);
    if (b2m) {
      const groupId = b2m[1];
      const rest    = b2m[2].trim();
      const dn      = splitDeptAndName(rest);
      if (!dn) continue;
      currentGroupId = groupId;
      currentDept    = dn.dept || groupId;
      addEntry(groups, groupId, currentDept, dn.name, shifts);
      addPerson(dn.name, shifts);
      continue;
    }

    // ── Folytatásos sor: "Munschau, Evgenij S-I ..." ──────────────
    if (currentGroupId && /^[A-ZÄÖÜ]/.test(header) && header.includes(',')) {
      // A header az egész név
      const name = header.trim();
      addEntry(groups, currentGroupId, currentDept||'', name, shifts);
      addPerson(name, shifts);
    }
  }

  // ── Összes bejegyzés feldolgozása (csoport + egyéni) ──────────────
  const allEntries = [
    ...Object.values(groups),
    ...Object.values(persons)
  ];

  const result = [];
  for (const g of allEntries) {
    // rawShifts tartalmazza az összes napot (F/S/N/X/SKIP)
    // clean: csak a valódi műszakok + X (SKIP nélkül, egyszerű detectCycle-hoz)
    const clean = g.rawShifts.filter(s => SHIFT_VALS.includes(s));
    if (clean.length < 8) continue;
    const detected = detectCycle(clean);

    const monthlyData = {};
    if (dateInfo) {
      const ym = dateInfo.year + '-' + String(dateInfo.month).padStart(2,'0');
      // FONTOS: teljes sorozatot tárolunk SKIP-ekkel – a dátum-alapú detektáló
      // maga hagyja ki a SKIP napokat, de a dayOffset-et megőrzi!
      monthlyData[ym] = g.rawShifts; // nem clean!
    }

    result.push({
      id:         g.id,
      dept:       g.dept,
      names:      g.names,
      blocks:     detected ? detected.blocks : rawToBlocks(clean),
      pattern:    detected ? detected.pattern : clean,
      confidence: detected ? detected.confidence : 0,
      source:     sourceName,
      dateInfo,
      monthlyData
    });
  }
  return result;
}

// ══════════════════════════════════════════════════════
//  CIKLUS DETEKTÁLÁS (shift tömb → ismétlődő blokkok)
// ══════════════════════════════════════════════════════
function rawToBlocks(shifts) {
  if (!shifts.length) return [];
  const result = [];
  let cur = shifts[0], cnt = 1;
  for (let i = 1; i < shifts.length; i++) {
    if (shifts[i] === cur) cnt++;
    else { result.push({shift:cur,count:cnt}); cur=shifts[i]; cnt=1; }
  }
  result.push({shift:cur,count:cnt});
  return result;
}
function blocksToPattern(blocks) {
  const p = [];
  blocks.forEach(b => { for(let i=0;i<b.count;i++) p.push(b.shift); });
  return p;
}

function detectCycle(shifts) {
  const clean = shifts.filter(s => SHIFT_VALS.includes(s));
  if (clean.length < 4) return null;

  // Milyen műszaktípusok vannak jelen?
  const presentShifts = ['F','S','N'].filter(s => clean.includes(s));
  // Legalább 1 aktív műszak kell (+ X)
  if (presentShifts.length < 1) return null;

  // Próbálunk minden lehetséges ciklushosszt (4-től a sorozat feléig)
  let best = null, bestScore = -1;

  for (let clen = 4; clen <= Math.min(clean.length - 1, 80); clen++) {
    const cand = clean.slice(0, clen);
    // Legalább az összes jelenlévő aktív műszaktípusnak szerepelnie kell
    const hasRequired = presentShifts.every(s => cand.includes(s));
    if (!hasRequired) continue;

    // Megszámoljuk hány nap egyezik ha ezt a mintát ismételjük
    let hits = 0;
    for (let i = 0; i < clean.length; i++) {
      if (clean[i] === cand[i % clen]) hits++;
    }
    const pct = hits / clean.length;

    // Score: találati arány × hossz (hosszabb jobb, de csak ha valóban ismétlődik)
    // Legalább 90% egyezés kell (tolerancia a hónap-határok miatt)
    if (pct < 0.90) continue;
    const score = pct * clen;
    if (score > bestScore) {
      bestScore = score;
      best = {
        pattern: cand,
        blocks: rawToBlocks(cand),
        confidence: Math.round(pct * 100)
      };
    }
  }
  return best;
}

// ══════════════════════════════════════════════════════
//  FÁZIS KISZÁMÍTÁSA horgonydátumból
// ══════════════════════════════════════════════════════
// Visszaadja: a pattern melyik indexén van az anchorDate műszakja
function calcPhaseFromAnchor(pattern, anchorDateObj, anchorShiftVal) {
  // Megkeressük a pattern összes olyan pozícióját ahol a shift egyezik
  const matches = [];
  for (let i = 0; i < pattern.length; i++) {
    if (pattern[i] === anchorShiftVal) matches.push(i);
  }
  if (!matches.length) return null; // műszak nem szerepel a ciklusban

  // Ha csak egy lehetséges pozíció van, azt vesszük
  if (matches.length === 1) return matches[0];

  // Ha több, a felhasználó dátuma alapján nem tudunk tovább szűkíteni
  // (nincs extra info), ezért visszaadjuk az összes lehetséges offsetet
  return matches; // tömb = bizonytalanság
}

// Adott dátumhoz a ciklus melyik napján vagyunk (ha ismerjük a 0. nap dátumát)
function shiftOnDate(pattern, cycleStartDate, targetDate) {
  const diff = Math.round((targetDate - cycleStartDate) / 86400000);
  const idx = ((diff % pattern.length) + pattern.length) % pattern.length;
  const s = pattern[idx];
  return (s === null || s === undefined) ? 'X' : s;
}

// A ciklus "0. napjának" dátuma: anchorDate - anchorPhaseIndex nap
function calcCycleStart(anchorDateObj, anchorPhaseIndex) {
  const d = new Date(anchorDateObj);
  d.setDate(d.getDate() - anchorPhaseIndex);
  return d;
}

// ══════════════════════════════════════════════════════
//  PDF FELDOLGOZÁS (fő folyamat)
// ══════════════════════════════════════════════════════
async function rotProcessFiles(files) {
  showStatus((window._currentTranslations&&window._currentTranslations.rwPdfProcessing)||'⏳ PDF feldolgozás...', 'info');
  showProg(5, (window._currentTranslations&&window._currentTranslations.pdfReadingFile)||'⏳ Betöltés...');
  const allGroups = [];

  for (let fi = 0; fi < files.length; fi++) {
    const file = files[fi];
    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') continue;
    if (file.size > 30*1024*1024) { showStatus('Max 30 MB!','err'); continue; }
    try {
      showProg(5 + fi/files.length*30, `${(window._currentTranslations&&window._currentTranslations.pdfReadingFile)||'⏳ PDF:'} ${file.name}`);
      const text = await rotExtractPdfText(file);
      const dateInfo = detectMonthYear(text);
      const groups = parsePdfGroups(text, dateInfo, file.name);
      allGroups.push(...groups);
    } catch(e) {
      showStatus('❌ PDF hiba: ' + e.message, 'err');
    }
  }

  if (!allGroups.length) {
    showStatus((window._currentTranslations&&window._currentTranslations.rwNoShiftRows)||'⚠️ Nem találtam beosztás sorokat. Ellenőrizd a PDF-et.','warn');
    hideProg(); return;
  }

  // Ha több PDF-et töltöttünk fel egyszerre, előbb összefűzzük a havi adatokat
  // csoportonként, és újra detektáljuk a ciklust a kombinált sorozatból
  const mergedGroups = {};
  allGroups.forEach(g => {
    // Keresünk azonos id-jű bejegyzést
    const existingKey = Object.keys(mergedGroups).find(k => mergedGroups[k].id === g.id);
    const key = existingKey || (g.dept.trim() + '_' + g.id);
    if (!mergedGroups[key]) {
      mergedGroups[key] = { ...g, monthlyData: { ...(g.monthlyData||{}) } };
    } else {
      // Nevek union
      const ns = new Set([...mergedGroups[key].names, ...g.names]);
      mergedGroups[key].names = [...ns];
      // Havi adatok összefűzése
      Object.assign(mergedGroups[key].monthlyData, g.monthlyData || {});
    }
  });

  // Ha van több hónap, dátum-alapú detektálással újra meghatározzuk a ciklust
  Object.values(mergedGroups).forEach(g => {
    const months = Object.keys(g.monthlyData||{}).sort();
    if (months.length >= 1) {
      // Dátum-alapú ciklus detektálás – már 1 hónap esetén is fut
      const detectedDated = detectCycleFromMonthlyData(g.monthlyData);
      if (detectedDated && detectedDated.confidence >= 88) {
        g.blocks      = detectedDated.blocks;
        g.pattern     = detectedDated.pattern;
        g.confidence  = detectedDated.confidence;
        g._cycleStart = detectedDated._cycleStart;
      } else {
        // Fallback: összefűzéses detektálás, csak egymás utáni hónapoknál
        if (areMonthsConsecutive(g.monthlyData)) {
          const combined = buildCombinedSequence(g.monthlyData);
          const detected = detectCycle(combined);
          if (detected && detected.confidence >= 90) {
            g.blocks     = detected.blocks;
            g.pattern    = detected.pattern;
            g.confidence = detected.confidence;
            g._cycleStart = getEarliestDate(g.monthlyData);
          }
        }
      }
    }
  });

  const finalGroups = Object.values(mergedGroups);
  const { added, updated } = dbMerge(finalGroups);
  hideProg();
  const cycleInfo = finalGroups.filter(g=>g._cycleStart).length;
  showStatus(`✅ ${finalGroups.length} ${(window._currentTranslations&&window._currentTranslations.rwCycleLoaded)||'csoport feldolgozva'} — ${added} új, ${updated} frissített${cycleInfo ? ', '+cycleInfo+' ciklus automatikusan felismerve' : ''}`, 'ok');
  renderGroupList();
  show('step-groups');
  document.getElementById('step-groups').scrollIntoView({behavior:'smooth',block:'start'});
}

// ══════════════════════════════════════════════════════
//  CSOPORT LISTA RENDERELÉS
// ══════════════════════════════════════════════════════
function renderGroupList(filter='') {
  const list = document.getElementById('group-list');
  const chips = document.getElementById('name-chips');
  list.innerHTML = '';
  chips.innerHTML = '';

  // Mindig frissítjük a DB-t a localStorage-ból (két script scope miatt)
  try { DB = JSON.parse(localStorage.getItem('rotApp_cycles_v1') || '{}'); } catch(e) { DB = {}; }
  // _cycleStart string → Date konverzió + pattern null tisztítás
  Object.values(DB).forEach(g => {
    if (g._cycleStart && !(g._cycleStart instanceof Date)) g._cycleStart = new Date(g._cycleStart);
    if (Array.isArray(g.pattern)) g.pattern = g.pattern.map(s => s || 'X');
  });
  // KNOWN_CYCLES beégetett adatok visszaállítása (loadKnownCycles után is)
  if (typeof loadKnownCycles === 'function') loadKnownCycles();

  const allGroups = Object.values(DB);
  if (!allGroups.length) {
    list.innerHTML = `<div style="font-size:12px;color:var(--mut);text-align:center;padding:20px;font-family:'DM Mono',monospace">${(window._currentTranslations&&window._currentTranslations.rwNoCycles)||'Nincs tárolt ciklus. Tölts fel PDF-et!'}</div>`;
    return;
  }

  // Ékezet+vessző normalizálás
  function _normName(s) {
    return (s||'').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[,.;\-\/]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  const q = _normName(filter);
  const qParts = q.split(' ').filter(Boolean);
  // Névegyezés: ékezet+vessző normalizálás + fordított sorrend (pl. "Zoltan Takacs" = "Takacs Zoltan")
  function nameMatchesQ(name) {
    const n = _normName(name);
    if (!qParts.length) return false;
    if (qParts.every(w => n.includes(w))) return true;
    const qRev = qParts.slice().reverse();
    if (qRev.every(w => n.includes(w))) return true;
    return false;
  }
  // subVariants neveit is bevonjuk a keresésbe
  function getSubVariantNames(g) {
    const knownKey = Object.keys(KNOWN_CYCLES).find(k => {
      function nkc(s){ return (s||'').toLowerCase().replace(/[\/.\-_\s]/g,''); }
      return nkc(k) === nkc(g.id) || nkc(k) === nkc(g.dept);
    });
    const kd = knownKey ? KNOWN_CYCLES[knownKey] : null;
    if (!kd || !Array.isArray(kd.subVariants)) return [];
    return kd.subVariants.flatMap(sv => sv.names || []);
  }
  const filtered = q ? allGroups.filter(g =>
    _normName(g.id).includes(q) ||
    _normName(g.dept).includes(q) ||
    g.names.some(n => nameMatchesQ(n)) ||
    getSubVariantNames(g).some(n => nameMatchesQ(n))
  ) : allGroups;

  filtered.sort((a,b) => {
    // Egyéni bejegyzések a végére
    const aP = a.id.startsWith('__p__') ? 1 : 0;
    const bP = b.id.startsWith('__p__') ? 1 : 0;
    if (aP !== bP) return aP - bP;
    return a.id.localeCompare(b.id, undefined, {numeric:true});
  });

  // Névchipek (első 12 egyedi név)
  const nameSet = new Set();
  allGroups.forEach(g => g.names.forEach(n => nameSet.add(n)));
  [...nameSet].sort().slice(0, 12).forEach(name => {
    const chip = document.createElement('div');
    chip.className = 'name-chip';
    chip.textContent = name;
    chip.addEventListener('click', () => {
      document.getElementById('name-search').value = name;
      renderGroupList(name);
    });
    chips.appendChild(chip);
  });

  filtered.forEach(g => {
    const card = document.createElement('div');
    card.className = 'group-card fadein' + (selectedGroup && selectedGroup.id === g.id && selectedGroup.dept === g.dept ? ' active' : '');

    const preview = g.pattern.slice(0,14);
    const badges = preview.map(s => `<span class="gc-badge gc-badge-${s}">${s}</span>`).join('');
    const lenBadge = `<span class="gc-badge gc-badge-len">${g.pattern.length}d</span>`;
    const isPerson = g.id.startsWith('__p__');
    const conf = g.confidence || 0;
    const confColor = conf >= 75 ? 'var(--U)' : conf >= 50 ? 'var(--F)' : 'var(--acc2)';
    const displayId = isPerson ? '👤' : g.id;
    const displayDept = isPerson ? g.dept : g.dept;

    card.innerHTML = `
      <div class="gc-top">
        <span class="gc-id">${displayId}</span>
        <span class="gc-dept">${displayDept}</span>
        <span style="font-size:10px;color:${confColor};font-family:'DM Mono',monospace">${conf}%</span>
      </div>
      <div class="gc-names">${g.names.slice(0,4).join(', ')}${g.names.length > 4 ? ' +' + (g.names.length-4) : ''}</div>
      <div class="gc-pattern">${badges}${preview.length < g.pattern.length ? '…' : ''}${lenBadge}</div>`;

    card.addEventListener('click', () => {
      document.querySelectorAll('.group-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      selectGroup(g);
    });
    list.appendChild(card);
  });

  // Ha 0 eredmény → csoportszám kérés
  if (!filtered.length) {
    const _rtr = window._currentTranslations || {};
    const _rt = k => (_rtr[k] || '');
    list.innerHTML = `
      <div style="padding:16px;background:rgba(124,106,255,.06);border:1px solid rgba(124,106,255,.2);border-radius:14px;">
        <div style="font-size:11px;color:var(--acc);font-family:'DM Mono',monospace;margin-bottom:10px;">
          ${(_rt('rcGroupNotFound')||'⚠️ Nem találtam „{q}" névre a tárolt adatokban.').replace('{q}', q)}
        </div>
        <div style="font-size:11px;color:var(--mut);font-family:'DM Mono',monospace;margin-bottom:10px;line-height:1.6;">
          ${_rt('rcGroupFallbackHint')||'Ha tudod a csoportszámodat (pl. 220), add meg – és az app a csoport tárolt ciklusa alapján folytatja:'}
        </div>
        <div style="display:flex;gap:8px;">
          <input id="groupid-fallback" type="text" placeholder="${_rt('rcGroupPlaceholder')||'pl. 220'}"
            style="width:100px;min-width:0;padding:9px 12px;background:var(--surf);border:1.5px solid var(--brd);border-radius:11px;color:var(--txt);font-size:15px;font-family:'DM Mono',monospace;letter-spacing:2px;"
            maxlength="10">
          <button id="groupid-go" class="btn btn-primary btn-sm" style="white-space:nowrap;flex-shrink:0;">${_rt('rcGroupGoBtn')||'→ Kiválaszt'}</button>
        </div>
        <div id="groupid-hint" style="font-size:11px;color:var(--mut);font-family:'DM Mono',monospace;margin-top:8px;"></div>
      </div>`;

    // Live preview miközben írja
    const inp = document.getElementById('groupid-fallback');
    const hint = document.getElementById('groupid-hint');
    const goBtn = document.getElementById('groupid-go');

    function tryGroupId(val) {
      const vRaw = val.trim();
      if (!vRaw) { hint.textContent = ''; goBtn.disabled = true; return; }
      // Normalizálás: kisbetű, "/", ".", "-", szóköz törölve – hogy "H10/G3", "h10g3",
      // "h10-g3" mind ugyanarra illeszkedjen. A B1-formátumban a "H10/G3" rész a dept
      // mezőben van, az id csak a számkód ("1_3") – ezért MINDKÉT mezőt nézzük.
      function gnorm(s) { return (s||'').toString().toLowerCase().replace(/[\/.\-_\s]/g, ''); }
      const vN = gnorm(vRaw);
      const vIdN = vRaw.replace(/\./g, '_').replace(/\s+/g, ''); // id-stílusú normalizálás (pl. "1.3"->"1_3")
      // Keresés id és dept alapján is, részleges egyezéssel
      const found = Object.values(DB).filter(g => {
        const idN = gnorm(g.id);
        const deptN = gnorm(g.dept);
        return idN.startsWith(vN) || idN === vN ||
               deptN.startsWith(vN) || deptN === vN ||
               g.id.startsWith(vIdN) || g.id === vIdN;
      });
      if (found.length === 1) {
        hint.innerHTML = `✓ <span style="color:var(--U)">${found[0].dept||found[0].id}</span> – ${found[0].id} · ${(_rt('rcDayCycle')||'{n} napos ciklus').replace('{n}', found[0].pattern.length)}`;
        goBtn.disabled = false;
        goBtn.dataset.groupKey = found[0].dept + '_' + found[0].id;
      } else if (found.length > 1) {
        hint.innerHTML = (_rt('rcMatches')||'{n} egyezés: {ids} – pontosítsd!').replace('{n}', found.length).replace('{ids}', found.map(g=>`<strong>${g.dept||g.id}</strong>`).join(', '));
        goBtn.disabled = true;
      } else {
        hint.innerHTML = `<span style="color:var(--acc2)">${_rt('rcGroupNotFoundDB')||'Nem találtam ilyen csoportot a tárolt adatokban.'}</span>`;
        goBtn.disabled = true;
      }
    }

    inp.addEventListener('input', e => tryGroupId(e.target.value));
    inp.addEventListener('keydown', e => { if(e.key==='Enter' && !goBtn.disabled) goBtn.click(); });
    goBtn.disabled = true;
    goBtn.addEventListener('click', () => {
      const key = goBtn.dataset.groupKey;
      if (!key || !DB[key]) return;
      const g = DB[key];
      // Kézzel is kereshetjük az adott csoportot hogy kijelöljük
      document.getElementById('name-search').value = g.id;
      renderGroupList(g.id);
      // Auto-select
      setTimeout(() => {
        const cards = document.querySelectorAll('.group-card');
        if (cards.length === 1) cards[0].click();
      }, 50);
    });
  }
}

// Globális regisztráció – pdfSearchName és egyéb hívók számára
window._rwRenderGroupList = function(filter) { renderGroupList(filter); };

function selectGroup(g) {
  // Pattern null/undefined tisztítás (régi DB kompatibilitás)
  if (Array.isArray(g.pattern)) {
    g.pattern = g.pattern.map(s => (s === null || s === undefined) ? 'X' : s);
  }
  selectedGroup = g;
  // Manuális szerkesztő feltöltése
  _manualBlocks = g.blocks.map(b => ({...b}));
  renderBlockEditor();

  // ── SUBGROUP PICKER: ha csoporton belül több eltérő fázis létezik ──
  // Csak csoportbejegyzéseknél (nem egyéni __p__ bejegyzéseknél)
  if (!g.id.startsWith('__p__')) {
    const subVariants = _findSubgroupVariants(g);
    if (subVariants.length >= 2) {
      const searchName = (document.getElementById('name-search') && document.getElementById('name-search').value) || '';
      renderSubgroupPicker(g, subVariants, searchName);
      hide('step-anchor');
      hide('step-generate');
      document.getElementById('step-subgroup').style.display = 'block';
      document.getElementById('step-subgroup').scrollIntoView({behavior:'smooth',block:'start'});
      return;
    }
  }

  // Ha a csoport már ismert cycleStart-tal rendelkezik (beégetett Bereich 2),
  // átugorjuk az anchor lépést és egyből a generálásra ugrunk
  if (g._cycleStart) {
    selectedGroup._cycleStart = g._cycleStart instanceof Date
      ? g._cycleStart : new Date(g._cycleStart);
    if (isNaN(selectedGroup._cycleStart.getTime())) {
      selectedGroup._cycleStart = null;
    } else {
      document.getElementById('step-subgroup').style.display = 'none';
      show('step-generate');
      _initGenSelects();
      document.getElementById('gen-btn').disabled = false;
      showStatus('✅ ' + g.id + ' – ' + g.dept + ' ' + ((window._currentTranslations&&window._currentTranslations.rwCycleLoaded)||'ciklus betöltve'), 'ok');
      document.getElementById('step-generate').scrollIntoView({behavior:'smooth',block:'start'});
      return;
    }
  }

  // Anchor lépés megjelenítése (ismeretlen ciklus)
  document.getElementById('step-subgroup').style.display = 'none';
  show('step-anchor');
  document.getElementById('step-anchor').scrollIntoView({behavior:'smooth',block:'start'});
  if (!document.getElementById('anchor-date').value) {
    document.getElementById('anchor-date').value = new Date().toISOString().split('T')[0];
  }
  checkAnchorReady();
}

// ──────────────────────────────────────────────────────────────────
//  SUBGROUP PICKER: csoporton belüli fázis-variánsok keresése
// ──────────────────────────────────────────────────────────────────

// Megkeresi a csoport neveit → keresi őket egyéni bejegyzésként a DB-ben
// → csoportosítja eltérő _cycleStart (napra pontosan) szerint
// Ha KNOWN_CYCLES-ben subVariants van, azt használja elsősorban.
// Visszatér: [{cycleStart: Date, pattern: [], names: []}, ...]
function _findSubgroupVariants(groupEntry) {
  const knownKey = _findKnownCycleKeyForGroup(groupEntry);
  const knownData = knownKey ? KNOWN_CYCLES[knownKey] : null;
  const basePattern = knownData ? knownData.pattern : groupEntry.pattern;

  // 1) KNOWN_CYCLES.subVariants – beégetett fázisok (pl. H10/G3)
  if (knownData && Array.isArray(knownData.subVariants) && knownData.subVariants.length >= 2) {
    return knownData.subVariants.map(sv => ({
      cycleStart: sv.cycleStart instanceof Date ? sv.cycleStart : new Date(sv.cycleStart),
      pattern: basePattern,
      names: sv.names || []
    }));
  }

  // 2) DB-ből egyéni __p__ bejegyzések alapján
  const groupNamesNorm = (groupEntry.names || []).map(n => _normNameSg(n));
  const personEntries = [];

  Object.values(DB).forEach(entry => {
    if (!entry.id.startsWith('__p__')) return;
    const entryNames = entry.names || [];
    const matches = entryNames.filter(n => groupNamesNorm.some(gn => _normNameSg(n) === gn));
    if (!matches.length) return;
    if (!entry._cycleStart) return;
    const cs = entry._cycleStart instanceof Date ? entry._cycleStart : new Date(entry._cycleStart);
    if (isNaN(cs.getTime())) return;
    personEntries.push({ names: matches, cycleStart: cs, pattern: entry.pattern || basePattern });
  });

  if (!personEntries.length) return [];

  // Csoportosítás cycleStart nap szerint (± 1 nap tolerancia)
  const variants = [];
  personEntries.forEach(pe => {
    const csTime = pe.cycleStart.getTime();
    const existing = variants.find(v => Math.abs(v.cycleStart.getTime() - csTime) <= 86400000);
    if (existing) {
      pe.names.forEach(n => { if (!existing.names.includes(n)) existing.names.push(n); });
    } else {
      variants.push({ cycleStart: new Date(pe.cycleStart), pattern: pe.pattern, names: [...pe.names] });
    }
  });

  if (variants.length < 2) return [];
  variants.sort((a,b) => a.cycleStart - b.cycleStart);
  return variants;
}

function _normNameSg(s) {
  return (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[,.\-\s]+/g,' ').trim();
}

// Megkeresi a KNOWN_CYCLES kulcsot a csoportbejegyzés dept/id alapján
function _findKnownCycleKeyForGroup(g) {
  // dept pl: "1.3 - H10/G3" vagy "H10/G3" vagy id "1.3_H10_G3"
  function normKC(s) { return (s||'').toLowerCase().replace(/[\/.\-_\s]/g,''); }
  const deptN = normKC(g.dept);
  const idN = normKC(g.id);
  return Object.keys(KNOWN_CYCLES).find(k => {
    const kn = normKC(k);
    return kn === idN || kn === deptN || deptN.includes(kn) || idN.includes(kn);
  }) || null;
}

// Rendereli a fázis-választó mini naptárakat
function renderSubgroupPicker(groupEntry, variants, searchName) {
  const container = document.getElementById('subgroup-list');
  container.innerHTML = '';

  const today = new Date(); today.setHours(0,0,0,0);
  const searchNorm = _normNameSg(searchName);
  const DAY_LETTERS = ['H','K','Sz','Cs','P','Sz','V'];

  // Keresett névhez legjobb egyezés meghatározása
  const matchScores = variants.map(v => {
    if (!searchNorm) return 0;
    const best = v.names.reduce((acc, n) => {
      const nn = _normNameSg(n);
      // Részleges egyezés is elég (searchNorm minden szava benne van)
      const parts = searchNorm.split(' ').filter(Boolean);
      if (parts.length && parts.every(w => nn.includes(w))) return 2;
      if (nn.includes(searchNorm) || searchNorm.includes(nn.split(' ')[0])) return 1;
      return acc;
    }, 0);
    return best;
  });
  const maxScore = Math.max(...matchScores);
  const highlightIdx = maxScore > 0 ? matchScores.indexOf(maxScore) : -1;

  variants.forEach((v, vi) => {
    const isHighlighted = vi === highlightIdx;
    const card = document.createElement('div');
    card.className = 'subgroup-card fadein' + (isHighlighted ? ' sg-highlighted' : '');

    // Header
    const cycleLen = (v.pattern || []).length || '?';
    const csLabel = v.cycleStart.toLocaleDateString('hu-HU', {year:'numeric',month:'long',day:'numeric'});
    const namesToShow = v.names.slice(0,4).join(', ') + (v.names.length > 4 ? ' +' + (v.names.length-4) : '');

    let headerHTML = `<div class="sg-header">
      <span class="sg-cycle-id">Fázis ${vi+1}</span>
      <span class="sg-cycle-len">${cycleLen} napos ciklus · kezdet: ${csLabel}</span>
      ${isHighlighted ? '<span class="sg-match-badge">✓ Névegyezés</span>' : ''}
    </div>
    <div class="sg-names">${namesToShow}</div>`;

    // Mini naptár: következő 14 nap
    let miniCalHTML = '<div class="mini-cal">';
    // Fejlécek (nap betűjele az adott naphoz)
    for (let d = 0; d < 14; d++) {
      const date = new Date(today); date.setDate(date.getDate() + d);
      const dow = date.getDay(); // 0=V,1=H,...6=Sz
      const isWe = dow === 0 || dow === 6;
      const letter = ['V','H','K','Sz','Cs','P','Sz'][dow];
      miniCalHTML += `<div class="mc-hdr${isWe?' we':''}">${letter}</div>`;
    }
    // Napok
    for (let d = 0; d < 14; d++) {
      const date = new Date(today); date.setDate(date.getDate() + d);
      const isToday = d === 0;
      const shift = shiftOnDate(v.pattern, v.cycleStart, date);
      const dayNum = date.getDate();
      miniCalHTML += `<div class="mc-cell${isToday?' mc-today':''}">
        <div class="mc-day">${String(dayNum).padStart(2,'0')}</div>
        <div class="mc-shift mcs-${shift}">${shift}</div>
      </div>`;
    }
    miniCalHTML += '</div>';

    card.innerHTML = headerHTML + miniCalHTML;

    card.addEventListener('click', () => {
      document.querySelectorAll('#subgroup-list .subgroup-card').forEach(c => c.classList.remove('sg-selected'));
      card.classList.add('sg-selected');

      // Kiválasztott variáns alkalmazása a selectedGroup-ra
      selectedGroup = {
        ...groupEntry,
        _cycleStart: v.cycleStart,
        pattern: v.pattern.map(s => s || 'X'),
        blocks: rawToBlocks(v.pattern.map(s => s || 'X')),
        _subVariantNames: v.names
      };

      hide('step-anchor');
      document.getElementById('step-subgroup').style.display = 'block';
      show('step-generate');
      const todayD = new Date(); todayD.setHours(0,0,0,0);
      _initGenSelects();
      document.getElementById('gen-btn').disabled = false;
      showStatus('✅ ' + ((window._currentTranslations&&window._currentTranslations.rwCycleApplied)||'Fázis kiválasztva') + ' ' + (vi+1) + ': ' + (v.names[0]||groupEntry.dept), 'ok');
      document.getElementById('step-generate').scrollIntoView({behavior:'smooth',block:'start'});
    });

    container.appendChild(card);
  });
}

// ══════════════════════════════════════════════════════
//  MANUÁLIS BLOKK SZERKESZTŐ
// ══════════════════════════════════════════════════════
let _manualBlocks = [];

function renderBlockEditor() {
  const wrap = document.getElementById('block-rows');
  wrap.innerHTML = '';
  _manualBlocks.forEach((b, i) => {
    const row = document.createElement('div');
    row.className = 'block-row fadein';
    row.innerHTML = `
      <select class="block-sel">
        ${SHIFT_VALS.map(s=>`<option value="${s}"${s===b.shift?' selected':''}>${s}</option>`).join('')}
      </select>
      <span style="font-size:12px;color:var(--mut)">×</span>
      <input type="number" class="block-cnt" value="${b.count}" min="1" max="60">
      <button class="block-del" title="Törlés">×</button>`;
    row.querySelector('select').addEventListener('change', e => { _manualBlocks[i].shift = e.target.value; renderBlockEditor(); });
    row.querySelector('input').addEventListener('input',  e => { _manualBlocks[i].count = parseInt(e.target.value)||1; renderBlockEditor(); });
    row.querySelector('.block-del').addEventListener('click', () => { _manualBlocks.splice(i,1); renderBlockEditor(); });
    wrap.appendChild(row);
  });
  // Preview
  const pat = blocksToPattern(_manualBlocks);
  const prev = document.getElementById('block-preview');
  prev.innerHTML = '';
  pat.slice(0,42).forEach(s => {
    const d = document.createElement('div');
    d.className = `bp-badge bp-${s}`;
    d.textContent = s;
    prev.appendChild(d);
  });
  if (pat.length > 42) {
    const d = document.createElement('div');
    d.className = 'bp-badge bp-X';
    d.textContent = '…';
    prev.appendChild(d);
  }
  document.getElementById('block-info').textContent = pat.length ? (window._currentTranslations&&window._currentTranslations.rcCycleLabel||'Ciklus: {n} nap').replace('{n}', pat.length) : '';
  // Ha selectedGroup van, frissítjük a pattern-t
  if (selectedGroup) {
    selectedGroup.blocks = _manualBlocks;
    selectedGroup.pattern = pat;
  }
}

// ══════════════════════════════════════════════════════
//  ANCHOR (HORGONY DÁTUM) LOGIKA
// ══════════════════════════════════════════════════════
function checkAnchorReady() {
  const hasDate  = !!document.getElementById('anchor-date').value;
  const hasShift = !!anchorShift;
  document.getElementById('calc-phase-btn').disabled = !(hasDate && hasShift);
}

function calcPhase() {
  if (!selectedGroup || !anchorShift) return;
  const dateStr = document.getElementById('anchor-date').value;
  if (!dateStr) return;
  anchorDate = new Date(dateStr + 'T00:00:00');
  const pattern = selectedGroup.pattern;
  if (!pattern.length) { showStatus((window._currentTranslations&&window._currentTranslations.rwNoCycleGroup)||'⚠️ Nincs ciklus mintáz adott csoporthoz','warn'); return; }

  const result = calcPhaseFromAnchor(pattern, anchorDate, anchorShift);
  const resultDiv = document.getElementById('phase-result');

  if (result === null) {
    resultDiv.innerHTML = `⚠️ <strong>${anchorShift}</strong> ${(window._currentTranslations&&window._currentTranslations.rwShiftNotInCycle)||'nem szerepel a ciklusban'} (${pattern.join(' ')}). Ellenőrizd a ciklust!`;
    resultDiv.style.display = 'block';
    return;
  }

  let offsets = Array.isArray(result) ? result : [result];

  // Ha több lehetséges offset van, megkérdezzük a felhasználót
  if (offsets.length > 1) {
    // Megmutatjuk az összes opciót mint chipeket
    resultDiv.innerHTML = `<strong>${offsets.length} ${(window._currentTranslations&&window._currentTranslations.rwPossiblePhases)||'lehetséges fázis – válassz:'}</strong> a(z) <strong style="color:var(--${anchorShift})">${anchorShift}</strong> alapján – válassz:<br><br>` +
      offsets.map((o,i) => {
        // Megmutatjuk mi lenne a következő 5 nap
        const next5 = Array.from({length:5},(_,j) => pattern[(o+1+j)%pattern.length]);
        return `<span data-offset="${o}" style="cursor:pointer;display:inline-flex;align-items:center;gap:4px;padding:5px 10px;border-radius:8px;background:var(--surf2);border:1.5px solid var(--brd);margin:3px;font-size:11px;">
          Pozíció ${o+1}: ${anchorShift} → ${next5.map(s=>`<span style="color:var(--${s})">${s}</span>`).join(' ')}
        </span>`;
      }).join('');
    resultDiv.style.display = 'block';

    resultDiv.querySelectorAll('[data-offset]').forEach(el => {
      el.addEventListener('click', () => {
        resultDiv.querySelectorAll('[data-offset]').forEach(e => e.style.borderColor='var(--brd)');
        el.style.borderColor = 'var(--U)';
        phaseOffset = parseInt(el.dataset.offset);
        applyPhase(phaseOffset);
      });
    });
    return;
  }

  phaseOffset = offsets[0];
  applyPhase(phaseOffset);
}

function applyPhase(offset) {
  const pattern = selectedGroup.pattern;
  const cycleStart = calcCycleStart(anchorDate, offset);
  // Következő 7 nap előnézet
  const preview = Array.from({length:7}, (_,i) => {
    const d = new Date(anchorDate); d.setDate(d.getDate()+i);
    const s = shiftOnDate(pattern, cycleStart, d);
    const dn = d.toLocaleDateString('hu-HU',{month:'short',day:'numeric'});
    return `<span style="color:var(--${s});font-weight:600">${dn}:${s}</span>`;
  }).join('  ');

  const resultDiv = document.getElementById('phase-result');
  resultDiv.innerHTML = `✓ ${(window._currentTranslations&&window._currentTranslations.rwPhaseDetermined)||'Fázis meghatározva – cikluspozíció:'} <strong>${offset+1}/${pattern.length}</strong><br>` +
    `Ciklus kezdete: <strong>${cycleStart.toLocaleDateString('hu-HU')}</strong><br>` +
    `Következő 7 nap: ${preview}`;
  resultDiv.style.display = 'block';

  // Mentjük a cycleStart-ot a selectedGroup-ba
  selectedGroup._cycleStart = cycleStart;

  // Léptetés a generálás lépésre
  show('step-generate');
  // Dátumtartomány alapértelmezés: mai naptól 6 hónapig
  const today = new Date(); today.setHours(0,0,0,0);
  const sixMonths = new Date(today); sixMonths.setMonth(sixMonths.getMonth()+6);
  _initGenSelects();
  document.getElementById('gen-btn').disabled = false;
  document.getElementById('step-generate').scrollIntoView({behavior:'smooth',block:'start'});
}

// ══════════════════════════════════════════════════════
//  NAPTÁR WIDGET
// ══════════════════════════════════════════════════════
function getHolidays(year) {
  const h = new Set();
  function easter(y) {
    const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25);
    const g=Math.floor((b-f+1)/3),h2=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4;
    const l=(32+2*e+2*i-h2-k)%7,m2=Math.floor((a+11*h2+22*l)/451);
    const month=Math.floor((h2+l-7*m2+114)/31),day=((h2+l-7*m2+114)%31)+1;
    return new Date(y,month-1,day);
  }
  function addD(d,n){const r=new Date(d);r.setDate(r.getDate()+n);return r;}
  function key(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  const e=easter(year);
  [new Date(year,0,1),addD(e,-2),addD(e,1),new Date(year,4,1),addD(e,39),
   addD(e,50),new Date(year,9,3),new Date(year,11,25),new Date(year,11,26),
   new Date(year,0,6),addD(e,60),new Date(year,10,1)].forEach(d=>h.add(key(d)));
  return h;
}
function dKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function dLabel(d){return d?`${d.getFullYear()}. ${MN_HU[d.getMonth()]} ${d.getDate()}.`:'–';}

function _initGenSelects() {
  const today = new Date();
  const curY = today.getFullYear();
  const curM = today.getMonth();
  const months = MN_HU;
  const years = Array.from({length: 11}, (_, i) => curY + i);

  ['gen-from-month','gen-to-month'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel || sel.options.length > 0) return;
    months.forEach((m, i) => {
      const o = document.createElement('option');
      o.value = i; o.textContent = m;
      sel.appendChild(o);
    });
  });
  ['gen-from-year','gen-to-year'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel || sel.options.length > 0) return;
    years.forEach(y => {
      const o = document.createElement('option');
      o.value = y; o.textContent = y;
      sel.appendChild(o);
    });
  });

  // Defaults: from = this month, to = +5 months
  const fromM = document.getElementById('gen-from-month');
  const fromY = document.getElementById('gen-from-year');
  const toM   = document.getElementById('gen-to-month');
  const toY   = document.getElementById('gen-to-year');

  if (fromM) fromM.value = curM;
  if (fromY) fromY.value = curY;
  const endDate = new Date(curY, curM + 5, 1);
  if (toM) toM.value = endDate.getMonth();
  if (toY) toY.value = endDate.getFullYear();

  function onSelChange() {
    const fM = parseInt(fromM.value), fY = parseInt(fromY.value);
    const tM = parseInt(toM.value),   tY = parseInt(toY.value);
    _cal.startDate = new Date(fY, fM, 1);
    _cal.endDate   = new Date(tY, tM+1, 0); // last day of to-month
    _cal.year = fY; _cal.month = fM;
    document.getElementById('gen-btn').disabled = !(selectedGroup && selectedGroup._cycleStart &&
      _cal.endDate >= _cal.startDate);
  }

  [fromM, fromY, toM, toY].forEach(sel => {
    if (sel) sel.addEventListener('change', onSelChange);
  });
  onSelChange();
}

// ══════════════════════════════════════════════════════
//  GENERÁLÁS
// ══════════════════════════════════════════════════════
function generate() {
  if(!selectedGroup||!_cal.startDate||!_cal.endDate||!selectedGroup._cycleStart) return;
  // Pattern null/undefined tisztítás
  const pattern = (selectedGroup.pattern || []).map(s => (s === null || s === undefined) ? 'X' : s);
  if (!pattern.length) { showStatus((window._currentTranslations&&window._currentTranslations.rwMissingCycle)||'⚠️ Hiányzó ciklus minta!', 'warn'); return; }
  // cycleStart mindig Date objektum
  const cycleStart = selectedGroup._cycleStart instanceof Date
    ? selectedGroup._cycleStart : new Date(selectedGroup._cycleStart);
  if (isNaN(cycleStart.getTime())) { showStatus((window._currentTranslations&&window._currentTranslations.rwBadCycleDate)||'⚠️ Hibás ciklus kezdődátum!', 'warn'); return; }
  const holidays = getHolidays(_cal.startDate.getFullYear());
  const holidays2 = _cal.endDate.getFullYear()!==_cal.startDate.getFullYear()
    ? getHolidays(_cal.endDate.getFullYear()) : new Set();
  const allHolidays = new Set([...holidays, ...holidays2]);

  generatedData = [];
  const knownDays = selectedGroup._knownDays || {};
  let cur = new Date(_cal.startDate);
  while (cur <= _cal.endDate) {
    const y = cur.getFullYear(), m = cur.getMonth()+1;
    let monthEntry = generatedData.find(e=>e.year===y&&e.month===m);
    if(!monthEntry){ monthEntry={year:y,month:m,days:[]}; generatedData.push(monthEntry); }
    const isHol = allHolidays.has(dKey(cur));
    const curKey = dKey(cur);
    const shift = knownDays[curKey] !== undefined ? knownDays[curKey] : shiftOnDate(pattern, cycleStart, cur);
    monthEntry.days.push({ day:cur.getDate(), shift, holiday:isHol });
    cur.setDate(cur.getDate()+1);
  }

  renderGeneratedCal();
  const genCal = document.getElementById('gen-cal');
  genCal.style.display = 'block';
  genCal.scrollIntoView({behavior:'smooth',block:'start'});
}

function renderGeneratedCal() {
  const container = document.getElementById('gen-months');
  container.innerHTML = '';
  const DAY_HDRS = ['H','K','Sz','Cs','P','Sz','V'];

  generatedData.forEach(({year,month,days}) => {
    const card = document.createElement('div');
    card.className = 'gen-month fadein';

    // Header stats
    const stats = {F:0,S:0,N:0,X:0};
    days.forEach(({shift,holiday})=>{ if(!holiday&&shift in stats) stats[shift]++; });
    card.innerHTML = `<div class="gen-month-hdr">
      <div class="gen-month-title">${MN_HU[month-1]} ${year}</div>
      <div class="gen-month-stats">
        ${Object.entries(stats).map(([s,c])=>`<span class="gen-ms gen-ms-${s}">${s}:${c}</span>`).join('')}
      </div>
    </div>`;

    // Grid
    const grid = document.createElement('div');
    grid.className = 'gen-grid';
    DAY_HDRS.forEach((d,i)=>{ const h=document.createElement('div'); h.className='gen-day-hdr'+(i>=5?' we':''); h.textContent=d; grid.appendChild(h); });

    const firstDay = new Date(year,month-1,1).getDay();
    const startOffset = (firstDay+6)%7;
    for(let i=0;i<startOffset;i++) grid.appendChild(document.createElement('div'));

    days.forEach(({day:dn,shift:s,holiday}) => {
      const dow = new Date(year,month-1,dn).getDay();
      const isWe = dow===0||dow===6;
      const cell = document.createElement('div');
      cell.className = 'gen-day-cell'+(isWe?' we':'')+(holiday?' holiday':'');
      const label = holiday ? '🎉' : s;
      const cls   = holiday ? 'gds-X' : `gds-${s}`;
      cell.innerHTML = `<div class="gen-day-num">${String(dn).padStart(2,'0')}</div>
        <div class="gen-day-shift ${cls}" title="${holiday?'Ünnepnap':''}">${label}</div>`;
      grid.appendChild(cell);
    });
    card.appendChild(grid);
    container.appendChild(card);
  });
}

// ══════════════════════════════════════════════════════
//  EXPORT
// ══════════════════════════════════════════════════════
function exportCSV() {
  if(!generatedData.length) return;
  const DAY_SH=['V','H','K','Sz','Cs','P','Sz'];
  let csv = 'Dátum,Év,Hónap,Nap,Nap neve,Műszak,Ünnepnap\n';
  generatedData.forEach(({year,month,days}) => {
    days.forEach(({day:dn,shift:s,holiday}) => {
      const date=new Date(year,month-1,dn);
      csv+=`${year}.${String(month).padStart(2,'0')}.${String(dn).padStart(2,'0')},${year},${month},${dn},${DAY_SH[date.getDay()]},${s},${holiday?'igen':''}\n`;
    });
  });
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'}));
  a.download=`rotacio_${(selectedGroup?.id||'export')}_${new Date().getFullYear()}.csv`;
  a.click();
}
function copyToClipboard() {
  if(!generatedData.length) return;
  let t = ((window._currentTranslations&&window._currentTranslations.rcRotationHeader)||'Rotáció – {id} ({n} napos ciklus)').replace('{id}', selectedGroup?.id||'').replace('{n}', selectedGroup?.pattern?.length||'?') + '\n\n';
  generatedData.forEach(({year,month,days}) => {
    t += `${MN_HU[month-1]} ${year}: ${days.map(d=>d.holiday?'🎉':d.shift).join(' ')}\n`;
  });
  navigator.clipboard.writeText(t).then(()=>showStatus((window._currentTranslations&&window._currentTranslations.rwCopied)||'✓ Vágólapra másolva!','ok'));
}

// ══════════════════════════════════════════════════════
//  TÁROLT ADATOK MEGJELENÍTÉSE
// ══════════════════════════════════════════════════════
function renderStoredInfo() {
  const el = document.getElementById('stored-info');
  const count = Object.keys(DB).length;
  if(!count){ el.innerHTML=''; return; }

  // Duplikátumok detektálása (azonos id, különböző kulcs)
  const idCount = {};
  Object.values(DB).forEach(g => { idCount[g.id] = (idCount[g.id]||0)+1; });
  const hasDups = Object.values(idCount).some(c => c > 1);
  const dupInfo = hasDups
    ? `<span style="color:var(--acc2);cursor:pointer;font-size:11px;text-decoration:underline" id="fix-dups-btn">⚠️ Duplikátumok találhatók – kattints a javításhoz</span>`
    : '';

  el.innerHTML = `<div class="stored-badge">💾 ${count} ${(window._currentTranslations&&window._currentTranslations.rwStoredCycles)||'tárolt ciklus elérhető'}</div> ${dupInfo}`;

  if(hasDups) {
    document.getElementById('fix-dups-btn').addEventListener('click', () => {
      // Kézi deduplikálás: azonos id-jű bejegyzéseknél a legjobban megtartjuk
      const seenIds = new Map();
      Object.keys(DB).forEach(key => {
        const id = DB[key].id;
        if(seenIds.has(id)) {
          const firstKey = seenIds.get(id);
          // Megtartjuk azt amelyiknek van _cycleStart és több havi adata van
          const firstMonths = Object.keys(DB[firstKey].monthlyData||{}).length;
          const curMonths   = Object.keys(DB[key].monthlyData||{}).length;
          const keepKey  = (DB[firstKey]._cycleStart && firstMonths >= curMonths) ? firstKey : key;
          const dropKey  = keepKey === firstKey ? key : firstKey;
          // Mergeljük a neveket és havi adatokat
          const ns = new Set([...DB[keepKey].names, ...DB[dropKey].names]);
          DB[keepKey].names = [...ns];
          Object.assign(DB[keepKey].monthlyData||{}, DB[dropKey].monthlyData||{});
          delete DB[dropKey];
          seenIds.set(id, keepKey);
        } else {
          seenIds.set(id, key);
        }
      });
      dbSave();
      renderStoredInfo();
      renderGroupList();
      showStatus((window._currentTranslations&&window._currentTranslations.rwDupsRemoved)||'✅ Duplikátumok eltávolítva!', 'ok');
    });
  }
}


// ══════════════════════════════════════════════════════
//  GYORS BEVITEL – INTERAKTÍV NAPTÁR + CIKLUS FELISMERÉS
// ══════════════════════════════════════════════════════
const _qShifts = {};
let _qYear = new Date().getFullYear();
let _qMonth = new Date().getMonth();
let _qActiveShift = 'S';

function dKeyQ(d) {
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
}

function _qLoadFromChronos() {
  try {
    if (!window._chronosState) return;
    const st = window._chronosState();
    const schedules = st.schedules || {};
    const shiftMap = { 'Früh':'F', 'Spät':'S', 'Nacht':'N' };
    let loaded = 0;
    Object.entries(schedules).forEach(([key, ids]) => {
      for (const id of ids) {
        // state.schedules kulcs: "2026-1-3" (nincs padding) → dKeyQ: "2026-01-03"
        // Normalizáljuk a kulcsot hogy egyezzen a dKeyQ formátummal
        const parts = key.split('-');
        if (parts.length === 3) {
          const normalized = parts[0] + '-' + parts[1].padStart(2,'0') + '-' + parts[2].padStart(2,'0');
          if (shiftMap[id]) { _qShifts[normalized] = shiftMap[id]; loaded++; break; }
        }
      }
    });
    if (loaded > 0) {
      const months = {};
      Object.keys(_qShifts).forEach(k => { const ym = k.substring(0,7); months[ym] = (months[ym]||0)+1; });
      const best = Object.entries(months).sort((a,b)=>b[1]-a[1])[0];
      if (best) { const [y,m] = best[0].split('-').map(Number); _qYear = y; _qMonth = m-1; }
      renderQCal(); qDetect();
      const btn = document.getElementById('q-load-chronos-btn');
      if (btn) {
        const tr = (window._currentTranslations && window._currentTranslations.qLoadCalOk || '✅ {n} nap betöltve').replace('{n}', loaded);
        btn.textContent = tr; btn.style.borderColor = 'rgba(74,222,128,0.5)'; btn.style.background = 'rgba(74,222,128,0.08)'; btn.style.color = '#4ade80';
      }
    } else {
      const btn = document.getElementById('q-load-chronos-btn');
      if (btn) {
        const tr = window._currentTranslations && window._currentTranslations.qLoadCalEmpty || '⚠️ Nincs műszak a naptárban';
        btn.textContent = tr; btn.style.borderColor = 'rgba(255,179,71,0.5)'; btn.style.color = '#ffb347';
      }
    }
  } catch(e) {}
}
window._qLoadFromChronos = _qLoadFromChronos;

function initQuickInput() {
  document.getElementById('q-prev').addEventListener('click', () => {
    _qMonth--; if(_qMonth<0){_qMonth=11;_qYear--;} renderQCal();
  });
  document.getElementById('q-next').addEventListener('click', () => {
    _qMonth++; if(_qMonth>11){_qMonth=0;_qYear++;} renderQCal();
  });
  document.querySelectorAll('.qsb').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.qsb').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      _qActiveShift = btn.dataset.qs;
    });
  });
  document.querySelector('.qsb-S').classList.add('active');
  document.getElementById('q-apply-btn').addEventListener('click', qApply);
  renderQCal();
}

function renderQCal() {
  const grid = document.getElementById('q-grid');
  grid.innerHTML = '';
  document.getElementById('q-title').textContent = MN_HU[_qMonth] + ' ' + _qYear;
  const DAY_H = ['H','K','Sz','Cs','P','Sz','V'];
  DAY_H.forEach((d,i) => {
    const h = document.createElement('div');
    h.textContent = d;
    h.style.cssText = 'text-align:center;font-size:9px;padding:2px 0 4px;color:'+(i>=5?'rgba(255,106,138,.5)':'var(--mut)')+';font-family:"DM Mono",monospace;';
    grid.appendChild(h);
  });
  const offset = (new Date(_qYear,_qMonth,1).getDay()+6)%7;
  for(let i=0;i<offset;i++) grid.appendChild(document.createElement('div'));
  const days = new Date(_qYear,_qMonth+1,0).getDate();
  const todayKey = dKeyQ(new Date());
  const SCOL = {F:'var(--F)',S:'var(--S)',N:'var(--N)',X:'var(--mut)'};
  for(let d=1;d<=days;d++) {
    const date = new Date(_qYear,_qMonth,d);
    const key = dKeyQ(date);
    const sh = _qShifts[key]||'';
    const isWe = ((date.getDay()+6)%7)>=5;
    const isToday = key===todayKey;
    const cell = document.createElement('div');
    cell.className = 'qcell'+(sh?' qs-'+sh:'')+(isToday?' q-today':'');
    const num = document.createElement('div');
    num.textContent = d;
    num.style.cssText = 'font-size:10px;font-family:"DM Mono",monospace;color:'+(isWe?'rgba(255,106,138,.6)':'var(--mut)')+(isToday?';font-weight:900;color:var(--acc)':'');
    cell.appendChild(num);
    if(sh){
      const sl=document.createElement('div');
      sl.textContent=sh;
      sl.style.cssText='font-size:12px;font-weight:700;font-family:"DM Mono",monospace;color:'+SCOL[sh]+';';
      cell.appendChild(sl);
    }
    cell.addEventListener('click',()=>{
      if(_qActiveShift==='') delete _qShifts[key];
      else _qShifts[key]=_qActiveShift;
      renderQCal(); qDetect();
    });
    grid.appendChild(cell);
  }
}

function qDetect() {
  const entries = Object.entries(_qShifts)
    .filter(([,s])=>['F','S','N','X'].includes(s))
    .sort(([a],[b])=>a.localeCompare(b));
  const btn = document.getElementById('q-apply-btn');
  const res = document.getElementById('q-result');

  if(entries.length < 2){ res.style.display='none'; btn.disabled=true; return; }

  const SCOL = {F:'var(--F)',S:'var(--S)',N:'var(--N)',X:'var(--mut)'};
  const shiftName = {F:'Früh (délelőtt)',S:'Spät (délután)',N:'Nacht (éjszaka)',X:'Szabad'};

  // Az összes bejelölt nap lineáris pozíciója az első naptól számítva
  const dates = entries.map(([dk]) => new Date(dk+'T00:00:00'));
  const firstDate = dates[0];
  const lastDate  = dates[dates.length-1];
  const spanDays  = Math.round((lastDate - firstDate) / 86400000) + 1;

  // dayOffset (0,1,2,...) → shift
  const knownShifts = {};
  entries.forEach(([dk, ds]) => {
    const off = Math.round((new Date(dk+'T00:00:00') - firstDate) / 86400000);
    knownShifts[off] = ds;
  });
  const totalKnown = Object.keys(knownShifts).length;
  const knownArr   = Object.entries(knownShifts).map(([o,s])=>({off:parseInt(o),s}));

  // ── SCORE ──────────────────────────────────────────────────────
  // Meghatározzuk, hogy ha az firstDate a ciklus `phase` sorszámú napja,
  // hány bejelölt nap egyezik a pattern-nel.
  // Visszaad: { hits, misses }
  function scorePhase(pattern, phase) {
    let hits = 0, misses = 0;
    for(const {off, s} of knownArr) {
      const idx = ((phase + off) % pattern.length + pattern.length) % pattern.length;
      if(pattern[idx] === s) hits++; else misses++;
    }
    return {hits, misses};
  }

  // ── LEGJOBB FÁZIS egy adott mintára ───────────────────────────
  // Végigpróbálja az összes lehetséges fázist (0..pattern.length-1),
  // visszaadja a legjobbat és a megfelelő cycleStart-ot.
  // Tie-breaking: ha X napokat is jelöltek be a felhasználó, azok alapján;
  // különben a munkásnapok közti hézagok alapján becsüljük a fázist.
  function findBestPhase(pattern) {
    let best = {hits:-1, misses:9999, phase:0};
    // Ha van X bejelölve, egyszerű keresés
    const hasX = knownArr.some(e => e.s === 'X');
    for(let ph = 0; ph < pattern.length; ph++) {
      const sc = scorePhase(pattern, ph);
      // Prioritás: 1) több egyezés, 2) kevesebb eltérés
      if(sc.hits > best.hits || (sc.hits===best.hits && sc.misses < best.misses)) {
        best = {...sc, phase:ph};
      }
    }
    // Ha nincs X jelölve, próbáljuk finomítani a fázist a munkásnapok közti
    // hézagok alapján: a ciklus X pozícióit illesztjük a "nem bejelölt" napokra
    if(!hasX && best.misses === 0) {
      // Több fázis is tökéletes lehet (összes ugyanolyan hits/misses)
      // Keressük azt ahol a pattern X-jei esnek a bejelölt napok "közé"
      const candidates = [];
      for(let ph = 0; ph < pattern.length; ph++) {
        const sc = scorePhase(pattern, ph);
        if(sc.hits === best.hits && sc.misses === best.misses) {
          // Számoljuk meg hány bejelöletlen nap esik X pozícióra
          let xScore = 0;
          for(let off = 0; off < spanDays; off++) {
            if(knownShifts[off] !== undefined) continue; // bejelölt nap
            const idx = ((ph + off) % pattern.length + pattern.length) % pattern.length;
            if(pattern[idx] === 'X') xScore++;
          }
          candidates.push({ph, xScore});
        }
      }
      if(candidates.length > 0) {
        // A legtöbb X-egyezéssel rendelkező fázis a legvalószínűbb
        candidates.sort((a,b) => b.xScore - a.xScore);
        best.phase = candidates[0].ph;
      }
    }
    const cs = new Date(firstDate);
    cs.setDate(cs.getDate() - best.phase);
    return {...best, cycleStart: cs};
  }

  // ── MINTA VERSENY ─────────────────────────────────────────────
  let bestPattern = null, bestCycleStart = null, bestLabel = '';
  let bestHits = 0, bestMisses = 9999, bestPatLen = 9999;
  const perfectCandidates = []; // tökéletes egyezések gyűjtője

  function contest(pattern, labelStr) {
    const fit = findBestPhase(pattern);
    if(fit.hits === 0) return;
    // Tökéletes: minden ismert nap egyezik
    if(fit.misses === 0 && fit.hits === totalKnown) {
      perfectCandidates.push({
        pattern: pattern.slice(), cycleStart: new Date(fit.cycleStart),
        label: labelStr, phase: fit.phase
      });
    }
    const better =
      fit.hits > bestHits ||
      (fit.hits === bestHits && fit.misses < bestMisses) ||
      (fit.hits === bestHits && fit.misses === bestMisses && pattern.length < bestPatLen);
    if(better) {
      bestHits = fit.hits; bestMisses = fit.misses; bestPatLen = pattern.length;
      bestPattern = pattern; bestCycleStart = fit.cycleStart; bestLabel = labelStr;
    }
  }

  // 1. Tárolt csoportok – ezeknek ismerjük a pontos ciklusát
  Object.values(DB).forEach(g => {
    if(!g.pattern || g.pattern.length < 5) return;
    contest(g.pattern, g.id + ' – ' + g.dept + ' (' + g.pattern.length + ' napos)');
  });

  // 2. Standard 3-műszakos ciklusok (ha nincs tárolt vagy van eltérés)
  if(!bestPattern || bestMisses > 0) {
    const ORDERS = [
      ['F','S','N'],['S','N','F'],['N','F','S'],
      ['F','N','S'],['S','F','N'],['N','S','F']
    ];
    // [munka, szabad] pár per műszak – összesen 3 blokk
    const PAIRS = [
      [5,2],[7,0],[6,1],[4,3],[5,4],[7,2],[4,2],[3,4],[6,2],[7,3]
    ];
    // Aszimmetrikus ciklusok: [w0,r0, w1,r1, w2,r2]
    const ASYM = [
      // 30 napos változatok (pl. 7+3+7+3+7+3=30, vagy 7+3+6+3+7+4=30 stb.)
      [7,3, 7,3, 7,3],
      [7,3, 6,3, 7,4],
      [7,3, 7,4, 6,3],
      [6,3, 7,3, 7,4],
      [7,4, 6,3, 7,3],
      [6,4, 7,3, 7,3],
      [7,3, 6,4, 7,3],
      [6,3, 6,3, 7,5],  // 30
      [7,4, 7,3, 6,3],  // 30
      // 28 napos változatok
      [7,2, 7,2, 7,3],
      [7,3, 7,2, 7,2],
      [7,2, 7,3, 7,2],
      // 23-24 napos
      [5,2, 5,2, 5,4],
      [7,0, 7,0, 7,2],
      [5,3, 5,3, 5,3],
      [5,2, 7,0, 5,2],
      // 42 napos
      [7,7, 7,7, 7,7],
      [5,9, 5,9, 5,9],
    ];

    const pats = new Set();
    function tryPat(p) {
      const k = p.join('');
      if(pats.has(k)) return;
      pats.add(k);
      contest(p, (window._currentTranslations&&window._currentTranslations.rcDayCycle||'{n} napos ciklus').replace('{n}', p.length));
    }

    ORDERS.forEach(ord => {
      PAIRS.forEach(([w,r]) => {
        const p = [];
        for(let si=0;si<3;si++){
          for(let k=0;k<w;k++) p.push(ord[si]);
          for(let k=0;k<r;k++) p.push('X');
        }
        tryPat(p);
      });
      ASYM.forEach(cfg => {
        const p = [];
        for(let si=0;si<3;si++){
          const w=cfg[si*2], r=cfg[si*2+1];
          for(let k=0;k<w;k++) p.push(ord[si]);
          for(let k=0;k<r;k++) p.push('X');
        }
        tryPat(p);
      });
    });
  }

  // 3. Direkt szekvencia-felismerés: ha minden nap be van jelölve (nincs gap)
  //    és az előző lépések nem adtak tökéletes eredményt
  if(bestMisses > 0) {
    // Összegyűjtjük a hézag nélküli sorozatot
    const seq = [];
    let gapless = true;
    for(let i=0;i<spanDays;i++){
      if(knownShifts[i]!==undefined) seq.push(knownShifts[i]);
      else gapless = false;
    }
    if(gapless && seq.length >= 5) {
      // A sorozatból próbáljuk kinyerni a ciklust:
      // Ha a sorozat legalább 1,5× hosszabb mint a gyanított ciklus,
      // az ismétlődő blokkokat megtalálhatjuk.
      // Próbáljunk minden lehetséges ciklushosszt a seq hosszának feléig.
      for(let clen = 5; clen <= seq.length - 1; clen++) {
        // Vegyük a sorozat első clen elemét mint jelölt ciklus
        const cand = seq.slice(0, clen);
        // Számoljuk meg hány elem egyezik ha ezt ismételjük
        let hits = 0;
        for(let i=0;i<seq.length;i++){
          if(seq[i] === cand[i % clen]) hits++;
        }
        if(hits === seq.length) {
          // Tökéletes egyezés – de ez lehet hogy a seq-ből vesszük,
          // tehát a fázis = 0 (az első bejelölt nap a ciklus 0. pozícióján van)
          // Azonban lehet hogy a ciklus közepéről indultunk, ezért
          // a findBestPhase megkeresi a valódi fázist.
          contest(cand, (window._currentTranslations&&window._currentTranslations.rcDayCycleDetected||'{n} napos ciklus (felismert)').replace('{n}', clen));
          break; // az első (legrövidebb) teljes egyezés a legjobb
        }
      }
    }
  }

  // 4. Nincs elég adat
  if(!bestPattern || bestHits === 0) {
    res.style.display = 'block';
    res.innerHTML = ((window._currentTranslations&&window._currentTranslations.rwNoCycleFound)||'⚠️ Nem sikerült ciklust felismerni!') +
      `<br><span style="color:var(--mut);font-size:11px">${totalKnown} nap megadva eddig.</span>`;
    btn.disabled = true;
    return;
  }

  // 4b. Ha több tökéletes jelölt van: megmutatjuk mindegyiket, a felhasználó választ
  // Deduplikálás: csak különböző ciklustartalmakat mutatunk
  const dedupedCandidates = [];
  if(perfectCandidates.length > 1) {
    const seenPats = new Set();
    perfectCandidates.forEach(c => {
      // Azonos minta különböző fázissal = különböző jelölt (más F pozíció)
      const key = c.pattern.join('') + '|' + c.phase;
      if(!seenPats.has(key)) { seenPats.add(key); dedupedCandidates.push(c); }
    });
  }

  if(dedupedCandidates.length > 1) {
    // Szűrjük: csak azokat mutatjuk ahol a legközelebbi F-blokk dátuma különböző
    // (ha ugyanaz a ciklus, de más fázis → valódi különbség)
    const today2 = new Date(); today2.setHours(0,0,0,0);
    const chips = dedupedCandidates.slice(0, 6).map((c, i) => {
      // Következő 7 nap ebből a pozícióból
      const next7 = Array.from({length:7}, (_,j) => {
        const d = new Date(today2); d.setDate(today2.getDate()+j);
        const diff = Math.round((d - c.cycleStart)/86400000);
        const idx = ((diff % c.pattern.length) + c.pattern.length) % c.pattern.length;
        return c.pattern[idx];
      });
      const preview = next7.map(s => '<span style="color:'+SCOL[s]+';font-weight:700">'+s+'</span>').join(' ');
      return '<div data-ci="'+i+'" style="cursor:pointer;padding:8px 10px;border-radius:10px;background:var(--surf);border:1.5px solid var(--brd);margin:4px 0;font-size:11px;font-family:monospace;transition:border-color .15s;">' +
        '<span style="color:var(--mut)">'+c.label+'</span><br>Ma→7 nap: ' + preview + '</div>';
    }).join('');

    res.style.display = 'block';
    res.innerHTML = '<strong>'+dedupedCandidates.length+' '+((window._currentTranslations&&window._currentTranslations.rwCyclesFit)||'lehetséges ciklus illeszkedik – válaszd ki amelyik a valódit mutatja (ma melyik van?):')+'</strong><br><br>' + chips;
    btn.disabled = true;

    res.querySelectorAll('[data-ci]').forEach(el => {
      el.addEventListener('click', () => {
        res.querySelectorAll('[data-ci]').forEach(e => e.style.borderColor='var(--brd)');
        el.style.borderColor = 'var(--U)';
        const ci = parseInt(el.dataset.ci);
        const chosen = dedupedCandidates[ci];
        const knownDaysChosen = {};
        entries.forEach(([dk, ds]) => { knownDaysChosen[dk] = ds; });
        selectedGroup = {id:'Gyors', dept:chosen.label, names:[], blocks:rawToBlocks(chosen.pattern), pattern:chosen.pattern, _cycleStart:chosen.cycleStart, _knownDays:knownDaysChosen};
        btn.disabled = false;
      });
    });
    return;
  }

  // Átnevezés a belső változókra a megjelenítéshez
  const pattern = bestPattern;
  const cycleStart = bestCycleStart;
  const label = bestLabel;
  const bestMissesVal = bestMisses;

  const matchPct = Math.round(bestHits / totalKnown * 100);
  const matchCol = bestMissesVal === 0 ? 'var(--U)' : matchPct >= 70 ? 'var(--F)' : 'var(--acc2)';

  // Ma
  const today = new Date(); today.setHours(0,0,0,0);
  const todayDiff = Math.round((today - cycleStart) / 86400000);
  const todayIdx  = ((todayDiff % pattern.length) + pattern.length) % pattern.length;
  const todayShift = pattern[todayIdx];

  // Következő váltás
  let daysToChange = 0;
  for(let i=1; i<=pattern.length; i++){
    if(pattern[(todayIdx+i)%pattern.length] !== todayShift){ daysToChange=i; break; }
  }
  const nextShift = pattern[(todayIdx+daysToChange)%pattern.length];

  // 3 hetes előnézet
  const prev = Array.from({length:21}, (_,i) => {
    const d = new Date(today); d.setDate(today.getDate()+i);
    const diff = Math.round((d-cycleStart)/86400000);
    const idx = ((diff%pattern.length)+pattern.length)%pattern.length;
    const s = pattern[idx];
    const dn = (d.getMonth()+1)+'.'+String(d.getDate()).padStart(2,'0')+'.';
    const prevIdx = (((diff-1)%pattern.length)+pattern.length)%pattern.length;
    const isChange = i>0 && pattern[prevIdx]!==s;
    return '<span style="color:'+SCOL[s]+';font-weight:700'+(isChange?';text-decoration:underline':'')+'">'+dn+s+'</span>';
  }).join(' ');

  // Megadott napok ellenőrzése
  let checkHtml = '';
  if(bestMissesVal > 0) {
    const wrong = [];
    entries.forEach(([dk,ds]) => {
      const off = Math.round((new Date(dk+'T00:00:00')-firstDate)/86400000);
      const phase = Math.round((firstDate - cycleStart)/86400000);
      const idx = ((phase + off) % pattern.length + pattern.length) % pattern.length;
      if(pattern[idx]!==ds) wrong.push(dk+': te <b>'+ds+'</b> → ciklus: <b>'+pattern[idx]+'</b>');
    });
    if(wrong.length) checkHtml = '<span style="color:var(--acc2);font-size:11px">⚠️ Eltérő napok: '+wrong.join(', ')+'</span><br>';
  }

  // Cikluspozíció az első bejelölt napon
  const firstPhase = Math.round((firstDate - cycleStart) / 86400000);
  const firstPhaseIdx = ((firstPhase % pattern.length) + pattern.length) % pattern.length;

  const hasXMarked = entries.some(([,s]) => s === 'X');
  const xWarning = !hasXMarked && bestPattern && bestPattern.includes('X')
    ? '<br><span style="color:var(--F);font-size:11px">⚠️ Tipp: jelölj be néhány X (szabad) napot is a pontosabb felismeréshez!</span>'
    : '';

  res.style.display='block';
  const _ctr = window._currentTranslations || {};
  res.innerHTML =
    '✅ <strong>'+label+'</strong><br>'+
    (_ctr.rcMatchLabel||'Egyezés')+': <span style="color:'+matchCol+'"><strong>'+bestHits+'/'+totalKnown+' ('+matchPct+'%)</strong></span>'+
    (bestMissesVal===0 ? ' – '+(_ctr.rcPerfect||'tökéletes!') : '')+
    '<br>'+checkHtml+xWarning+'<br>'+
    (_ctr.rcFirstDayPhase||'Első bejelölt nap cikluspozíciója: ')+'<strong>'+(firstPhaseIdx+1)+'/'+pattern.length+'</strong><br>'+
    (_ctr.rcCycleSeq||'Ciklus')+': '+pattern.map(s=>'<span style="color:'+SCOL[s]+'">'+s+'</span>').join(' ')+'<br>'+
    '<br>📅 <strong>'+(_ctr.rcToday||'Ma')+' (<span style="color:'+SCOL[todayShift]+'">'+todayShift+'</span>)</strong> – '+shiftName[todayShift]+
    '  ⏭ '+(_ctr.rcNextChange||'Váltás')+': <strong>'+daysToChange+' '+(_ctr.rcDaysFromNow||'nap múlva')+' → <span style="color:'+SCOL[nextShift]+'">'+nextShift+'</span></strong><br>'+
    '<br><strong>'+(_ctr.rcNext3Weeks||'Következő 3 hét')+':</strong><br>'+prev;

  // Mentjük a bejelölt napokat is – ezeket a generálásnál fix értékként kezeljük
  const knownDays = {};
  entries.forEach(([dk, ds]) => { knownDays[dk] = ds; });
  selectedGroup={id:'Gyors',dept:label,names:[],blocks:rawToBlocks(pattern),pattern,_cycleStart:cycleStart,_knownDays:knownDays};
  btn.disabled=false;
}

function qApply(){
  if(!selectedGroup||!selectedGroup._cycleStart) return;
  const today=new Date();today.setHours(0,0,0,0);
  const sixM=new Date(today);sixM.setMonth(sixM.getMonth()+6);
  show('step-generate');
  _initGenSelects();
  document.getElementById('gen-btn').disabled=false;
  showStatus((window._currentTranslations&&window._currentTranslations.rwCycleApplied)||'✅ Ciklus alkalmazva','ok');
  document.getElementById('step-generate').scrollIntoView({behavior:'smooth',block:'start'});
}

// ══════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════
function init() {
  dbLoad();
  loadKnownCycles();
  renderStoredInfo();
  initQuickInput();
  show('step-quick');

  // Ha már van tárolt adat, egyből megmutatjuk a csoportlistát
  if(Object.keys(DB).length > 0) {
    renderGroupList();
    show('step-groups');
  }

  // Upload
  const fileInput = document.getElementById('file-input');
  const uploadZone = document.getElementById('upload-zone');
  fileInput.addEventListener('click', ()=>{ fileInput.value=''; });
  fileInput.addEventListener('change', e => {
    if(e.target.files.length) rotProcessFiles(Array.from(e.target.files));
  });
  uploadZone.addEventListener('dragover', e=>{ e.preventDefault(); uploadZone.classList.add('drag'); });
  uploadZone.addEventListener('dragleave', ()=>uploadZone.classList.remove('drag'));
  uploadZone.addEventListener('drop', e=>{
    e.preventDefault(); uploadZone.classList.remove('drag');
    if(e.dataTransfer.files.length) rotProcessFiles(Array.from(e.dataTransfer.files));
  });

  // Névkeresés
  document.getElementById('name-search').addEventListener('input', e => {
    renderGroupList(e.target.value);
    // Ha pontosan 1 találat → auto-select
    setTimeout(function() {
      var cards = document.querySelectorAll('#group-list .group-card');
      if (cards.length === 1) cards[0].click();
    }, 150);
  });

  // Manuális szerkesztő
  document.getElementById('add-block').addEventListener('click', ()=>{
    _manualBlocks.push({shift:'F',count:5}); renderBlockEditor();
  });
  document.getElementById('clear-blocks').addEventListener('click', ()=>{
    _manualBlocks=[]; renderBlockEditor();
  });

  // Anchor műszak pillek
  document.querySelectorAll('.shift-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.shift-pill').forEach(p=>p.classList.remove('active'));
      pill.classList.add('active');
      anchorShift = pill.dataset.shift;
      checkAnchorReady();
    });
  });
  document.getElementById('anchor-date').addEventListener('change', checkAnchorReady);
  document.getElementById('calc-phase-btn').addEventListener('click', calcPhase);

  // Naptár navigáció
  // cal-prev/cal-next removed (replaced by month/year selects)

  // Generálás
  document.getElementById('gen-btn').addEventListener('click', generate);

  // Export
  document.getElementById('exp-csv').addEventListener('click', exportCSV);
  document.getElementById('exp-copy').addEventListener('click', copyToClipboard);

  // ── 2. FEATURE: Chronos importálás ──
  document.getElementById('exp-chronos').addEventListener('click', importToChronos);

  // ── 3. FEATURE: Naptárból visszaolvasás ──
  tryLoadFromChronos();

  // Init calendar
  _initGenSelects();

  // ── AUTO-SELECT: mentett csoport automatikus betöltése ──
  // A DB és KNOWN_CYCLES már be van töltve, biztosan megtaláljuk
  (function() {
    var savedGroup = '';
    try {
      if (window._chronosState) {
        var _st = window._chronosState();
        savedGroup = (_st && _st.shiftGroup) || '';
      }
      if (!savedGroup) savedGroup = localStorage.getItem('chronos_user_shiftGroup') || '';
      if (!savedGroup) savedGroup = window._obPendingGroup || '';
    } catch(e) {}
    if (!savedGroup) return;

    // Keresés DB-ben és KNOWN_CYCLES-ban
    var allEntries = Object.values(DB);
    var known = (typeof KNOWN_CYCLES !== 'undefined') ? KNOWN_CYCLES : {};
    Object.entries(known).forEach(function(kv) {
      if (!DB[kv[0]] && !allEntries.find(function(x){ return x.id===kv[0]; })) {
        allEntries.push({ id: kv[0], dept: kv[1].dept, pattern: kv[1].pattern, names: [], _cycleStart: kv[1].cycleStart, blocks: rawToBlocks(kv[1].pattern) });
      }
    });

    var g = allEntries.find(function(x){ return x.id === savedGroup; });
    if (!g) {
      // KNOWN_CYCLES közvetlen elérés
      var kc = known[savedGroup];
      if (kc) g = { id: savedGroup, dept: kc.dept, pattern: kc.pattern, names: [], _cycleStart: kc.cycleStart, blocks: rawToBlocks(kc.pattern) };
    }
    if (!g) return;

    // blocks biztosítása
    if (!g.blocks && g.pattern) g.blocks = rawToBlocks(g.pattern);
    if (!g.blocks) g.blocks = [];

    // cycleStart biztosítása
    if (!g._cycleStart) {
      var kc2 = known[savedGroup];
      if (kc2 && kc2.cycleStart) g._cycleStart = kc2.cycleStart;
    }

    // Kiválasztás – selectGroup egyből generálós szekcióra ugrik ha van _cycleStart
    selectGroup(g);
  })();
}

// ── 2. FEATURE: importToChronos ──
function importToChronos() {
  if (!generatedData.length) return;
  if (!window._chronosState || !window._chronosSaveState || !window._chronosEnsureSchedules) {
    showChronosResult((window._currentTranslations && window._currentTranslations.rotChronosNotAvail) || '⚠️ Chronos nem elérhető – próbáld újra az app-on belül.', false);
    return;
  }
  const st = window._chronosState();
  window._chronosEnsureSchedules();
  function toShiftId(s) {
    if (s==='F') return 'Früh';
    if (s==='S') return 'Spät';
    if (s==='N') return 'Nacht';
    return null;
  }
  let imported = 0, skipped = 0;
  generatedData.forEach(({ year, month, days }) => {
    days.forEach(({ day, shift, holiday }) => {
      if (holiday) return;
      const shiftId = toShiftId(shift);
      if (!shiftId) return;
      const key = `${year}-${month}-${day}`;
      if (!st.schedules[key]) st.schedules[key] = [];
      if (!st.schedules[key].includes(shiftId)) { st.schedules[key].push(shiftId); imported++; }
      else skipped++;
    });
  });
  window._chronosSaveState();
  if (window._chronosRender) window._chronosRender();
  if (generatedData.length && window._chronosSetYearMonth) {
    window._chronosSetYearMonth(generatedData[0].year, generatedData[0].month - 1);
    if (window._chronosRender) window._chronosRender();
  }
  const _rtr = window._currentTranslations;
  showChronosResult(
    (typeof (_rtr && _rtr.rotImportOk) === 'function')
      ? _rtr.rotImportOk(imported, skipped)
      : `✅ ${imported} nap importálva (${skipped} már létezett, megtartva). Chronos naptár frissült!`,
    true
  );
  setTimeout(() => {
    window.closeRotationCreator();
    const calBtn = document.querySelector('.nav-item[data-view="calendar"]');
    if (calBtn) calBtn.click();
  }, 1000);
}

function showChronosResult(msg, ok) {
  const el = document.getElementById('exp-chronos-result');
  if (!el) return;
  el.textContent = msg;
  el.style.display = 'block';
  el.style.background = ok ? 'rgba(110,231,183,.1)' : 'rgba(255,106,138,.1)';
  el.style.color = ok ? '#6ee7b7' : '#ff6a8a';
  el.style.border = ok ? '1px solid rgba(110,231,183,.2)' : '1px solid rgba(255,106,138,.2)';
}

// ── 3. FEATURE: Naptárból visszaolvasás ──
function tryLoadFromChronos() {
  if (!window._chronosState) return;
  const st = window._chronosState();
  const schedules = st.schedules || {};
  const keys = Object.keys(schedules);
  // DB frissítés + KNOWN_CYCLES visszaállítás
  try { DB = JSON.parse(localStorage.getItem('rotApp_cycles_v1') || '{}'); } catch(e) { DB = {}; }
  Object.values(DB).forEach(g => {
    if (g._cycleStart && !(g._cycleStart instanceof Date)) g._cycleStart = new Date(g._cycleStart);
    if (Array.isArray(g.pattern)) g.pattern = g.pattern.map(s => s || 'X');
  });
  if (typeof loadKnownCycles === 'function') loadKnownCycles();

  const shiftMap = { 'Früh':'F', 'Spät':'S', 'Nacht':'N' };
  const dayEntries = [];
  keys.forEach(key => {
    const ids = schedules[key] || [];
    const parts = key.split('-');
    if (parts.length < 3) return;
    const y = parseInt(parts[0]), m = parseInt(parts[1]), d = parseInt(parts[2]);
    if (!y || !m || !d) return;
    let code = null;
    for (const id of ids) { if (shiftMap[id]) { code = shiftMap[id]; break; } }
    if (code) dayEntries.push({ date: new Date(y, m-1, d), code });
  });
  dayEntries.sort((a,b) => a.date - b.date);

  let matchedGroup = null, bestScore = 0;
  // Minimum 3 bejegyzés elég az egyezés ellenőrzéséhez
  if (dayEntries.length >= 3) {
    Object.values(DB).forEach(g => {
      if (!g.pattern || !g._cycleStart) return;
      const cs = g._cycleStart instanceof Date ? g._cycleStart : new Date(g._cycleStart);
      if (isNaN(cs.getTime())) return;
      let matches = 0;
      dayEntries.forEach(({ date, code }) => {
        const idx = Math.floor((date - cs) / 86400000);
        const pat = g.pattern.map(s => s || 'X');
        const expected = pat[((idx % pat.length) + pat.length) % pat.length];
        if (expected === code) matches++;
      });
      const score = matches / dayEntries.length;
      if (score > bestScore && score >= 0.75) { bestScore = score; matchedGroup = g; }
    });
  }
  // Ha nincs egyezés de van naptárban adat → felajánljuk az összes KNOWN_CYCLES csoportot
  if (!matchedGroup && dayEntries.length === 0) return;
  if (!matchedGroup) {
    // ── SZABAD DETEKTÁLÁS a naptár műszakjaiból ──
    if (dayEntries.length >= 10) {
      const epoch = new Date(2000, 0, 1);
      const SHIFT_VALS = ['F','S','N','X'];
      const dated = dayEntries
        .filter(e => SHIFT_VALS.includes(e.code))
        .map(e => ({ dayOffset: Math.round((e.date - epoch) / 86400000), shift: e.code }));
      if (dated.length >= 10) {
        const baseOffset = dated[0].dayOffset;
        const presentShifts = ['F','S','N'].filter(s => dated.some(e => e.shift === s));
        let freeDet = null, freeBest = -1;
        for (let clen = 10; clen <= 63; clen++) {
          for (let startOff = 0; startOff < clen; startOff++) {
            const pattern = new Array(clen).fill(null);
            let conflicts = 0;
            for (const e of dated) {
              const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
              if (pattern[idx] === null) pattern[idx] = e.shift;
              else if (pattern[idx] !== e.shift) conflicts++;
            }
            if (pattern.filter(x=>x!==null).length < Math.min(clen, dated.length)) continue;
            if (conflicts > dated.length * 0.08) continue;
            if (!presentShifts.every(s => pattern.includes(s))) continue;
            let hits = 0;
            for (const e of dated) {
              const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
              if (pattern[idx] === e.shift) hits++;
            }
            const pct = hits / dated.length;
            if (pct < 0.88) continue;
            const score = pct * clen;
            if (score > freeBest) {
              freeBest = score;
              const csEpoch = new Date(epoch.getTime() + (baseOffset - startOff) * 86400000);
              freeDet = { pattern: pattern.map(s => s || 'X'), confidence: Math.round(pct*100), _cycleStart: csEpoch };
            }
          }
        }
        if (freeDet && freeDet.confidence >= 88) {
          matchedGroup = {
            id: 'auto-' + freeDet.pattern.length + 'd',
            dept: 'Auto',
            pattern: freeDet.pattern,
            _cycleStart: freeDet._cycleStart,
            _fromSchedule: true,
            confidence: freeDet.confidence
          };
          bestScore = freeDet.confidence / 100;
        }
      }
    }
    if (!matchedGroup) {
      // Megmutatjuk a step-groups-t hogy csoportot válasszon
      renderGroupList();
      show('step-groups');
      return;
    }
  }
  const pct = Math.round(bestScore * 100);
  // Hint a step-groups kártyán belül (chronos-cycle-hint div)
  function _showChronosHint() {
    const hint = document.getElementById('chronos-cycle-hint');
    if (!hint) return;
    hint.innerHTML = `<div style="margin-bottom:10px;padding:10px 14px;background:rgba(110,231,183,.07);border:1px solid rgba(110,231,183,.2);border-radius:12px;font-size:12px;font-family:'DM Mono',monospace;">
      <div style="color:#6ee7b7;font-weight:600;margin-bottom:4px;">📅 ${matchedGroup._fromSchedule ? '🔍 Automatikusan felismert' : 'Chronos naptárból'}: ${pct}% egyezés</div>
      <div style="color:#a89dff;">${((window._currentTranslations&&window._currentTranslations.rcGroupSelectBtn)||'Csoport {id} · {n} napos ciklus').replace('{id}', matchedGroup.id).replace('{n}', matchedGroup.pattern.length)}</div>
      <button id="auto-load-btn" style="margin-top:8px;width:100%;padding:8px;border:none;border-radius:9px;background:linear-gradient(135deg,#7c6aff,#ff6a8a);color:#fff;font-size:13px;font-weight:600;cursor:pointer;">⚡ Betöltés PDF nélkül</button>
    </div>`;
    document.getElementById('auto-load-btn').addEventListener('click', function() {
      selectedGroup = matchedGroup;
      // Pattern null tisztítás
      if (Array.isArray(selectedGroup.pattern)) {
        selectedGroup.pattern = selectedGroup.pattern.map(s => (s === null || s === undefined) ? 'X' : s);
      }
      // _cycleStart mindig Date objektum legyen
      selectedGroup._cycleStart = selectedGroup._cycleStart instanceof Date
        ? selectedGroup._cycleStart : new Date(selectedGroup._cycleStart);
      show('step-generate');
      const today = new Date(); today.setHours(0,0,0,0);
      const sixM = new Date(today); sixM.setMonth(sixM.getMonth()+6);
      _cal.startDate = today; _cal.endDate = sixM;
      _initGenSelects();
      document.getElementById('gen-btn').disabled = false;
    });
  }
  // stored-info-ba is tesszük (step-upload kártya)
  const el = document.getElementById('stored-info');
  if (el) {
    const autoDiv = document.createElement('div');
    autoDiv.style.cssText = 'margin-top:8px;padding:10px 14px;background:rgba(110,231,183,.07);border:1px solid rgba(110,231,183,.2);border-radius:12px;font-size:12px;font-family:"DM Mono",monospace;';
    autoDiv.innerHTML = `<div style="color:#6ee7b7;font-weight:600;margin-bottom:3px;">📅 Chronos naptárból felismert: <b>${matchedGroup.id}</b> (${pct}%)</div>`;
    el.appendChild(autoDiv);
  }
  // step-groups megjelenésekor hint megmutatása
  renderGroupList();
  show('step-groups');
  _showChronosHint();
}

document.addEventListener('DOMContentLoaded', init);
})();



window.openRotationCreator = function() {
  var o = document.getElementById('rotWidgetOverlay');
  if(o) { o.style.display='block'; document.body.style.overflow='hidden'; }
  // Naptárból felismerés újrafuttatása megnyitáskor
  setTimeout(function() {
    if (typeof tryLoadFromChronos === 'function') tryLoadFromChronos();
  }, 100);
  // ── Gyors bevitel előtöltése a naptárból ──
  setTimeout(function() {
    if (typeof window._qLoadFromChronos === 'function') window._qLoadFromChronos();
  }, 150);
  // ── 1. Beállításokban mentett név + csoport automatikus betöltése ──
  var workerName = '';
  var shiftGroup = '';
  if (window._chronosState) {
    var st = window._chronosState();
    workerName = (st && st.workerName) || '';
    shiftGroup = (st && st.shiftGroup) || '';
  }
  if (!workerName) workerName = window._obPendingName || '';
  if (!shiftGroup) shiftGroup = localStorage.getItem('chronos_user_shiftGroup') || '';
  if (workerName && window._applyObName) {
    setTimeout(function() { window._applyObName(workerName); }, TIMING.OB_APPLY_NAME_ROT);
  }
  // ── Csoport szám előtöltése a fallback mezőbe (ha a névkeresés nem talál) ──
  if (shiftGroup) {
    setTimeout(function() {
      var fb = document.getElementById('groupid-fallback');
      if (fb && !fb.value) {
        fb.value = shiftGroup;
        fb.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, 400);
  }

  // ── 2. FEATURE: PDF import-ból már kinyert szövegek átadása ──
  // Ha a beosztás importban már fel volt töltve PDF, azt itt is használjuk
  setTimeout(function() {
    try {
      // pdfAllExtractedTexts a beosztás import globális változója
      // pdfAllExtractedTexts: vagy a globális window ref, vagy a lokális változó
      var texts = window.pdfAllExtractedTexts || [];
      var files = window.selectedFiles || [];
      if (texts.length > 0) {
        var textObjs = texts.map(function(txt, i) {
          return {
            text: txt,
            fileName: (files[i] && files[i].name) ? files[i].name : ('file' + i + '.pdf')
          };
        });
        // Rotation widget feldolgozása
        if (typeof window.rotAnalyzePdfTexts === 'function') {
          window.rotAnalyzePdfTexts(textObjs);
        }
        // Standalone rotation widget DB feltöltése
        if (typeof window.rwFeedPdfTexts === 'function') {
          window.rwFeedPdfTexts(textObjs);
        }
      }
    } catch(e) { /* hiba ne törje a megnyitást */ }
  }, 300);
};
window.closeRotationCreator = function() {
  var o = document.getElementById('rotWidgetOverlay');
  if(o) { o.style.display='none'; document.body.style.overflow=''; }
};
document.addEventListener('DOMContentLoaded', function() {
  var o = document.getElementById('rotWidgetOverlay');
  if(o) o.addEventListener('click', function(e) { if(e.target===o) window.closeRotationCreator(); });
});
