/* Chronos.App — fő alkalmazáslogika (Fázis 1 modularizáció)
   RÉSZ 4 + UI kiegészítések (fiók dialógus, névtér-aliasok, ...)
   Előfeltétel: js/chronos-i18n.js (window.TRANSLATIONS)
*/
'use strict';

  (function() {
    'use strict';

    /* ================================================================
     *  CHRONOS v3.0 – Főmodul  (RÉSZ 4: Chronos.App)
     *  ================================================================
     *  Ez a fájl legnagyobb, ~10 500 soros blokkja. A teljes futtatható
     *  kód EGY nagy (function(){ 'use strict'; ... })() IIFE-ben van,
     *  tehát minden itt deklarált const/function alapból PRIVÁT - csak
     *  azok érhetők el kívülről, amik explicit "window.<név> = ..."-ként
     *  exportálva vannak (lásd a blokk legvégén, "Globális hozzáférés a
     *  rotáció szkript számára" felirat alatt, és a "window.<fn> ="
     *  exportokat az egyes szekciókban).
     *
     *  SZEKCIÓK ÉS HOZZÁVETŐLEGES SORTARTOMÁNYOK (ebben a fájlban):
     *   1.  KONSTANSOK & ALAPÁLLAPOT         kb.   1 -  2919
     *         - APP_VERSION, frissítés-ellenőrzés (doUpdateCheck)
     *         - DEFAULT_STATE (state default-jai)
     *         - BUILT-IN MŰSZAKOK (Früh/Spät/Nacht stb.)
     *         - TRANSLATIONS (10 nyelvű i18n szótár - ez teszi ki a
     *           legtöbb sort, kb. 220-2630)
     *   2.  ÁLLAPOT KEZELÉS (save/load)       kb. 2920 -  3367
     *         - state objektum, loadState/saveState, migrateState
     *         - PDF import segédváltozók, dátumértelmező (parseDate)
     *         - getShiftName, ünnepnap-számítás (isPublicHoliday)
     *   3.  RENDERELÉS (naptár, műszak)       kb. 3368 -  4220
     *         - renderCalendar, openShiftSheet/Edit, naptár-cellák
     *   4.  BÉRKALKULÁTOR                     kb. 4221 -  5639
     *         - calculatePayroll és a hozzá tartozó pótlék-/adó-logika
     *           (NH₃-szerű program-szám alapú szabályok itt NINCSENEK -
     *           azok a B.A.S.I.S projektben vannak, ne keverd össze!)
     *         - manuális óra-szerkesztés (openHoursEditMode stb.)
     *   5.  SZABADSÁG                         kb. 5640 -  5671
     *         - updateVacation, szabadság-számítás
     *   5b. PÓTLÉKOK / KIEGÉSZÍTŐK / STATISZTIKA  kb. 5672 -  6091
     *         - Zeitkonto, egyéb juttatások (EZ/WG/DA), updateStats
     *   6.  IMPORT (PDF / Excel / CSV)        kb. 6092 -  8831
     *         6a. PDF import UI, Schichtplan export, többfájl-kezelés
     *         6b. PDF feldolgozó függvények (extractPdfText stb.)
     *         6c. Excel/CSV feldolgozás (v2 widget logika)
     *         6d. Schichtplan szöveg feldolgozás (névkeresés, sablonok)
     *         6e. ZEUS feldolgozás (payroll PDF -> bér/naptár import)
     *         6f. Hónap-lista megjelenítés, Smart Rotation csoport-
     *             felismerés (rotCalcPhase, rotGenerate stb.)
     *   7.  PIN-KÓD + BIOMETRIA                kb. 8832 -  9161
     *         - PIN beállítás/ellenőrzés, autoLock, biometrikus belépés
     *   8.  EGYÉB UI / GLOBÁLIS SEGÉDEK        kb. 9162 -  9715
     *         - scroll, témaváltás, navigáció, setFontSize stb.
     *   9.  INICIALIZÁLÁS & ESEMÉNYKEZELŐK     kb. 9716 - 10495 (a fájl
     *         végéig)
     *         - init(), DOMContentLoaded, és a teljes window.* export-
     *           lista a "Globális hozzáférés a rotáció szkript számára"
     *           felirat alatt.
     *
     *  GLOBÁLIS ÁLLAPOT (state objektum)
     *  ----------------------------------
     *  A `state` const tartalmazza a teljes alkalmazás-állapotot
     *  (schedules, payroll-beállítások, nyelv, csoport, PIN-hash stb.).
     *  Mentés/betöltés kulcsa: localStorage['chronos_10'] (LS.state) (a pontos
     *  kulcsnevet lásd a 2. szekció elején, loadState/saveState).
     *  KÜLSŐ HOZZÁFÉRÉS a state-hez csak window._chronosState() révén
     *  történjen (lásd a fájl legvégén) - ezt használja a RÉSZ 1
     *  (AutoRot), RÉSZ 7 (RotWidget) és RÉSZ 8 (ZeusWidget) is.
     *
     *  HIBAKERESÉSI TIPPEK
     *  --------------------
     *  - Ha a naptár nem frissül egy adatbevitel után: nézd meg, hogy a
     *    hívó kód meghívja-e a window._chronosSaveState() ÉS
     *    window._chronosRender()-t (sok widget-hívás ezt felejti el).
     *  - Ha az i18n (fordítás) hiányzik egy nyelven: keresd meg a
     *    TRANSLATIONS objektumban (1. szekció) az adott kulcsot - ha
     *    egy nyelvnél hiányzik, a kód a 'de' (német) fallbackre esik
     *    vissza (lásd checkMonthlyTaxRates és tr()-szerű függvények).
     *  - Ha a bérszámítás eredménye gyanús: a calculatePayroll (4.
     *    szekció) az, ahol a pótlékok, adók, Zeitkonto összeadódnak -
     *    itt érdemes console.log-gal közbeavatkozni.
     * ================================================================ */

    // ── ALKALMAZÁS VERZIÓ ──
    // Az APP_VERSION-t a scripts/bump-and-deploy.js írja felül minden
    // deploy előtt — kézzel csak vészhelyzetben módosítsd.
    const APP_VERSION = '1.0.1.8'; // fallback ha a verzióellenőrzés nem elérhető
    // 4. fázis (terv 6.4 pont): a régi Drive-alapú fájl helyett egy
    // version.json. FIGYELEM: ez a PWA-ban ÉS az APK-ban (natív fetch,
    // nincs "azonos origin") is abszolút URL kell legyen.
    // A backend mostantól Firebase Hostingra deployol (lásd README 6/b),
    // DE a Netlify `_redirects` proxy-rewrite miatt ez az URL NEM
    // változik — a Netlify domain csak "átlátszóan" továbbítja a
    // kérést a Firebase Hosting felé. Csak akkor kell átírni, ha a
    // Netlify domaint véglegesen leváltjátok (README 6/c).
    const VERSION_TXT_URL = 'https://chronos-b8002.web.app/version.json';
    // UPDATE_VERSION_URL: doUpdateCheck() erre hivatkozik (azonos a VERSION_TXT_URL-lel)
    const UPDATE_VERSION_URL = VERSION_TXT_URL;

    // ── DEBUG PANEL: footer hosszú érintésére megjelenít egy log-ablakot ──
    var _chronosVerLog = [];
    function _chronosVerDebug(msg) {
      _chronosVerLog.push(msg);
      var box = document.getElementById('chronosVerDebugBox');
      if (box) box.textContent = _chronosVerLog.join('\n');
    }
    (function() {
      var f = document.querySelector('.footer');
      if (!f) return;
      var pressTimer = null;
      function showDebugBox() {
        if (document.getElementById('chronosVerDebugBox')) return;
        var box = document.createElement('div');
        box.id = 'chronosVerDebugBox';
        box.style.cssText = 'position:fixed;left:8px;right:8px;bottom:40px;z-index:99999;'
          + 'background:#0f172a;border:1px solid #00e5a0;border-radius:8px;padding:10px;'
          + 'color:#e2e8f0;font-size:11px;font-family:monospace;white-space:pre-wrap;'
          + 'max-height:60vh;overflow:auto;box-shadow:0 0 20px rgba(0,0,0,.6);';
        box.textContent = _chronosVerLog.length ? _chronosVerLog.join('\n') : '(még nincs log – várj 1-2 mp-et, vagy lehet hogy a fetch már lefutott induláskor; zárd be és nyisd meg az appot újra)';
        box.addEventListener('click', function() { box.remove(); });
        document.body.appendChild(box);
      }
      f.addEventListener('touchstart', function() {
        pressTimer = setTimeout(showDebugBox, TIMING.DEBUG_LONGPRESS);
      });
      f.addEventListener('touchend', function() {
        if (pressTimer) clearTimeout(pressTimer);
      });
      f.addEventListener('touchmove', function() {
        if (pressTimer) clearTimeout(pressTimer);
      });
    })();

    // Frissítés-ellenőrzés – version.json-ból olvassa az aktuális verziót
    // (Netlify, azonos origin mint a PWA — 4. fázis, terv 6.4 pont), és ha
    // újabb van, megjeleníti a letöltés-bannert. (A footer nem mutat
    // verziószámot, csak ez a háttér-ellenőrzés fut.)
    (function() {
      // A version.json tartalma JSON ({"version":"1.0.0.1","url":"..."}).
      // CapacitorHttp: natív Android HTTP, robusztusabb mint a WebView fetch()
      // APK-ban, ezért elsőbbséget kap; sima fetch() a fallback (PWA/böngésző).
      (async function() {
        var rawText = null;
        try {
          var capHttp = window.Capacitor &&
                        window.Capacitor.Plugins &&
                        window.Capacitor.Plugins.CapacitorHttp;
          if (capHttp) {
            var capResp = await capHttp.request({
              method: 'GET',
              url: VERSION_TXT_URL,
              headers: { 'Accept': 'application/json, text/plain, */*' },
              responseType: 'text'
            });
            _chronosVerDebug('capHttp status:' + (capResp && capResp.status));
            if (capResp && capResp.status === 200 && capResp.data) {
              rawText = typeof capResp.data === 'string' ? capResp.data : JSON.stringify(capResp.data);
            }
          }
        } catch (e) {
          _chronosVerDebug('capHttp error: ' + (e && e.message));
        }

        if (!rawText) {
          try {
            var r = await fetch(VERSION_TXT_URL, { cache: 'no-cache' });
            _chronosVerDebug('fetch fallback status: ' + r.status + ' ok:' + r.ok + ' url:' + r.url);
            if (r.ok) rawText = await r.text();
          } catch (e) {
            _chronosVerDebug('fetch fallback error: ' + (e && e.message));
          }
        }

        _chronosVerDebug('raw: ' + (rawText === null ? '(null)' : '"' + rawText + '"'));
        if (!rawText) return;
        var raw = rawText.trim();
        if (!raw) return;
        // Csak valódi JSON fogadható el – ha nem parseolható, csendesen kilépünk
        // (Drive vírusszűrő HTML-t küldhet vissza, azt nem szabad feldolgozni)
        var v = null;
        var dlUrl = null;
        var pwaUrl = 'https://chronos-b8002.web.app/';
        try {
          var data = JSON.parse(raw);
          if (data && data.version) v = String(data.version).trim();
          if (data && data.pwaUrl) pwaUrl = data.pwaUrl;
          if (data && data.apkUrl) dlUrl = data.apkUrl;
          else if (data && data.url) {
            var m = data.url.match(/\/file\/d\/([^\/]+)\//);
            dlUrl = m ? 'https://drive.google.com/uc?export=download&id=' + m[1] : data.url;
          }
          _chronosVerDebug('parsed OK, version=' + v);
        } catch (e) {
          _chronosVerDebug('JSON parse FAILED: ' + e.message);
          return;
        }
        if (!v) { _chronosVerDebug('no version field found in JSON'); return; }
        if (typeof isNewerVersion === 'function' && isNewerVersion(v, APP_VERSION)) {
          if (window.Capacitor || window.AndroidBridge) {
            if (dlUrl && dlUrl.indexOf('dropbox.com') === -1 && dlUrl.length > 8) {
              _showPwaUpdateBanner(v, dlUrl, true);
            } else {
              _chronosVerDebug('APK update: nincs érvényes apkUrl');
            }
          } else {
            _showPwaUpdateBanner(v, pwaUrl, false);
          }
        }
      })();
    })();


    // Verzióösszehasonlítás: "1.0" < "1.1" < "2.0"
    function _showPwaUpdateBanner(newVer, dlUrl, isApk) {
      if (document.getElementById('chronosUpdateBanner')) return;
      var b = document.createElement('div');
      b.id = 'chronosUpdateBanner';
      b.style.cssText =
        'position:fixed;bottom:0;left:0;right:0;z-index:9999;'
        + 'background:#1e293b;border-top:2px solid #00e5a0;'
        + 'padding:12px 16px;display:flex;align-items:center;'
        + 'justify-content:space-between;gap:12px;'
        + 'box-shadow:0 -2px 16px rgba(0,0,0,.4);';
      var href = dlUrl || 'https://chronos-b8002.web.app/';
      var label = isApk ? '⬇ APK' : '🔄 Frissítés';
      var aTag;
      if (isApk) {
        aTag = '<a href="' + href + '" target="_blank" '
          + 'style="background:#00e5a0;color:#0f172a;font-weight:700;font-size:13px;'
          + 'padding:6px 14px;border-radius:6px;text-decoration:none;"'
          + '>' + label + '</a>';
      } else {
        aTag = '<a href="' + href + '" '
          + 'onclick="try{if(window.caches){caches.keys().then(function(ks){ks.forEach(function(k){caches.delete(k);});});}}catch(e){}'
          + 'setTimeout(function(){location.href=\'' + href + '\';},150);return false;" '
          + 'style="background:#00e5a0;color:#0f172a;font-weight:700;font-size:13px;'
          + 'padding:6px 14px;border-radius:6px;text-decoration:none;"'
          + '>' + label + '</a>';
      }
      var xBtn = '<button onclick="document.getElementById(\'chronosUpdateBanner\').remove()" '
        + 'style="background:transparent;border:1px solid #475569;color:#94a3b8;'
        + 'font-size:12px;padding:6px 10px;border-radius:6px;cursor:pointer;">&#x2715;</button>';
      b.innerHTML = '<span style="color:#e2e8f0;font-size:13px;">'
        + '&#x1F195; Új verzió elérhető: <b>v' + newVer + '</b></span>'
        + '<div style="display:flex;gap:8px;">' + aTag + xBtn + '</div>';
      document.body.appendChild(b);
    }

    function isNewerVersion(latest, current) {
      const a = String(latest).split('.').map(Number);
      const b = String(current).split('.').map(Number);
      for (let i = 0; i < Math.max(a.length, b.length); i++) {
        const x = a[i] || 0, y = b[i] || 0;
        if (x > y) return true;
        if (x < y) return false;
      }
      return false;
    }

    // ── LOCALSTORAGE KULCSOK ──
    // EGYETLEN FORRÁS: a tényleges definíció a RÉSZ 0-ban van (var LS = {...},
    // sor ~2562, a <head>-ben, ez globálisan window.LS-ként létezik, mire ez
    // az IIFE lefut). Itt korábban egy szóról szóra duplikált const LS állt -
    // ez pont az a fajta duplikáció volt, ami a Drive-restore-fix / i18n
    // session-divergenciánál is gondot okozott (két helyen kellett volna
    // szinkronban tartani). Most már csak egy alias van rá.
    const LS = window.LS;

    // ── ONLINE ÁLLAPOT KEZELÉS ──
    // Ha az app éppen online, automatikusan elvégzi a frissítés- és adóellenőrzést.
    // Ha offline, csendben vár – amint internet lesz, azonnal lefut.
    let _onlineChecksRan = false; // Egy munkameneten belül egyszer fut le automatikusan

    async function runOnlineChecks() {
      if (_onlineChecksRan) return;
      _onlineChecksRan = true;
      // Kis késleltetés hogy a UI teljesen betöltődjön
      await new Promise(r => setTimeout(r, TIMING.INIT_ONLINE_CHECK));
      // 1. Frissítés keresése (csendben – csak ha van újabb, mutat valamit)
      doUpdateCheck(false);
      // 2. Adó (BMF) frissítés – a calculatePayroll() már aszinkron hívja,
      //    itt csak jelezzük hogy online vagyunk, így ha a bér lap aktív, újraszámol
      if (typeof calculatePayroll === 'function') {
        try { calculatePayroll(); } catch(e) {}
      }
    }

    // Induláskor: ha már online, rögtön fut; ha offline, vár az 'online' eseményre
    
    // ── Havi járulékmérték emlékeztető ──
    function checkMonthlyTaxRates() {
      try {
        const lastCheck = localStorage.getItem(LS.taxRateCheck);
        const now = Date.now();
        const ONE_MONTH = 30 * 24 * 60 * 60 * 1000;
        if (!lastCheck || (now - parseInt(lastCheck)) > ONE_MONTH) {
          localStorage.setItem(LS.taxRateCheck, now.toString());
          // Értesítés megjelenítése késleltetve (app init után)
          setTimeout(() => {
            const msg = (TRANSLATIONS[state && state.currentLang || 'hu'] || TRANSLATIONS.de).taxRateCheckMsg
              || 'ℹ️ Bitte prüfe ob die aktuellen Steuersätze und KK-Beiträge in den Einstellungen noch aktuell sind.';
            showNotification(msg, 6000, 'warning');
          }, 3000);
        }
      } catch(e) { /* ignore */ }
    }

    window.addEventListener('load', () => {
      if (navigator.onLine) {
        runOnlineChecks();
      }
    });
    // Internetkapcsolat visszaállásánál automatikusan fut
    window.addEventListener('online', () => {
      _onlineChecksRan = false; // Reset – minden online-visszatérésnél újra fut
      runOnlineChecks();
    });

    async function doUpdateCheck(showIfUpToDate) {
      const btn = document.getElementById('updateCheckBtn');
      const box = document.getElementById('updateStatusBox');
      if (!box) return;
      if (btn) { btn.textContent = '⏳'; btn.disabled = true; }

      // Ha nincs beállított URL – fejlesztői módban csak kézzel nyomva jelzünk
      if (UPDATE_VERSION_URL.includes('VERSION_JSON_FILE_ID')) {
        if (btn) { btn.textContent = t('checkUpdateBtn')||'🔄 Frissítés keresése'; btn.disabled = false; }
        if (showIfUpToDate) {
          box.style.cssText = 'display:block; padding:8px 12px; border-radius:10px; font-size:12px; margin-bottom:10px; background:rgba(251,191,36,0.1); border:1px solid var(--yellow); color:var(--yellow);';
          box.innerHTML = `⚙️ <code>version.json</code> Drive file ID még nincs beállítva a kódban.`;
        }
        return;
      }

      try {
        const resp = await fetch(UPDATE_VERSION_URL, { cache: 'no-store' });
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const data = await resp.json();
        const latest = data.version || '0';

        if (isNewerVersion(latest, APP_VERSION)) {
          box.style.cssText = 'display:block; padding:10px 12px; border-radius:10px; font-size:12px; margin-bottom:10px; background:rgba(74,222,128,0.15); border:1px solid var(--green); color:var(--green); line-height:1.6;';
          var _dl = (window.Capacitor || window.AndroidBridge)
            ? (data.apkUrl || data.url || 'https://chronos-b8002.web.app/')
            : (data.pwaUrl || 'https://chronos-b8002.web.app/');
          box.innerHTML = `🆕 <strong>${t('otaNewVersionLabel')||'Új verzió'}: v${latest}</strong> &nbsp;<a href="${_dl}" target="_blank" style="padding:4px 12px; background:var(--green); color:#000; border-radius:20px; font-weight:700; font-size:11px; text-decoration:none; white-space:nowrap;">${t('otaDownloadBtn')||'⬇️ Letöltés'}</a>`;
        } else if (showIfUpToDate) {
          box.style.cssText = 'display:block; padding:8px 12px; border-radius:10px; font-size:12px; margin-bottom:10px; background:rgba(95,158,247,0.08); border:1px solid var(--border); color:var(--text2);';
          box.innerHTML = (t('otaUpToDate')||'✅ Naprakész (v{v})').replace('{v}', APP_VERSION);
        } else {
          box.style.display = 'none';
        }
      } catch(e) {
        if (showIfUpToDate) {
          box.style.cssText = 'display:block; padding:8px 12px; border-radius:10px; font-size:12px; margin-bottom:10px; background:rgba(255,51,51,0.08); border:1px solid var(--red); color:var(--red);';
          box.innerHTML = t('otaOffline')||'❌ Offline – nem sikerült ellenőrizni';
        } else {
          box.style.display = 'none';
        }
      }
      if (btn) { btn.textContent = t('checkUpdateBtn')||'🔄 Frissítés keresése'; btn.disabled = false; }
    }

    // Kézzel (gomb)
    window.checkForUpdate = () => doUpdateCheck(true);

    // ==================== ALAPÁLLAPOT (DEFAULT) ====================
    // ⚠️  FRISSÍTÉSI ÚTMUTATÓ:
    //   – Új mező hozzáadása: csak ide kell felvenni; migrateState() automatikusan kezeli.
    //   – potlekRules módosítása: a nameKey-t is frissítsd + a megfelelő ruleNames fordítást.
    //   – A calculatePayroll() a potlekRules-t dinamikusan olvassa: % módosítás azonnal érvényes.
    //   – BUILTIN_SHIFTS módosítása: ID-t ne változtass (visszakompatibilitás), csak mezőket.
    // APP_DATA_VERSION: emelés esetén a migrateState()-ben adj hozzá migrációs logikát.
    const APP_DATA_VERSION = 3;
    const DEFAULT = {
      _dataVersion: APP_DATA_VERSION,
      year: new Date().getFullYear(),
      month: new Date().getMonth(),
      payrollYear: new Date().getFullYear(),
      payrollMonth: new Date().getMonth(),
      payrollSync: true,
      payrollDisplayMode: 'leistung',
      hapticsEnabled: true,
      selectedShift: 'Früh',
      schedules: {},
      customShifts: [],
      resturlaub: { years: {} },
      grundlohn: null,
      feststunden: 174,
      taxClass: 1,
      kinder: 0,
      kirche: 0,
      birthYear: 1990,
      bundesland: 'BW',
      krankenkasse: 'AOK_BW',
      zeitkonto: { enabled: false, monthly: 0, balance: 0, maxBalance: 0, withdrawals: [], monthlyOverrides: [], saveAllOvertime: false },
      darlehen: { enabled: false, monthly: 0, balance: 0 },
      einmalzahlung: { enabled: false, payments: [] },
      weihnachtsgeld: { enabled: false, satz: 0.5 },
      otherDeductions: [],
      otherDeductionsEnabled: false,
      potlekRules: [
        { name: '', nameKey: 'ruleNight25a', start: '20:00', end: '00:00', percent: 25, type: 'normal', taxFree: true },
        { name: '', nameKey: 'ruleNight40',  start: '00:00', end: '04:00', percent: 40, type: 'normal', taxFree: true },
        { name: '', nameKey: 'ruleNight25b', start: '04:00', end: '06:00', percent: 25, type: 'normal', taxFree: true },
        { name: '', nameKey: 'ruleSunday',   start: '00:00', end: '24:00', percent: 50, type: 'sunday', taxFree: true },
        { name: '', nameKey: 'ruleHoliday',  start: '00:00', end: '24:00', percent: 125, type: 'holiday', taxFree: true },
        { name: '', nameKey: 'ruleOvertime', start: '', end: '', percent: 25, type: 'overtime', taxFree: false, satNightOvertime: true }
      ],
      pinEnabled: false,
      pinHash: '',
      biometricEnabled: false,
      webauthnCredentialId: '', // PWA WebAuthn credential (eszközhöz kötött, mint pinHash)
      biometricOnStart: true,
      biometricOnAutoLock: true,
      biometricOnPayroll: true,
      autoLock: 0,
      privateMode: false,
      showPrivateBtn: true,
      privateLockRequired: false,
      privateLockAsked: false,
      incognitoLockMode: 'app',
      currentTheme: 'default',
      currentLang: 'hu',
      navPosition: 'top',
      fontSize: 'large',
      quickIds: ['Früh', 'Spät', 'Nacht', 'Freiwillig Früh', 'Freiwillig Spät', 'Freiwillig Nacht', 'Urlaub', 'Krank', 'ZK'],
      shiftSurcharges: {},
      shiftSurchargeRuleIdxs: {},
      hiddenShifts: [],
      builtinOverrides: {},
      zeusImportedMonths: [],  // Zeus Monatsjournal-ból importált hónapok: ["2026-06", ...]
      lastSaved: 0             // Drive szinkron timestamp
    };

    // ==================== BEÉPÍTETT MŰSZAKOK ====================
    const BUILTIN_SHIFTS = [
      { id: 'Früh', name: 'Morning', nameDe: 'Früh', nameEn: 'Morning', color: '#00aa00', builtin: true, start: '05:45', end: '14:15' },
      { id: 'Spät', name: 'Afternoon', nameDe: 'Spät', nameEn: 'Afternoon', color: '#ff3333', builtin: true, start: '13:45', end: '22:15' },
      { id: 'Nacht', name: 'Night', nameDe: 'Nacht', nameEn: 'Night', color: '#0066ff', builtin: true, start: '21:45', end: '06:15' },
      { id: 'Freiwillig Früh', name: 'Vol. Morning', nameDe: 'Fw. Früh', nameEn: 'Volunteer Morning', color: '#86efac', builtin: true, start: '05:45', end: '14:15' },
      { id: 'Freiwillig Spät', name: 'Vol. Afternoon', nameDe: 'Fw. Spät', nameEn: 'Volunteer Afternoon', color: '#fca5a5', builtin: true, start: '13:45', end: '22:15' },
      { id: 'Freiwillig Nacht', name: 'Vol. Night', nameDe: 'Fw. Nacht', nameEn: 'Volunteer Night', color: '#93c5fd', builtin: true, start: '21:45', end: '06:15' },
      { id: 'Fei Fr', name: 'Hol. Morning', nameDe: 'Feiertag Früh', nameEn: 'Holiday Morning', color: '#86efac', builtin: true, start: '05:45', end: '14:15' },
      { id: 'Fei Sp', name: 'Hol. Afternoon', nameDe: 'Feiertag Spät', nameEn: 'Holiday Afternoon', color: '#fca5a5', builtin: true, start: '13:45', end: '22:15' },
      { id: 'Fei Na', name: 'Hol. Night', nameDe: 'Feiertag Nacht', nameEn: 'Holiday Night', color: '#93c5fd', builtin: true, start: '21:45', end: '06:15' },
      { id: 'Urlaub', name: 'Vacation', nameDe: 'Urlaub', nameEn: 'Vacation', color: '#94a3b8', builtin: true },
      { id: 'Urlaub1', name: 'Vac. 1st half', nameDe: 'Halber Urlaub 1', nameEn: 'Half Vacation 1', color: '#94a3b8', builtin: true },
      { id: 'Urlaub2', name: 'Vac. 2nd half', nameDe: 'Halber Urlaub 2', nameEn: 'Half Vacation 2', color: '#94a3b8', builtin: true },
      { id: 'Krank', name: 'Beteg', nameDe: 'Krank', nameEn: 'Sick', color: '#fbbf24', builtin: true },
      { id: 'ZK',    name: 'Zeitkonto', nameDe: 'Zeitkonto', nameEn: 'Time Account', color: '#a78bfa', builtin: true },
      { id: 'ZK1',   name: 'Zeitkonto ½', nameDe: 'ZK ½ (1. Hälfte)', nameEn: 'Time Account ½', color: '#a78bfa', builtin: true },
      { id: 'ZK2',   name: 'Zeitkonto ½', nameDe: 'ZK ½ (2. Hälfte)', nameEn: 'Time Account ½', color: '#a78bfa', builtin: true }
    ];

    // ==================== TIMING KONSTANSOK ====================
    // → Globálisan definiálva a fájl ELSŐ script blokkjában (var TIMING = {...})
    //   hogy minden RÉSZ elérhesse. Lokális alias az IIFE-n belüli használathoz:
    const TIMING = window.TIMING;
    // ──────────────────────────────────────────────────────────────────────────

    // ==================== NYELVI ADATOK ====================
    // ── KULCS-PREFIX KONVENCIÓK ──────────────────────────────────────────────────
    // Minden fordítási kulcs névprefix alapján értelmezhető. Új kulcs hozzáadásakor
    // az alábbi listát kövesd – ha egyik sem illik, adj hozzá új prefixet:
    //   rc*    = RotCalc / AutoRot  (rotáció-generátor és automatikus felismerés)
    //   pdf*   = PDF import pipeline (PDF/Excel/CSV feldolgozás, import UI)
    //   pin*   = PIN kezelés és biometrikus zárolás
    //   pwa*   = PWA telepítési banner (showBanner, IOSModal stb.)
    //   ota*   = OTA frissítés-szalag (otaNewVersionLabel, otaDownloadBtn, otaUpToDate)
    //   rot*   = RotWidget (rotáció generátor widget, RÉSZ 7)
    //   rw*    = RotWidget belső UI (rwTitle, rwSubtitle, rwCard* stb.)
    //   zk*    = Zeitkonto bottom-sheet és saldo UI
    //   terms* = EULA / felhasználási feltételek
    //   drv*   = Drive szinkron visszajelzők
    //   gmail* = Gmail / Zeus auto-import visszajelzők
    //   zeus*  = ZEUS import widgethez kapcsolódó UI szövegek (fő app oldalán)
    //   (Zeus-widget saját fordításai: ZTR objektum, RÉSZ 9 – NE keverd össze)
    // ─────────────────────────────────────────────────────────────────────────────
    // ==================== FORDÍTÁSOK ====================
    // TRANSLATIONS: lásd js/chronos-i18n.js (window.TRANSLATIONS) — Fázis 1
    const TRANSLATIONS = window.TRANSLATIONS;
    if (!TRANSLATIONS) { console.error('Chronos: window.TRANSLATIONS hiányzik — chronos-i18n.js nem töltődött be.'); }

    // MONTH_NAMES and WEEKDAY_NAMES derived from TRANSLATIONS
    const MONTH_NAMES = {};
    const WEEKDAY_NAMES = {};
    Object.keys(TRANSLATIONS).forEach(lang => {
      MONTH_NAMES[lang] = TRANSLATIONS[lang].monthNames;
      WEEKDAY_NAMES[lang] = TRANSLATIONS[lang].weekdays;
    });

    // ── FORDÍTÁS-TELJESSÉG ELLENŐRZŐ (dev/debug eszköz) ──────────────────
    // Minden nyelv kulcskészletét összeveti az ÖSSZES nyelv kulcsainak
    // uniójával (nem csak a hu-hoz hasonlítva, mert ha épp a hu-ból
    // hiányzik valami, az is kiderüljön). Cél: új funkció/kulcs
    // hozzáadásakor azonnal látszódjon, melyik nyelvnél maradt le a
    // fordítás - mielőtt OTA-ban kimegy. Konzolból: window._checkTranslations()
    // A debug panel "🌐 Fordítások ellenőrzése" gombja is ezt hívja.
    function checkTranslationCompleteness() {
      const langs = Object.keys(TRANSLATIONS);
      const allKeys = new Set();
      langs.forEach(l => Object.keys(TRANSLATIONS[l]).forEach(k => allKeys.add(k)));

      const report = {};
      langs.forEach(l => {
        const have = new Set(Object.keys(TRANSLATIONS[l]));
        const missing = [...allKeys].filter(k => !have.has(k));
        if (missing.length) report[l] = missing;
      });

      const hasIssues = Object.keys(report).length > 0;
      if (hasIssues) {
        console.warn('⚠️ Hiányzó fordítási kulcsok:', report);
      } else {
        console.log('✅ Minden nyelv komplett (' + langs.length + ' nyelv, ' + allKeys.size + ' kulcs).');
      }
      return report;
    }
    window._checkTranslations = checkTranslationCompleteness;

    // Helper: get translation key for current language
    function t(key) {
      const lang = state ? state.currentLang : 'de';
      const tr = TRANSLATIONS[lang] || TRANSLATIONS.de;
      return tr[key] !== undefined ? tr[key] : (TRANSLATIONS.hu[key] || key);
    }

    // Global KK change handler
    function kkChanged() {
      if (!document.getElementById('krankenkasse')) return;
      state.krankenkasse = document.getElementById('krankenkasse').value;
      const row = document.getElementById('kkCustomRow');
      if (row) row.style.display = state.krankenkasse === 'custom' ? 'flex' : 'none';
      saveState();
      calculatePayroll();
    }
    // ── Globális elérhetőség (a HTML onchange="kkChanged()" ezt hívja) ──
    window.kkChanged = kkChanged;

    // Apply translations to static UI elements
    function applyTranslations() {
      const lang = state.currentLang || 'hu';
      const tr = TRANSLATIONS[lang] || TRANSLATIONS.de;

      // 1. All elements with data-i18n attribute
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (tr[key] !== undefined && typeof tr[key] === 'string') el.textContent = tr[key];
      });

      // 1b. Elements with data-i18n-title (tooltip/title attribute)
      document.querySelectorAll('[data-i18n-title]').forEach(el => {
        const key = el.getAttribute('data-i18n-title');
        if (tr[key] !== undefined && typeof tr[key] === 'string') el.title = tr[key];
      });

      // 2. Nav buttons (data-i18n-nav)
      document.querySelectorAll('[data-i18n-nav]').forEach(btn => {
        const key = btn.getAttribute('data-i18n-nav');
        if (!tr[key]) return;
        const span = btn.querySelector('.nav-label') || btn.querySelector('span:not(.nav-icon-wrap)');
        if (span) span.textContent = tr[key];
        else btn.textContent = tr[key];
      });

      // 3. Theme button
      const themeBtn = document.getElementById('themeBtn');
      if (themeBtn && tr.theme) {
        const icons = { default: '🌑', light: '☀️', dark: '🌙', oled: '⬛' };
        const icon = icons[state.currentTheme] || '🌑';
        themeBtn.textContent = icon + ' ' + tr.theme;
      }

      // 4. Auto-lock select options
      const als = document.getElementById('autoLockSelect');
      if (als) {
        const opts = als.querySelectorAll('option');
        const labels = [tr.off||'Ki', tr.min1||'1 p', tr.min3||'3 p', tr.min5||'5 p', tr.min10||'10 p'];
        opts.forEach((o, i) => { if (labels[i]) o.textContent = labels[i]; });
        als.value = state.autoLock || 0;
      }
      // incognito lock mode select szinkron (data-i18n kezeli a szövegeket, itt csak value)
      const ilSel2 = document.getElementById('incognitoLockModeSelect');
      if (ilSel2) ilSel2.value = state.incognitoLockMode || 'app';

      // 5. Church tax select
      const kirche = document.getElementById('kirche');
      if (kirche) {
        const opts = kirche.querySelectorAll('option');
        if (opts[0]) opts[0].textContent = tr.no || 'Nem';
        if (opts[1]) opts[1].textContent = tr.yes || 'Igen';
      }

      // 6. Payroll title
      const pt = document.getElementById('payrollTitle');
      if (pt && tr.payrollMonthTitle) pt.textContent = tr.payrollMonthTitle;

      // 7. Card titles (shifts, import sections)
      const shiftsTitle = document.getElementById('shiftsCardTitle');
      if (shiftsTitle && tr.shiftsTitle) shiftsTitle.textContent = tr.shiftsTitle;
      const importTitle = document.getElementById('importCardTitle');
      if (importTitle && tr.importTitle) importTitle.textContent = tr.importTitle;

      // 8. Import buttons
      const btnSch = document.getElementById('btnSchichtplan');
      if (btnSch && tr.schichtplanBtn) btnSch.textContent = tr.schichtplanBtn;
      const btnSchExp = document.getElementById('btnSchichtplanExport');
      if (btnSchExp && tr.schichtplanExportBtn) btnSchExp.textContent = tr.schichtplanExportBtn;
      const btnZeus = document.getElementById('btnZeus');
      if (btnZeus && tr.zeusBtn) btnZeus.textContent = tr.zeusBtn;

      // 9. Shift modal
      const modalTitle = document.getElementById('modalTitle');
      if (modalTitle && tr.newShiftTitle) modalTitle.textContent = tr.newShiftTitle;
      const modalName = document.getElementById('modalName');
      if (modalName && tr.shiftNamePlaceholder) modalName.placeholder = tr.shiftNamePlaceholder;
      const modalSave = document.getElementById('modalSave');
      if (modalSave && tr.save) modalSave.textContent = tr.save;
      const modalCancel = document.getElementById('modalCancel');
      if (modalCancel && tr.cancel) modalCancel.textContent = tr.cancel;

      // 10. Font size section label
      const fsSizeLabel = document.querySelector('[data-i18n="fontSize"]');
      if (fsSizeLabel && tr.fontSize) fsSizeLabel.textContent = tr.fontSize;

      // 11. New surcharge button
      const addPotlekBtn = document.getElementById('addPotlekBtn');
      if (addPotlekBtn && tr.newSurcharge) addPotlekBtn.textContent = tr.newSurcharge;

      // 12. Worker name label in PDF modal + settings
      const wnLabel = document.getElementById('workerNameLabel');
      if (wnLabel && tr.workerNameLabel) wnLabel.textContent = tr.workerNameLabel;
      const sgLabel = document.getElementById('settingsShiftGroupLabel');
      if (sgLabel && tr.groupLabel) sgLabel.textContent = '🔄 ' + tr.groupLabel;
      const snLabel = document.getElementById('settingsNameLabel');
      if (snLabel && tr.workerNameLabel) snLabel.textContent = '👤 ' + tr.workerNameLabel;
      // 12b. Settings save buttons
      ['settingsWorkerNameBtn','settingsWorkerPersonalNrBtn','settingsShiftGroupBtn'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn && tr.settingsSave) btn.textContent = tr.settingsSave;
      });
      // 12c. Personal Nr. title and hint
      const pnLabel = document.getElementById('settingsPersonalNrLabel');
      if (pnLabel && tr.personalNrTitle) pnLabel.textContent = tr.personalNrTitle;
      const pnHint = document.getElementById('settingsPersonalNrHint');
      if (pnHint && tr.personalNrHint) pnHint.textContent = tr.personalNrHint;

      // 13. Font size button labels update
      setFontSize(state.fontSize || 'large');

      // 14. Feldolgozott hónapok felirat + Mind/Egyik sem gombok
      const procLabel = document.getElementById('processedMonthsLabel');
      if (procLabel && tr.processedMonthsTitle) procLabel.textContent = tr.processedMonthsTitle;
      const selAll = document.getElementById('pdfSelectAllBtn');
      if (selAll && tr.selectAll) selAll.textContent = tr.selectAll;
      const deselAll = document.getElementById('pdfDeselectAllBtn');
      if (deselAll && tr.deselectAll) deselAll.textContent = tr.deselectAll;
      // Upload zone
      const uzText = document.getElementById('uploadZoneText');
      if (uzText && tr.uploadZoneText) uzText.textContent = tr.uploadZoneText;
      const uzHint = document.getElementById('uploadZoneHint');
      if (uzHint && tr.uploadZoneHint) uzHint.textContent = tr.uploadZoneHint;
      // PDF name search button
      const pdfSearchBtn = document.querySelector('#pdfNameSection .modal-btn.save');
      if (pdfSearchBtn && tr.searchBtn) pdfSearchBtn.textContent = tr.searchBtn;
      // PDF names accordion label
      const pdfNamesLabel = document.getElementById('pdfNamesAccordionLabel');
      if (pdfNamesLabel && tr.namesAccordionLabel) pdfNamesLabel.textContent = tr.namesAccordionLabel;
      // PDF import modal close button and import button
      const pdfImportBtnEl = document.getElementById('pdfImportBtn');
      if (pdfImportBtnEl && tr.importBtnLabel) pdfImportBtnEl.textContent = tr.importBtnLabel;
      // Overwrite modal text
      const pwOverwriteNo = document.querySelector('#pdfOverwriteOverlay button:first-child');
      if (pwOverwriteNo && tr.overwriteNo) pwOverwriteNo.textContent = tr.overwriteNo;
      const pwConfirmLabel = document.getElementById('pdfOverwriteConfirmBtn');
      // PDF modal close button
      const pdfModalCloseBtn = document.getElementById('pdfModalCloseBtn');
      if (pdfModalCloseBtn && tr.close) pdfModalCloseBtn.textContent = tr.close;
      // ZEUS note
      const zeusNote = document.getElementById('pdfOverwriteZeusNote');
      if (zeusNote && tr.zeusOverwriteNote) zeusNote.textContent = tr.zeusOverwriteNote;
      // Terms modal buttons
      const termsAcceptBtn = document.getElementById('termsAcceptBtn');
      if (termsAcceptBtn && tr.termsAccept) termsAcceptBtn.textContent = tr.termsAccept;
      const termsDeclineBtn = document.getElementById('termsDeclineBtn');
      if (termsDeclineBtn && tr.termsDecline) termsDeclineBtn.textContent = tr.termsDecline;
      // Terms modal content (uses innerHTML for bold tags preservation)
      const termsKeys = ['termsDisclaimerRisk','termsDisclaimerLiability','termsDisclaimerBackup',
                         'termsDataText','termsSalaryText','termsPinText','termsIntroText'];
      termsKeys.forEach(key => {
        const el = document.querySelector(`[data-i18n="${key}"]`);
        if (el && tr[key]) el.innerHTML = tr[key];
      });
      // RTL support (Arabic)
      const isRtl = tr === TRANSLATIONS.ar;
      // RTL direction for PDF modal
      const pdfModal = document.getElementById('pdfImportModal');
      if (pdfModal) pdfModal.setAttribute('dir', isRtl ? 'rtl' : 'ltr');
      // Install guide button translation
      const installGuideBtn = document.getElementById('showInstallGuideBtn');
      if (installGuideBtn && tr.installGuideBtn) installGuideBtn.textContent = tr.installGuideBtn;

      // 15. Rotation Creator modal translations
      const rcBtn = document.getElementById('btnRotationCreator');
      if (rcBtn && tr.rotationCreatorBtn) rcBtn.textContent = tr.rotationCreatorBtn;
      const zeusBtn = document.getElementById('btnZeusImport');
      if (zeusBtn && tr.zeusImportBtn) zeusBtn.textContent = tr.zeusImportBtn;
      const gmailPendingBtn = document.getElementById('btnGmailZeusPending');
      if (gmailPendingBtn && tr.zeusAutoImportPendingBtn && gmailPendingBtn.style.display !== 'none') gmailPendingBtn.textContent = tr.zeusAutoImportPendingBtn;
      const driveSyncBtn2 = document.getElementById('driveSyncBtn');
      if (driveSyncBtn2 && tr.driveSyncBtn) driveSyncBtn2.textContent = tr.driveSyncBtn;
      const gmailZeusCheckBtn2 = document.getElementById('btnGmailZeusCheck');
      if (gmailZeusCheckBtn2 && tr.gmailZeusCheckBtn) gmailZeusCheckBtn2.textContent = tr.gmailZeusCheckBtn;
      const zkBalCardTitle = document.getElementById('zkBalCardTitle');
      if (zkBalCardTitle && tr.zkCurrentBalance) zkBalCardTitle.textContent = '⏱ Zeitkonto – ' + tr.zkCurrentBalance.toUpperCase();
      const rcModalTitle = document.getElementById('rcModalTitle');
      if (rcModalTitle && tr.rcModalTitle) rcModalTitle.textContent = tr.rcModalTitle;
      const rcModalSubtitle = document.getElementById('rcModalSubtitle');
      if (rcModalSubtitle && tr.rcModalSubtitle) rcModalSubtitle.textContent = tr.rcModalSubtitle;
      const rcAutoDetectLabel = document.getElementById('rcAutoDetectLabel');
      if (rcAutoDetectLabel && tr.rcAutoDetectLabel) rcAutoDetectLabel.textContent = tr.rcAutoDetectLabel;
      const rcAutoDetectHint = document.getElementById('rcAutoDetectHint');
      if (rcAutoDetectHint && tr.rcAutoDetectHint) rcAutoDetectHint.textContent = tr.rcAutoDetectHint;
      const qLoadCalBtn = document.getElementById('q-load-chronos-btn');
      if (qLoadCalBtn && tr.qLoadCalBtn) qLoadCalBtn.textContent = tr.qLoadCalBtn;

      // 16. Rotation Widget belső szövegek (rw-*)
      var _rw = function(id, key) {
        var el = document.getElementById(id);
        if (el && tr[key]) el.textContent = tr[key];
      };
      _rw('rw-title',           'rwTitle');
      _rw('rw-subtitle',        'rwSubtitle');
      _rw('prog-label',         'rwProcessing');
      _rw('rw-card1-title',     'rwCard1Title');
      _rw('rw-card1-helper',    'rwCard1Helper');
      _rw('rw-upload-text',     'rwUploadText');
      _rw('rw-upload-hint',     'rwUploadHint');
      _rw('rw-card-quick-title','rwCardQuickTitle');
      _rw('rw-card-quick-helper','rwCardQuickHelper');
      _rw('q-apply-btn',        'rwQApplyBtn');
      _rw('rw-card2-title',     'rwCard2Title');
      _rw('rw-card2-helper',    'rwCard2Helper');
      _rw('rw-card3-title',     'rwCard3Title');
      _rw('rw-card3-helper',    'rwCard3Helper');
      _rw('calc-phase-btn',     'rwCalcPhaseBtn');
      _rw('rw-card4-title',     'rwCard4Title');
      _rw('rw-card4-helper',    'rwCard4Helper');
      _rw('range-start',        'rwRangeStart');
      _rw('range-end',          'rwRangeEnd');
      _rw('rw-bw-note',         'rwBwNote');
      _rw('gen-btn',            'rwGenBtn');
      _rw('rw-from-month-label', 'rwFromMonth');
      _rw('rw-to-month-label',   'rwToMonth');
      _rw('exp-copy',           'rwExpCopy');
      _rw('exp-chronos',        'rwExpChronos');

      window._currentTranslations = tr;
      const rcScanFromLabel = document.getElementById('rcScanFromLabel');
      if (rcScanFromLabel && tr.rcScanFromLabel) rcScanFromLabel.textContent = tr.rcScanFromLabel;
      const rcScanToLabel = document.getElementById('rcScanToLabel');
      if (rcScanToLabel && tr.rcScanToLabel) rcScanToLabel.textContent = tr.rcScanToLabel;
      const rcDetectBtn = document.getElementById('rcDetectBtn');
      if (rcDetectBtn && tr.rcDetectBtn) rcDetectBtn.textContent = tr.rcDetectBtn;
      const rcSection1Label = document.getElementById('rcSection1Label');
      if (rcSection1Label && tr.rcSection1Label) rcSection1Label.textContent = tr.rcSection1Label;
      const rcPatternEmpty = document.getElementById('rotCreatorPatternEmpty');
      if (rcPatternEmpty && tr.rcPatternEmpty) rcPatternEmpty.textContent = tr.rcPatternEmpty;
      const rcCycleDaysLabel = document.getElementById('rcCycleDaysLabel');
      if (rcCycleDaysLabel && tr.rcCycleDaysLabel) rcCycleDaysLabel.textContent = tr.rcCycleDaysLabel;
      const rcUndoBtn = document.getElementById('rcUndoBtn');
      if (rcUndoBtn && tr.rcUndoBtn) rcUndoBtn.textContent = tr.rcUndoBtn;
      const rcClearBtn = document.getElementById('rcClearBtn');
      if (rcClearBtn && tr.rcClearBtn) rcClearBtn.textContent = tr.rcClearBtn;
      const rcSection2Label = document.getElementById('rcSection2Label');
      if (rcSection2Label && tr.rcSection2Label) rcSection2Label.textContent = tr.rcSection2Label;
      const rcAnchorQuestion = document.getElementById('rcAnchorQuestion');
      if (rcAnchorQuestion && tr.rcAnchorQuestion) rcAnchorQuestion.textContent = tr.rcAnchorQuestion;
      const rcAnchorHint = document.getElementById('rcAnchorHint');
      if (rcAnchorHint && tr.rcAnchorHint) rcAnchorHint.textContent = tr.rcAnchorHint;
      const rcRefDateLabel = document.getElementById('rcRefDateLabel');
      if (rcRefDateLabel && tr.rcRefDateLabel) rcRefDateLabel.textContent = tr.rcRefDateLabel;
      const rcRefDateLabel2 = document.getElementById('rcRefDateLabel2');
      if (rcRefDateLabel2 && tr.rcRefDateLabel) rcRefDateLabel2.textContent = tr.rcRefDateLabel;
      const rcShiftTypeLabel = document.getElementById('rcShiftTypeLabel');
      if (rcShiftTypeLabel && tr.rcShiftTypeLabel) rcShiftTypeLabel.textContent = tr.rcShiftTypeLabel;
      const rcAnchorCalcLabel = document.getElementById('rcAnchorCalcLabel');
      if (rcAnchorCalcLabel && tr.rcAnchorCalcLabel) rcAnchorCalcLabel.textContent = tr.rcAnchorCalcLabel;
      const rcAdvancedSummary = document.getElementById('rcAdvancedSummary');
      if (rcAdvancedSummary && tr.rcAdvancedSummary) rcAdvancedSummary.textContent = tr.rcAdvancedSummary;
      const rcPositionLabel = document.getElementById('rcPositionLabel');
      if (rcPositionLabel && tr.rcPositionLabel) rcPositionLabel.textContent = tr.rcPositionLabel;
      const rcCalcLabel = document.getElementById('rcCalcLabel');
      if (rcCalcLabel && tr.rcCalcLabel) rcCalcLabel.textContent = tr.rcCalcLabel;
      const rcCalcPhaseBtn = document.getElementById('rcCalcPhaseBtn');
      if (rcCalcPhaseBtn && tr.rcCalcLabel) rcCalcPhaseBtn.innerHTML = '📍 <span id="rcCalcLabel">' + tr.rcCalcLabel + '</span>';
      const rcSection3Label = document.getElementById('rcSection3Label');
      if (rcSection3Label && tr.rcSection3Label) rcSection3Label.textContent = tr.rcSection3Label;
      const rcStartDateLabel = document.getElementById('rcStartDateLabel');
      if (rcStartDateLabel && tr.rcStartDateLabel) rcStartDateLabel.textContent = tr.rcStartDateLabel;
      const rcEndDateLabel = document.getElementById('rcEndDateLabel');
      if (rcEndDateLabel && tr.rcEndDateLabel) rcEndDateLabel.textContent = tr.rcEndDateLabel;
      const rcOverwriteLabel = document.getElementById('rcOverwriteLabel');
      if (rcOverwriteLabel && tr.rcOverwriteLabel) rcOverwriteLabel.textContent = tr.rcOverwriteLabel;
      const rcApplyBtnLabel = document.getElementById('rcApplyBtnLabel');
      if (rcApplyBtnLabel && tr.rcApplyBtnLabel) rcApplyBtnLabel.textContent = tr.rcApplyBtnLabel;

      // Rotáció widget statikus elemek
      const nameSearch = document.getElementById('name-search');
      if (nameSearch && tr.rcSearchPlaceholder) nameSearch.placeholder = tr.rcSearchPlaceholder;
      const manualSummary = document.querySelector('#manual-edit > summary');
      if (manualSummary && tr.rcManualCycleEdit) manualSummary.textContent = tr.rcManualCycleEdit;
      const addBlock = document.getElementById('add-block');
      if (addBlock && tr.rcAddBlock) addBlock.textContent = tr.rcAddBlock;
      const clearBlocks = document.getElementById('clear-blocks');
      if (clearBlocks && tr.rcClearBlocks) clearBlocks.textContent = tr.rcClearBlocks;
      // rotNameSearch placeholder (főnézet)
      const rotNameSearchEl = document.getElementById('rotNameSearch');
      if (rotNameSearchEl && tr.rcSearchPlaceholder) rotNameSearchEl.placeholder = tr.rcSearchPlaceholder;
      // Óra szerkesztés gomb title
      const hoursEditBtnEl = document.getElementById('hoursEditBtn');
      if (hoursEditBtnEl && tr.hoursEditBtn) hoursEditBtnEl.title = tr.hoursEditBtn;

      // 17. Bottom-sheet (ZK / Urlaub) translations
      const _ss = function(id, text) { const el = document.getElementById(id); if (el && text) el.textContent = text; };
      _ss('zkSheetTitle',        tr.zkSheetTitle);
      _ss('zkSheetPillLabel',    tr.zkSheetPillLabel);
      _ss('zkSheetSub',          tr.zkSheetSub);
      _ss('zkSheetDeductLabel',  tr.sheetDeductSaldo);
      _ss('zkSheetRemainLabel',  tr.sheetSaldoRemains);
      _ss('zks-full-label',      tr.sheetFullDay);
      _ss('zks-h1-label',        tr.sheetFirstHalf);
      _ss('zks-h2-label',        tr.sheetSecondHalf);
      const zkConfirm = document.getElementById('zkSheetConfirm');
      if (zkConfirm && tr.sheetConfirm) zkConfirm.textContent = tr.sheetConfirm;
      const zkCancel = document.getElementById('zkSheetCancelBtn');
      if (zkCancel && tr.sheetCancel) zkCancel.textContent = tr.sheetCancel;

      _ss('urlaubSheetTitle',       tr.urlaubSheetTitle);
      _ss('urlaubSheetPillLabel',   tr.urlaubSheetPillLabel);
      _ss('urlaubSheetSub',         tr.urlaubSheetSub);
      _ss('urlaubSheetDeductLabel', tr.sheetDeductFrame);
      _ss('urlaubSheetRemainLabel', tr.sheetVacRemains);
      _ss('urs-full-label',         tr.sheetFullDay);
      _ss('urs-h1-label',           tr.sheetFirstHalf);
      _ss('urs-h2-label',           tr.sheetSecondHalf);
      // Update day-unit sub-labels inside opt buttons
      const _dayUnit = tr.sheetDayUnit || 'nap';
      const ursFullSm = document.querySelector('#urs-full small');
      if (ursFullSm) ursFullSm.textContent = '−1 ' + _dayUnit;
      const ursH1Sm = document.querySelector('#urs-h1 small');
      if (ursH1Sm) ursH1Sm.textContent = '−0.5 ' + _dayUnit;
      const ursH2Sm = document.querySelector('#urs-h2 small');
      if (ursH2Sm) ursH2Sm.textContent = '−0.5 ' + _dayUnit;
      const urConfirm = document.getElementById('urlaubSheetConfirm');
      if (urConfirm && tr.sheetConfirm) urConfirm.textContent = tr.sheetConfirm;
      const urCancel = document.getElementById('urlaubSheetCancelBtn');
      if (urCancel && tr.sheetCancel) urCancel.textContent = tr.sheetCancel;

      // 18. Műszak csoport súgó popup fordítás
      if (typeof window._updateSgHintLang === 'function') window._updateSgHintLang();
    }

    const MONTH_DE = ['', 'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

    // ==================== ÁLLAPOT KEZELÉS ====================
    let state = JSON.parse(JSON.stringify(DEFAULT));
    let pinInput = '';
    let firstPin = '', confirmPin = '', setupPhase = 'first';
    let payrollVisible = false;
    let payrollTimer = null;
    // 'app' módban (alapbeállítás): app megnyitása óta egyszer kell csak azonosítani,
    // utána az app bezárásáig (vagy újratöltéséig) nem kérdez újra a bér fülre lépéskor.
    let payrollUnlockedThisSession = false;

    // ==================== HAPTIKUS VISSZAJELZÉS ====================
    // Capacitor Haptics plugin ha elérhető (jövőbeli @capacitor/haptics build esetén),
    // egyébként natív web Vibration API fallback (Android WebView/Capacitor WebView támogatja).
    function haptic(style) {
      try {
        if (!state.hapticsEnabled) return;
        const HapticsPlugin = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Haptics;
        if (HapticsPlugin && HapticsPlugin.impact) {
          HapticsPlugin.impact({ style: style === 'heavy' ? 'HEAVY' : style === 'medium' ? 'MEDIUM' : 'LIGHT' });
          return;
        }
        if (navigator.vibrate) {
          navigator.vibrate(style === 'heavy' ? 30 : style === 'medium' ? 18 : 10);
        }
      } catch (e) { /* csendben elnyel - sosem akasztja meg a UI-t */ }
    }
    window.haptic = haptic;

    // Globális delegált listener: minden gomb/interaktív elem nyomására finom haptika,
    // kivéve ahol explicit egyedi (erősebb) vibráció van már beállítva (pl. PIN siker/hiba).
    document.addEventListener('pointerdown', function(e) {
      if (!state.hapticsEnabled) return;
      const target = e.target.closest('button, .nav-item, .switch, .quick-btn, [role="button"], .rot-pill, .shift-pill');
      if (target) haptic('light');
    }, { passive: true });

    // ==================== PDF IMPORT VÁLTOZÓK ====================
    const PDFJS_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    const PDFJS_WORKER = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    const XLSX_CDN = 'https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js';

    let pdfMode = 'schichtplan';
    let pdfAllMonths = []; // Összes feldolgozott hónap az összes fájlból
    let pdfZeusMonths = [];
    let pdfExtractedText = '';
    let pdfExtractedItems = [];
    let pdfAllExtractedTexts = []; // All files' texts stored separately
    let pdfLibLoaded = false;
    let xlsxLibLoaded = false;
    let selectedFiles = []; // Több fájl tárolása
    // Globális elérhetőség a rotation widget számára
    Object.defineProperty(window, 'pdfAllExtractedTexts', { get: () => pdfAllExtractedTexts });
    Object.defineProperty(window, 'selectedFiles', { get: () => selectedFiles });

    const SCHICHT_MAP = {
      'F': 'Früh', 'S': 'Spät', 'N': 'Nacht',
      'FF': 'Freiwillig Früh', 'FS': 'Freiwillig Spät', 'FN': 'Freiwillig Nacht',
      'URL': 'Urlaub', 'U': 'Urlaub', 'K': 'Krank', 'KR': 'Krank', 'KRA': 'Krank',
      'EZ': null, 'X': null
    };

    const PDF_MONTH_MAP = {
      'januar': 1, 'jänner': 1, 'jan': 1,
      'februar': 2, 'feb': 2,
      'märz': 3, 'maerz': 3, 'mär': 3,
      'april': 4, 'apr': 4,
      'mai': 5,
      'juni': 6, 'jun': 6,
      'juli': 7, 'jul': 7,
      'august': 8, 'aug': 8,
      'september': 9, 'sep': 9,
      'oktober': 10, 'okt': 10,
      'november': 11, 'nov': 11,
      'dezember': 12, 'dez': 12
    };
    // ==================== ÁLLAPOT KEZELŐ FÜGGVÉNYEK ====================
    // ── ÁLLAPOT MIGRÁCIÓ ──
    // Minden induláskor lefut: ha a mentett adatban hiányzik valami az aktuális DEFAULT-ból,
    // csendesen hozzáadja az alapértékkel. Így a régi mentések soha nem törnek el frissítés után.
    function migrateState(loaded) {
      function mergeDeep(target, source) {
        const out = Object.assign({}, source);
        for (const key of Object.keys(source)) {
          if (
            target[key] !== undefined &&
            typeof source[key] === 'object' &&
            source[key] !== null &&
            !Array.isArray(source[key]) &&
            typeof target[key] === 'object' &&
            target[key] !== null &&
            !Array.isArray(target[key])
          ) {
            out[key] = mergeDeep(target[key], source[key]);
          } else if (target[key] !== undefined) {
            out[key] = target[key];
          }
        }
        // Megőrizzük a loaded-ban lévő extra mezőket is (pl. egyedi adatok)
        for (const key of Object.keys(target)) {
          if (out[key] === undefined) out[key] = target[key];
        }
        return out;
      }
      const result = mergeDeep(loaded, DEFAULT);
      // If fontSize was the old default 'normal' and no explicit user preference recorded,
      // upgrade to new default 'large' (middle option)
      if (result.fontSize === 'normal' && !loaded._fontSizeSetByUser) {
        result.fontSize = 'large';
      }
      // ── VERZIÓ-ALAPÚ MIGRÁCIÓ ──
      // Ide kerüljön minden jövőbeni adatstruktúra-változás kezelése.
      // Pl.: if (!result._dataVersion || result._dataVersion < 2) { /* upgrade */ }
      if (!result._dataVersion || result._dataVersion < APP_DATA_VERSION) {
        result._dataVersion = APP_DATA_VERSION;
      }

      // otherDeductionsEnabled migráció: ha régi state-ben már vannak tételek, automatikusan bekapcsol
      if (result.otherDeductionsEnabled === undefined || result.otherDeductionsEnabled === null) {
        result.otherDeductionsEnabled = !!(result.otherDeductions && result.otherDeductions.length > 0);
      }

      // taxFree migráció + nameKey migráció
      if (result.potlekRules) {
        result.potlekRules = result.potlekRules.map(rule => {
          if (rule.taxFree === undefined || rule.taxFree === null) {
            rule.taxFree = rule.type !== 'overtime';
          }
          // nameKey migráció: régi névből kulcsot rendelünk
          if (!rule.nameKey) {
            if (rule.type === 'overtime') {
              rule.nameKey = 'ruleOvertime';
            } else if (rule.type === 'sunday') {
              rule.nameKey = 'ruleSunday';
            } else if (rule.type === 'holiday') {
              rule.nameKey = 'ruleHoliday';
            } else if (rule.type === 'normal' && rule.start === '20:00') {
              rule.nameKey = 'ruleNight25a';
            } else if (rule.type === 'normal' && rule.start === '00:00' && rule.end === '04:00') {
              rule.nameKey = 'ruleNight40';
            } else if (rule.type === 'normal' && rule.start === '04:00') {
              rule.nameKey = 'ruleNight25b';
            }
            // Ha sikerült nameKey-t rendelni, töröljük a rögzített nevet
            if (rule.nameKey) rule.name = '';
          }
          return rule;
        });
      }
      return result;
    }

    function saveState() {
      try {
        state.lastSaved = Date.now(); // timestamp a Drive szinkron frissesség-ellenőrzéséhez
        localStorage.setItem(LS.state, JSON.stringify(state));
      } catch (e) {
        console.warn('Save error:', e);
      }
      updateLockBtnVisibility();
      // Felhő szinkron — aszinkron, nem blokkolja a UI-t.
      // CLOUD_BACKEND dönti el, melyik backend aktív (lásd a
      // "CHRONOS CLOUD BACKEND VÁLASZTÓ" blokkot lejjebb a fájlban).
      if (window.CLOUD_BACKEND === 'firebase' && window.ChronosCloud) {
        // Debounce a gyakori billentyűzetre, DE Capacitor/APK-n azonnali flush is
        // (a háttérbe küldés gyakran megöli a timer-t).
        window.ChronosCloud.save(state);
        if (window.Capacitor || window.AndroidBridge) {
          try { window.ChronosCloud.flush(state); } catch (e) {}
        }
      } else if (window.ChronosDriveSync) {
        window.ChronosDriveSync.save(state);
      }
    }

    function updateLockBtnVisibility() {
      const btn = document.getElementById('lockBtn');
      if (!btn) return;
      const hasData = Object.keys(state.schedules || {}).length > 0
                   || (state.grundlohn && state.grundlohn > 0)
                   || state.pinEnabled;
      const show = hasData && (state.showPrivateBtn !== false);
      btn.style.display = show ? '' : 'none';
    }

    function loadState() {
      try {
        // ── LS kulcs migráció: raiseEnabled → chronos_raiseEnabled ──
        // Régi prefix nélküli kulcs → új, chronos_ prefix-es kulcsra másolás (egyszer fut)
        (function() {
          try {
            var _old = localStorage.getItem('raiseEnabled');
            if (_old !== null && localStorage.getItem('chronos_raiseEnabled') === null) {
              localStorage.setItem('chronos_raiseEnabled', _old);
              localStorage.removeItem('raiseEnabled');
            }
          } catch(e) {}
        })();
        const raw = localStorage.getItem(LS.state);
        if (raw) {
          const parsed = JSON.parse(raw);
          // migrateState biztosítja, hogy minden DEFAULT mező meglegyen,
          // miközben a meglévő adatokat (műszakok, bérek stb.) megőrzi
          state = migrateState(parsed);
        } else {
          // Első indítás: üres naptár (nincs demo bejegyzés)
        }
      } catch (e) {
        console.warn('Load error:', e);
      }
    }

    // Teljes UI újrarajzolás — Drive betöltés után hívjuk
    function _renderAll() {
      try {
        document.body.setAttribute('data-theme', state.currentTheme);
        setFontSize(state.fontSize || 'large');
        setLanguage(state.currentLang);
        setNavPosition(state.navPosition);
        renderCalendar();
        renderShifts();
        renderPotlek();
        renderExtras();
        updateVacation();
        updateStats();
        renderVacationHistory();
        maskPayroll();
        updateLockBtnVisibility();
        if (typeof calculatePayroll === 'function') { try { calculatePayroll(); } catch(e) {} }
        fitNavLabels();
      } catch(e) {
        console.warn('Chronos _renderAll error:', e);
      }
    }

    // Drive-ról való betöltés — induláskor fut le aszinkron
    // Ha van Drive-on mentés → betölti (ha frissebb); ha nincs → létrehoz egyet
    async function loadStateFromDrive() {
      // Felhő-backend váltó: ha 'firebase' van beállítva, a Firestore-os
      // úton töltünk be (lásd loadStateFromCloud lejjebb), és itt kilépünk.
      if (window.CLOUD_BACKEND === 'firebase') {
        return loadStateFromCloud();
      }
      if (!window.ChronosDriveSync) return;
      const personalNr = (state && state.workerPersonalNr) || '';
      if (!personalNr) {
        console.log('Chronos Drive: nincs personalNr – add meg a Beállításokban.');
        return;
      }
      const statusEl = document.getElementById('driveSyncStatus');
      function _setStatus(msg, color) {
        if (statusEl) { statusEl.textContent = msg; statusEl.style.color = color || 'var(--text2)'; }
      }
      // Cloud pill → syncing animáció
      const _pill  = document.getElementById('cloudPillBtn');
      const _label = document.getElementById('cloudPillLabel');
      if (_pill)  _pill.className = 'cloud-pill syncing';
      if (_label) _label.textContent = '☁';
      _setStatus((window._currentTranslations&&window._currentTranslations.drvChecking)||'☁️ Drive ellenőrzése…', 'var(--text2)');
      try {
        const driveData = await window.ChronosDriveSync.load(personalNr);
        if (!driveData) {
          // Nincs még mentés Drive-on.
          // BIZTONSÁGI ELLENŐRZÉS: csak akkor hozunk létre új Drive-mentést, ha
          // az onboarding már lefutott ÉS a state tartalmaz érdemi adatot.
          // Ez megakadályozza, hogy újratelepítéskor a TIMING.INIT_DRIVE_LOAD (2s)
          // trigger felülírja a Drive-on lévő régi mentést egy üres state-tel,
          // mielőtt a wizard befejezte volna a personalNr beállítását.
          var _onbDone = false;
          try { _onbDone = localStorage.getItem('chronos_onboarding_done') === '1'; } catch(e_) {}
          var _hasData = _onbDone && (
            (state.grundlohn && state.grundlohn > 0) ||
            (state.workerName && state.workerName.length > 0) ||
            (Object.keys(state.schedules || {}).length > 0) ||
            state.pinEnabled
          );
          if (!_hasData) {
            console.log('Chronos Drive: onboarding folyamatban vagy üres state – Drive-mentés kihagyva.');
            _setStatus('', '');
            return;
          }
          console.log('Chronos Drive: nincs mentés, új fájl létrehozása...');
          window.ChronosDriveSync.save(state);
          _setStatus((window._currentTranslations&&window._currentTranslations.drvCreated&&window._currentTranslations.drvCreated(''))||'✅ Drive: új mentés létrehozva', '#00e5a0');
          setTimeout(function() { _setStatus('', ''); }, 4000);
          return;
        }
        // Drive mindig az elsődleges forrás — DE: timestamp összehasonlítás:
        // Ha a lokális state frissebb (pl. friss wizard/PIN setup), a Drive-on lévő
        // RÉGI adat ne írja felül a biztonsági beállításokat (pinEnabled, pinHash,
        // biometricEnabled). Ez megakadályozza, hogy a Drive-betöltés törölje a
        // wizard után épp beállított PIN/bio értékeket.
        const parsed = typeof driveData === 'string' ? JSON.parse(driveData) : driveData;
        const driveTs = parsed.lastSaved ? new Date(parsed.lastSaved).getTime() : 0;
        const localTs = state.lastSaved ? new Date(state.lastSaved).getTime() : 0;
        const _driveIsOlder = driveTs < localTs;
        // Biztonsági mezők mentése ha a lokális frissebb
        const _localSec = _driveIsOlder ? {
          pinEnabled: state.pinEnabled,
          pinHash: state.pinHash,
          biometricEnabled: state.biometricEnabled,
          webauthnCredentialId: state.webauthnCredentialId,
          biometricOnStart: state.biometricOnStart,
          biometricOnAutoLock: state.biometricOnAutoLock,
          biometricOnPayroll: state.biometricOnPayroll,
        } : null;
        state = migrateState(parsed);
        if (_localSec) {
          // Lokális frissebb → biztonsági beállítások visszaállítása
          Object.assign(state, _localSec);
          console.log('Chronos Drive: lokális state frissebb – biztonsági beállítások megtartva.');
        }
        try { localStorage.setItem(LS.state, JSON.stringify(state)); } catch(e) {}
        _renderAll();
        const driveDate = parsed.lastSaved ? new Date(parsed.lastSaved).toLocaleString('de-DE') : '?';
        _setStatus(((window._currentTranslations&&window._currentTranslations.drvLoaded)||((d)=>'✅ Drive: adat betöltve ('+d+')'))(driveDate), '#00e5a0');
        console.log('Chronos: Drive betöltve (' + driveDate + ').');
        // Cloud pill + timestamp frissítése az auto-betöltés után
        try {
          const _now = new Date();
          localStorage.setItem('chronos_driveLastSync', _now.toISOString());
          const _pill  = document.getElementById('cloudPillBtn');
          const _label = document.getElementById('cloudPillLabel');
          if (_pill)  _pill.className  = 'cloud-pill ok';
          if (_label) _label.textContent = _now.getHours().toString().padStart(2,'0') + ':' + _now.getMinutes().toString().padStart(2,'0');
        } catch(e) {}
        setTimeout(function() { _setStatus('', ''); }, 4000);
      } catch(e) {
        _setStatus((window._currentTranslations&&window._currentTranslations.drvNotAvail)||'⚠️ Drive szinkron hiba', '#f87171');
        if (_pill)  _pill.className = 'cloud-pill err';
        if (_label) _label.textContent = '!';
        console.warn('Drive load error:', e);
      }
    }

    // Felhőből (Firestore) való betöltés — a loadStateFromDrive() hívja,
    // ha CLOUD_BACKEND === 'firebase'. Ugyanazt a UI-visszajelzést adja
    // (driveSyncStatus szöveg, cloud-pill állapot), mint a Drive-os út.
    async function loadStateFromCloud() {
      if (!window.ChronosCloud) return;
      const statusEl = document.getElementById('driveSyncStatus');
      function _setStatus(msg, color) {
        if (statusEl) { statusEl.textContent = msg; statusEl.style.color = color || 'var(--text2)'; }
      }
      const _pill  = document.getElementById('cloudPillBtn');
      const _label = document.getElementById('cloudPillLabel');

      if (!window.ChronosCloud.isConfigured()) {
        return;
      }
      // Várjuk meg az első onAuthStateChanged-et (ES module + persistence async)
      try {
        if (typeof window.ChronosCloud.whenReady === 'function') {
          await window.ChronosCloud.whenReady();
        }
      } catch (e) { console.warn('Chronos Cloud whenReady:', e); }

      if (!window.ChronosCloud.isLoggedIn()) {
        _setStatus((window._currentTranslations&&window._currentTranslations.drvNotAvail)||'☁️ Felhő: nincs bejelentkezve', 'var(--text2)');
        return;
      }

      if (_pill)  _pill.className = 'cloud-pill syncing';
      if (_label) _label.textContent = '☁';
      _setStatus((window._currentTranslations&&window._currentTranslations.drvChecking)||'☁️ Felhő ellenőrzése…', 'var(--text2)');
      try {
        const cloudData = await window.ChronosCloud.load();
        if (!cloudData) {
          // Nincs még felhő-mentés ehhez a fiókhoz: megpróbáljuk migrálni
          // a jelenlegi lokális state-et (pl. korábbi Drive-adatot).
          var _onbDone = false;
          try { _onbDone = localStorage.getItem('chronos_onboarding_done') === '1'; } catch(e_) {}
          var _hasData = _onbDone && (
            (state.grundlohn && state.grundlohn > 0) ||
            (state.workerName && state.workerName.length > 0) ||
            (Object.keys(state.schedules || {}).length > 0) ||
            state.pinEnabled
          );
          if (_hasData) {
            await window.ChronosCloud.migrateFromDrive(state);
            _setStatus((window._currentTranslations&&window._currentTranslations.drvCreated&&window._currentTranslations.drvCreated(''))||'✅ Felhő: adat feltöltve', '#00e5a0');
          } else {
            _setStatus('', '');
          }
          setTimeout(function() { _setStatus('', ''); }, 4000);
          return;
        }
        // Frissesség-összehasonlítás: ha a lokális state frissebb, mint a
        // felhőben tárolt (pl. az app bezárása megelőzte a debounce-olt
        // mentést), NEM szabad a régebbi felhő-adattal felülírni a friss
        // lokális szerkesztést (ez volt a korábbi hiba: itt mindig a
        // cloudData-t vette át, csak a PIN/biometria mezőket mentette
        // vissza lokálisból — minden más lokális változás elveszett).
        // Ilyenkor a lokális marad érvényben, és azonnal visszaírjuk a
        // felhőbe (flush), hogy a két oldal újra szinkronban legyen.
        // Multi-device LWW: a felhő az igazság forrása, ha lastSaved >= local.
        // Fontos: NEM szabad automatikusan felülírni a felhőt "frissebb" lokális
        // timestamp miatt, ha a lokális csak egy másik eszköz régi másolata
        // (PWA lastSaved frissülhet anélkül, hogy az APK módosításait tartalmazná).
        const cloudTs = cloudData.lastSaved ? new Date(cloudData.lastSaved).getTime() : 0;
        const localTs = state.lastSaved ? new Date(state.lastSaved).getTime() : 0;
        const _cloudSched = Object.keys(cloudData.schedules || {}).length;
        const _localSched = Object.keys(state.schedules || {}).length;
        const _skew = 3000; // 3 mp óraeltérés tűrés
        // Lokális csak akkor nyeri a felhőt, ha EGYÉRTELMŰEN újabb ÉS van érdemi adat
        const _localClearlyNewer = localTs > cloudTs + _skew && _localSched > 0;
        // Alapértelmezés: felhő alkalmazása (APK → PWA sync)
        const _preferLocal = _localClearlyNewer && _localSched >= _cloudSched;

        console.log('Chronos Cloud merge: localTs=' + localTs + ' cloudTs=' + cloudTs +
          ' localSched=' + _localSched + ' cloudSched=' + _cloudSched + ' preferLocal=' + _preferLocal);

        if (_preferLocal) {
          console.log('Chronos Cloud: lokális egyértelműen újabb – felhő frissítése.');
          try { window.ChronosCloud.flush(state); } catch(e) { try { window.ChronosCloud.save(state); } catch(e2) {} }
          _setStatus((window._currentTranslations&&window._currentTranslations.drvSynced)||'✅ Felhő: helyi adat frissebb, szinkronizálva', '#00e5a0');
        } else {
          // Felhő nyer — PIN/bio helyi marad
          const _localSecCloud = {
            pinEnabled: state.pinEnabled,
            pinHash: state.pinHash,
            biometricEnabled: state.biometricEnabled,
            webauthnCredentialId: state.webauthnCredentialId,
            biometricOnStart: state.biometricOnStart,
            biometricOnAutoLock: state.biometricOnAutoLock,
            biometricOnPayroll: state.biometricOnPayroll,
          };
          state = migrateState(cloudData);
          Object.assign(state, _localSecCloud);
          console.log('Chronos Cloud: felhő alkalmazva, sched=' + Object.keys(state.schedules||{}).length);
          try { localStorage.setItem(LS.state, JSON.stringify(state)); } catch(e) {}
          _renderAll();
          const cloudDate = cloudData.lastSaved ? new Date(cloudData.lastSaved).toLocaleString('de-DE') : '?';
          _setStatus(((window._currentTranslations&&window._currentTranslations.drvLoaded)||((d)=>'✅ Felhő: adat betöltve ('+d+')'))(cloudDate), '#00e5a0');
          console.log('Chronos: Felhő betöltve (' + cloudDate + ').');
        }
        try {
          const _now = new Date();
          localStorage.setItem('chronos_driveLastSync', _now.toISOString());
          if (_pill)  _pill.className  = 'cloud-pill ok';
          if (_label) _label.textContent = _now.getHours().toString().padStart(2,'0') + ':' + _now.getMinutes().toString().padStart(2,'0');
        } catch(e) {}
        setTimeout(function() { _setStatus('', ''); }, 4000);
      } catch(e) {
        _setStatus((window._currentTranslations&&window._currentTranslations.drvNotAvail)||'⚠️ Felhő szinkron hiba', '#f87171');
        if (_pill)  _pill.className = 'cloud-pill err';
        if (_label) _label.textContent = '!';
        console.warn('Chronos Cloud load error:', e);
      }
    }

    // Globális export: az onboarding-flow és más külső closure-ök is
    // (pl. a régi DOMContentLoaded listener) biztonságosan elérik innen.
    window.loadStateFromDrive = loadStateFromDrive;

    // ── Havi biztonsági mentés emlékeztető ──────────────────────────────────
    function checkBackupReminder() {
      // Capacitor APK-ban ne mutassuk (natív app)
      if (window.Capacitor) return;
      const INTERVAL_DAYS = 30;
      const key = LS.lastBackupReminder;
      const now = Date.now();
      const last = parseInt(localStorage.getItem(key) || '0');
      const daysSince = Math.floor((now - last) / (1000 * 60 * 60 * 24));
      // Csak akkor mutassuk ha van érdemi adat
      const hasData = Object.keys(state.schedules || {}).length > 0
                   || (state.grundlohn && state.grundlohn > 0);
      if (!hasData) return;
      if (last === 0 || daysSince >= INTERVAL_DAYS) {
        const lang = (state && state.currentLang) || 'hu';
        const msgs = {
          hu: `💾 Biztonsági mentés emlékeztető\n\nUtoljára ${last === 0 ? 'még sosem' : daysSince + ' napja'} mentettél biztonsági másolatot.\n\nSzeretné most exportálni az adatokat?`,
          de: `💾 Backup-Erinnerung\n\nDu hast ${last === 0 ? 'noch nie' : 'vor ' + daysSince + ' Tagen'} eine Sicherung erstellt.\n\nMöchtest du jetzt exportieren?`,
          en: `💾 Backup reminder\n\nYou last backed up ${last === 0 ? 'never' : daysSince + ' days ago'}.\n\nWould you like to export now?`,
          bs: `💾 Podsjetnik za sigurnosnu kopiju\n\nZadnji put si sačuvao sigurnosnu kopiju ${last === 0 ? 'nikad' : 'prije ' + daysSince + ' dana'}.\n\nŽeliš li sada izvesti podatke?`,
          ro: `💾 Memento backup\n\nUltimul backup a fost ${last === 0 ? 'niciodată' : 'acum ' + daysSince + ' zile'}.\n\nDoriți să exportați acum?`,
          tr: `💾 Yedek hatırlatıcı\n\nSon yedeği ${last === 0 ? 'hiç almadın' : daysSince + ' gün önce aldın'}.\n\nŞimdi dışa aktarmak ister misin?`,
          el: `💾 Υπενθύμιση αντιγράφου\n\nΤελευταίο αντίγραφο ${last === 0 ? 'ποτέ' : 'πριν ' + daysSince + ' μέρες'}.\n\nΘέλετε να εξαγάγετε τώρα;`,
          ru: `💾 Напоминание о резервной копии\n\nПоследнее резервное копирование: ${last === 0 ? 'никогда' : daysSince + ' дней назад'}.\n\nЖелаете экспортировать сейчас?`,
          uk: `💾 Нагадування про резервну копію\n\nОстання копія: ${last === 0 ? 'ніколи' : daysSince + ' днів тому'}.\n\nБажаєте експортувати зараз?`,
          ar: `💾 تذكير النسخ الاحتياطي\n\nآخر نسخة احتياطية: ${last === 0 ? 'أبدًا' : 'منذ ' + daysSince + ' أيام'}.\n\nهل تريد التصدير الآن؟`
        };
        const msg = msgs[lang] || msgs.de;
        // Kis késleltetés hogy az app teljesen betöltsön
        setTimeout(() => {
          if (confirm(msg)) {
            localStorage.setItem(key, now.toString());
            // Azonnal exportál – ugyanaz mint az Export gomb
            const defaultName = `chronos_${new Date().toISOString().slice(0, 10)}`;
            const data = JSON.stringify(state, null, 2);
            const blob = new Blob([data], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = defaultName + '.json';
            a.click();
            URL.revokeObjectURL(a.href);
          } else {
            // Elhalasztja – 30 nap múlva újra kérdez
            localStorage.setItem(key, now.toString());
          }
        }, 2500);
      }
    }

    function getAllShifts() {
      const overrides = state.builtinOverrides || {};
      const builtin = BUILTIN_SHIFTS.map(s => {
        if (overrides[s.id]) {
          // Csak a színt módosítjuk; a nevet a getShiftName kezeli (builtinOverrides + fordítás)
          return { ...s, color: overrides[s.id].color || s.color };
        }
        return s;
      });
      return [...builtin, ...(state.customShifts || [])];
    }

    function getShiftName(shift) {
      if (!shift) return '';
      const lang = state.currentLang;
      // 1. Felhasználó által átnevezett built-in műszak (felülírja a fordítást)
      const overrideName = (state.builtinOverrides || {})[shift.id]?.name;
      if (overrideName) return overrideName;
      // 2. Fordítási tábla (kiválasztott nyelv)
      const tr = TRANSLATIONS[lang];
      if (tr && tr.shiftNames && tr.shiftNames[shift.id]) return tr.shiftNames[shift.id];
      // 3. Egyéni műszak neve
      if (!shift.builtin) return shift.name;
      // 4. Nyelv szerinti fallback
      if (lang === 'de') return shift.nameDe || shift.name;
      if (lang === 'en') return shift.nameEn || shift.name;
      return shift.nameDe || shift.nameEn || shift.name;
    }

    // Pótlék szabály neve: nameKey → fordítás, vagy fallback a mentett name-re
    function getPotlekName(rule) {
      if (rule.nameKey) {
        const tr = TRANSLATIONS[state.currentLang];
        const sn = tr && tr.surchargeNames;
        if (sn && sn[rule.nameKey]) return sn[rule.nameKey];
        // Ha nincs fordítás, próbáljuk DE-t mint alapértelmezett
        const de = TRANSLATIONS.de && TRANSLATIONS.de.surchargeNames;
        if (de && de[rule.nameKey]) return de[rule.nameKey];
      }
      return rule.name || '';
    }
    function showNotification(msg, duration = 3000, type = 'success') {
      // Ha a 2. paraméter string, akkor régi stílusú hívás (msg, type)
      if (typeof duration === 'string') { type = duration; duration = 3000; }
      const notif = document.createElement('div');
      notif.className = 'notification' + (type === 'warning' ? ' warning' : '');
      notif.textContent = msg;
      if (type === 'warning') notif.style.borderColor = 'var(--yellow)';
      else if (type === 'error') notif.style.borderColor = 'var(--red)';
      else notif.style.borderColor = 'var(--green)';
      document.body.appendChild(notif);
      setTimeout(() => notif.remove(), duration);
    }

    // Natív in-app megerősítő dialógus – a böngésző confirm() helyett (Capacitor-barát)
    function showConfirmDialog(msg, callback) {
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
      const box = document.createElement('div');
      box.style.cssText = 'background:var(--surface,#1a1f2e);border:1px solid rgba(95,158,247,0.25);border-radius:18px;padding:24px 20px;max-width:320px;width:100%;box-shadow:0 8px 40px rgba(0,0,0,0.6);';
      box.innerHTML = `
        <div style="font-size:28px;text-align:center;margin-bottom:12px;">👆</div>
        <p style="color:#e8eeff;font-size:14px;text-align:center;margin:0 0 20px;line-height:1.5;">${msg}</p>
        <div style="display:flex;gap:10px;">
          <button id="_cdNo" style="flex:1;padding:12px;border-radius:12px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.05);color:#7a8ab0;font-size:14px;cursor:pointer;">✕</button>
          <button id="_cdYes" style="flex:2;padding:12px;border-radius:12px;border:none;background:linear-gradient(135deg,#4f8ef5,#7b61ff);color:#fff;font-size:14px;font-weight:700;cursor:pointer;">${(window._currentTranslations&&window._currentTranslations.yes)||'Igen'}</button>
        </div>`;
      overlay.appendChild(box);
      document.body.appendChild(overlay);
      const close = (val) => { overlay.remove(); callback(val); };
      box.querySelector('#_cdYes').addEventListener('click', () => close(true));
      box.querySelector('#_cdNo').addEventListener('click', () => close(false));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(false); });
    }

    // ==================== ÜNNEPNAPOK (Gesetzliche Feiertage) ====================
    function getGermanHolidays(year, bundesland) {
      // Húsvét számítása (Gauss algoritmus)
      const easterSunday = (y) => {
        const a = y % 19, b = Math.floor(y / 100), c = y % 100;
        const d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25);
        const g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
        const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7;
        const m = Math.floor((a + 11 * h + 22 * l) / 451);
        const month = Math.floor((h + l - 7 * m + 114) / 31);
        const day = ((h + l - 7 * m + 114) % 31) + 1;
        return new Date(y, month - 1, day);
      };

      const easter = easterSunday(year);
      const addDays = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
      const fmt = (d) => `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;

      // Bundesweite Feiertage
      const holidays = {
        [fmt(new Date(year,0,1))]:   'Neujahr',
        [fmt(addDays(easter,-2))]:   'Karfreitag',
        [fmt(easter)]:               'Ostersonntag',
        [fmt(addDays(easter,1))]:    'Ostermontag',
        [fmt(new Date(year,4,1))]:   'Tag der Arbeit',
        [fmt(addDays(easter,39))]:   'Christi Himmelfahrt',
        [fmt(addDays(easter,49))]:   'Pfingstsonntag',
        [fmt(addDays(easter,50))]:   'Pfingstmontag',
        [fmt(new Date(year,9,3))]:   'Tag der Deutschen Einheit',
        [fmt(new Date(year,11,25))]: 'Erster Weihnachtstag',
        [fmt(new Date(year,11,26))]: 'Zweiter Weihnachtstag',
      };

      // Bundesland-spezifikus ünnepek
      const bl = bundesland || 'BW';

      if (['BW','BY','ST'].includes(bl)) // Heilige Drei Könige
        holidays[fmt(new Date(year,0,6))] = 'Heilige Drei Könige';

      if (['BB','MV','SN','ST','TH'].includes(bl)) // Reformationstag
        holidays[fmt(new Date(year,9,31))] = 'Reformationstag';

      if (['BW','BY','NW','RP','SL'].includes(bl)) // Fronleichnam
        holidays[fmt(addDays(easter,60))] = 'Fronleichnam';

      if (['BY','SL'].includes(bl)) // Mariä Himmelfahrt
        holidays[fmt(new Date(year,7,15))] = 'Mariä Himmelfahrt';

      if (['BW'].includes(bl)) // Allerheiligen BW
        holidays[fmt(new Date(year,10,1))] = 'Allerheiligen';
      if (['BY'].includes(bl)) // Allerheiligen BY
        holidays[fmt(new Date(year,10,1))] = 'Allerheiligen';
      if (['NW','RP','SL'].includes(bl)) // Allerheiligen
        holidays[fmt(new Date(year,10,1))] = 'Allerheiligen';

      if (['SN'].includes(bl)) // Buß- und Bettag
        holidays[fmt(getBussUndBettag(year))] = 'Buß- und Bettag';

      if (['TH'].includes(bl)) // Weltkindertag
        holidays[fmt(new Date(year,8,20))] = 'Weltkindertag';

      if (['SH','HH','HB','NI','MV'].includes(bl)) // Internationaler Frauentag
        holidays[fmt(new Date(year,2,8))] = 'Internationaler Frauentag';

      if (['BE'].includes(bl)) // Frauentag Berlin
        holidays[fmt(new Date(year,2,8))] = 'Internationaler Frauentag';

      return holidays;
    }

    function getBussUndBettag(year) {
      // Buß- und Bettag: Mittwoch vor dem 23. November
      const nov23 = new Date(year, 10, 23);
      const dow = nov23.getDay(); // 0=Sun
      const diff = (dow === 3) ? 0 : (dow < 3) ? -(dow + 4) : (3 - dow + 7) % 7 - 7;
      return new Date(year, 10, 23 + diff - (dow >= 3 ? dow - 3 : dow + 4));
    }

    function isPublicHoliday(year, month1based, day) {
      const holidays = getGermanHolidays(year, state.bundesland);
      return `${year}-${month1based}-${day}` in holidays;
    }

    function getHolidayName(year, month1based, day) {
      const holidays = getGermanHolidays(year, state.bundesland);
      return holidays[`${year}-${month1based}-${day}`] || null;
    }

    // ==================== NAPTÁR MEGJELENÍTÉS ====================
    function renderCalendar(slideDir) {
      const lang = state.currentLang;
      const year = state.year;
      const month = state.month;

      document.getElementById('monthDisplay').textContent = 
        (MONTH_NAMES[lang] || MONTH_NAMES.hu)[month] + ' ' + year;

      const wd = document.getElementById('weekdays');
      wd.innerHTML = '';
      (WEEKDAY_NAMES[lang] || WEEKDAY_NAMES.hu).forEach(d => {
        const el = document.createElement('div');
        el.textContent = d;
        wd.appendChild(el);
      });

      const cal = document.getElementById('calendar');
      cal.innerHTML = '';

      const firstDow = (new Date(year, month, 1).getDay() + 6) % 7;
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const prevDays = new Date(year, month, 0).getDate();
      const today = new Date();

      for (let i = 0; i < firstDow; i++) {
        const d = prevDays - firstDow + 1 + i;
        const g = document.createElement('div');
        g.className = 'day other-month';
        g.style.opacity = '1';
        const dowLblG = document.createElement('div');
        dowLblG.className = 'day-dow';
        dowLblG.style.opacity = '0.2';
        const prevDate = new Date(month === 0 ? year - 1 : year, month === 0 ? 11 : month - 1, d);
        const prevDow = prevDate.getDay();
        const wdNamesG = (WEEKDAY_NAMES[lang] || WEEKDAY_NAMES.hu);
        dowLblG.textContent = wdNamesG[(prevDow + 6) % 7];
        g.appendChild(dowLblG);
        const num = document.createElement('div');
        num.className = 'day-dnum';
        num.textContent = d;
        num.style.opacity = '0.3';
        g.appendChild(num);
        const prevKey = `${month === 0 ? year - 1 : year}-${month === 0 ? 12 : month}-${d}`;
        const prevShifts = state.schedules[prevKey] || [];
        if (prevShifts.length) {
          const all = getAllShifts();
          const linesDiv = document.createElement('div');
          linesDiv.className = 'lines';
          prevShifts.forEach(id => {
            const s = all.find(x => x.id === id);
            if (s) {
              const row = document.createElement('div'); row.className = 'line-row';
              const l = document.createElement('div'); l.className = 'line full';
              l.style.background = s.color;
              row.appendChild(l); linesDiv.appendChild(row);
            }
          });
          g.appendChild(linesDiv);
        }
        cal.appendChild(g);
      }

      for (let d = 1; d <= daysInMonth; d++) {
        const key = `${year}-${month + 1}-${d}`;
        const shiftIds = state.schedules[key] || [];
        const all = getAllShifts();
        const date = new Date(year, month, d);
        const dow = date.getDay();
        const isWeekend = dow === 0 || dow === 6;
        const isToday = today.getDate() === d && 
                       today.getMonth() === month && 
                       today.getFullYear() === year;

        const isHolidayDay = isPublicHoliday(year, month + 1, d);
        const holidayName = isHolidayDay ? getHolidayName(year, month + 1, d) : null;

        const el = document.createElement('div');
        el.className = 'day' + (isWeekend ? ' weekend' : '') + (isToday ? ' today' : '') + (isHolidayDay ? ' public-holiday' : '');

        if (isHolidayDay && holidayName) {
          el.title = holidayName;
        }

        // B+C stílus: napnév felül + szám + (műszak rövidítés) + színes sáv alul
        const wdNames = (WEEKDAY_NAMES[lang] || WEEKDAY_NAMES.hu);
        const dowLbl = document.createElement('div');
        dowLbl.className = 'day-dow';
        dowLbl.textContent = wdNames[(dow + 6) % 7]; // Mon-based
        el.appendChild(dowLbl);

        const dnEl = document.createElement('div');
        dnEl.className = 'day-dnum';
        dnEl.textContent = d;
        el.appendChild(dnEl);

        // Műszak rövidítés előre kiszámítva (első nem-Urlaub shift)
        const ABBR_MAP = {
          'Früh': 'Fr', 'Spät': 'Sp', 'Nacht': 'Na',
          'Freiwillig Früh': 'FwF', 'Freiwillig Spät': 'FwS', 'Freiwillig Nacht': 'FwN',
          'Fei Fr': 'FeF', 'Fei Sp': 'FeS', 'Fei Na': 'FeN',
          'Urlaub': 'U', 'Urlaub1': 'U½', 'Urlaub2': 'U½', 'Krank': 'Kr', 'ZK': 'ZK', 'ZK1': 'ZK½', 'ZK2': 'ZK½',
        };
        const firstShiftId = shiftIds.find(id => id !== 'Urlaub1' && id !== 'Urlaub2' && id !== 'ZK1' && id !== 'ZK2');
        if (firstShiftId) {
          const fs = all.find(x => x.id === firstShiftId);
          const abbr = ABBR_MAP[firstShiftId] || (fs ? fs.id.substring(0, 3) : '');
          if (abbr && fs) {
            const abEl = document.createElement('div');
            abEl.className = 'day-abbr';
            abEl.style.color = fs.color;
            abEl.textContent = abbr;
            el.appendChild(abEl);
          }
        }

        if (shiftIds.length) {
          const linesDiv = document.createElement('div');
          linesDiv.className = 'lines';

          const hasU1 = shiftIds.includes('Urlaub1') || shiftIds.includes('ZK1');
          const hasU2 = shiftIds.includes('Urlaub2') || shiftIds.includes('ZK2');
          const _u1Color = shiftIds.includes('ZK1') ? '#a78bfa' : '#94a3b8';
          const _u2Color = shiftIds.includes('ZK2') ? '#a78bfa' : '#94a3b8';
          const others = shiftIds.filter(id => id !== 'Urlaub1' && id !== 'Urlaub2' && id !== 'ZK1' && id !== 'ZK2');

          if (hasU1 || hasU2) {
            const row = document.createElement('div');
            row.className = 'line-row';

            if (hasU1) {
              const l = document.createElement('div');
              l.className = 'line half-left';
              l.style.background = _u1Color;
              row.appendChild(l);
            }

            if (hasU2) {
              const l = document.createElement('div');
              l.className = 'line half-right';
              l.style.background = _u2Color;
              row.appendChild(l);
            }

            if (others.length > 0 && !(hasU1 && hasU2)) {
              const firstShift = all.find(s => s.id === others[0]);
              if (firstShift) {
                const l = document.createElement('div');
                l.className = hasU1 ? 'line half-right' : 'line half-left';
                l.style.background = firstShift.color;

                if (hasU2 && !hasU1) {
                  row.insertBefore(l, row.firstChild);
                } else {
                  row.appendChild(l);
                }
              }

              for (let i = 1; i < others.length; i++) {
                const s = all.find(x => x.id === others[i]);
                if (s) {
                  const r = document.createElement('div');
                  r.className = 'line-row';
                  const l2 = document.createElement('div');
                  l2.className = 'line full';
                  l2.style.background = s.color;
                  r.appendChild(l2);
                  linesDiv.appendChild(r);
                }
              }
            } else if (others.length > 0 && hasU1 && hasU2) {
              for (let i = 0; i < others.length; i++) {
                const s = all.find(x => x.id === others[i]);
                if (s) {
                  const r = document.createElement('div');
                  r.className = 'line-row';
                  const l2 = document.createElement('div');
                  l2.className = 'line full';
                  l2.style.background = s.color;
                  r.appendChild(l2);
                  linesDiv.appendChild(r);
                }
              }
            }

            linesDiv.appendChild(row);
          } else {
            others.forEach(id => {
              const s = all.find(x => x.id === id);
              if (s) {
                const r = document.createElement('div');
                r.className = 'line-row';
                const l = document.createElement('div');
                l.className = 'line full';
                l.style.background = s.color;
                r.appendChild(l);
                linesDiv.appendChild(r);
              }
            });
          }

          el.appendChild(linesDiv);
        }

        el.addEventListener('click', (e) => {
          // Ripple animáció – a #calendar containerbe rakjuk, mert el.appendChild
          // után a renderCalendar() azonnal törli a nap-elemet
          const calContainer = document.getElementById('calendar');
          if (calContainer) {
            const calRect = calContainer.getBoundingClientRect();
            const rx = e.clientX - calRect.left;
            const ry = e.clientY - calRect.top;
            const rEl = document.createElement('span');
            rEl.style.cssText = `position:absolute;left:${rx}px;top:${ry}px;width:100px;height:100px;border-radius:50%;background:rgba(255,255,255,0.15);transform:translate(-50%,-50%) scale(0);animation:chronos-ripple 0.55s ease-out forwards;pointer-events:none;z-index:10;`;
            calContainer.style.position = 'relative';
            calContainer.appendChild(rEl);
            setTimeout(() => rEl.remove(), 600);
          }

          const key = `${state.year}-${state.month + 1}-${d}`;
          const layers = (state.schedules[key] || []).slice();
          const idx = layers.indexOf(state.selectedShift);

          if (idx !== -1) {
            layers.splice(idx, 1);
          } else {
            layers.push(state.selectedShift);
          }

          if (layers.length) {
            state.schedules[key] = layers;
          } else {
            delete state.schedules[key];
          }

          saveState();
          if (window._arDetectFromSchedule) setTimeout(window._arDetectFromSchedule, TIMING.AR_DETECT_AFTER_IMPORT);
          renderCalendar();
          updateVacation();
        });

        cal.appendChild(el);
      }

      const total = firstDow + daysInMonth;
      const rem = total % 7;
      if (rem > 0) {
        const nextYear = month === 11 ? year + 1 : year;
        const nextMonth = month === 11 ? 1 : month + 2;
        for (let n = 1; n <= 7 - rem; n++) {
          const g = document.createElement('div');
          g.className = 'day other-month';
          g.style.opacity = '1';
          const num = document.createElement('span');
          num.textContent = n;
          num.style.opacity = '0.3';
          g.appendChild(num);
          const nextKey = `${nextYear}-${nextMonth}-${n}`;
          const nextShifts = state.schedules[nextKey] || [];
          if (nextShifts.length) {
            const all = getAllShifts();
            const linesDiv = document.createElement('div');
            linesDiv.className = 'lines';
            nextShifts.forEach(id => {
              const s = all.find(x => x.id === id);
              if (s) {
                const row = document.createElement('div'); row.className = 'line-row';
                const l = document.createElement('div'); l.className = 'line full';
                l.style.background = s.color;
                row.appendChild(l); linesDiv.appendChild(row);
              }
            });
            g.appendChild(linesDiv);
          }
          cal.appendChild(g);
        }
      }

      // Slide animáció hónap-váltáskor
      if (slideDir === 'next' || slideDir === 'prev') {
        cal.classList.remove('anim-r', 'anim-l');
        void cal.offsetWidth;
        cal.classList.add(slideDir === 'next' ? 'anim-l' : 'anim-r');
        cal.addEventListener('animationend', () => cal.classList.remove('anim-r', 'anim-l'), { once: true });
      }
    }

    // ==================== MŰSZAKOK MEGJELENÍTÉSE ====================
    function renderShifts() {
      const qb = document.getElementById('quickButtons');
      qb.innerHTML = '';

      const all = getAllShifts();

      // Use state-stored quickIds order, fallback to defaults
      if (!state.quickIds || state.quickIds.length === 0) {
        state.quickIds = ['Früh', 'Spät', 'Nacht', 'Freiwillig Früh', 'Freiwillig Spät', 'Freiwillig Nacht', 'Urlaub', 'Krank', 'ZK'];
      }
      // Fei* shift-eket kizárjuk a gyors gombokból (automatikusan kezeltek)
      // hiddenShifts konzisztencia: ha valami hidden, a quickIds-ből is kizárjuk
      const _hiddenSet = new Set(state.hiddenShifts || []);
      const quickIds = state.quickIds.filter(id => !id.startsWith('Fei') && !_hiddenSet.has(id));

      let dragSrcId = null;

      quickIds.forEach(id => {
        const s = all.find(x => x.id === id);
        if (!s) return;

        const btn = document.createElement('div');
        btn.className = 'quick-btn' + (s.id === state.selectedShift ? ' active' : '');
        btn.draggable = true;
        btn.dataset.shiftId = s.id;

        const dot = document.createElement('span');
        dot.className = 'color-dot';
        dot.style.background = s.color;

        btn.appendChild(dot);
        btn.appendChild(document.createTextNode(getShiftName(s)));

        btn.addEventListener('click', () => {
          if (s.id === 'Urlaub') {
            openShiftSheet('urlaub');
            return;
          }
          if (s.id === 'ZK') {
            openShiftSheet('zk');
            return;
          }
          state.selectedShift = s.id;
          renderShifts();
        });

        // Drag-and-drop for reordering
        btn.addEventListener('dragstart', e => {
          dragSrcId = s.id;
          btn.classList.add('dragging');
          e.dataTransfer.effectAllowed = 'move';
        });
        btn.addEventListener('dragend', () => {
          btn.classList.remove('dragging');
          qb.querySelectorAll('.quick-btn').forEach(b => b.classList.remove('drag-over'));
        });
        btn.addEventListener('dragover', e => {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
          btn.classList.add('drag-over');
        });
        btn.addEventListener('dragleave', () => {
          btn.classList.remove('drag-over');
        });
        btn.addEventListener('drop', e => {
          e.preventDefault();
          e.stopPropagation();
          btn.classList.remove('drag-over');
          if (dragSrcId && dragSrcId !== s.id) {
            const srcIdx = state.quickIds.indexOf(dragSrcId);
            const dstIdx = state.quickIds.indexOf(s.id);
            if (srcIdx !== -1 && dstIdx !== -1) {
              state.quickIds.splice(srcIdx, 1);
              state.quickIds.splice(dstIdx, 0, dragSrcId);
              saveState();
              renderShifts();
            }
          }
        });

        qb.appendChild(btn);
      });

      const panel = document.getElementById('shiftPanel');
      panel.innerHTML = '';

      // Panel mindig lista nézetben jelenik meg
      panel.classList.add('list-mode');

      // ── LISTA NÉZET ──
      if (true) {
        const hiddenIds = state.hiddenShifts || [];
        const groups = [
          { key: 'normal', ids: ['Früh','Spät','Nacht'], labelKey: 'groupNormal', labelFb: 'Normál műszakok' },
          { key: 'fw',     ids: ['Freiwillig Früh','Freiwillig Spät','Freiwillig Nacht'], labelKey: 'groupFw', labelFb: 'Önkéntes (Freiwillig)' },
          { key: 'vac',    ids: ['Urlaub','Krank'], labelKey: 'groupVac', labelFb: 'Szabadság / Beteg' },
          { key: 'other',  ids: ['ZK'], labelKey: 'groupOther', labelFb: 'Egyéb' },
        ];
        // Custom műszakok az Egyéb csoportba
        const customShifts = (state.customShifts || []).filter(s => !hiddenIds.includes(s.id));
        const allForList = getAllShifts().filter(s =>
          !hiddenIds.includes(s.id) &&
          !s.id.startsWith('Fei') &&
          s.id !== 'ZK1' && s.id !== 'ZK2'
        );
        // Szín-badge helper
        const _badgeStyle = (type) => {
          if (type === 'overtime') return 'background:rgba(249,115,22,0.2);color:#fb923c';
          return 'background:rgba(34,197,94,0.2);color:#4ade80';
        };
        const _renderListShift = (s) => {
          const inQ = state.quickIds.includes(s.id);
          const row = document.createElement('div');
          row.className = 'shift-list-row';
          // Bal színsáv
          const bar = document.createElement('div');
          bar.className = 'shift-list-color-bar';
          bar.style.background = s.color;
          // Info
          const info = document.createElement('div');
          info.className = 'shift-list-info';
          const nameEl = document.createElement('div');
          nameEl.className = 'shift-list-name';
          nameEl.textContent = getShiftName(s);
          const meta = document.createElement('div');
          meta.className = 'shift-list-meta';
          if (s.start && s.end) {
            const timeEl = document.createElement('span');
            timeEl.className = 'shift-list-time';
            timeEl.textContent = s.start + ' – ' + s.end;
            meta.appendChild(timeEl);
          }
          // Pótlék badge-ek az aktuális kijelölt szabályok alapján
          const _idxs = (() => {
            if (!state.shiftSurchargeRuleIdxs) return [];
            const stored = state.shiftSurchargeRuleIdxs[s.id];
            if (stored && stored.length) return stored;
            const oldIdx = (state.shiftSurchargeRuleIdx || {})[s.id];
            if (oldIdx != null) return [oldIdx];
            if (!s.builtin && s.surchargeRuleIdx != null) return [s.surchargeRuleIdx];
            return [];
          })();
          const _rules = state.potlekRules || [];
          if (_idxs.length) {
            _idxs.forEach(ri => {
              const r = _rules[ri];
              if (!r) return;
              const hasTime = r.start && r.end && !(r.start==='00:00'&&r.end==='24:00') && r.type!=='overtime';
              const b = document.createElement('span');
              b.className = 'shift-list-badge';
              b.style.cssText = _badgeStyle(r.type);
              b.textContent = r.percent + '%' + (hasTime ? ' ('+r.start+'–'+r.end+')' : '');
              meta.appendChild(b);
            });
          } else if (s.id.startsWith('Freiwillig')) {
            const b = document.createElement('span');
            b.className = 'shift-list-badge';
            b.style.cssText = _badgeStyle('overtime');
            b.textContent = t('overtimeBadge')||'túlóra';
            meta.appendChild(b);
          }
          info.appendChild(nameEl);
          info.appendChild(meta);
          // Jobb oldal: badge gomb + csillag
          const right = document.createElement('div');
          right.className = 'shift-list-right';
          // Pótlék badge gomb (mini)
          const badgeBtn2 = document.createElement('button');
          badgeBtn2.className = 'potlek-badge-btn';
          badgeBtn2.style.maxWidth = '90px';
          const _curIdxs2 = _idxs;
          badgeBtn2.textContent = _curIdxs2.length
            ? _curIdxs2.map(i => _rules[i] ? _rules[i].percent+'%' : '').filter(Boolean).join('+')
            : (t('defaultSurcharge')||'– alap –');
          if (_curIdxs2.length) badgeBtn2.classList.add('has-rules');
          badgeBtn2.addEventListener('click', e => {
            e.stopPropagation();
            const existingOverlay = document.getElementById('potlekPopupOverlay');
            if (existingOverlay) existingOverlay.remove();
            // Mindig friss potlekRules (ha új szabály lett hozzáadva)
            const rulesList = state.potlekRules || [];
            // Aktuális indexek frissen olvasva (ne closure)
            const curIdxs3 = (() => {
              if (!state.shiftSurchargeRuleIdxs) return [];
              const st = state.shiftSurchargeRuleIdxs[s.id];
              if (st && st.length) return st.slice();
              const oi = (state.shiftSurchargeRuleIdx || {})[s.id];
              if (oi != null) return [oi];
              if (!s.builtin && s.surchargeRuleIdx != null) return [s.surchargeRuleIdx];
              return [];
            })();
            const overlay2 = document.createElement('div');
            overlay2.id = 'potlekPopupOverlay';
            overlay2.className = 'potlek-popup-overlay';
            const popup2 = document.createElement('div');
            popup2.className = 'potlek-popup';
            const title2 = document.createElement('div');
            title2.className = 'potlek-popup-title';
            title2.textContent = t('surchargeRules') || 'Pótlék szabályok';
            popup2.appendChild(title2);
            const cbs2 = [];
            rulesList.forEach((rule, ri) => {
              const item2 = document.createElement('label');
              item2.className = 'potlek-popup-item';
              const cb2 = document.createElement('input');
              cb2.type = 'checkbox';
              cb2.checked = curIdxs3.includes(ri);
              cbs2.push({ cb: cb2, ri });
              const lbl2 = document.createElement('div');
              lbl2.className = 'potlek-popup-item-label';
              const hasT = rule.start && rule.end && !(rule.start==='00:00'&&rule.end==='24:00') && rule.type!=='overtime';
              const taxS = rule.taxFree ? (t('taxFreeShort')||'adóm.') : (t('taxableShort')||'adóz.');
              lbl2.innerHTML = `<b>${rule.percent}%${hasT?' ('+rule.start+'–'+rule.end+')':''}</b> · ${taxS}<small>${getPotlekName(rule)}</small>`;
              item2.appendChild(cb2); item2.appendChild(lbl2);
              popup2.appendChild(item2);
              cb2.addEventListener('change', () => {
                const newIdxs2 = cbs2.filter(x => x.cb.checked).map(x => x.ri);
                if (!state.shiftSurchargeRuleIdxs) state.shiftSurchargeRuleIdxs = {};
                state.shiftSurchargeRuleIdxs[s.id] = newIdxs2;
                const fr = newIdxs2.length ? rulesList[newIdxs2[0]] : null;
                if (s.builtin) {
                  if (!state.shiftSurcharges) state.shiftSurcharges = {};
                  if (!state.shiftSurchargeRuleIdx) state.shiftSurchargeRuleIdx = {};
                  if (!state.shiftSurchargeRuleType) state.shiftSurchargeRuleType = {};
                  if (!fr) { delete state.shiftSurcharges[s.id]; delete state.shiftSurchargeRuleIdx[s.id]; delete state.shiftSurchargeRuleType[s.id]; }
                  else { state.shiftSurcharges[s.id]=fr.percent; state.shiftSurchargeRuleIdx[s.id]=newIdxs2[0]; if(fr.type) state.shiftSurchargeRuleType[s.id]=fr.type; }
                } else {
                  s.surchargePercent = fr ? fr.percent : null;
                  s.surchargeRuleIdx = newIdxs2[0] ?? null;
                  s.surchargeRuleType = fr ? fr.type : null;
                  const idx3 = (state.customShifts||[]).findIndex(cs=>cs.id===s.id);
                  if (idx3!==-1) { state.customShifts[idx3].surchargePercent=s.surchargePercent; state.customShifts[idx3].surchargeRuleIdx=s.surchargeRuleIdx; state.customShifts[idx3].surchargeRuleType=s.surchargeRuleType; }
                }
                badgeBtn2.textContent = newIdxs2.length ? newIdxs2.map(i=>rulesList[i]?rulesList[i].percent+'%':'').filter(Boolean).join('+') : (t('defaultSurcharge')||'– alap –');
                badgeBtn2.classList.toggle('has-rules', newIdxs2.length > 0);
                saveState();
              });
            });
            document.body.appendChild(overlay2); document.body.appendChild(popup2);
            const rect2 = badgeBtn2.getBoundingClientRect();
            const popW2=250, popH2=Math.min(280,48+rulesList.length*38);
            let top2=rect2.bottom+4, left2=rect2.left;
            if (left2+popW2>window.innerWidth-8) left2=window.innerWidth-popW2-8;
            if (top2+popH2>window.innerHeight-8) top2=rect2.top-popH2-4;
            popup2.style.top=top2+'px'; popup2.style.left=left2+'px';
            overlay2.addEventListener('click', () => { overlay2.remove(); popup2.remove(); });
          });
          // Csillag
          const star = document.createElement('span');
          star.className = 'shift-list-star';
          star.textContent = inQ ? '⭐' : '☆';
          star.title = inQ ? (t('removeFromQuick')||'Remove') : (t('addToQuick')||'Add');
          star.addEventListener('click', e => {
            e.stopPropagation();
            const idx = state.quickIds.indexOf(s.id);
            if (idx !== -1) state.quickIds.splice(idx, 1);
            else state.quickIds.push(s.id);
            saveState(); renderShifts();
          });
          // ✏️ Szerkesztés gomb
          const editBtn2 = document.createElement('button');
          editBtn2.textContent = '✏️';
          editBtn2.title = t('editShiftLabel') || 'Szerkesztés';
          editBtn2.style.cssText = 'background:none;border:none;font-size:14px;cursor:pointer;padding:2px 3px;line-height:1;flex-shrink:0;';
          editBtn2.addEventListener('click', e => {
            e.stopPropagation();
            openShiftEdit(s);
          });

          // 🗑️ Törlés gomb
          const delBtn2 = document.createElement('button');
          delBtn2.textContent = '🗑️';
          delBtn2.title = t('deleteShiftLabel') || 'Törlés';
          delBtn2.style.cssText = 'background:none;border:none;font-size:14px;cursor:pointer;padding:2px 3px;line-height:1;flex-shrink:0;';
          delBtn2.addEventListener('click', e => {
            e.stopPropagation();
            const confirmMsg = (t('confirmDeleteShift') || 'Törlöd: {name}?').replace('{name}', getShiftName(s));
            if (!confirm(confirmMsg)) return;
            if (s.builtin) {
              if (!state.hiddenShifts) state.hiddenShifts = [];
              if (!state.hiddenShifts.includes(s.id)) state.hiddenShifts.push(s.id);
            } else {
              state.customShifts = (state.customShifts || []).filter(cs => cs.id !== s.id);
            }
            saveState(); renderShifts();
          });

          right.appendChild(badgeBtn2);
          right.appendChild(editBtn2);
          right.appendChild(delBtn2);
          right.appendChild(star);
          row.appendChild(bar); row.appendChild(info); row.appendChild(right);
          row.addEventListener('click', () => {
            if (s.id === 'Urlaub') { openShiftSheet('urlaub'); return; }
            if (s.id === 'ZK') { openShiftSheet('zk'); return; }
            state.selectedShift = s.id; renderShifts();
          });
          panel.appendChild(row);
        };
        groups.forEach(g => {
          const items = allForList.filter(s => g.ids.includes(s.id));
          // Custom műszakok az utolsó csoport után
          const extras = g.key === 'other' ? customShifts : [];
          if (!items.length && !extras.length) return;
          const sec = document.createElement('div');
          sec.className = 'shift-list-section';
          sec.textContent = g.labelFb;
          panel.appendChild(sec);
          items.forEach(_renderListShift);
          extras.forEach(_renderListShift);
        });
        // + Új műszak gomb lista módban is
        const newBtnL = document.createElement('div');
        newBtnL.className = 'shift-list-row';
        newBtnL.style.justifyContent = 'center';
        newBtnL.style.color = 'var(--accent)';
        newBtnL.style.fontWeight = '600';
        newBtnL.style.fontSize = '12px';
        newBtnL.style.borderStyle = 'dashed';
        newBtnL.textContent = (t('newShiftBtn') || '+ Új műszak');
        newBtnL.addEventListener('click', () => { document.getElementById('shiftModal').classList.add('visible'); });
        panel.appendChild(newBtnL);
        return; // lista nézet kész, rács nézet kód kihagyva
      }

      // ── RÁCS NÉZET (eredeti logika) ──
      const hiddenIds = state.hiddenShifts || [];
      all.forEach(s => {
        // Ünnepnap-specifikus Fei* shift-eket kihagyjuk (automatikusan kezeltek)
        if (s.builtin && s.id.startsWith('Fei')) return;
        // ZK1/ZK2 kiszűrése: a ZK gomb sheet-en belül kezeli a félnapokat
        if (s.id === 'ZK1' || s.id === 'ZK2') return;
        // Törölt/rejtett műszakok kihagyása
        if (hiddenIds.includes(s.id)) return;

        const div = document.createElement('div');
        div.className = 'shift-item';
        div.style.borderTopColor = s.color;
        const inQuick = state.quickIds.includes(s.id);

        // Felső sor: csillag + név
        const nameRow = document.createElement('div');
        nameRow.className = 'shift-name-row';

        const starBtn = document.createElement('span');
        starBtn.title = inQuick ? (t('removeFromQuick')||'Remove') : (t('addToQuick')||'Add');
        starBtn.textContent = inQuick ? '⭐' : '☆';
        starBtn.style.cssText = 'position:absolute; top:2px; right:3px; font-size:10px; cursor:pointer; line-height:1; z-index:1;';
        starBtn.addEventListener('click', e => {
          e.stopPropagation();
          const idx = state.quickIds.indexOf(s.id);
          if (idx !== -1) {
            state.quickIds.splice(idx, 1);
          } else {
            state.quickIds.push(s.id);
          }
          saveState();
          renderShifts();
        });

        const nameSpan = document.createElement('span');
        nameSpan.textContent = getShiftName(s);
        nameSpan.style.cssText = 'font-size:11px; font-weight:600;';
        nameRow.appendChild(nameSpan);

        // Alsó sor: pótlék multi-select badge gomb
        const surchargeRow = document.createElement('div');
        surchargeRow.className = 'shift-select-row';
        surchargeRow.addEventListener('click', e => e.stopPropagation());

        // Helper: aktuális kijelölt rule indexek tömbje
        const _getPotlekIdxs = () => {
          if (!state.shiftSurchargeRuleIdxs) state.shiftSurchargeRuleIdxs = {};
          const stored = state.shiftSurchargeRuleIdxs[s.id];
          if (stored && stored.length) return stored;
          // Visszakompatibilitás: ha van régi egyedi beállítás
          const oldIdx = (state.shiftSurchargeRuleIdx || {})[s.id];
          if (oldIdx != null) return [oldIdx];
          if (!s.builtin && s.surchargeRuleIdx != null) return [s.surchargeRuleIdx];
          return [];
        };

        const _potlekBadgeLabel = (idxs) => {
          const rules = state.potlekRules || [];
          if (!idxs.length) return t('defaultSurcharge') || '– alapért. –';
          return idxs.map(i => {
            const r = rules[i];
            if (!r) return '';
            const hasTime = r.start && r.end && !(r.start==='00:00' && r.end==='24:00') && r.type!=='overtime';
            return `${r.percent}%${hasTime ? ' ('+r.start+'–'+r.end+')' : ''}`;
          }).filter(Boolean).join(' + ');
        };

        const badgeBtn = document.createElement('button');
        badgeBtn.className = 'potlek-badge-btn';
        const _curIdxs = _getPotlekIdxs();
        badgeBtn.textContent = _potlekBadgeLabel(_curIdxs);
        if (_curIdxs.length) badgeBtn.classList.add('has-rules');

        badgeBtn.addEventListener('click', e => {
          e.stopPropagation();
          // Bezárjuk az esetleg nyitott más popupot
          const existingOverlay = document.getElementById('potlekPopupOverlay');
          if (existingOverlay) existingOverlay.remove();

          const rules = state.potlekRules || [];
          const curIdxs = _getPotlekIdxs();

          const overlay = document.createElement('div');
          overlay.id = 'potlekPopupOverlay';
          overlay.className = 'potlek-popup-overlay';

          const popup = document.createElement('div');
          popup.className = 'potlek-popup';

          const title = document.createElement('div');
          title.className = 'potlek-popup-title';
          title.textContent = t('surchargeRules') || 'Pótlék szabályok';
          popup.appendChild(title);

          const checkboxes = [];
          rules.forEach((rule, ri) => {
            const item = document.createElement('label');
            item.className = 'potlek-popup-item';
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.checked = curIdxs.includes(ri);
            checkboxes.push({ cb, ri });

            const lbl = document.createElement('div');
            lbl.className = 'potlek-popup-item-label';
            const hasTime = rule.start && rule.end &&
              !(rule.start==='00:00' && rule.end==='24:00') && rule.type!=='overtime';
            const timeStr = hasTime ? ` (${rule.start}–${rule.end})` : '';
            const taxStr = rule.taxFree ? (t('taxFreeShort')||'adóm.') : (t('taxableShort')||'adóz.');
            lbl.innerHTML = `<b>${rule.percent}%${timeStr}</b> · ${taxStr}<small>${getPotlekName(rule)}</small>`;

            item.appendChild(cb);
            item.appendChild(lbl);
            popup.appendChild(item);

            cb.addEventListener('change', () => {
              const newIdxs = checkboxes.filter(x => x.cb.checked).map(x => x.ri);
              if (!state.shiftSurchargeRuleIdxs) state.shiftSurchargeRuleIdxs = {};
              state.shiftSurchargeRuleIdxs[s.id] = newIdxs;

              // Visszakompatibilitás: első kijelölt szabályt írjuk az egyedi mezőkbe is
              const firstRule = newIdxs.length ? rules[newIdxs[0]] : null;
              const firstPct = firstRule ? firstRule.percent : null;
              const firstType = firstRule ? firstRule.type : null;
              const firstNameKey = firstRule ? (firstRule.nameKey || null) : null;

              if (s.builtin) {
                if (!state.shiftSurcharges) state.shiftSurcharges = {};
                if (!state.shiftSurchargeRuleIdx) state.shiftSurchargeRuleIdx = {};
                if (!state.shiftSurchargeRuleType) state.shiftSurchargeRuleType = {};
                if (firstPct == null) {
                  delete state.shiftSurcharges[s.id];
                  delete state.shiftSurchargeRuleIdx[s.id];
                  delete state.shiftSurchargeRuleType[s.id];
                } else {
                  state.shiftSurcharges[s.id] = firstPct;
                  state.shiftSurchargeRuleIdx[s.id] = newIdxs[0];
                  if (firstType) state.shiftSurchargeRuleType[s.id] = firstType;
                }
              } else {
                s.surchargePercent = firstPct;
                s.surchargeRuleIdx = newIdxs[0] ?? null;
                s.surchargeRuleType = firstType;
                const idx2 = (state.customShifts || []).findIndex(cs => cs.id === s.id);
                if (idx2 !== -1) {
                  state.customShifts[idx2].surchargePercent = firstPct;
                  state.customShifts[idx2].surchargeRuleIdx = newIdxs[0] ?? null;
                  state.customShifts[idx2].surchargeRuleType = firstType;
                }
              }
              // Badge frissítés
              const freshIdxs = checkboxes.filter(x => x.cb.checked).map(x => x.ri);
              badgeBtn.textContent = _potlekBadgeLabel(freshIdxs);
              badgeBtn.classList.toggle('has-rules', freshIdxs.length > 0);
              saveState();
            });
          });

          // Popup pozícionálás
          document.body.appendChild(overlay);
          document.body.appendChild(popup);
          const rect = badgeBtn.getBoundingClientRect();
          const popW = 250;
          const popH = Math.min(280, 48 + rules.length * 38);
          let top = rect.bottom + 4;
          let left = rect.left;
          if (left + popW > window.innerWidth - 8) left = window.innerWidth - popW - 8;
          if (top + popH > window.innerHeight - 8) top = rect.top - popH - 4;
          popup.style.top = top + 'px';
          popup.style.left = left + 'px';

          overlay.addEventListener('click', () => { overlay.remove(); popup.remove(); });
        });

        surchargeRow.appendChild(badgeBtn);

        // Edit overlay (hosszú nyomásra)
        const editOverlay = document.createElement('div');
        editOverlay.className = 'shift-edit-overlay';
        editOverlay.addEventListener('click', e => e.stopPropagation());

        const editBtn = document.createElement('button');
        editBtn.textContent = '✏️';
        editBtn.title = t('editShiftLabel') || 'Edit';
        editBtn.addEventListener('click', e => {
          e.stopPropagation();
          div.classList.remove('show-edit-overlay');
          openShiftEdit(s);
        });

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '🗑️';
        deleteBtn.title = t('deleteShiftLabel') || 'Törlés / Elrejtés';
        deleteBtn.addEventListener('click', e => {
          e.stopPropagation();
          div.classList.remove('show-edit-overlay');
          const confirmMsg = t('confirmDeleteShift') || ('Törlöd: ' + getShiftName(s) + '?');
          if (!confirm(confirmMsg.replace('{name}', getShiftName(s)))) return;
          if (s.builtin) {
            if (!state.hiddenShifts) state.hiddenShifts = [];
            if (!state.hiddenShifts.includes(s.id)) {
              state.hiddenShifts.push(s.id);
              saveState();
              renderShifts();
            }
          } else {
            state.customShifts = (state.customShifts || []).filter(cs => cs.id !== s.id);
            saveState();
            renderShifts();
          }
        });

        editOverlay.appendChild(editBtn);
        editOverlay.appendChild(deleteBtn);

        div.appendChild(nameRow);
        div.appendChild(starBtn);
        div.appendChild(surchargeRow);
        div.appendChild(editOverlay);

        // Hosszú nyomás detektálás
        let lpTimer = null;
        const startLP = (e) => {
          lpTimer = setTimeout(() => {
            // Zárjuk be a többi overlay-t
            document.querySelectorAll('.shift-item.show-edit-overlay').forEach(el => el.classList.remove('show-edit-overlay'));
            div.classList.add('show-edit-overlay');
          }, 500);
        };
        const cancelLP = () => { clearTimeout(lpTimer); };
        div.addEventListener('touchstart', startLP, {passive:true});
        div.addEventListener('touchend', cancelLP);
        div.addEventListener('touchmove', cancelLP);
        div.addEventListener('mousedown', startLP);
        div.addEventListener('mouseup', cancelLP);
        div.addEventListener('mouseleave', cancelLP);

        // Overlay bezárás kattintásra máshova
        document.addEventListener('click', () => div.classList.remove('show-edit-overlay'), {capture: false});

        div.addEventListener('click', () => {
          if (div.classList.contains('show-edit-overlay')) return;
          state.selectedShift = s.id;
          renderShifts();
        });

        panel.appendChild(div);
      });

      const newBtn = document.createElement('div');
      newBtn.className = 'shift-item';
      newBtn.style.background = 'rgba(95,158,247,0.15)';
      newBtn.textContent = '+ ' + (t('newShiftBtn') || 'New').replace('+ ','');
      newBtn.addEventListener('click', () => {
        document.getElementById('shiftModal').classList.add('visible');
      });
      panel.appendChild(newBtn);


    }

    // ==================== BÉR SZÁMÍTÁS ====================
    function maskPayroll() {
      const c = document.getElementById('payrollContent');
      if (c) { c.style.filter = 'blur(8px)'; c.style.userSelect = 'none'; c.style.pointerEvents = 'none'; }
    }
    function unmaskPayroll() {
      const c = document.getElementById('payrollContent');
      if (c) { c.style.filter = ''; c.style.userSelect = ''; c.style.pointerEvents = ''; }
    }

    // ── PRIVÁT NÉZET ──
    function applyPrivateMode(on) {
      state.privateMode = on;
      const btn = document.getElementById('lockBtn');

      if (on) {
        // Naptár: műszak csíkok elrejtése
        document.querySelectorAll('.line, .line-row').forEach(el => el.style.visibility = 'hidden');
        // Bér fül: blur
        maskPayroll();
        // Stat értékek elfedése
        ['yearHours','yearOvertime','yearVacation','yearSick','yearGross',
         'hoursWorked','overtimeHours','night25Hours','night40Hours',
         'sundayHours','holidayHours','vacationBonusHours','bruttoSum','nettoSum']
          .forEach(id => {
            const el = document.getElementById(id);
            if (el) { el.dataset.realText = el.textContent; el.textContent = '***'; }
          });
        // Névmező elfedése
        const nameEl = document.getElementById('settingsNameLabel');
        if (nameEl) { nameEl.dataset.realText = nameEl.textContent; nameEl.textContent = '***'; }
        if (btn) btn.textContent = '🔓';
      } else {
        // Visszaállítás
        document.querySelectorAll('.line, .line-row').forEach(el => el.style.visibility = '');
        unmaskPayroll();
        ['yearHours','yearOvertime','yearVacation','yearSick','yearGross',
         'hoursWorked','overtimeHours','night25Hours','night40Hours',
         'sundayHours','holidayHours','vacationBonusHours','bruttoSum','nettoSum']
          .forEach(id => {
            const el = document.getElementById(id);
            if (el && el.dataset.realText) { el.textContent = el.dataset.realText; delete el.dataset.realText; }
          });
        const nameEl = document.getElementById('settingsNameLabel');
        if (nameEl && nameEl.dataset.realText) { nameEl.textContent = nameEl.dataset.realText; delete nameEl.dataset.realText; }
        if (btn) btn.textContent = '🔒';
      }
    }

    async function togglePrivateMode() {
      if (!state.privateMode) {
        // Bekapcsolás: mindig azonnal, zárolás nélkül
        applyPrivateMode(true);
        // Ha van Grundlohn és még nem kérdeztük meg, ÉS van PIN beállítva
        if (!state.privateLockAsked && state.grundlohn > 0
            && state.pinEnabled && state.pinHash) {
          state.privateLockAsked = true;
          saveState();
          setTimeout(() => {
            const msg = t('privateLockOfferText') ||
              'Szeretnéd, hogy a privát nézet feloldásához PIN/biometria szükséges legyen?';
            if (confirm(msg)) {
              state.privateLockRequired = true;
              saveState();
              renderPrivateLockSwitch();
            }
          }, 400);
        }
      } else {
        // Kikapcsolás — csak akkor kér PIN-t ha a felhasználó ezt tudatosan bekapcsolta
        if (state.privateLockRequired && state.pinEnabled && state.pinHash) {
          if (state.biometricEnabled) {
            const ok = await unlockWithBiometricOrPinAsync();
            if (ok) applyPrivateMode(false);
            else {
              // Bio sikertelen → PIN fallback
              window._privateModeUnlockCallback = () => applyPrivateMode(false);
              showPinOverlay('verify');
            }
          } else {
            window._privateModeUnlockCallback = () => applyPrivateMode(false);
            showPinOverlay('verify');
          }
        } else {
          // Nincs zárolás → azonnal felold
          applyPrivateMode(false);
        }
      }
    }

    function renderPrivateLockSwitch() {
      const pbSw = document.getElementById('privateBtnSwitch');
      if (pbSw) pbSw.classList.toggle('on', state.showPrivateBtn !== false);
      // Inkognito zárolási mód select szinkron
      const ilSel = document.getElementById('incognitoLockModeSelect');
      if (ilSel) ilSel.value = state.incognitoLockMode || 'app';
      // incognitoLockModeRow csak ha privateBtnRow látható
      const ilRow = document.getElementById('incognitoLockModeRow');
      if (ilRow) ilRow.style.display = (state.showPrivateBtn !== false) ? '' : 'none';
    }

    // Biometria async feloldás (Promise-alapú)
    async function unlockWithBiometricOrPinAsync() {
      if (state.biometricEnabled) {
        const avail = await isBiometricAvailable();
        if (avail) {
          return await triggerBiometric(t('privateUnlockTitle')||'CHRONOS privát nézet feloldása');
        }
      }
      return false;
    }

    // ── HAVI BRUTTÓ SZÁMÍTÁS (DOM-mentes helper az éves összesítőhöz) ──
    // Visszaad: { brutto, overtimeH, workH, vacD, sickD } vagy null ha nincs adat az adott hónapra.
    function calcMonthBruttoFull(yr, mo) {
      const _grund = parseFloat(state.grundlohn) || 0;
      const _fest  = parseFloat(state.feststunden) || 174;
      const _stl   = _fest > 0 ? _grund / _fest : 0;
      const _pRules = state.potlekRules || [];
      const _sunR   = _pRules.find(r => r.type === 'sunday');
      const _holR   = _pRules.find(r => r.type === 'holiday');
      const _ovtR   = _pRules.find(r => r.type === 'overtime');
      const _vacR   = _pRules.find(r => r.type === 'vacation');
      const SUN_PCT = _sunR ? (_sunR.percent / 100) : 0.50;
      const HOL_PCT = _holR ? (_holR.percent / 100) : 1.25;
      const OVT_PCT = _ovtR ? (_ovtR.percent / 100) : 0.25;

      let hasAnyShift = false;
      let workH = 0, overtimeH = 0, vacD = 0, sickD = 0;
      let pNight = 0, pSun = 0, pHol = 0, pOvt = 0, pVac = 0;

      Object.entries(state.schedules).forEach(([key, ids]) => {
        const parts = key.split('-').map(Number);
        if (parts[0] !== yr || parts[1] !== mo) return;
        const day = parts[2];
        const date = new Date(yr, mo - 1, day);
        const dow = date.getDay();
        const isSun = dow === 0;
        const isHol = isPublicHoliday(yr, mo, day);
        hasAnyShift = true;

        // Szabadság
        const hasU  = ids.includes('Urlaub');
        const hasU1 = ids.includes('Urlaub1');
        const hasU2 = ids.includes('Urlaub2');
        if (hasU)  { vacD += 1; workH += 8; pVac += 8 * _stl * 0.50; }
        if (hasU1) { vacD += 0.5; workH += 4; pVac += 4 * _stl * 0.50; }
        if (hasU2) { vacD += 0.5; workH += 4; pVac += 4 * _stl * 0.50; }
        const fullVac = hasU || (hasU1 && hasU2);

        ids.forEach(id => {
          if (['Urlaub','Urlaub1','Urlaub2'].includes(id)) return;
          if (id === 'Krank') { sickD += 1; workH += 8; return; }

          const allS = getAllShifts();
          const sdef = allS.find(s => s.id === id);
          const isBuiltin = ['Früh','Spät','Nacht','Freiwillig Früh','Freiwillig Spät',
                             'Freiwillig Nacht','Fei Fr','Fei Sp','Fei Na'].includes(id);
          const isCust = sdef && !sdef.builtin && !['Urlaub','Krank','X','ZK'].some(x => id.startsWith(x));
          if (!isBuiltin && !isCust) return;
          if (fullVac) return;

          const h = sdef && sdef.hours ? sdef.hours : 8;
          workH += h;

          // Túlóra detektálás (ugyanaz mint calculatePayroll)
          const rType = sdef ? (sdef.builtin
            ? (state.shiftSurchargeRuleType || {})[id]
            : sdef.surchargeRuleType) : null;
          const rIdx  = sdef ? (sdef.builtin
            ? (state.shiftSurchargeRuleIdx  || {})[id]
            : sdef.surchargeRuleIdx) : null;
          let isOvt = rType === 'overtime';
          if (!isOvt && rIdx != null && _pRules[rIdx]) isOvt = _pRules[rIdx].type === 'overtime';
          // Freiwillig builtin alapértelmezetten túlóra, ha nem felülbírált
          if (!isOvt && rType == null && rIdx == null && id.startsWith('Freiwillig')) isOvt = true;

          if (isHol || id.startsWith('Fei')) {
            pHol += h * _stl * HOL_PCT;
          } else if (isSun) {
            pSun += h * _stl * SUN_PCT;
          } else if (isOvt) {
            pOvt += h * _stl * (1 + OVT_PCT);
            overtimeH += h;
          } else {
            // Éjszakai pótlék: közelítés (pontos időablak-számítás nélkül)
            const isN = id.includes('Nacht') || (sdef && sdef.start && (() => {
              const sm = parseInt(sdef.start.split(':')[0]) * 60 + parseInt(sdef.start.split(':')[1]);
              return sm >= 21 * 60 || sm < 6 * 60;
            })());
            if (isN) pNight += h * _stl * 0.25;
          }
        });
      });

      if (!hasAnyShift) return null;

      // ZK kivétel
      let zkPay = 0;
      if (state.zeitkonto && state.zeitkonto.enabled) {
        const _zkW = (state.zeitkonto.withdrawals || []).find(w => w.month === yr + '-' + mo);
        if (_zkW) zkPay = Math.min(_zkW.hours, state.zeitkonto.balance || 0) * _stl;
      }

      // Einmalzahlung (brutto típusú)
      let ezBonus = 0;
      if (state.einmalzahlung && state.einmalzahlung.enabled) {
        (state.einmalzahlung.payments || []).forEach(p => {
          const pMo = p.month ? parseInt(p.month) : null;
          if (!pMo || pMo === mo) {
            if (!p.type || p.type === 'brutto') ezBonus += parseFloat(p.amount) || 0;
          }
        });
      }

      const brutto = _grund + pNight + pSun + pHol + pOvt + pVac + zkPay + ezBonus;
      return { brutto, overtimeH, workH, vacD, sickD };
    }

    // Async race condition guard: minden calculatePayroll() hívás egyedi ID-t kap.
    // Ha közben új hívás érkezik, a régi BMF callback eredményt eldob.
    let _calcPayrollCallId = 0;

    function calculatePayroll() {
      const _myCallId = ++_calcPayrollCallId;
      const year = state.payrollYear;
      const month = state.payrollMonth + 1; // 1-alapú, naptárban kiválasztott hónap

      // ════════════════════════════════════════════════════════════════════════
      // LEISTUNGS vs ZAHLUNGSMONAT + FIZETÉSEMELÉS LOGIKA
      //
      // Leistungsmonat: naptár hónap = ledolgozott hónap
      //   → Grundlohn + pótlékok: aktuális hónap
      //
      // Zahlungsmonat: naptár hónap = előző ledolgozott hónap,
      //   megjelenítés +1 hónappal csúszik (júliust nézed → "Augusztus (Kif.)")
      //   → Grundlohn: megjelenített hónap (payrollMonth+1)
      //   → Pótlék/túlóra stl alapja: ledolgozott hónap (payrollMonth)
      //
      // Fizetésemelés:
      //   - Zahlung átmenet hónapban (pl. aug. emelés, aug. kif.):
      //       Grundlohn = ÚJ | pótlék stl = RÉGI (júliusi)
      //   - Zahlung teljes hónap (szept. és utána):
      //       Grundlohn = ÚJ | pótlék stl = ÚJ
      //   - Leistung: Grundlohn = pótlék stl = ÚJ (azonos hónaptól)
      // ════════════════════════════════════════════════════════════════════════

      const isZahlung = state.payrollDisplayMode === 'zahlung';

      // Megjelenített hónap (0-alapú)
      let dispMi = state.payrollMonth;
      let dispYi = state.payrollYear;
      if (isZahlung) {
        dispMi = state.payrollMonth + 1;
        if (dispMi > 11) { dispMi = 0; dispYi = state.payrollYear + 1; }
      }

      const grundBase = parseFloat(state.grundlohn) || 0;

      // ══════════════════════════════════════════════════════════════════
      // Új Grundlohn kiolvasása az új raise struktúrából (localStorage)
      // chronos_raise_pending: { grundlohn, pct, year, month(1-alapú) }
      // chronos_raise_history: [ { grundlohn, pct, year, month } ... ]
      //
      // AUTO-APPLY: ha a kifizetési hónap (dispMi/dispYi) >= pending hónap
      // → az emelés érvényre lép, archiválva lesz, pending törlődik.
      // Ezt a calculatePayroll csak jelzi; az archív logika a RaiseWidget-ben fut.
      // ══════════════════════════════════════════════════════════════════
      function getRaiseInfo() {
        try {
          var pendingRaw = localStorage.getItem('chronos_raise_pending');
          if (!pendingRaw) return null;
          var p = JSON.parse(pendingRaw);
          if (!p || !p.grundlohn || !p.year || p.month == null) return null;
          var fromMi = p.month - 1; // 0-alapú
          var fromYi = p.year;
          var newG = parseFloat(p.grundlohn);
          if (!newG || newG <= 0 || newG === grundBase) return null;
          return { newG: newG, fromMi: fromMi, fromYi: fromYi };
        } catch(e) { return null; }
      }
      const raiseInfo = getRaiseInfo();

      // Auto-apply check: CSAK a valós mai dátum alapján triggerelni
      // (nem a payroll megjelenítési hónapja alapján – különben ha visszanézel
      // egy régebbi hónapot, azonnal alkalmazódik az emelés)
      (function _raiseAutoApplyCheck() {
        try {
          if (!raiseInfo) return;
          var appliedKey = 'chronos_raise_auto_applied_' + raiseInfo.fromYi + '_' + (raiseInfo.fromMi + 1);
          if (sessionStorage.getItem(appliedKey)) return; // már kezeltük ebben a session-ben
          var now = new Date();
          var todayIdx = now.getFullYear() * 12 + now.getMonth(); // valós mai dátum (0-alapú hónap)
          var raiseIdx = raiseInfo.fromYi * 12 + raiseInfo.fromMi;
          if (todayIdx >= raiseIdx) {
            sessionStorage.setItem(appliedKey, '1');
            // Async hívás, hogy ne blokkolja a payroll számítást
            setTimeout(function() {
              if (typeof window.raiseDoAutoApply === 'function') window.raiseDoAutoApply(raiseInfo);
            }, 200);
          }
        } catch(e) {}
      })();

      function raiseActiveFor(mi, yi) {
        if (!raiseInfo) return false;
        return (yi * 12 + mi) >= (raiseInfo.fromYi * 12 + raiseInfo.fromMi);
      }

      // Grundlohn a kifizetési sorhoz (megjelenített/kifizetési hónap)
      let grund = grundBase;
      if (raiseActiveFor(dispMi, dispYi)) grund = raiseInfo.newG;

      // Grundlohn a pótlék/túlóra órabérhez (ledolgozott hónap)
      // Leistung: ugyanaz mint grund
      // Zahlung: előző (ledolgozott) hónap → az emelés csak a KÖVETKEZŐ hónaptól hat a stl-re
      let grundForBonus = grundBase;
      if (isZahlung) {
        if (raiseActiveFor(state.payrollMonth, state.payrollYear)) grundForBonus = raiseInfo.newG;
      } else {
        grundForBonus = grund;
      }

      const fest = parseFloat(state.feststunden) || 174;
      const stl = fest > 0 ? grundForBonus / fest : 0;

      // Megjelenített hónap neve
      const _monthNames = (MONTH_NAMES[state.currentLang] || MONTH_NAMES.hu);
      const _dispYear = dispYi, _dispMonth = dispMi;
      const _modeLabel = isZahlung ? ' (' + (t('payrollModeZahlung') || 'Kif.') + ')' : '';
      document.getElementById('payrollMonthDisplay').textContent =
        _monthNames[_dispMonth] + ' ' + _dispYear + _modeLabel;
      const _modeBtn = document.getElementById('payrollModeToggle');
      if (_modeBtn) {
        _modeBtn.textContent = isZahlung ? '📤' : '📅';
        _modeBtn.title = isZahlung
          ? (t('payrollModeZahlungTitle') || 'Kifizetési hónap szerint (következő hónap) – kattints a váltáshoz')
          : (t('payrollModeLeistungTitle') || 'Teljesítési hónap szerint (ledolgozott hónap) – kattints a váltáshoz');
      }


      let workHours = 0, nightHours25 = 0, nightHours40 = 0, sundayHours = 0, holidayHours = 0, overtimeHours = 0;
      let premiumNight = 0, premiumSunday = 0, premiumHoliday = 0, premiumOvertime = 0;
      // Külön éjszakai pótlék bontás: adómentes vs adóköteles
      let premiumNightTaxFree = 0, premiumNightTaxable = 0;

      // ── DINAMIKUS PÓTLÉK SZABÁLYOK ──
      // A potlekRules-ból olvassuk ki az aktuális %-okat, nem hardkódolva.
      // Ha felhasználó módosítja a szabályt, a bérfejtés azonnal az új értékkel számol.
      const _pRules = state.potlekRules || [];
      const _sundayRule   = _pRules.find(r => r.type === 'sunday');
      const _holidayRule  = _pRules.find(r => r.type === 'holiday');
      const _overtimeRule = _pRules.find(r => r.type === 'overtime');
      const _vacationRule = _pRules.find(r => r.type === 'vacation');
      const SUNDAY_PCT   = _sundayRule   ? (_sundayRule.percent   / 100) : 0.50;
      const HOLIDAY_PCT  = _holidayRule  ? (_holidayRule.percent  / 100) : 1.25;
      const OVERTIME_PCT = _overtimeRule ? (_overtimeRule.percent / 100) : 0.25;

      let vacationBonusHours = 0, premiumVacation = 0;

      Object.entries(state.schedules).forEach(([key, ids]) => {
        const parts = key.split('-').map(Number);
        if (parts[0] !== year || parts[1] !== month) return;

        const day = parts[2];
        const date = new Date(year, month - 1, day);
        const dow = date.getDay();
        const isSunday = dow === 0;

        // ── SZABADSÁG PÓTLÉK LOGIKA ──
        // Meghatározzuk hogy az adott napon milyen szabadság van rögzítve
        const hasUrlaub  = ids.includes('Urlaub');
        const hasUrlaub1 = ids.includes('Urlaub1');
        const hasUrlaub2 = ids.includes('Urlaub2');
        // Teljes nap szabadság: Urlaub VAGY Urlaub1+Urlaub2 együtt → csak szab.pótlék, semmi más
        const fullDayVacation = hasUrlaub || (hasUrlaub1 && hasUrlaub2);
        // Fél nap szabadság (az egyik fél dolgozik): az adott fél csak szab.pótlék, a munkafél normál
        const halfDayVacation = (hasUrlaub1 && !hasUrlaub2) || (hasUrlaub2 && !hasUrlaub1);

        // Szabadság pótlék hozzáadása
        if (hasUrlaub) {
          // Teljes nap: 8 óra × 50%
          vacationBonusHours += 8;
          premiumVacation += 8 * stl * 0.50;
          workHours += 8; // alap órabér is jár
        }
        if (hasUrlaub1) {
          // Fél nap: 4 óra × 50%
          vacationBonusHours += 4;
          premiumVacation += 4 * stl * 0.50;
          workHours += 4;
        }
        if (hasUrlaub2) {
          // Fél nap: 4 óra × 50%
          vacationBonusHours += 4;
          premiumVacation += 4 * stl * 0.50;
          workHours += 4;
        }

        ids.forEach(id => {
          const allShifts = getAllShifts();
          const shiftDef = allShifts.find(s => s.id === id);

          // Egyéni pótlék: ha a shift-nek van saját surchargePercent, azt alkalmazzuk
          const builtinOverride = (state.shiftSurcharges || {})[id];
          const customSurcharge = (builtinOverride != null) ? builtinOverride :
                                  (shiftDef && shiftDef.surchargePercent != null) ? shiftDef.surchargePercent : null;

          // Munkanap típusok meghatározása
          const isDateHoliday = isPublicHoliday(year, month, day); // automatikus ünnepnap-felismerés
          const isHolidayShift = id.startsWith('Fei'); // régi Fei* ID-k visszakompatibilitáshoz

          // Betegszabadság: 8 óra alapbér, pótlék nélkül
          const isKrank = id === 'Krank' || (shiftDef && !shiftDef.builtin && id.startsWith('Krank'));
          if (isKrank) {
            const h = shiftDef && shiftDef.hours ? shiftDef.hours : 8;
            workHours += h;
            return; // pótlék nélkül
          }

          // Tényleges munka-e: beépített műszakok + custom műszakok (ha nem ünnep/szabadság/beteg típusú)
          const isBuiltinWork = ['Früh', 'Spät', 'Nacht', 'Freiwillig Früh',
                         'Freiwillig Spät', 'Freiwillig Nacht',
                         'Fei Fr', 'Fei Sp', 'Fei Na'].includes(id);
          const isCustomWork = shiftDef && !shiftDef.builtin &&
            !['Urlaub','Krank','X'].some(x => id.startsWith(x));
          const isWork = isBuiltinWork || isCustomWork;

          // Szombat éjszaka = túlóra (ha be van kapcsolva az overtime rule-ban)
          const isSaturday = dow === 6;
          const isNachtShift = id === 'Nacht' || id === 'Freiwillig Nacht' || id === 'Fei Na' ||
                               (shiftDef && !shiftDef.builtin && id.toLowerCase().includes('nacht'));
          const _satOvertimeEnabled = (_overtimeRule && _overtimeRule.satNightOvertime === true);
          const isSatNightOvertime = _satOvertimeEnabled && isSaturday && isNachtShift;

          // Teljes nap szabadság → a munkamüszakok minden pótlékát blokkoljuk erre a napra
          // (az alap workHours-t és a szab.pótlékot már fentebb számoltuk)
          if (fullDayVacation && isWork) return;

          // Fél nap szabadság → csak az érintett felet blokkoljuk
          // Urlaub1 = reggel szabad → a Früh műszak pótlékát blokkoljuk
          // Urlaub2 = délután szabad → a Spät műszak pótlékát blokkoljuk
          if (halfDayVacation) {
            if (hasUrlaub1 && (id === 'Früh' || id === 'Freiwillig Früh')) return;
            if (hasUrlaub2 && (id === 'Spät' || id === 'Freiwillig Spät')) return;
          }
          // Túlóra felismerés: régi beépített ID-k VAGY ha a műszakhoz rendelt pótlékszabály type='overtime'
          // (builtin ÉS custom műszakra egyaránt)
          const _assignedRuleIdx = (() => {
            if (shiftDef && shiftDef.builtin) {
              return (state.shiftSurchargeRuleIdx || {})[id] ?? null;
            }
            return shiftDef ? (shiftDef.surchargeRuleIdx ?? null) : null;
          })();
          // Legmegbízhatóbb: a mentett ruleType alapján döntünk
          const _assignedRuleType = (() => {
            if (shiftDef && shiftDef.builtin) {
              return (state.shiftSurchargeRuleType || {})[id] ?? null;
            }
            return shiftDef ? (shiftDef.surchargeRuleType ?? null) : null;
          })();
          const _customSurchargeRule = (() => {
            // 1. Legmegbízhatóbb: mentett ruleType
            if (_assignedRuleType != null) {
              return _assignedRuleType === 'overtime' ? { type: 'overtime', percent: builtinOverride ?? shiftDef?.surchargePercent ?? 25 } : null;
            }
            // 2. Index alapján (ha elérhető)
            if (_assignedRuleIdx != null && _pRules[_assignedRuleIdx]) {
              return _pRules[_assignedRuleIdx].type === 'overtime' ? _pRules[_assignedRuleIdx] : null;
            }
            // 3. Fallback: % egyezés alapján (régi adatok visszakompatibilitás)
            const pctToCheck = builtinOverride != null ? builtinOverride
                             : (shiftDef && shiftDef.surchargePercent != null ? shiftDef.surchargePercent : null);
            if (pctToCheck != null) {
              return _pRules.find(r => r.type === 'overtime' && r.percent === pctToCheck) || null;
            }
            return null;
          })();
          // Builtin és custom műszakra egyaránt: ha a rendelt pótlékszabály overtime típusú → túlóra
          const _hasOvertimeRule = _customSurchargeRule != null;
          // Szombat éjszaka túlóra felülbírálja a normál overtime detektálást
          const isOvertime = isSatNightOvertime ||
                             id.startsWith('Overtime') || id === 'Überstunde' ||
                             id.startsWith('Freiwillig') ||
                             ((isWork) && _hasOvertimeRule);
          const isNacht = id.includes('Nacht');
          const isHoliday = isDateHoliday || isHolidayShift;

          if (isWork || isOvertime) {
            const h = shiftDef && shiftDef.hours ? shiftDef.hours : 8;

            // Éjfélen átmenő műszaknál csak az éjfélig tartó részt számítsuk az adott nap pótlékába.
            // Az éjfél utáni részt a crossesMidnight ág kezeli nextIsHoliday/nextIsSunday alapján.
            const _toMin = s => { const [hh,mm] = s.split(':').map(Number); return hh*60+mm; };
            const _shiftStart = shiftDef ? shiftDef.start : null;
            const _shiftEnd   = shiftDef ? shiftDef.end   : null;
            const _sMin = _shiftStart ? _toMin(_shiftStart) : 0;
            const _eMin = _shiftEnd   ? _toMin(_shiftEnd)   : 0;
            const _crossesMidnight = _shiftStart && _shiftEnd && (_eMin <= _sMin);
            // Azon az ünnep/vasárnapon 0-24 közé eső tényleges órák
            const hDay = _crossesMidnight ? (1440 - _sMin) / 60 : h;
            // Szünet (30 perc) csak az éjfélen átmenő műszak éjfél utáni részéből vonódik le.
            // Reggeli/délutáni műszaknál NEM vonódik le az ünnep/vasárnapi pótlékból (ZEUS referencia).
            const PAUSE_H = 0.5;
            const hDayNet = hDay;

            if (isOvertime) {
              overtimeHours += h;
              premiumOvertime += h * stl * (1 + OVERTIME_PCT);
              // Szombat éjszaka túlóra + Freiwillig esetén a napi pótlékok (vasárnap/ünnep) is megmaradnak
              if (isSatNightOvertime || id.startsWith('Freiwillig')) {
                if (isHoliday) {
                  holidayHours += hDayNet;
                  premiumHoliday += hDayNet * stl * HOLIDAY_PCT;
                } else if (isSunday) {
                  sundayHours += hDayNet;
                  premiumSunday += hDayNet * stl * SUNDAY_PCT;
                }
              }
            } else {
              workHours += h;

              if (isHoliday) {
                // Ünnepnap: alapbér (workHours-ban már benne van) + 125% adómentes pótlék
                // Csak az adott nap 0-24 közé eső rész kap ünnepnapi pótlékot, szünet levonva
                holidayHours += hDayNet;
                const hPct = (customSurcharge != null) ? customSurcharge / 100 : HOLIDAY_PCT;
                premiumHoliday += hDayNet * stl * hPct;
                // Vasárnapi ünnepnap: vasárnapi pótlék is kumuláltan jár
                if (isSunday) {
                  sundayHours += hDayNet;
                  const sPct = (customSurcharge != null) ? customSurcharge / 100 : SUNDAY_PCT;
                  premiumSunday += hDayNet * stl * sPct;
                }
              } else if (isSunday) {
                sundayHours += hDayNet;
                const sPct = (customSurcharge != null) ? customSurcharge / 100 : SUNDAY_PCT;
                premiumSunday += hDayNet * stl * sPct;
              } else if (customSurcharge != null && customSurcharge > 0) {
                // Egyéni pótlék hétköznapra is – taxFree az assigned rule alapján
                const _customTaxFree = (() => {
                  if (_assignedRuleIdx != null && _pRules[_assignedRuleIdx]) return _pRules[_assignedRuleIdx].taxFree !== false;
                  return true; // alapértelmezés: adómentes
                })();
                const amt = h * stl * (customSurcharge / 100);
                premiumNight += amt;
                if (_customTaxFree) premiumNightTaxFree += amt; else premiumNightTaxable += amt;
              }
            }

            // Éjszakai pótlék számítása potlék szabályok alapján
            // FONTOS: éjfélen átmenő műszaknál az éjfél utáni részt a KÖVETKEZŐ nap szabályai szerint kezeljük
            if (!isOvertime || isSatNightOvertime || id.startsWith('Freiwillig')) {
              // Műszak időpontjai
              const shiftStart = shiftDef ? shiftDef.start : null;
              const shiftEnd = shiftDef ? shiftDef.end : null;

              if (shiftStart && shiftEnd) {
                const toMin = s => {
                  const [hh, mm] = s.split(':').map(Number);
                  return hh * 60 + mm;
                };
                const startMin = toMin(shiftStart);
                let endMin = toMin(shiftEnd);
                // Ha vége kisebb mint eleje → átmegy éjfélen
                const crossesMidnight = endMin <= startMin;
                if (crossesMidnight) endMin += 1440;

                // Következő nap (éjfélen átmenő műszaknál)
                const nextDate = new Date(year, month - 1, day + 1);
                const nextDow = nextDate.getDay();
                const nextIsSunday = nextDow === 0;
                const nextIsHoliday = isPublicHoliday(nextDate.getFullYear(), nextDate.getMonth() + 1, nextDate.getDate());
                // Éjfél utáni rész TELJES hossza (a műszak teljes éjfél utáni időtartama,
                // FÜGGETLENÜL attól, hogy az éjszakai pótlék-sávok lefedik-e). Ez azért fontos,
                // mert ha a műszak vége (pl. 06:15) túlnyúlik a definiált éjszakai sáv végén
                // (pl. 06:00), az a "lyuk" a régi logikában kimaradt az ünnep/vasárnapi órákból is.
                if (crossesMidnight) {
                  const afterMidnightTotal = (endMin - 1440) / 60;
                  if (afterMidnightTotal > 0) {
                    const pauseForHolSun = Math.min(PAUSE_H, afterMidnightTotal);
                    const afterMidnightNet = afterMidnightTotal - pauseForHolSun;
                    if (nextIsHoliday) {
                      holidayHours += afterMidnightNet;
                      premiumHoliday += afterMidnightNet * stl * HOLIDAY_PCT;
                    } else if (nextIsSunday) {
                      sundayHours += afterMidnightNet;
                      premiumSunday += afterMidnightNet * stl * SUNDAY_PCT;
                    }
                  }
                }

                // Normál éjszakai pótlékszabályok (type='normal') – csak a 25%/40% éjszakai
                // pótlékhoz; az ünnep/vasárnapi órákat fent, a teljes időtartam alapján számoltuk.
                const nightRules = (state.potlekRules || []).filter(r => r.type === 'normal' && r.start && r.end);

                nightRules.forEach(rule => {
                  const rs = toMin(rule.start);
                  let re = toMin(rule.end);
                  if (re === 0) re = 1440; // 00:00 end = éjfél = nap vége

                  // Szabály sáv normalizálása (esetleg éjfélen átmenő szabály)
                  let ruleSlots = [];
                  if (rs < re) {
                    ruleSlots.push([rs, re]);
                  } else {
                    ruleSlots.push([rs, 1440]);
                    if (re > 0) ruleSlots.push([0, re]);
                  }

                  ruleSlots.forEach(([vs, ve]) => {
                    // Átfedés a műszakkal [startMin, endMin] (endMin lehet >1440)
                    // 1. rész: éjfél ELŐTTI szakasz (0..1440) → az aktuális nap szabályai
                    // 2. rész: éjfél UTÁNI szakasz (1440..2880) → a következő nap szabályai
                    const overlapA_s = Math.max(startMin, vs);
                    const overlapA_e = Math.min(Math.min(endMin, 1440), ve);
                    if (overlapA_e > overlapA_s) {
                      // Éjfél előtti rész: ha az adott nap nem vasárnap/ünnep, éjszakai pótlék jár
                      if (!isHoliday && !isSunday) {
                        const overlapH = (overlapA_e - overlapA_s) / 60;
                        if (rule.percent >= 40) nightHours40 += overlapH; else nightHours25 += overlapH;
                        const amt = overlapH * stl * (rule.percent / 100);
                        premiumNight += amt;
                        if (rule.taxFree !== false) premiumNightTaxFree += amt; else premiumNightTaxable += amt;
                      }
                    }

                    // Éjfél UTÁNI rész (csak éjfélen átmenő műszaknál) – itt már csak a 25%/40%
                    // éjszakai pótlék jár, az ünnep/vasárnapi órákat fent külön számoltuk.
                    if (crossesMidnight) {
                      const vs2 = vs + 1440;
                      const ve2 = ve + 1440;
                      const overlapB_s = Math.max(startMin, vs2);
                      const overlapB_e = Math.min(endMin, ve2);
                      if (overlapB_e > overlapB_s) {
                        const overlapH = (overlapB_e - overlapB_s) / 60;
                        if (rule.percent >= 40) nightHours40 += overlapH; else nightHours25 += overlapH;
                        const amt = overlapH * stl * (rule.percent / 100);
                        premiumNight += amt;
                        if (rule.taxFree !== false) premiumNightTaxFree += amt; else premiumNightTaxable += amt;
                      }
                    }
                  });
                });

                // Vasárnap/ünnepnap éjszakai pótlék: ha maga a nap vasárnap/ünnep,
                // az éjszakai pótlékos idősávra is jár az éjszakai pótlék (kumuláltan)
                if ((isSunday || isHoliday) && nightRules.length > 0) {
                  nightRules.forEach(rule => {
                    const rs = toMin(rule.start);
                    let re = toMin(rule.end);
                    if (re === 0) re = 1440;
                    let ruleSlots2 = rs < re ? [[rs, re]] : [[rs, 1440], ...(re > 0 ? [[0, re]] : [])];
                    ruleSlots2.forEach(([vs, ve]) => {
                      const overlapStart = Math.max(startMin, vs);
                      const overlapEnd = Math.min(Math.min(endMin, 1440), ve);
                      if (overlapEnd > overlapStart) {
                        const overlapH = (overlapEnd - overlapStart) / 60;
                        if (rule.percent >= 40) nightHours40 += overlapH; else nightHours25 += overlapH;
                        const amt = overlapH * stl * (rule.percent / 100);
                        premiumNight += amt;
                        if (rule.taxFree !== false) premiumNightTaxFree += amt; else premiumNightTaxable += amt;
                      }
                    });
                  });
                }
              } else if (isNacht && !isSunday && !isHoliday) {
                // Fallback: ha nincs shift definíció, a régi logika (adómentesnek vesszük)
                nightHours += h;
                const amt = h * stl * 0.40;
                premiumNight += amt;
                premiumNightTaxFree += amt;
              }
            }
          }
        });
      });

      // ── ZEITKONTO logika ──
      // Normál hónap: zk_monthly levonódik az overtimeHours-ból → a ki nem fizetett UE az egyenlegen gyűlik
      // Kivétel hónap: nincs UE levonás, helyette a withdrawal.hours az egyenlegből kerül kifizetésre
      //   → külön adóköteles sor (zkPayoutPay), pótlék nélkül
      let zkPayoutHours = 0; // Zeitkonto egyenlegből kifizetett órák ebben a hónapban
      let zkDeductHours = 0; // Normál hónapban ZK-ba utalt (levont) túlóra-órák
      // ZEUS-importált hónapokban a végösszesítő már végleges → ZK levonás nem kerül újraszámításra
      const _zeusMonthKey = state.payrollYear + '-' + month; // zeusData 1-alapú hónap-kulcs (month már 1-alapú)
      const _isZeusMonth = !!(state.zeusData && state.zeusData[_zeusMonthKey]);
      if (state.zeitkonto && state.zeitkonto.enabled && !_isZeusMonth) {
        const _mKeyZK = state.payrollYear + '-' + month; // 'YYYY-M'
        const _zkWithdrawal = (state.zeitkonto.withdrawals || []).find(w => w.month === _mKeyZK);
        if (_zkWithdrawal) {
          // Kivétel hónap: ZK egyenlegből fizetjük ki, nincs UE levonás
          zkPayoutHours = Math.min(_zkWithdrawal.hours, state.zeitkonto.balance || 0);
        } else if (state.zeitkonto.saveAllOvertime) {
          // "Összes túlóra → ZK" mód: az egész havi túlóra az egyenlegre kerül, nincs kifizetés
          zkDeductHours = overtimeHours;
          overtimeHours = 0;
          premiumOvertime = 0;
        } else {
          // Manuális havi felülírás ellenőrzése (monthlyOverrides)
          const _zkOverride = (state.zeitkonto.monthlyOverrides || []).find(o => o.month === _mKeyZK);
          const _zkEffectiveMonthly = (_zkOverride !== undefined) ? _zkOverride.hours : (state.zeitkonto.monthly || 0);
          if (_zkEffectiveMonthly > 0) {
            // Kalkulált (nem ZEUS) hónap: le vonjuk az UE-ból (fix, teljes vagy felülírt érték)
            zkDeductHours = Math.min(_zkEffectiveMonthly, overtimeHours);
            overtimeHours = Math.max(0, overtimeHours - zkDeductHours);
            premiumOvertime = overtimeHours * stl * (1 + OVERTIME_PCT);
          }
        }
      }
      const zkPayoutPay = zkPayoutHours * stl; // adóköteles, pótlék nélkül

      const basePay = grund; // fix alapbér – mindig a teljes grundlohn, függetlenül a ledolgozott óráktól

      // ── EGYSZERI KIFIZETÉS bruttó bónuszok ──
      // Csak a 'brutto' típusú (vagy típus nélküli legacy) tételek kerülnek a bruttóba
      let ezBruttoBonus = 0;
      if (state.einmalzahlung && state.einmalzahlung.enabled && state.einmalzahlung.payments) {
        state.einmalzahlung.payments.forEach(p => {
          const pMonth = p.month ? parseInt(p.month) : null;
          if (!pMonth || pMonth === month) {
            if (!p.type || p.type === 'brutto') {
              ezBruttoBonus += parseFloat(p.amount) || 0;
            }
          }
        });
      }
      // Előnézet: el nem mentett ez_amount input (bruttó típus esetén)
      const _ezPreviewAmt = parseFloat(document.getElementById('ez_amount')?.value) || 0;
      const _ezPreviewType = document.getElementById('ez_type')?.value || 'brutto';
      const _ezPreviewMo = document.getElementById('ez_month')?.value;
      const _ezPreviewMoN = _ezPreviewMo ? parseInt(_ezPreviewMo) : null;
      const _ezPreviewMatch = !_ezPreviewMoN || _ezPreviewMoN === month;
      if (state.einmalzahlung && state.einmalzahlung.enabled && _ezPreviewAmt > 0 && _ezPreviewMatch) {
        if (!_ezPreviewType || _ezPreviewType === 'brutto') ezBruttoBonus += _ezPreviewAmt;
      }

      // ── KARÁCSONYI PÓTLÉK bruttó bónusz (október, 10. hónap – az októberi fizetéssel kerül kifizetésre) ──
      // Alap: aug+szept+okt havi bruttó átlaga (Urlaubszuschlag nélkül) × percent%
      let wgBruttoBonus = 0;
      let wgMissingMonths = []; // hiányos hónapok listája
      window._wgBruttoBonus = 0;
      window._wgMissingMonths = [];
      if (state.weihnachtsgeld && state.weihnachtsgeld.enabled && month === 10) {
        // Segédfüggvény: adott év+hónap bruttóját számolja ki Urlaubszuschlag nélkül
        function calcMonthBruttoNoVac(yr, mo) {
          const _grund = parseFloat(state.grundlohn) || 0;
          const _fest = parseFloat(state.feststunden) || 174;
          const _stl = _fest > 0 ? _grund / _fest : 0;
          const _pRules2 = state.potlekRules || [];
          const _sundayRule2 = _pRules2.find(r => r.type === 'sunday');
          const _holidayRule2 = _pRules2.find(r => r.type === 'holiday');
          const _overtimeRule2 = _pRules2.find(r => r.type === 'overtime');
          const SUN_PCT2 = _sundayRule2 ? (_sundayRule2.percent / 100) : 0.50;
          const HOL_PCT2 = _holidayRule2 ? (_holidayRule2.percent / 100) : 1.25;
          const OVT_PCT2 = _overtimeRule2 ? (_overtimeRule2.percent / 100) : 0.25;
          let hasAnyShift = false;
          let pNight = 0, pSun = 0, pHol = 0, pOvt = 0;
          let zkPay2 = 0;
          // ZK kivétel az adott hónapra
          const _mKeyWG = yr + '-' + mo;
          const _zkW2 = (state.zeitkonto.withdrawals || []).find(w => w.month === _mKeyWG);
          if (_zkW2 && state.zeitkonto.enabled) {
            zkPay2 = Math.min(_zkW2.hours, state.zeitkonto.balance || 0) * _stl;
          }
          Object.entries(state.schedules).forEach(([key, ids]) => {
            const parts = key.split('-').map(Number);
            if (parts[0] !== yr || parts[1] !== mo) return;
            const day = parts[2];
            const date = new Date(yr, mo - 1, day);
            const dow = date.getDay();
            const isSunday2 = dow === 0;
            const isDateHoliday2 = isPublicHoliday(yr, mo, day);
            hasAnyShift = true;
            ids.forEach(id => {
              const allShifts2 = getAllShifts();
              const shiftDef2 = allShifts2.find(s => s.id === id);
              const isBuiltinWork2 = ['Früh','Spät','Nacht','Freiwillig Früh','Freiwillig Spät','Freiwillig Nacht','Fei Fr','Fei Sp','Fei Na'].includes(id);
              const isCustomWork2 = shiftDef2 && !shiftDef2.builtin && !['Urlaub','Krank','X'].some(x => id.startsWith(x));
              const isWork2 = isBuiltinWork2 || isCustomWork2;
              if (!isWork2) return;
              const h2 = shiftDef2 && shiftDef2.hours ? shiftDef2.hours : 8;
              const isNacht2 = id.includes('Nacht');
              if (isDateHoliday2 || id.startsWith('Fei')) {
                pHol += h2 * _stl * HOL_PCT2;
              } else if (isSunday2) {
                pSun += h2 * _stl * SUN_PCT2;
              } else if (id.startsWith('Freiwillig') || id.startsWith('Overtime')) {
                pOvt += h2 * _stl * (1 + OVT_PCT2);
              } else if (isNacht2) {
                // éjszakai pótlék közelítés (25% + 40% arány nélkül, 25%-ot használunk)
                pNight += h2 * _stl * 0.25;
              }
            });
          });
          if (!hasAnyShift) return null; // nincs adat
          // Urlaubszuschlag NÉLKÜL: csak alapbér + éjszakai/vasárnapi/ünnepi/túlóra pótlék + ZK
          return _grund + pNight + pSun + pHol + pOvt + zkPay2;
        }
        const _wgYear = state.payrollYear; // a pótlék az októberi fizetéssel kerül kifizetésre, a payrollYear éve alapján (nem decemberi!)
        const _wgBaseYear = _wgYear; // aug-okt ugyanabban az évben
        const _wgMonths = [
          { yr: _wgBaseYear, mo: 8,  label: 'Aug' },
          { yr: _wgBaseYear, mo: 9,  label: 'Szept' },
          { yr: _wgBaseYear, mo: 10, label: 'Okt' },
        ];
        let _wgTotal = 0;
        let _wgCount = 0;
        wgMissingMonths = [];
        _wgMonths.forEach(m => {
          const b = calcMonthBruttoNoVac(m.yr, m.mo);
          if (b === null) {
            wgMissingMonths.push(m.label);
          } else {
            _wgTotal += b;
            _wgCount++;
          }
        });
        if (_wgCount > 0 && wgMissingMonths.length === 0) {
          const _wgAvg = _wgTotal / 3;
          const _wgPct = parseFloat(state.weihnachtsgeld.percent) || 0;
          wgBruttoBonus = _wgAvg * (_wgPct / 100);
        }
        // Ha van hiányzó hónap → wgBruttoBonus marad 0, jelzés a UI-ban
        window._wgBruttoBonus = wgBruttoBonus;
        window._wgMissingMonths = wgMissingMonths;
      }

      const brutto = basePay + premiumNight + premiumSunday + premiumHoliday + premiumOvertime + premiumVacation + zkPayoutPay + ezBruttoBonus + wgBruttoBonus;

      // ── ADÓMENTES PÓTLÉKOK LEVONÁSA A LOHNSTEUER ALAPBÓL (§3b EStG) ──
      // Kizárólag azt vonjuk le az adóalapból, amit a felhasználó adómentesnek jelölt a pótlék szabályoknál.
      const _sundayTaxFree   = _sundayRule   ? (_sundayRule.taxFree   !== false) : true;
      const _holidayTaxFree  = _holidayRule  ? (_holidayRule.taxFree  !== false) : true;
      const _overtimeTaxFree = _overtimeRule ? (_overtimeRule.taxFree === true)  : false;
      const _vacationTaxFree = _vacationRule ? (_vacationRule.taxFree === true) : false;
      // premiumNightTaxFree: per-rule bontással számítva a fenti loop-ban
      const totalTaxFreePremium =
        premiumNightTaxFree +
        (_sundayTaxFree   ? premiumSunday   : 0) +
        (_holidayTaxFree  ? premiumHoliday  : 0) +
        (_overtimeTaxFree ? premiumOvertime : 0) +
        (_vacationTaxFree ? premiumVacation : 0);
      const bruttoSteuerpflichtig = Math.max(0, brutto - totalTaxFreePremium);

      // ── SZOCIÁLIS JÁRULÉKOK (munkavállalói rész) ──
      // Krankenkasse Zusatzbeitrag
      // KK Zusatzbeitrag 2026-os tényleges értékek (forrás: kasszák saját közleményei, állapot: 2026 jan.)
      // Megjegyzés: 'IKK_BW' itt az IKK classic rátáját kapta (nincs külön "IKK Baden-Württemberg"); 'BKK' a BKK VBU (mostani neve: mkk) rátája
      const KK_RATES = {'AOK_BW':2.99,'AOK_BY':2.69,'AOK_PLUS':3.10,'TK':2.69,'DAK':3.20,'BARMER':3.29,'KKH':3.78,'IKK_BW':3.40,'BKK':3.50};
      const kkId = state.krankenkasse || 'AOK_BW';
      const kkZusatz = (kkId === 'custom' ? (parseFloat(document.getElementById('kkCustom') && document.getElementById('kkCustom').value) || 1.70) : (KK_RATES[kkId] || 1.70)) / 100;

      const tc = parseInt(state.taxClass) || 1;
      const kinder = parseFloat(state.kinder) || 0;
      const kirche = (typeof state.kirche === 'boolean') ? state.kirche : (parseInt(state.kirche) > 0);
      const birthYear = parseInt(state.birthYear) || 1990;
      const bundesland = state.bundesland || 'BW';
      const kinderlosBeitrag = kinder === 0 && (new Date().getFullYear() - birthYear) >= 23 ? 0.006 : 0;
      const kirchensteuerSatz = kirche ? (bundesland === 'BY' || bundesland === 'BW' ? 0.08 : 0.09) : 0;

      // ── SV ráták 2026 + BBG ──
      // Értékek: SV-Rechengrößenverordnung 2026 (BGBl. 2025 I Nr. 361, hatályos 2026.01.01.)
      // BBG RV/AV: 8.450 €/hó (101.400 €/év) – 2025-ben: 8.050 €
      // BBG KV/PV: 5.812,50 €/hó (69.750 €/év) – 2025-ben: 5.512,50 €
      // PV AN-rész: 1,80% (teljes: 3,60%, forrás: §55 SGB XI, változatlan 2025 óta)
      // Automatikus frissítés: lásd _svAutoUpdate() függvény (évente egyszer, BMF/lohn-info.de alapján)
      const _SV_YEAR = window._svCachedYear || 2026;
      const _svDefaults = {
        BBG_RV:  8450,
        BBG_KV:  5812.50,
        pv_base: 0.018
      };
      const _svLive = window._svLiveRates || {};
      const BBG_RV = _svLive.BBG_RV  || _svDefaults.BBG_RV;
      const BBG_KV = _svLive.BBG_KV  || _svDefaults.BBG_KV;
      const SV = {
        rv: 0.093,
        kv: 0.073 + kkZusatz / 2,  // KV: 7.3% + Zusatzbeitrag AN-rész (fele)
        pv_base: _svLive.pv_base || _svDefaults.pv_base,  // PV AN-rész 2026: 1.80%
        av: 0.013
      };
      const pvSatz = SV.pv_base + kinderlosBeitrag;
      // svGesamt csak referencia; BBG-vel a calcSV() számol
      const svGesamt = SV.rv + SV.kv + pvSatz + SV.av;
      // calcSV: BBG-vel levágott, pontos SV számítás
      function calcSV(b) {
        const rvB = Math.min(b, BBG_RV);
        const kvB = Math.min(b, BBG_KV);
        return rvB * SV.rv + kvB * SV.kv + kvB * pvSatz + rvB * SV.av;
      }
      // SV-alap = bruttoSteuerpflichtig (§3b EStG adómentes pótlékok SV-mentesek is)
      const svBetrag = calcSV(bruttoSteuerpflichtig);

      // Egyéb levonások
      let otherDeductions = 0;
      if (state.otherDeductionsEnabled && state.otherDeductions && state.otherDeductions.length > 0) {
        state.otherDeductions.forEach(d => {
          if (!d.month || parseInt(d.month) === month) {
            otherDeductions += parseFloat(d.amount) || 0;
          }
        });
      }
      // Előnézet: a még el nem mentett other_amount input értéke (ha be van írva)
      const _otherPreviewAmt = parseFloat(document.getElementById('other_amount')?.value) || 0;
      const _otherPreviewMo = document.getElementById('other_month')?.value;
      if (state.otherDeductionsEnabled && _otherPreviewAmt > 0) {
        const _opm = _otherPreviewMo ? parseInt(_otherPreviewMo) : null;
        if (!_opm || _opm === month) otherDeductions += _otherPreviewAmt;
      }

      // Kölcsön (Darlehen) – havi törlesztő, ha engedélyezve
      // Ha tartozás 0/üres, a havi törlesztőt vonjuk le korlátozás nélkül
      if (state.darlehen && state.darlehen.enabled) {
        const _daMonthly = parseFloat(state.darlehen.monthly) || 0;
        const _daBal = parseFloat(state.darlehen.balance) || 0;
        if (_daMonthly > 0) {
          otherDeductions += _daBal > 0 ? Math.min(_daMonthly, _daBal) : _daMonthly;
        }
      }

      // Egyszeri kifizetés (Einmalzahlung) – nettó típusú tételek direkt nettóhoz adódnak
      // (bruttó típusúak már a brutto változóba kerültek fentebb)
      let ezNettoBonus = 0;
      if (state.einmalzahlung && state.einmalzahlung.enabled && state.einmalzahlung.payments) {
        state.einmalzahlung.payments.forEach(p => {
          const pMonth = p.month ? parseInt(p.month) : null;
          if (!pMonth || pMonth === month) {
            if (p.type === 'netto') {
              ezNettoBonus += parseFloat(p.amount) || 0;
            }
          }
        });
      }
      // Előnézet: el nem mentett ez_amount input (nettó típus esetén)
      if (state.einmalzahlung && state.einmalzahlung.enabled && _ezPreviewAmt > 0 && _ezPreviewMatch) {
        if (_ezPreviewType === 'netto') ezNettoBonus += _ezPreviewAmt;
      }
      // Nettó bónusz: negatív "levonás" → növeli a nettót
      otherDeductions -= ezNettoBonus;

      // ── BMF LOHNSTEUER API (Bundesministerium der Finanzen) ──
      // Forrás: https://www.bmf-steuerrechner.de – hivatalos, ingyenes, nyilvános API
      // LZZ=2 = havi lekérdezés; RE4 = havi bruttó Centben; LSTLZZ = havi lohnsteuer Centben
      // CapacitorHttp-t használunk a WebView CORS korlát megkerülésére (natív Android HTTP)
      async function fetchBmfTax(bruttoMonat, steuerklasse, kinderFb, kircheFlag, calcYear) {
        const re4 = Math.round(bruttoMonat * 100); // havi bruttó Centben
        const zkf = kinderFb;
        const r = kircheFlag ? 1 : 0;
        // Az API URL évenként frissül a BMF-nél (pl. 2026Version1.xhtml)
        const apiYear = calcYear >= 2026 ? 2026 : 2025;
        const url = `https://www.bmf-steuerrechner.de/interface/${apiYear}Version1.xhtml`
          + `?code=ext${apiYear}&LZZ=2&RE4=${re4}&STKL=${steuerklasse}&ZKF=${zkf}&R=${r}`
          + `&KRV=0&PKV=0&AF=0&AJAHR=0&ALTER1=0&ENTSCH=0&F=0&JFREIB=0&JHINZU=0`
          + `&JRE4=0&JVBEZ=0&KFB=0&LZZFREIB=0&LZZHINZU=0&MBV=0&PKPV=0&PVS=0&PVZ=0`
          + `&SONSTB=0&SONSTENT=0&STERBE=0&VBEZ=0&VBEZM=0&VBEZS=0&VBS=0&VJAHR=0`
          + `&VKAPA=0&VMT=0&VSP=0&WFUNLP=0&ZRE4=0&ZVBEZ=0`;

        let xml = null;

        // CapacitorHttp: natív Android HTTP, megkerüli a WebView CORS-t
        // A BMF API XML választ ad vissza – a responseType: 'text' kényszeríti a string formátumot
        try {
          const capHttp = window.Capacitor &&
                          window.Capacitor.Plugins &&
                          window.Capacitor.Plugins.CapacitorHttp;
          if (capHttp) {
            const resp = await capHttp.request({
              method: 'GET',
              url,
              headers: { 'Accept': 'text/xml, application/xml, */*' },
              responseType: 'text'
            });
            if (resp && resp.status === 200 && resp.data) {
              xml = typeof resp.data === 'string' ? resp.data : JSON.stringify(resp.data);
            }
          }
        } catch(e) {
          console.warn('CapacitorHttp BMF error:', e);
        }

        // Fallback: sima fetch (böngészőben / ha CapacitorHttp nem elérhető)
        if (!xml) {
          try {
            const resp = await fetch(url);
            if (resp.ok) xml = await resp.text();
          } catch(e) {
            console.warn('fetch BMF error:', e);
          }
        }

        // Válasz XML: <LSTLZZ> = havi lohnsteuer Cent, <SOLZLZZ> = havi soli Cent
        const lstMatch = xml.match(/<LSTLZZ>(\d+)<\/LSTLZZ>/);
        const soliMatch = xml.match(/<SOLZLZZ>(\d+)<\/SOLZLZZ>/);
        const lst = lstMatch ? parseInt(lstMatch[1]) / 100 : null; // Cent → €
        const soli = soliMatch ? parseInt(soliMatch[1]) / 100 : null;
        return { lst, soli };
      }

      // Offline fallback: §32a EStG 2026 paraméterek
      // Forrás: BGBl. 2024 I Nr. 449 (Steuerfortentwicklungsgesetz, hatályos 2026.01.01.)
      // Tarifformula: §32a Abs. 1 EStG 2026
      //   0 €        – 12.348 €  : 0 Steuer (Grundfreibetrag)
      //   12.349 €   – 17.799 €  : (914,51·y + 1.400)·y
      //   17.800 €   – 69.878 €  : (172,31·z + 2.397)·z + 1.025,38
      //   69.879 €   – 277.825 € : 0,42·x – 10.908,16
      //   > 277.825 €            : 0,45·x – 19.470,38
      // Automatikus frissítés: lásd _svAutoUpdate() – a window._svLiveRates.lohnsteuerParams-ból veszi ha elérhető
      function calcLohnsteuerLocal(bruttoMonat, steuerklasse, kinderfreibetrag) {
        const z = bruttoMonat * 12;
        // Vorsorgepauschale – §39b EStG szerinti közelítés (SV-alapú)
        // RV/AV: BBG_RV*12, KV+PV: BBG_KV*12
        const BBG_RV_J = BBG_RV * 12;
        const BBG_KV_J = BBG_KV * 12;
        const rvJ = Math.min(z, BBG_RV_J);
        const kvJ = Math.min(z, BBG_KV_J);
        const vp_rv = rvJ * SV.rv;
        const vp_av = rvJ * SV.av;
        const vp_kv = kvJ * (SV.kv + pvSatz);
        // Stk 1/2/4: teljes SV; Stk 3: kétszeres RV/AV; Stk 5/6: 0
        let vp = 0;
        if (steuerklasse === 3) {
          vp = vp_rv * 2 + vp_av * 2 + vp_kv;
        } else if (steuerklasse <= 4) {
          vp = vp_rv + vp_av + vp_kv;
        }
        // §32a EStG 2026 – Grundfreibetrag + Steuerklassen-Lohnsteuerfreibetrag
        // Stk 1/4: 12.348 €  |  Stk 2: 13.840 €  |  Stk 3: 24.696 €  |  Stk 5/6: 0 €
        // Automatikus frissítés: window._svLiveRates.grundfreibetrag ha elérhető
        const _gfLive = (window._svLiveRates || {}).grundfreibetrag;
        const _gfBase = _gfLive || 12348;
        const freibetrag = {
          1: _gfBase,
          2: Math.round(_gfBase * 1.12 + 144),  // Stk2 ≈ Grundfreibetrag + Alleinerziehendenentlastung (1.492 €)
          3: _gfBase * 2,
          4: _gfBase,
          5: 0,
          6: 0
        }[steuerklasse] || _gfBase;
        // Kinderfreibetrag 2026: 4.872 € / Kind (9.744 € / Paar → Hälfte AN)
        // Live-érték: window._svLiveRates.kinderfreibetragHalb
        const _kfbHalb = ((window._svLiveRates || {}).kinderfreibetragHalb) || 4872;
        const kindFB = kinderfreibetrag * _kfbHalb;
        // BUGFIX: freibetrag (Grundfreibetrag) NEM vonódik le zvE-ből – a §32a EStG zónáiba már be van építve!
        // (zone-0: zvE <= 12.348 → 0 Steuer – ezt az alábbi if kezeli freibetrag-alapon)
        // Werbungskosten-Pauschbetrag §9a EStG 2026: 1.230 €/év (Stk3: kétszeres = 2.460 €; Stk5/6: 0)
        const WERBK = steuerklasse === 3 ? 2460 : (steuerklasse >= 5 ? 0 : 1230);
        const zvE = Math.max(0, Math.floor(z - kindFB - vp - WERBK));
        // §32a Abs. 1 EStG 2026 tarifformula
        // Live-paraméterek: window._svLiveRates.lohnsteuerParams ha elérhető
        const _lp = (window._svLiveRates || {}).lohnsteuerParams || {
          s1_to: 17799, s2_to: 69878, s3_to: 277825,
          s1_a: 914.51,  s1_b: 1400,
          s2_a: 172.31,  s2_b: 2397,   s2_c: 1025.38,
          s3_k: 0.42,    s3_d: 10908.16,
          s4_k: 0.45,    s4_d: 19470.38,
          grundfreibetrag: _gfBase
        };
        let steuer = 0;
        if (zvE <= freibetrag) {
          steuer = 0;  // zone-0: Grundfreibetrag (Stk1: 12.348, Stk3: 24.696, Stk5/6: 0)
        } else if (zvE <= _lp.s1_to) {
          const y = (zvE - _lp.grundfreibetrag) / 10000;
          steuer = (_lp.s1_a * y + _lp.s1_b) * y;
        } else if (zvE <= _lp.s2_to) {
          const z2 = (zvE - _lp.s1_to) / 10000;
          steuer = (_lp.s2_a * z2 + _lp.s2_b) * z2 + _lp.s2_c;
        } else if (zvE <= _lp.s3_to) {
          steuer = _lp.s3_k * zvE - _lp.s3_d;
        } else {
          steuer = _lp.s4_k * zvE - _lp.s4_d;
        }
        if (steuerklasse === 5) steuer = Math.max(0, steuer * 1.35);
        if (steuerklasse === 6) steuer = zvE * 0.42;
        return Math.max(0, steuer / 12);
      }

      // UI előzetesen frissítése offline adatokkal
      const lohnsteuerLocal = calcLohnsteuerLocal(bruttoSteuerpflichtig, tc, kinder);
      // Soli-Freigrenze 2026: 20.350 €/év (egyedülálló) — forrás: BMF, 2025: 19.950 €
      // Milderungszone: a küszöb felett a Soli fokozatosan nő (max 11,9% a különbözetre), nem ugrik rögtön 5,5%-ra
      const SOLI_FREIGRENZE_MONTHLY_2026 = 20350 / 12;
      const soliLocal = lohnsteuerLocal > SOLI_FREIGRENZE_MONTHLY_2026
        ? Math.min(lohnsteuerLocal * 0.055, (lohnsteuerLocal - SOLI_FREIGRENZE_MONTHLY_2026) * 0.119)
        : 0;
      let _bmfUsed = false;

      function _animCountUp(el, targetVal) {
        if (!el) return;
        const dur = 900, steps = 45;
        let i = 0;
        if (el._countUpTimer) clearInterval(el._countUpTimer);
        el._countUpTimer = setInterval(() => {
          i++;
          const p = i / steps;
          const ease = 1 - Math.pow(1 - p, 3);
          el.textContent = (targetVal * ease).toFixed(2) + ' €';
          if (i >= steps) {
            clearInterval(el._countUpTimer);
            el._countUpTimer = null;
            el.textContent = targetVal.toFixed(2) + ' €';
          }
        }, dur / steps);
      }

      function renderPayrollUI(lst, s, fromBmf, _bruttoOverride, _svOverride) {
        const _b = (_bruttoOverride !== undefined) ? _bruttoOverride : brutto;
        const _sv = (_svOverride !== undefined) ? _svOverride : svBetrag;
        // _svBase: az SV-megjelenítésnél mutatott alap (adóköteles bruttó)
        const _svBase = _sv / svGesamt;
        const kst2 = lst * kirchensteuerSatz;
        const sg = lst + s + kst2;
        const ga = _sv + sg;
        const fn = Math.max(0, _b - ga - otherDeductions);
        _animCountUp(document.getElementById('nettoSum'), fn);

        // ── Kiegészítő tételek: taxDetails-ben jelennek meg (ld. fent) ──
        // extrasInPayroll div üresen marad, tételek a taxDetails-ben vannak
        const _extDiv = document.getElementById('extrasInPayroll');
        if (_extDiv) { _extDiv.innerHTML = ''; _extDiv.style.display = 'none'; }
        if (false) {
          let _extHtml = '';
          // Kölcsön
          if (state.darlehen && state.darlehen.enabled) {
            const _daM = parseFloat(state.darlehen.monthly) || 0;
            const _daB = parseFloat(state.darlehen.balance) || 0;
            if (_daM > 0) {
              const _daAmt = _daB > 0 ? Math.min(_daM, _daB) : _daM;
              _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);"><span>${t('darlehen')||'🏦 Kölcsön'}</span><span>-${_daAmt.toFixed(2)} €</span></div>`;
            }
          }
          // Egyszeri kifizetés – aktív tételek
          if (state.einmalzahlung && state.einmalzahlung.enabled && state.einmalzahlung.payments) {
            state.einmalzahlung.payments.forEach(p => {
              const pMo = p.month ? parseInt(p.month) : null;
              if (!pMo || pMo === month) {
                const _ezAmt = parseFloat(p.amount) || 0;
                const _ezTyp = p.type === 'netto' ? (t('nettoType')||'nettó') : (t('bruttoType')||'bruttó');
                const _ezCol = p.type === 'netto' ? '#4ade80' : '#60a5fa';
                _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);"><span>🎁 ${p.name||'Bónusz'} <span style="color:${_ezCol};font-size:10px;">${_ezTyp}</span></span><span>+${_ezAmt.toFixed(2)} €</span></div>`;
              }
            });
          }
          // Karácsonyi pótlék
          if (state.weihnachtsgeld && state.weihnachtsgeld.enabled && month === 10) {
            if (wgMissingMonths && wgMissingMonths.length > 0) {
              _extHtml += `<div class="stat-row" style="font-size:12px;color:#f87171;"><span>🎄 ${t('weihnachtsgeld')||'Karácsonyi'}</span><span>⚠️ ${wgMissingMonths.join(', ')}</span></div>`;
            } else if (wgBruttoBonus > 0) {
              _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);"><span>🎄 ${t('weihnachtsgeld')||'Karácsonyi'} <span style="color:#60a5fa;font-size:10px;">${t('bruttoType')||'bruttó'}</span></span><span>+${wgBruttoBonus.toFixed(2)} €</span></div>`;
            }
          }
          // Egyéb levonások – mentett tételek
          if (state.otherDeductionsEnabled && state.otherDeductions && state.otherDeductions.length > 0) {
            state.otherDeductions.forEach(d => {
              const dMo = d.month ? parseInt(d.month) : null;
              if (!dMo || dMo === month) {
                const _dAmt = parseFloat(d.amount) || 0;
                _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);"><span>🧾 ${d.name||'Levonás'}</span><span>-${_dAmt.toFixed(2)} €</span></div>`;
              }
            });
          }
          // Előnézet: el nem mentett other_amount input
          const _opAmt = parseFloat(document.getElementById('other_amount')?.value) || 0;
          const _opMo = document.getElementById('other_month')?.value;
          const _opMoN = _opMo ? parseInt(_opMo) : null;
          if (state.otherDeductionsEnabled && _opAmt > 0 && (!_opMoN || _opMoN === month)) {
            _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);opacity:0.7;"><span>🧾 <em>${t('preview')||'Előnézet'}</em></span><span>-${_opAmt.toFixed(2)} €</span></div>`;
          }
          // Előnézet: el nem mentett ez_amount input
          const _epAmt = parseFloat(document.getElementById('ez_amount')?.value) || 0;
          const _epType = document.getElementById('ez_type')?.value || 'brutto';
          const _epMo = document.getElementById('ez_month')?.value;
          const _epMoN = _epMo ? parseInt(_epMo) : null;
          if (state.einmalzahlung && state.einmalzahlung.enabled && _epAmt > 0 && (!_epMoN || _epMoN === month)) {
            const _epCol = _epType === 'netto' ? '#4ade80' : '#60a5fa';
            const _epTypLbl = _epType === 'netto' ? 'nettó' : 'bruttó';
            _extHtml += `<div class="stat-row" style="font-size:12px;color:var(--text2);opacity:0.7;"><span>🎁 <em>${t('preview')||'Előnézet'}</em> <span style="color:${_epCol};font-size:10px;">${_epTypLbl}</span></span><span>+${_epAmt.toFixed(2)} €</span></div>`;
          }
          _extDiv.innerHTML = _extHtml;
          _extDiv.style.display = _extHtml ? 'block' : 'none';
        } // end if(false)
        // ZK kifizetés sor megjelenítése
        const _zkRow = document.getElementById('zkPayoutRow');
        const _zkHEl = document.getElementById('zkPayoutHours');
        if (_zkRow && _zkHEl) {
          if (zkPayoutHours > 0) {
            _zkHEl.innerHTML = `<span class="sv-hours">${zkPayoutHours.toFixed(2)} ${t('hours')||'h'}</span><span class="sv-euro">${zkPayoutPay.toFixed(2)} €</span>`;
            _zkRow.style.display = '';
          } else {
            _zkRow.style.display = 'none';
          }
        }
        // ZK havi levonás sor megjelenítése
        const _zkDRow = document.getElementById('zkDeductRow');
        const _zkDEl = document.getElementById('zkDeductDisplay');
        if (_zkDRow && _zkDEl) {
          if (zkDeductHours > 0) {
            _zkDEl.innerHTML = `<span class="sv-hours" style="color:#a78bfa;">${zkDeductHours.toFixed(2)} ${t('hours')||'h'}</span>`;
            _zkDRow.style.display = '';
          } else {
            _zkDRow.style.display = 'none';
          }
        }
        const taxEl = document.getElementById('taxDetails');
        if (taxEl) {
          // Extra tételek sorai (kölcsön, egyéb, egyszeri)
          let _taxExtras = '';
          // Kölcsön
          if (state.darlehen && state.darlehen.enabled) {
            const _dm2 = parseFloat(state.darlehen.monthly)||0, _db2 = parseFloat(state.darlehen.balance)||0;
            if (_dm2 > 0) _taxExtras += `<div class="stat-row" style="font-size:11px; color:var(--text2);"><span>${t('darlehen')||'🏦 Kölcsön'}</span><span>-${(_db2>0?Math.min(_dm2,_db2):_dm2).toFixed(2)} €</span></div>`;
          }
          // Karácsonyi pótlék (csak október, ha aktív) – korábban csak a kikapcsolt
          // if(false) ágban jelent meg, innen hiányzott
          if (state.weihnachtsgeld && state.weihnachtsgeld.enabled && month === 10) {
            if (wgMissingMonths && wgMissingMonths.length > 0) {
              _taxExtras += `<div class="stat-row" style="font-size:11px;color:#f87171;"><span>${t('weihnachtsgeld')||'🎄 Karácsonyi'}</span><span>⚠️ ${wgMissingMonths.join(', ')}</span></div>`;
            } else if (wgBruttoBonus > 0) {
              _taxExtras += `<div class="stat-row" style="font-size:11px;color:#60a5fa;"><span>${t('weihnachtsgeld')||'🎄 Karácsonyi'} <span style="font-size:9px;">(${t('bruttoType')||'bruttó'})</span></span><span>+${wgBruttoBonus.toFixed(2)} €</span></div>`;
            }
          }
          // Egyéb levonások – mentett tételek
          if (state.otherDeductionsEnabled && state.otherDeductions) {
            state.otherDeductions.forEach(d => { const dm=d.month?parseInt(d.month):null; if(!dm||dm===month) _taxExtras+=`<div class="stat-row" style="font-size:11px;color:var(--text2);"><span>🧾 ${d.name||'Levonás'}</span><span>-${(parseFloat(d.amount)||0).toFixed(2)} €</span></div>`; });
          }
          // Egyéb levonás előnézet
          const _otPvA=parseFloat(document.getElementById('other_amount')?.value)||0, _otPvM=document.getElementById('other_month')?.value;
          if (state.otherDeductionsEnabled && _otPvA>0 && (!_otPvM||parseInt(_otPvM)===month)) _taxExtras+=`<div class="stat-row" style="font-size:11px;color:var(--text2);opacity:0.65;"><span>🧾 <em>${t('preview')||'Előnézet'}</em></span><span>-${_otPvA.toFixed(2)} €</span></div>`;
          // Egyszeri kifizetés – mentett bruttó tételek (eddig hiányzott innen,
          // csak a brutto-ba folyt bele, sor nélkül)
          if (state.einmalzahlung && state.einmalzahlung.enabled && state.einmalzahlung.payments) {
            state.einmalzahlung.payments.forEach(p => { const pm=p.month?parseInt(p.month):null; if((!pm||pm===month)&&(!p.type||p.type==='brutto')) _taxExtras+=`<div class="stat-row" style="font-size:11px;color:#60a5fa;"><span>🎁 ${p.name||'Bónusz'} <span style="font-size:9px;">(${t('bruttoType')||'bruttó'})</span></span><span>+${(parseFloat(p.amount)||0).toFixed(2)} €</span></div>`; });
          }
          // Egyszeri kifizetés – mentett nettó tételek
          if (state.einmalzahlung && state.einmalzahlung.enabled && state.einmalzahlung.payments) {
            state.einmalzahlung.payments.forEach(p => { const pm=p.month?parseInt(p.month):null; if((!pm||pm===month)&&p.type==='netto') _taxExtras+=`<div class="stat-row" style="font-size:11px;color:#4ade80;"><span>🎁 ${p.name||'Bónusz'} <span style="font-size:9px;">(${t('nettoType')||'nettó'})</span></span><span>+${(parseFloat(p.amount)||0).toFixed(2)} €</span></div>`; });
          }
          // Egyszeri kifizetés – el nem mentett előnézet (bruttó vagy nettó típus szerint)
          const _ezPvA=parseFloat(document.getElementById('ez_amount')?.value)||0, _ezPvT=document.getElementById('ez_type')?.value||'brutto', _ezPvM=document.getElementById('ez_month')?.value;
          if (state.einmalzahlung && state.einmalzahlung.enabled && _ezPvA>0 && (!_ezPvM||parseInt(_ezPvM)===month)) {
            if (_ezPvT === 'netto') {
              _taxExtras+=`<div class="stat-row" style="font-size:11px;color:#4ade80;opacity:0.65;"><span>🎁 <em>${t('preview')||'Előnézet'}</em> <span style="font-size:9px;">(${t('nettoType')||'nettó'})</span></span><span>+${_ezPvA.toFixed(2)} €</span></div>`;
            } else {
              _taxExtras+=`<div class="stat-row" style="font-size:11px;color:#60a5fa;opacity:0.65;"><span>🎁 <em>${t('preview')||'Előnézet'}</em> <span style="font-size:9px;">(${t('bruttoType')||'bruttó'})</span></span><span>+${_ezPvA.toFixed(2)} €</span></div>`;
            }
          }

          taxEl.innerHTML = `
            <div class="stat-row" style="font-size:11px; color:var(--text2);"><span>RV – AN rész (9,3%)</span><span>-${(_svBase * SV.rv).toFixed(2)} €</span></div>
            <div class="stat-row" style="font-size:11px; color:var(--text2);"><span>KV ${kkId} (${((0.073+kkZusatz/2)*100).toFixed(2)}%)</span><span>-${(_svBase*SV.kv).toFixed(2)} €</span></div>
            <div class="stat-row" style="font-size:11px; color:var(--text2);"><span>PV (${(pvSatz*100).toFixed(2)}%)</span><span>-${(_svBase*pvSatz).toFixed(2)} €</span></div>
            <div class="stat-row" style="font-size:11px; color:var(--text2);"><span>AV (1,3%)</span><span>-${(_svBase*SV.av).toFixed(2)} €</span></div>
            <div class="stat-row" style="font-size:11px; color:var(--text2);"><span>Lohnsteuer (Stk. ${tc})</span><span>-${lst.toFixed(2)} €</span></div>
            ${s > 0 ? `<div class="stat-row" style="font-size:11px; color:var(--text2);"><span>Soli (5,5%)</span><span>-${s.toFixed(2)} €</span></div>` : ''}
            ${kst2 > 0 ? `<div class="stat-row" style="font-size:11px; color:var(--text2);"><span>Kirchensteuer (${(kirchensteuerSatz*100).toFixed(0)}%)</span><span>-${kst2.toFixed(2)} €</span></div>` : ''}
            ${_taxExtras}
            <div class="stat-row" style="font-size:11px; color:var(--text2); border-top:1px solid var(--border); padding-top:4px; margin-top:2px;"><span>${t('totalDeductions')||'Összes levonás'}</span><span>-${(ga+otherDeductions).toFixed(2)} €</span></div>
          `;
          taxEl.style.display = 'block';
        }
        // Forrásjelölés + SV-ráta státusz
        let srcEl = document.getElementById('taxSourceLabel');
        if (!srcEl) {
          srcEl = document.createElement('div');
          srcEl.id = 'taxSourceLabel';
          srcEl.style.cssText = 'margin-top:4px; font-size:10px; color:var(--text2); text-align:right; display:flex; align-items:center; justify-content:flex-end; gap:6px; flex-wrap:wrap;';
          if (taxEl && taxEl.parentNode) taxEl.parentNode.appendChild(srcEl);
        }
        const _bmfLabel = fromBmf
          ? '🏛️ BMF Lohnsteuerrechner (bmf-steuerrechner.de)'
          : '📋 Helyi számítás (§32a EStG 2026) – offline';
        // SV-ráta forrás badge
        const _svStatus = (window._svLiveRates || {});
        const _svBadge = _svStatus.source === 'lohn-info.de'
          ? `<span title="SV-ráták automatikusan frissítve: ${(_svStatus.updatedAt||'').slice(0,10)}" style="color:#4ade80;">🔄 SV ${_svStatus.year}</span>`
          : `<span title="Beégetett 2026-os SV értékek (nincs net. frissítés)" style="color:var(--text2);">📌 SV 2026</span>`;
        srcEl.innerHTML = `<span>${_bmfLabel}</span>${_svBadge}<button onclick="window.refreshBmfTax()" title="${t('bmfRefreshTitle')||'BMF adó frissítése'}" style="background:none;border:1px solid var(--border);border-radius:4px;color:var(--text2);font-size:10px;padding:1px 5px;cursor:pointer;">🔄</button>`;
      }

      // ── MANUÁLIS OVERRIDE ──
      // Ha a felhasználó manuálisan módosított egy értéket, azt használjuk a bérszámításban.
      const _mKey = state.payrollYear + '-' + state.payrollMonth;
      const _mOverrides = (state.manualHours && state.manualHours[_mKey]) || {};
      const _hasManualOverride = Object.keys(_mOverrides).length > 0;
      function _fmtH(v) {
        return v.toFixed(2);
      }
      function _applyOverride(id, calcVal) {
        let el = document.getElementById(id);
        if (!el) return calcVal;
        const hSuffix = ' ' + (t('hours')||'h');
        const val = _mOverrides[id] !== undefined ? _mOverrides[id] : calcVal;
        // Ha az elem INPUT és szerkesztési módban vagyunk, hagyjuk inputként (preview)
        if (el.tagName === 'INPUT') {
          if (window._hoursEditMode) return val;
          const span = document.createElement('span');
          span.id = id;
          span.className = 'stat-value';
          el.parentNode.replaceChild(span, el);
          el = span;
        }
        // Csak az óra részt írjuk – az euro-t _appendEuro adja hozzá
        el.innerHTML = '<span class="sv-hours' + (_mOverrides[id] !== undefined ? ' hours-manual' : '') + '">' + _fmtH(val) + hSuffix + '</span>';
        return val;
      }

      const _workHours     = _applyOverride('hoursWorked',       workHours);
      const _overtimeHours = _applyOverride('overtimeHours',     overtimeHours);
      const _night25Hours  = _applyOverride('night25Hours',      nightHours25);
      const _night40Hours  = _applyOverride('night40Hours',      nightHours40);
      const _sundayHours   = _applyOverride('sundayHours',       sundayHours);
      const _holidayHours  = _applyOverride('holidayHours',      holidayHours);
      const _vacBonusHours = _applyOverride('vacationBonusHours',vacationBonusHours);

      // Pótlék összegek kiírása az órák mellé (override-tudatos, a tényleges _* értékekkel)
      function _appendEuro(id, amount) {
        const el = document.getElementById(id);
        if (!el || el.tagName === 'INPUT' || amount <= 0) return;
        // Töröljük az esetleg már meglévő sv-euro span-t
        const old = el.querySelector('.sv-euro');
        if (old) old.remove();
        const s = document.createElement('span');
        s.className = 'sv-euro';
        s.textContent = amount.toFixed(2) + ' €';
        el.appendChild(s);
      }
      // _appendEuro-t az override ág után hívjuk meg, hogy a helyes _* órákkal számoljon
      // – lásd lentebb a Ha nincs manuális override blokk után

      // Ha nincs manuális override → használjuk a fő számítás pontos értékeit
      let _brutto, _bruttoStp, _svBetragOverride, _lohnsteuerOverride, _soliOverride;

      if (!_hasManualOverride) {
        // Nincs override: a fő számítás értékei pontosak, ezeket használjuk
        _brutto = brutto;
        _bruttoStp = bruttoSteuerpflichtig;
        _svBetragOverride = svBetrag;
        _lohnsteuerOverride = lohnsteuerLocal;
        _soliOverride = soliLocal;
      } else {
        // Van override: újraszámítás az override órákkal
        const _premOvt  = _overtimeHours * stl * (1 + OVERTIME_PCT);
        const _premSun  = _sundayHours   * stl * SUNDAY_PCT;
        const _premHol  = _holidayHours  * stl * HOLIDAY_PCT;
        const _premVac  = _vacBonusHours * stl * 0.5;
        const _nightTotal = nightHours25 + nightHours40;
        const _night25Ratio = _nightTotal > 0 ? nightHours25 / _nightTotal : 1;
        const _night40Ratio = _nightTotal > 0 ? nightHours40 / _nightTotal : 0;
        const _overrideNightTotal = _night25Hours + _night40Hours;
        const _premNight = _overrideNightTotal * stl * (_night25Ratio * 0.25 + _night40Ratio * 0.40);
        _brutto = grund + _premNight + _premSun + _premHol + _premOvt + _premVac + zkPayoutPay + ezBruttoBonus + wgBruttoBonus;

        const _nightTaxFreeRatio = (() => {
          const nRules = _pRules.filter(r => r.type === 'normal');
          if (!nRules.length) return 1;
          const tfCount = nRules.filter(r => r.taxFree !== false).length;
          return tfCount / nRules.length;
        })();
        const _totalTaxFree =
          (_premNight * _nightTaxFreeRatio) +
          (_sundayTaxFree   ? _premSun : 0) +
          (_holidayTaxFree  ? _premHol : 0) +
          (_overtimeTaxFree ? _premOvt : 0) +
          (_vacationTaxFree ? _premVac : 0);
        // zkPayoutPay adóköteles, nem vonjuk le az adóalapból
        _bruttoStp = Math.max(0, _brutto - _totalTaxFree);
        _svBetragOverride = calcSV(_bruttoStp); // BBG-vel pontos SV
        _lohnsteuerOverride = calcLohnsteuerLocal(_bruttoStp, tc, kinder);
        // Soli 2026: Freigrenze 20.350 €/év → havi 1.695,83 € lohnsteuer alatt = 0
        // Milderungszone: fokozatosan nő, nem ugrik 5,5%-ra
        const _soliFreiG = ((window._svLiveRates || {}).soliFreigrenze || 20350) / 12;
        _soliOverride = _lohnsteuerOverride > _soliFreiG
          ? Math.min(_lohnsteuerOverride * 0.055, (_lohnsteuerOverride - _soliFreiG) * 0.119)
          : 0;
      }

      // Pótlék összegek kiírása az órák mellé (override utáni pontos értékekkel)
      _appendEuro('night25Hours',      _night25Hours * stl * 0.25);
      _appendEuro('night40Hours',      _night40Hours * stl * 0.40);
      _appendEuro('overtimeHours',     _overtimeHours * stl * (1 + OVERTIME_PCT));
      _appendEuro('sundayHours',       _sundayHours * stl * SUNDAY_PCT);
      _appendEuro('holidayHours',      _holidayHours * stl * HOLIDAY_PCT);
      _appendEuro('vacationBonusHours',_vacBonusHours * stl * 0.5);

      // Órabér frissítés (minden calculatePayroll hívásnál)
      const _stlSpan = document.getElementById('stundenlohn');
      if (_stlSpan) _stlSpan.textContent = stl.toFixed(2) + ' €';

      _animCountUp(document.getElementById('bruttoSum'), _brutto);
      // Azonnali megjelenítés offline adatokkal
      renderPayrollUI(_lohnsteuerOverride, _soliOverride, false, _brutto, _svBetragOverride);

      // Ha online: BMF API hívás, frissítjük a pontos értékekkel
      // _myCallId guard: ha közben új calculatePayroll() hívás érkezett, a régi callback nem ír felül
      if (navigator.onLine) {
        fetchBmfTax(_bruttoStp, tc, kinder, kirche, year).then(res => {
          if (_myCallId !== _calcPayrollCallId) return; // elavult hívás, eldobjuk
          if (res.lst !== null) {
            renderPayrollUI(res.lst, res.soli || 0, true, _brutto, _svBetragOverride);
          }
        }).catch(() => {
          // Marad a helyi számítás
        });
      }
    }

    // ── Globális elérhetőség (külső scriptek, pl. raise modul számára) ──
    window.calculatePayroll = calculatePayroll;


    // ══════════════════════════════════════════════════════════════════════
    //  SV AUTO-UPDATE: automatikus SV-ráta és adóparaméter frissítés
    // ══════════════════════════════════════════════════════════════════════
    //
    //  Évente egyszer (Jan. 1. után) lekéri az aktuális évre vonatkozó
    //  SV-Rechengrößen értékeket a lohn-info.de oldalról (nyilvános, stabil),
    //  kinyeri a kulcsértékeket és eltárolja window._svLiveRates-ben
    //  (és localStorage-ban chronos_sv_rates_YYYY kulcson).
    //
    //  Fallback: ha az API nem elérhető, a beégetett 2026-os értékek maradnak.
    //
    //  A window._svLiveRates objektum mezői (ha elérhetőek):
    //    BBG_RV            : havi RV/AV BBG (pl. 8450)
    //    BBG_KV            : havi KV/PV BBG (pl. 5812.50)
    //    pv_base           : PV AN-rész (pl. 0.018)
    //    grundfreibetrag   : §32a Grundfreibetrag (pl. 12348)
    //    kinderfreibetragHalb : Kinderfreibetrag AN-fél (pl. 4872)
    //    soliFreigrenze    : éves Soli Freigrenze (pl. 20350)
    //    lohnsteuerParams  : §32a tarifa koefficiensek objektum (ha elérhető)
    //    year              : melyik évre vonatkozik
    //    updatedAt         : ISO timestamp
    // ══════════════════════════════════════════════════════════════════════

    (function() {
      const LS_SV_KEY_PREFIX = 'chronos_sv_rates_';
      const currentYear = new Date().getFullYear();
      const lsKey = LS_SV_KEY_PREFIX + currentYear;

      // Beégetett 2026-os alapértékek (fallback)
      const BUILTIN_2026 = {
        BBG_RV:   8450,
        BBG_KV:   5812.50,
        pv_base:  0.018,
        grundfreibetrag: 12348,
        kinderfreibetragHalb: 4872,
        soliFreigrenze: 20350,
        lohnsteuerParams: {
          s1_to: 17799, s2_to: 69878, s3_to: 277825,
          s1_a: 914.51,  s1_b: 1400,
          s2_a: 172.31,  s2_b: 2397,   s2_c: 1025.38,
          s3_k: 0.42,    s3_d: 10908.16,
          s4_k: 0.45,    s4_d: 19470.38,
          grundfreibetrag: 12348
        },
        year: 2026,
        source: 'builtin'
      };

      // Alapértékek betöltése: localStorage → builtin
      function _loadCachedRates() {
        try {
          const raw = localStorage.getItem(lsKey);
          if (raw) {
            const parsed = JSON.parse(raw);
            if (parsed && parsed.year === currentYear) {
              window._svLiveRates = parsed;
              window._svCachedYear = currentYear;
              return true;
            }
          }
        } catch(e) {}
        // Builtin fallback az aktuális évre
        if (currentYear === 2026) {
          window._svLiveRates = Object.assign({}, BUILTIN_2026);
          window._svCachedYear = 2026;
        }
        return false;
      }

      // lohn-info.de scraping: kinyerjük a BBG értékeket a HTML táblából
      // Ez egy nyilvánosan elérhető, évente frissülő oldal
      async function _fetchSvRatesFromLohnInfo(year) {
        const url = `https://www.lohn-info.de/sozialversicherungsbeitraege${year}.html`;
        try {
          // CapacitorHttp (natív Android, CORS-mentes)
          const capHttp = window.Capacitor?.Plugins?.CapacitorHttp;
          let html = null;
          if (capHttp) {
            const r = await capHttp.request({ method: 'GET', url, headers: {}, responseType: 'text' });
            if (r?.status === 200 && r?.data) html = r.data;
          }
          if (!html) {
            const r = await fetch(url);
            if (r.ok) html = await r.text();
          }
          if (!html) return null;

          // Kinyerés regex-szel a HTML szövegből
          // BBG RV: "8.450" vagy "8450" közelében "RV" / "Renten"
          function _extractNum(pattern, text, fallback) {
            const m = text.match(pattern);
            if (!m) return fallback;
            return parseFloat(m[1].replace(/\./g,'').replace(',','.'));
          }

          // BBG RV/AV: "8.450" Euro / Monat közelében "Rentenversicherung" táblában
          const bbgRv = _extractNum(/Beitragsbemessungsgrenze.*?RV.*?([\d]{1,2}[\.\d]*\.\d{3})\s*(?:Euro|€)?\s*(?:monatlich|\/Monat)/i, html, null)
            || _extractNum(/([\d]\.[\d]{3})\s*(?:Euro|€)[\s\S]{0,200}?Rentenversicherung/i, html, null);

          // BBG KV/PV
          const bbgKv = _extractNum(/Beitragsbemessungsgrenze.*?KV.*?([\d]{1,2}[\.\d]*\.\d{2,3})\s*(?:Euro|€)?/i, html, null)
            || _extractNum(/(5[\.\d]{4,7})\s*(?:Euro|€)[\s\S]{0,300}?Krankenversicherung/i, html, null);

          // PV Beitragssatz AN-rész: "1,80" vagy "1,8" közelében "Pflege"
          const pvMatch = html.match(/Pflegeversicherung[\s\S]{0,500}?(\d[,\.]\d+)\s*%[\s\S]{0,100}?Arbeitnehmer/i)
            || html.match(/Arbeitnehmer[\s\S]{0,100}?(\d[,\.]\d+)\s*%[\s\S]{0,200}?Pflege/i);
          const pvBase = pvMatch ? parseFloat(pvMatch[1].replace(',','.')) / 100 : null;

          // Grundfreibetrag: "12.348" közelében "Grundfreibetrag" vagy "§32a"
          const gfMatch = html.match(/Grundfreibetrag[\s\S]{0,200}?([\d]{2}\.[\d]{3})\s*(?:Euro|€)/i)
            || html.match(/(12\.[\d]{3})\s*(?:Euro|€)[\s\S]{0,100}?Grundfreibetrag/i);
          const grundfreibetrag = gfMatch ? parseInt(gfMatch[1].replace('.','')) : null;

          // Ha egyik sem jött be, null-t adunk vissza (builtin marad)
          if (!bbgRv && !bbgKv && !pvBase) return null;

          const rates = {
            BBG_RV:  bbgRv  || (currentYear === 2026 ? 8450   : BUILTIN_2026.BBG_RV),
            BBG_KV:  bbgKv  || (currentYear === 2026 ? 5812.5 : BUILTIN_2026.BBG_KV),
            pv_base: pvBase || (currentYear === 2026 ? 0.018  : BUILTIN_2026.pv_base),
            grundfreibetrag: grundfreibetrag || BUILTIN_2026.grundfreibetrag,
            kinderfreibetragHalb: BUILTIN_2026.kinderfreibetragHalb,
            soliFreigrenze: BUILTIN_2026.soliFreigrenze,
            lohnsteuerParams: Object.assign({}, BUILTIN_2026.lohnsteuerParams, {
              grundfreibetrag: grundfreibetrag || BUILTIN_2026.grundfreibetrag
            }),
            year: currentYear,
            updatedAt: new Date().toISOString(),
            source: 'lohn-info.de'
          };
          return rates;
        } catch(e) {
          console.warn('[SV Auto-Update] Fetch error:', e);
          return null;
        }
      }

      // Éves frissítési logika: csak egyszer naponta, és csak ha az év eleje van (jan–febr.)
      // vagy ha a cache hiányzik / elavult évből való
      async function _svAutoUpdate() {
        const now = Date.now();
        const lastFetch = parseInt(localStorage.getItem(LS_SV_KEY_PREFIX + 'lastFetch') || '0');
        const hoursSinceFetch = (now - lastFetch) / 3600000;

        // Frissítési feltételek:
        // 1. Nincs cache az aktuális évre, VAGY
        // 2. Jan 1–Feb 28 között vagyunk és 24h telt el az utolsó próba óta
        const noCache = !localStorage.getItem(lsKey);
        const isYearStart = new Date().getMonth() < 2; // jan vagy febr.
        const shouldFetch = noCache || (isYearStart && hoursSinceFetch > 24);

        if (!shouldFetch) return;

        localStorage.setItem(LS_SV_KEY_PREFIX + 'lastFetch', now.toString());
        const rates = await _fetchSvRatesFromLohnInfo(currentYear);

        if (rates) {
          try {
            localStorage.setItem(lsKey, JSON.stringify(rates));
            window._svLiveRates = rates;
            window._svCachedYear = currentYear;
            console.info(`[SV Auto-Update] ✅ ${currentYear}: BBG_RV=${rates.BBG_RV}, BBG_KV=${rates.BBG_KV}, PV=${(rates.pv_base*100).toFixed(2)}%, GFB=${rates.grundfreibetrag} (forrás: ${rates.source})`);
            // Újraszámítás az új értékekkel
            if (typeof calculatePayroll === 'function') {
              try { calculatePayroll(); } catch(e) {}
            }
          } catch(e) {}
        } else {
          console.info(`[SV Auto-Update] ℹ️ Scraping sikertelen, beégetett ${currentYear === 2026 ? '2026' : '?'}-os értékek maradnak.`);
        }
      }

      // Státusz lekérése (UI badge-hez)
      window._svGetStatus = function() {
        const r = window._svLiveRates;
        if (!r) return { source: 'builtin', year: 2026 };
        return r;
      };

      // Init: cache betöltése, majd async frissítés háttérben
      _loadCachedRates();
      // Rövid késleltetéssel, hogy ne lassítsa az app induló betöltését
      setTimeout(_svAutoUpdate, TIMING.INIT_SV_UPDATE);

    })();

    // ── BMF manuális frissítés gomb ──
    // Újra lekéri a BMF API-t és frissíti az adószámítást.
    window.refreshBmfTax = function() {
      const srcEl = document.getElementById('taxSourceLabel');
      if (srcEl) srcEl.innerHTML = `<span>${t('bmfQuerying')||'⏳ BMF lekérdezés...'}</span>`;
      calculatePayroll();
    };


    // ==================== MANUÁLIS ÓRA SZERKESZTÉS ====================
    const HOURS_FIELDS = [
      'hoursWorked','overtimeHours','night25Hours','night40Hours',
      'sundayHours','holidayHours','vacationBonusHours'
    ];

    window.openHoursEditMode = function() {
      window._hoursEditMode = true;
      const mKey = state.payrollYear + '-' + state.payrollMonth;
      const overrides = (state.manualHours && state.manualHours[mKey]) || {};

      // Minden stat-value span-t inputra cserél
      HOURS_FIELDS.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        const cur = overrides[id] !== undefined ? overrides[id] : (parseFloat(el.textContent) || 0);
        const inp = document.createElement('input');
        inp.type = 'number';
        inp.className = 'hours-inline-input';
        inp.dataset.fieldId = id;
        inp.value = cur.toFixed(1);
        inp.step = '0.5';
        inp.min = '0';
        // Azonnali újraszámítás minden értékváltáskor (előnézet mentés nélkül)
        inp.addEventListener('input', _previewHoursCalc);
        el.parentNode.replaceChild(inp, el);
      });

      // Gomb váltás: ✏️ → ✅ Mentés + ↩ Visszavonás
      const bar = document.getElementById('hoursEditBar');
      if (bar) {
        bar.innerHTML = `
          <button class="hours-edit-toggle-btn" onclick="window.cancelHoursEdit()" data-i18n="hoursCancelBtn" title="${t('hoursCancelBtn')||'Cancel'}">↩</button>
          <button class="hours-edit-toggle-btn active" onclick="window.saveHoursEdit()" data-i18n="hoursSaveBtn" title="${t('hoursSaveBtn')||'Save'}">✅</button>
          <button class="hours-edit-toggle-btn" onclick="window.resetAllHoursOverrides()" data-i18n="hoursResetAllBtn" title="${t('hoursResetAllBtn')||'Reset all'}">🔄</button>
        `;
      }
    };

    // Élő előnézet: az input mezőkből olvas, ideiglenesen az state.manualHours-ba írja,
    // újraszámolja a bért, majd visszaállítja az eredeti state-et.
    function _previewHoursCalc() {
      const mKey = state.payrollYear + '-' + state.payrollMonth;
      const prevOverrides = (state.manualHours && state.manualHours[mKey])
        ? JSON.parse(JSON.stringify(state.manualHours[mKey])) : null;

      if (!state.manualHours) state.manualHours = {};
      if (!state.manualHours[mKey]) state.manualHours[mKey] = {};

      HOURS_FIELDS.forEach(id => {
        const inp = document.querySelector(`.hours-inline-input[data-field-id="${id}"]`);
        if (!inp) return;
        const val = parseFloat(inp.value);
        if (!isNaN(val) && val >= 0) {
          state.manualHours[mKey][id] = val;
        }
      });

      calculatePayroll();

      // Visszaállítás: ne töröljük az eredeti state-et (nem hívunk saveState-t)
      if (prevOverrides === null) {
        delete state.manualHours[mKey];
      } else {
        state.manualHours[mKey] = prevOverrides;
      }
    }

    window.saveHoursEdit = function() {
      const mKey = state.payrollYear + '-' + state.payrollMonth;
      if (!state.manualHours) state.manualHours = {};
      if (!state.manualHours[mKey]) state.manualHours[mKey] = {};

      HOURS_FIELDS.forEach(id => {
        const inp = document.querySelector(`.hours-inline-input[data-field-id="${id}"]`);
        if (!inp) return;
        const val = parseFloat(inp.value);
        if (!isNaN(val) && val >= 0) {
          state.manualHours[mKey][id] = val;
        }
        // Input visszacserélése span-ra
        const span = document.createElement('span');
        span.id = id;
        span.className = 'stat-value';
        inp.parentNode.replaceChild(span, inp);
      });

      if (Object.keys(state.manualHours[mKey]).length === 0) delete state.manualHours[mKey];
      saveState();
      _restoreEditBar();
      calculatePayroll();
    };

    window.cancelHoursEdit = function() {
      HOURS_FIELDS.forEach(id => {
        const inp = document.querySelector(`.hours-inline-input[data-field-id="${id}"]`);
        if (!inp) return;
        const span = document.createElement('span');
        span.id = id;
        span.className = 'stat-value';
        inp.parentNode.replaceChild(span, inp);
      });
      _restoreEditBar();
      calculatePayroll();
    };

    window.resetAllHoursOverrides = function() {
      const mKey = state.payrollYear + '-' + state.payrollMonth;
      if (state.manualHours && state.manualHours[mKey]) {
        delete state.manualHours[mKey];
        saveState();
      }
      HOURS_FIELDS.forEach(id => {
        const inp = document.querySelector(`.hours-inline-input[data-field-id="${id}"]`);
        if (!inp) return;
        const span = document.createElement('span');
        span.id = id;
        span.className = 'stat-value';
        inp.parentNode.replaceChild(span, inp);
      });
      _restoreEditBar();
      calculatePayroll();
    };

    function _restoreEditBar() {
      window._hoursEditMode = false;
      const bar = document.getElementById('hoursEditBar');
      if (bar) {
        bar.innerHTML = `<button id="hoursEditBtn" class="hours-edit-toggle-btn" onclick="window.openHoursEditMode()" data-i18n="hoursEditBtn">✏️</button>`;
        // i18n frissítés
        const btn = document.getElementById('hoursEditBtn');
        if (btn) btn.title = t('hoursEditBtn') || 'Edit hours';
      }
    }

    // ==================== SZABADSÁG KEZELÉS ====================
    function getCurrentYearVacation() {
      if (!state.resturlaub.years[state.year]) {
        state.resturlaub.years[state.year] = { base: 30, carried: 0, used: 0 };
      }
      return state.resturlaub.years[state.year];
    }

    function calculateVacationUsed(year) {
      let used = 0;
      Object.entries(state.schedules).forEach(([key, ids]) => {
        if (key.startsWith(year + '-')) {
          ids.forEach(id => {
            if (id === 'Urlaub') used += 1;
            if (id === 'Urlaub1' || id === 'Urlaub2') used += 0.5;
          });
        }
      });
      return used;
    }

    function updateVacation() {
      const current = getCurrentYearVacation();
      current.used = calculateVacationUsed(state.year);
      const total = current.base + current.carried;

      document.getElementById('vacUsed').textContent = current.used + ' ' + (t('days')||'d');
      document.getElementById('vacTotal').textContent = total + ' ' + (t('days')||'d');
      document.getElementById('vacLeft').textContent = (total - current.used) + ' ' + (t('days')||'d');
      document.getElementById('vacCarriedDisplay').textContent = current.carried + ' ' + (t('days')||'d');
    }

    // ==================== PÓTLÉK SZABÁLYOK ====================
    function renderPotlek() {
      const c = document.getElementById('potlekContent');
      if (!c) return;

      c.innerHTML = '';

      state.potlekRules.forEach((r, i) => {
        const div = document.createElement('div');
        div.className = 'potlek-edit-row';

        const isOvertime = r.type === 'overtime';

        div.innerHTML = `
          <input type="text" value="${getPotlekName(r)}" placeholder="Name" data-index="${i}" data-field="name" style="flex:1;">
          ${!isOvertime 
            ? `<input type="time" value="${r.start || ''}" data-index="${i}" data-field="start"><span>–</span><input type="time" value="${r.end || ''}" data-index="${i}" data-field="end">` 
            : `<span>${t('overtimeLabel') || 'Overtime'}</span>`}
          <input type="number" value="${r.percent}" min="0" max="300" step="5" style="width:50px;" data-index="${i}" data-field="percent"><span>%</span>
          <label style="display:flex;align-items:center;gap:2px;font-size:10px;white-space:nowrap;" title="${t('taxFreeShort')||'adóm.'}">
            <input type="checkbox" data-index="${i}" data-field="taxFree" ${r.taxFree ? 'checked' : ''} style="width:auto;margin:0;">
            <span style="color:var(--text2)" class="taxfree-label">${t('taxFreeShort')||'adóm.'}</span>
          </label>
          ${isOvertime ? `
          <div class="sat-night-row" onclick="this.querySelector('input[type=checkbox]').click()">
            <label class="sat-mini-toggle" onclick="event.stopPropagation()">
              <input type="checkbox" data-index="${i}" data-field="satNightOvertime" ${r.satNightOvertime ? 'checked' : ''}>
              <span class="sat-mini-slider"></span>
            </label>
            <span>🌙 <span class="sat-night-text">${t('satNightOvertimeLabel')||'Szombat éjszaka = túlóra'}</span></span>
          </div>` : ''}
          <button class="potlek-del-btn" data-index="${i}">🗑️</button>
        `;

        c.appendChild(div);
      });

      document.querySelectorAll('.potlek-edit-row input').forEach(input => {
        input.addEventListener('input', (e) => {
          const i = e.target.dataset.index;
          const f = e.target.dataset.field;
          let v = e.target.value;
          if (f === 'percent') v = parseFloat(v) || 0;
          if (f === 'taxFree') v = e.target.checked;
          if (f === 'name') {
            // Ha a felhasználó szerkeszti a nevet, töröljük a nameKey-t (egyéni név lesz)
            state.potlekRules[i].nameKey = null;
          }
          state.potlekRules[i][f] = v;
          saveState();
          // Azonnal frissítjük a műszak gombokat
          renderShifts();
          // Ha adózási beállítás változott, bérszámítást is frissítjük
          if (f === 'taxFree' || f === 'percent') calculatePayroll();
        });
        input.addEventListener('change', (e) => {
          const field = e.target.dataset.field;
          const i = e.target.dataset.index;
          if (field === 'taxFree') {
            state.potlekRules[i]['taxFree'] = e.target.checked;
            saveState();
            renderShifts();
            calculatePayroll();
          } else if (field === 'satNightOvertime') {
            state.potlekRules[i]['satNightOvertime'] = e.target.checked;
            saveState();
            renderShifts();
          }
        });
      });

      document.querySelectorAll('.potlek-del-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const i = e.target.dataset.index;
          if (confirm(t('confirmDelete') || 'Delete?')) {
            state.potlekRules.splice(i, 1);
            saveState();
            renderPotlek();
            renderShifts();
          }
        });
      });
    }

    // ==================== KIEGÉSZÍTŐK ====================
    function renderExtras() {
      const c = document.getElementById('extrasContent');
      if (!c) return;

      // Mentjük az aktuális input értékeket újraépítés előtt
      const _savedEzAmt  = document.getElementById('ez_amount')?.value  || '';
      const _savedEzName = document.getElementById('ez_name')?.value    || '';
      const _savedEzType = document.getElementById('ez_type')?.value    || 'brutto';
      const _savedEzMo   = document.getElementById('ez_month')?.value   || '';
      const _savedOtAmt  = document.getElementById('other_amount')?.value || '';
      const _savedOtName = document.getElementById('other_name')?.value  || '';
      const _savedOtMo   = document.getElementById('other_month')?.value || '';

      c.innerHTML = '';

      const month = state.payrollMonth + 1;

      const _mn = (TRANSLATIONS[state.currentLang] || TRANSLATIONS.de).monthNames;
      const _mshort = _mn.map(m => m.slice(0,3));
      const MONTH_OPTS = `<option value="">${t('allMonths') || 'All months'}</option>` +
        _mshort.map((m,i) => `<option value="${i+1}">${m}</option>`).join('');

      function makeBlock(key, icon, label, enabled, detailsHTML) {
        const wrap = document.createElement('div');
        wrap.style.marginBottom = '8px';

        const row = document.createElement('div');
        row.className = 'stat-row';
        row.style.cursor = 'pointer';
        row.innerHTML = `<span>${label}</span><div class="switch${enabled ? ' on' : ''}" id="sw_${key}"></div>`;

        wrap.appendChild(row);

        const det = document.createElement('div');
        det.id = `det_${key}`;
        det.style.display = enabled ? 'block' : 'none';
        det.style.padding = '8px 0 4px';
        det.innerHTML = detailsHTML;

        det.addEventListener('click', function(e) { e.stopPropagation(); });

        wrap.appendChild(det);
        c.appendChild(wrap);

        return det;
      }

      // Zeitkonto
      // Kivételek (withdrawals) listája – YYYY-M kulcsú bejegyzések
      const _zkW = state.zeitkonto.withdrawals || [];
      let _zkWList = '';
      _zkW.forEach((w, i) => {
        // YYYY-M → hónap név megjelenítéshez
        const _wParts = w.month ? w.month.split('-') : [];
        const _wYr = _wParts[0] || '';
        const _wMi = _wParts[1] ? parseInt(_wParts[1]) - 1 : -1;
        const _wMName = _wMi >= 0 ? (_mshort[_wMi] || '') : '';
        _zkWList += `<div class="stat-row" style="font-size:12px;">
          <span style="flex:1">${_wYr} ${_wMName}</span>
          <strong>${w.hours} h</strong>
          ${w.note ? `<span style="color:var(--text2); margin:0 4px; font-size:11px;">${w.note}</span>` : ''}
          <button class="small-btn" onclick="delZkWithdrawal(${i})">🗑️</button>
        </div>`;
      });
      // Hónap-választó: aktuális évhez
      const _zkYr = state.payrollYear || new Date().getFullYear();
      const _zkMonthOpts = _mshort.map((m, i) => `<option value="${_zkYr}-${i+1}">${m} ${_zkYr}</option>`).join('');

      // Manuális havi felülírások (monthlyOverrides) listája
      const _zkMO = state.zeitkonto.monthlyOverrides || [];
      let _zkMOList = '';
      _zkMO.forEach((o, i) => {
        const _oParts = o.month ? o.month.split('-') : [];
        const _oYr = _oParts[0] || '';
        const _oMi = _oParts[1] ? parseInt(_oParts[1]) - 1 : -1;
        const _oMName = _oMi >= 0 ? (_mshort[_oMi] || '') : '';
        _zkMOList += `<div class="stat-row" style="font-size:12px;">
          <span style="flex:1">${_oYr} ${_oMName}</span>
          <strong>${o.hours} h</strong>
          <button class="small-btn" onclick="delZkMonthlyOverride(${i})">🗑️</button>
        </div>`;
      });

      const zkDet = makeBlock('zk', '⏱️', t('zeitkonto') || 'Zeitkonto', state.zeitkonto.enabled,
        `<div class="stat-row"><span class="stat-label">${t('zkSaveAll')||'Összes túlóra → ZK'}</span><label class="toggle-label" style="margin:0;"><input type="checkbox" id="zk_save_all" ${state.zeitkonto.saveAllOvertime ? 'checked' : ''} onchange="saveZKSaveAll()"><span class="toggle-track"></span></label></div>
         <div class="stat-row" id="zk_monthly_row" style="${state.zeitkonto.saveAllOvertime ? 'opacity:0.35;pointer-events:none;' : ''}"><span class="stat-label">${t('monthlyCost')||'Monthly deduction'}</span><div><input type="number" class="base-input" id="zk_monthly" value="${state.zeitkonto.monthly || ''}" placeholder="" oninput="saveZK()" onchange="saveZK()"><span class="input-unit">${t('hours')||'h'}</span></div></div>
         <div class="stat-row"><span class="stat-label">${t('balance')||'Balance'}</span><div><input type="number" class="base-input" id="zk_balance" value="${state.zeitkonto.balance || ''}" placeholder="" oninput="saveZKBal()" onchange="saveZKBal()"><span class="input-unit">${t('hours')||'h'}</span></div></div>
         <div class="stat-row"><span class="stat-label">${t('zkMaxBalance')||'Max. keret (opcionális)'}</span><div><input type="number" class="base-input" id="zk_max_balance" value="${state.zeitkonto.maxBalance || ''}" placeholder="–" min="0" oninput="saveZKMax()" onchange="saveZKMax()"><span class="input-unit">${t('hours')||'h'}</span></div></div>
         ${_zkMOList ? `<div style="margin-top:6px; font-size:11px; color:var(--text2); padding-bottom:2px;">${t('zkMonthlyOverrides')||'Havi egyedi felülírások'}</div>${_zkMOList}` : ''}
         <div style="margin-top:8px; font-size:11px; color:var(--text2); padding-bottom:2px;">${t('zkAddMonthlyOverride')||'Manuális havi ZK-óra'}</div>
         <div class="stat-row" style="flex-wrap:wrap; gap:6px; margin-top:4px;">
           <select class="base-select" id="zk_mo_month" style="font-size:11px;">${_zkMonthOpts}</select>
           <input class="base-input" id="zk_mo_hours" type="number" placeholder="${t('hours')||'h'}" step="0.5" min="0" style="width:60px;">
           <button class="small-btn" onclick="addZkMonthlyOverride()">➕</button>
         </div>
         ${_zkWList ? `<div style="margin-top:8px; font-size:11px; color:var(--text2); padding-bottom:2px;">${t('zkWithdrawals')||'Kivételek'}</div>${_zkWList}` : ''}
         <div style="margin-top:6px; font-size:11px; color:var(--text2); padding-bottom:2px;">${t('zkAddWithdrawal')||'Manuális kivétel hozzáadása'}</div>
         <div class="stat-row" style="flex-wrap:wrap; gap:6px; margin-top:4px;">
           <select class="base-select" id="zk_w_month" style="font-size:11px;">${_zkMonthOpts}</select>
           <input class="base-input" id="zk_w_hours" type="number" placeholder="${t('hours')||'h'}" step="0.5" min="0" style="width:60px;">
           <button class="small-btn" onclick="addZkWithdrawal()">➕</button>
         </div>`
      );

      // Darlehen
      const daDet = makeBlock('da', '🏦', t('darlehen') || 'Darlehen', state.darlehen.enabled,
        `<div class="stat-row"><span class="stat-label">${t('monthlyPayment')||'Monthly payment'}</span><div><input type="number" class="base-input" id="da_monthly" value="${state.darlehen.monthly || ''}" placeholder="" oninput="saveDA()" onchange="saveDA()"><span class="input-unit">€</span></div></div>
         <div class="stat-row"><span class="stat-label">${t('amountOwed')||'Amount owed'}</span><div><input type="number" class="base-input" id="da_balance" value="${state.darlehen.balance || ''}" placeholder="" oninput="saveDABal()" onchange="saveDABal()"><span class="input-unit">€</span></div></div>`
      );

      // Einmalzahlung
      let ezList = '';
      state.einmalzahlung.payments.forEach((p, i) => {
        const ezTypLabel = p.type === 'netto' ? '<span style="font-size:10px;color:#4ade80;margin:0 4px;">nettó</span>' : '<span style="font-size:10px;color:#60a5fa;margin:0 4px;">bruttó</span>';
        ezList += `<div class="stat-row" style="font-size:12px;">
          <span style="flex:1">${p.name || t('payment') || 'Payment'}</span>
          ${ezTypLabel}
          <strong>${p.amount} €</strong>
          <span style="color:var(--text2); margin:0 6px;">${p.month ? ((TRANSLATIONS[state.currentLang]||TRANSLATIONS.de).monthNames[parseInt(p.month)-1]||'').slice(0,3) : (t('allMonths')||'All')}</span>
          <button class="small-btn" onclick="delEZ(${i})">🗑️</button>
        </div>`;
      });

      const ezDet = makeBlock('ez', '🎁', t('einmalzahlung') || 'Einmalzahlung', state.einmalzahlung.enabled,
        ezList + `<div class="stat-row" style="flex-wrap:wrap; gap:6px; margin-top:6px;">
          <input class="base-input" id="ez_name" placeholder="Name" style="width:80px;">
          <input class="base-input" id="ez_amount" placeholder="Amount" style="width:60px;" oninput="calculatePayroll()" onchange="calculatePayroll()">
          <select class="base-select" id="ez_type" style="font-size:11px;" onchange="calculatePayroll()">
            <option value="brutto">bruttó</option>
            <option value="netto">nettó</option>
          </select>
          <select class="base-select" id="ez_month" style="font-size:11px;" onchange="calculatePayroll()">${MONTH_OPTS}</select>
          <button class="small-btn" onclick="addEZ()">➕</button>
        </div>`
      );

      // Egyéb levonások (hiányzó)
      let otherList = '';
      if (state.otherDeductions) {
        state.otherDeductions.forEach((o, i) => {
          otherList += `<div class="stat-row" style="font-size:12px;">
            <span style="flex:1">${o.name}</span>
            <strong>${o.amount} €</strong>
            <span style="color:var(--text2); margin:0 6px;">${o.month ? ((TRANSLATIONS[state.currentLang]||TRANSLATIONS.de).monthNames[parseInt(o.month)-1]||'').slice(0,3) : (t('allMonths')||'All')}</span>
            <button class="small-btn" onclick="delOther(${i})">🗑️</button>
          </div>`;
        });
      }

      const otherDet = makeBlock('other', '🧾', t('otherDeductions') || 'Other deductions', !!state.otherDeductionsEnabled,
        otherList + `<div class="stat-row" style="flex-wrap:wrap; gap:6px; margin-top:6px;">
          <input class="base-input" id="other_name" placeholder="Name" style="width:90px;">
          <input class="base-input" id="other_amount" placeholder="Amount" style="width:60px;" oninput="calculatePayroll()" onchange="calculatePayroll()">
          <select class="base-select" id="other_month" style="font-size:11px;" onchange="calculatePayroll()">${MONTH_OPTS}</select>
          <button class="small-btn" onclick="addOther()">➕</button>
        </div>`
      );

      // Weihnachtsgeld
      if (!state.weihnachtsgeld.percent) state.weihnachtsgeld.percent = '50';
      // wgMissingMonths és wgBruttoBonus a calculatePayroll()-ból jön, window-on keresztül
      const wgMissingMonths = window._wgMissingMonths || [];
      const wgBruttoBonus = window._wgBruttoBonus || 0;
      const _wgPctUI = parseFloat(state.weihnachtsgeld.percent) || 0;
      let _wgAvgUI = 0;
      // Gyors átlag számítás csak UI megjelenítéshez (október nézetben)
      if (month === 10) {
        let _wgTotalUI = 0, _wgCntUI = 0;
        [8,9,10].forEach(mo => {
          let hasShift = false;
          let pNightUI=0, pSunUI=0, pHolUI=0, pOvtUI=0;
          const _grund2 = parseFloat(state.grundlohn)||0;
          const _fest2 = parseFloat(state.feststunden)||174;
          const _stl2 = _fest2>0?_grund2/_fest2:0;
          Object.entries(state.schedules).forEach(([key,ids])=>{
            const parts=key.split('-').map(Number);
            if(parts[0]!==state.payrollYear||parts[1]!==mo)return;
            hasShift=true;
          });
          if(hasShift){_wgTotalUI+=_grund2; _wgCntUI++;}
        });
        if(_wgCntUI===3) _wgAvgUI = _wgTotalUI/3;
      }
      const wgAmtUI = (wgMissingMonths && wgMissingMonths.length > 0)
        ? '⚠️ ' + (t('wgMissingLabel')||'Hiányos') + ': ' + wgMissingMonths.join(', ')
        : (wgBruttoBonus > 0 ? wgBruttoBonus.toFixed(2) + ' €' : (month !== 10 ? '(' + (t('wgOnlyInOct') || 'csak októberben') + ')' : '0.00 €'));
      const wgDet = makeBlock('wg', '🎄', t('weihnachtsgeld') || 'Weihnachtsgeld', state.weihnachtsgeld.enabled,
        `<div class="stat-row">
          <span class="stat-label">${t('amount')||'Mérték'}</span>
          <div style="display:flex;align-items:center;gap:4px;">
            <input type="number" class="base-input" id="wg_percent" value="${state.weihnachtsgeld.percent||'50'}" min="0" max="200" step="1" style="width:60px;" oninput="saveWGPercent()" onchange="saveWGPercent()">
            <span class="input-unit">%</span>
          </div>
        </div>
        <div style="font-size:11px;color:var(--text2);padding:3px 0 1px;">${t('wgBaseDesc')||'Alap: aug+szept+okt bruttó átlag (Urlaubszuschlag nélkül)'}</div>
        <div style="font-size:12px; color:${(wgMissingMonths&&wgMissingMonths.length>0)?'#f87171':'var(--text2)'}; padding:4px 0;" id="wg_amt">= ${wgAmtUI}</div>`
      );

      // Eseménykezelők – a teljes sorra (row = sw_* szülője) kattintva kapcsol,
      // így a felirat és a kapcsoló gomb egyaránt működik.
      const _swZkRow = document.getElementById('sw_zk')?.parentElement;
      if (_swZkRow) _swZkRow.addEventListener('click', function() {
        state.zeitkonto.enabled = !state.zeitkonto.enabled;
        const _sw = document.getElementById('sw_zk');
        if (_sw) _sw.classList.toggle('on', state.zeitkonto.enabled);
        zkDet.style.display = state.zeitkonto.enabled ? 'block' : 'none';
        saveState();
        calculatePayroll();
      });

      // Értékek visszaállítása az újraépítés után
      if (_savedEzAmt)  { const _el = document.getElementById('ez_amount');  if (_el) _el.value = _savedEzAmt; }
      if (_savedEzName) { const _el = document.getElementById('ez_name');    if (_el) _el.value = _savedEzName; }
      if (_savedEzType) { const _el = document.getElementById('ez_type');    if (_el) _el.value = _savedEzType; }
      if (_savedEzMo)   { const _el = document.getElementById('ez_month');   if (_el) _el.value = _savedEzMo; }
      if (_savedOtAmt)  { const _el = document.getElementById('other_amount'); if (_el) _el.value = _savedOtAmt; }
      if (_savedOtName) { const _el = document.getElementById('other_name');   if (_el) _el.value = _savedOtName; }
      if (_savedOtMo)   { const _el = document.getElementById('other_month');  if (_el) _el.value = _savedOtMo; }
      // Ha volt visszaállított érték, frissítjük a számítást
      if (_savedEzAmt || _savedOtAmt) calculatePayroll();

      const _swDaRow = document.getElementById('sw_da')?.parentElement;
      if (_swDaRow) _swDaRow.addEventListener('click', function() {
        state.darlehen.enabled = !state.darlehen.enabled;
        const _sw = document.getElementById('sw_da');
        if (_sw) _sw.classList.toggle('on', state.darlehen.enabled);
        daDet.style.display = state.darlehen.enabled ? 'block' : 'none';
        saveState();
        calculatePayroll();
      });

      const _swEzRow = document.getElementById('sw_ez')?.parentElement;
      if (_swEzRow) _swEzRow.addEventListener('click', function() {
        state.einmalzahlung.enabled = !state.einmalzahlung.enabled;
        const _sw = document.getElementById('sw_ez');
        if (_sw) _sw.classList.toggle('on', state.einmalzahlung.enabled);
        ezDet.style.display = state.einmalzahlung.enabled ? 'block' : 'none';
        saveState();
        calculatePayroll();
      });

      const _swOtherRow = document.getElementById('sw_other')?.parentElement;
      if (_swOtherRow) _swOtherRow.addEventListener('click', function() {
        state.otherDeductionsEnabled = !state.otherDeductionsEnabled;
        const _sw = document.getElementById('sw_other');
        if (_sw) _sw.classList.toggle('on', state.otherDeductionsEnabled);
        otherDet.style.display = state.otherDeductionsEnabled ? 'block' : 'none';
        saveState();
        calculatePayroll();
      });

      const _swWgRow = document.getElementById('sw_wg')?.parentElement;
      if (_swWgRow) _swWgRow.addEventListener('click', function() {
        state.weihnachtsgeld.enabled = !state.weihnachtsgeld.enabled;
        const _sw = document.getElementById('sw_wg');
        if (_sw) _sw.classList.toggle('on', state.weihnachtsgeld.enabled);
        wgDet.style.display = state.weihnachtsgeld.enabled ? 'block' : 'none';
        saveState();
        calculatePayroll();
      });
    }
          // ==================== STATISZTIKA ====================
      function updateStats() {
        if (!state.grundlohn) {
          // Nincs grundlohn → csak a sima óra/szabadság/beteg összesítő
          let hours = 0, overtime = 0, vacation = 0, sick = 0;
          const _pRules = state.potlekRules || [];
          const _ovtR = _pRules.find(r => r.type === 'overtime');
          const OVT_PCT = _ovtR ? (_ovtR.percent / 100) : 0.25;
          const normalBuiltin   = ['Früh','Spät','Nacht'];
          const overtimeBuiltin = ['Freiwillig Früh','Freiwillig Spät','Freiwillig Nacht','Fei Fr','Fei Sp','Fei Na'];
          Object.entries(state.schedules).forEach(([key, ids]) => {
            if (!key.startsWith(state.year + '-')) return;
            ids.forEach(id => {
              if (id === 'Urlaub') { vacation += 1; return; }
              if (id === 'Urlaub1' || id === 'Urlaub2') { vacation += 0.5; return; }
              if (id === 'Krank') { sick += 1; return; }
              if (normalBuiltin.includes(id))   { hours += 8; return; }
              if (overtimeBuiltin.includes(id)) { hours += 8; overtime += 8; return; }
            });
          });
          const hS = t('hours') || 'h', dS = t('days') || 'nap';
          document.getElementById('yearHours').textContent    = hours + ' ' + hS;
          document.getElementById('yearOvertime').textContent = overtime + ' ' + hS;
          document.getElementById('yearVacation').textContent = vacation + ' ' + dS;
          document.getElementById('yearSick').textContent     = sick + ' ' + dS;
          document.getElementById('statsYearDisplay').textContent = state.year;
          const gr = document.getElementById('yearGrossRow');
          if (gr) gr.style.display = 'none';
          return;
        }

        // Van grundlohn → calcMonthBruttoFull() alapú pontos összesítő
        let totalBrutto = 0, totalOvtH = 0, totalWorkH = 0, totalVacD = 0, totalSickD = 0;
        let hasAnyData = false;
        for (let mo = 1; mo <= 12; mo++) {
          const r = calcMonthBruttoFull(state.year, mo);
          if (r !== null) {
            hasAnyData = true;
            totalBrutto += r.brutto;
            totalOvtH   += r.overtimeH;
            totalWorkH  += r.workH;
            totalVacD   += r.vacD;
            totalSickD  += r.sickD;
          }
        }

        const hS = t('hours') || 'h', dS = t('days') || 'nap';
        document.getElementById('yearHours').textContent    = totalWorkH + ' ' + hS;
        document.getElementById('yearOvertime').textContent = totalOvtH  + ' ' + hS;
        document.getElementById('yearVacation').textContent = totalVacD  + ' ' + dS;
        document.getElementById('yearSick').textContent     = totalSickD + ' ' + dS;
        document.getElementById('statsYearDisplay').textContent = state.year;

        const grossRow = document.getElementById('yearGrossRow');
        const grossEl  = document.getElementById('yearGross');
        if (grossRow && grossEl) {
          if (hasAnyData) {
            grossEl.textContent = totalBrutto.toLocaleString('de-DE',
              { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
            grossRow.style.display = '';
          } else {
            grossRow.style.display = 'none';
          }
        }
      }

      function renderVacationHistory() {
        const container = document.getElementById('vacationHistory');
        if (!container) return;

        const years = Object.keys(state.resturlaub.years)
          .sort((a, b) => b - a)
          .slice(0, 10);

        let html = '<div class="history-grid">' +
          '<div class="history-header">' +
          `<div>${t('histYear')||'Yr'}</div><div>${t('histBase')||'Base'}</div><div>${t('histCarried')||'C/O'}</div><div>${t('histTotal')||'Tot'}</div><div>${t('histUsed')||'Used'}</div><div>${t('histLeft')||'Left'}</div>` +
          '</div>';

        years.forEach(year => {
          const data = state.resturlaub.years[year];
          const total = data.base + data.carried;
          const left = total - data.used;

          html += `<div class="history-row">
            <div class="history-year">${year}</div>
            <div class="history-base">${data.base}</div>
            <div class="history-carried">${data.carried}</div>
            <div class="history-total">${total}</div>
            <div class="history-used">${data.used}</div>
            <div class="history-left">${left}</div>
          </div>`;
        });

        html += '</div>';
        container.innerHTML = html;
      }

      // ==================== PDF IMPORT UI ====================
      function pdfSetStatus(msg, type = 'info') {
        const el = document.getElementById('pdfStatus');
        el.textContent = msg;
        el.className = 'pdf-status-' + type;
        el.style.display = msg ? 'block' : 'none';
      }

      function pdfSetProgress(pct, label) {
        document.getElementById('pdfProgress').style.display = pct < 100 ? 'block' : 'none';
        document.getElementById('pdfProgressFill').style.width = pct + '%';
        document.getElementById('pdfProgressLabel').textContent = label;
      }

      // ==================== SCHICHTPLAN EXPORT ====================
      window.exportSchichtplan = function() {
        // Schichtplan export: csak a beosztás adatokat exportálja, béradatok nélkül
        const exportData = {
          _chronos_schichtplan_export: true,  // Felismerő jelölő az importhoz
          _version: APP_VERSION,
          _exported: new Date().toISOString(),
          schedules: state.schedules,
          customShifts: (state.customShifts || []).map(s => ({
            id: s.id, name: s.name, nameDe: s.nameDe, nameEn: s.nameEn, color: s.color, builtin: s.builtin,
            start: s.start, end: s.end
          }))
        };

        const json = JSON.stringify(exportData, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const now = new Date();
        const dateStr = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0');
        a.href = url;
        a.download = 'schichtplan_' + dateStr + '.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showNotification('✅ Schichtplan exportálva!');
      };

      window.openPdfImport = function(mode) {
        pdfMode = mode;
        pdfAllMonths = [];
        pdfZeusMonths = [];
        pdfExtractedText = '';
        pdfExtractedItems = [];
        pdfAllExtractedTexts = [];
        selectedFiles = [];

        document.getElementById('pdfImportTitle').textContent =
          mode === 'schichtplan' ? t('schichtplanBtn') : t('zeusBtn');

        // ── Névmező előfeltöltése a mentett névből ──
        const savedName = (state.workerName || window._obPendingName || '').trim();
        if (savedName) {
          const pdfIn = document.getElementById('pdfNameInput');
          if (pdfIn && !pdfIn.value) pdfIn.value = savedName;
          const rwIn = document.getElementById('name-search');
          if (rwIn && !rwIn.value) {
            rwIn.value = savedName;
            if (typeof window._rwRenderGroupList === 'function') window._rwRenderGroupList(savedName);
          }
          const rotIn = document.getElementById('rotNameSearch');
          if (rotIn && !rotIn.value) {
            rotIn.value = savedName;
            if (typeof window.rotRenderGroups === 'function') window.rotRenderGroups(savedName);
          }
        }

        document.getElementById('pdfFileInput').value = '';
        document.getElementById('pdfProgress').style.display = 'none';
        document.getElementById('pdfStatus').style.display = 'none';
        document.getElementById('pdfNameSection').style.display = 'none';
        document.getElementById('pdfMonthList').style.display = 'none';
        document.getElementById('pdfPreview').style.display = 'none';
        document.getElementById('pdfImportBtn').style.display = 'none';
        document.getElementById('pdfNameChips').innerHTML = '';
        document.getElementById('pdfMonthItems').innerHTML = '';
        document.getElementById('selectedFilesList').style.display = 'none';
        document.getElementById('selectedFilesList').innerHTML = '';
        // Accordion visszaállítása
        const acc = document.getElementById('pdfNamesAccordion');
        if (acc) acc.style.display = 'none';
        const arrow = document.getElementById('pdfNamesAccordionArrow');
        if (arrow) { arrow.textContent = '▼'; arrow.style.transform = 'rotate(0deg)'; }
        // Rotáció szekció visszaállítása
        const rotSec = document.getElementById('rotSection');
        if (rotSec) {
          rotSec.style.display = 'none';
          ['rotGroupSection','rotAnchorSection','rotGenSection'].forEach(id=>{
            const el=document.getElementById(id); if(el) el.style.display='none';
          });
          const rs=document.getElementById('rotStatus'); if(rs) rs.style.display='none';
          const rp=document.getElementById('rotPhaseResult'); if(rp) rp.style.display='none';
          const rb=document.getElementById('rotGenBtn'); if(rb){rb.disabled=true;rb.style.opacity='0.5';rb.textContent=t('rotImportingBtn')||'🔄 Rotáció importálása';}
          document.querySelectorAll('.rot-pill').forEach(p=>p.classList.remove('rot-active'));
        }
        // Smart rotation UI resetelése
        const smartSec = null;
        if (smartSec) smartSec.style.display = 'none';

        document.getElementById('pdfImportModal').classList.add('visible');
      };

      window.closePdfImport = function() {
        document.getElementById('pdfImportModal').classList.remove('visible');
      };

      // ==================== TÖBB FÁJL KEZELÉS ====================
      function updateSelectedFilesList() {
        const listEl = document.getElementById('selectedFilesList');
        if (selectedFiles.length === 0) {
          listEl.style.display = 'none';
          listEl.innerHTML = '';
          return;
        }

        let html = '';
        selectedFiles.forEach((file, index) => {
          const size = file.size < 1024 * 1024
            ? (file.size / 1024).toFixed(1) + ' KB'
            : (file.size / 1024 / 1024).toFixed(1) + ' MB';
          html += `
            <div class="file-item">
              <span class="file-name">${file.name}</span>
              <span class="file-size">${size}</span>
              <span class="file-remove" onclick="removeFile(${index})" title="Eltávolítás">✕</span>
            </div>
          `;
        });

        // Nincs külön "További fájlok" gomb – a feltöltő zóna már többes kijelölést támogat

        listEl.innerHTML = html;
        listEl.style.display = 'block';
      }

      window.removeFile = function(index) {
        selectedFiles.splice(index, 1);
        updateSelectedFilesList();
        if (selectedFiles.length === 0) {
          // Ha nincs több fájl, visszaállítjuk a UI-t
          document.getElementById('pdfProgress').style.display = 'none';
          document.getElementById('pdfStatus').style.display = 'none';
          document.getElementById('pdfMonthList').style.display = 'none';
          document.getElementById('pdfImportBtn').style.display = 'none';
          pdfAllMonths = [];
          pdfZeusMonths = [];
        } else {
          // Újrafeldolgozzuk a maradék fájlokat
          processAllFiles();
        }
      };

      window.addMoreFiles = function() {
        // Trigger the existing file input directly (mobile-safe)
        const inp = document.getElementById('pdfFileInput');
        if (inp) {
          inp.click();
        }
      };

      // ==================== PDF IMPORT FÜGGVÉNYEK ====================
      function initPdfUploadZone() {
        const zone = document.getElementById('pdfUploadZone');
        const inp = document.getElementById('pdfFileInput');

        zone.addEventListener('dragover', e => {
          e.preventDefault();
          zone.style.borderColor = 'var(--accent)';
        });

        zone.addEventListener('dragleave', () => {
          zone.style.borderColor = 'var(--border2)';
        });

        zone.addEventListener('drop', e => {
          e.preventDefault();
          zone.style.borderColor = 'var(--border2)';
          const files = Array.from(e.dataTransfer.files);
          files.forEach(file => {
            if (file.size <= 30 * 1024 * 1024) {
              const isDuplicate = selectedFiles.some(f => f.name === file.name && f.size === file.size);
              if (!isDuplicate) selectedFiles.push(file);
            }
          });
          updateSelectedFilesList();
          if (selectedFiles.length > 0) processAllFiles();
        });

        inp.addEventListener('change', e => {
          const files = Array.from(e.target.files || []);
          files.forEach(file => {
            if (file.size <= 30 * 1024 * 1024) {
              // Duplikátum ellenőrzés
              const isDuplicate = selectedFiles.some(f => f.name === file.name && f.size === file.size);
              if (!isDuplicate) selectedFiles.push(file);
            }
          });
          // Value reset – így újra triggelhetős ugyanazzal a fájllal is
          e.target.value = '';
          updateSelectedFilesList();
          if (selectedFiles.length > 0) processAllFiles();
        });
      }

      async function processAllFiles() {
        pdfSetProgress(5, t('processing') + '...');
        pdfSetStatus(t('pdfProcessing')||'⏳ Feldolgozás...', 'info');

        pdfAllMonths = [];
        pdfZeusMonths = [];
        pdfAllExtractedTexts = [];

        let anyError = null;
        let hasPdfSchichtplan = false;

        for (let i = 0; i < selectedFiles.length; i++) {
          const file = selectedFiles[i];
          pdfSetProgress(10 + (i / selectedFiles.length) * 80, (i + 1) + '/' + selectedFiles.length + ': ' + file.name);

          try {
            const name = file.name.toLowerCase();

            if (name.endsWith('.pdf')) {
              pdfSetStatus((t('pdfReadingFile')||'⏳ PDF feldolgozása:') + ' ' + file.name, 'info');
              await loadPdfJs();
              const modeLabel = window.pdfjsLib ? '' : ' (offline mód)';
              pdfSetStatus((t('pdfReadingMode')||'⏳ PDF olvasása') + modeLabel + ': ' + file.name, 'info');
              await extractPdfText(file);
              if (pdfMode === 'schichtplan') {
                // Store each file's text separately; process combined later
                pdfAllExtractedTexts.push(pdfExtractedText);
                // window.pdfAllExtractedTexts getter már automatikusan frissül (defineProperty)
                hasPdfSchichtplan = true;
              } else {
                processZeusText(true);
              }
            } else if (name.endsWith('.json')) {
              // Lehet CHRONOS Schichtplan export fájl
              pdfSetStatus((t('pdfReadingJson')||'⏳ JSON feldolgozása:') + ' ' + file.name, 'info');
              const text = await file.text();
              try {
                const jsonData = JSON.parse(text);
                if (jsonData._chronos_schichtplan_export === true) {
                  // Schichtplan export fájl – importáljuk a beosztásokat
                  const importedSchedules = jsonData.schedules || {};
                  const importedCustomShifts = jsonData.customShifts || [];

                  // Hónapok gyűjtése
                  const monthSet = new Set();
                  Object.keys(importedSchedules).forEach(key => {
                    const parts = key.split('-');
                    if (parts.length >= 2) {
                      monthSet.add(parts[0] + '-' + parts[1]);
                    }
                  });

                  monthSet.forEach(ym => {
                    const [y, m] = ym.split('-').map(Number);
                    const monthShifts = {};
                    Object.keys(importedSchedules).forEach(key => {
                      if (key.startsWith(ym + '-')) {
                        const day = parseInt(key.split('-')[2]);
                        monthShifts[day] = importedSchedules[key];
                      }
                    });
                    pdfAllMonths.push({
                      year: y, month: m,
                      shifts: monthShifts,
                      _isSchichtplanJson: true,
                      _customShifts: importedCustomShifts
                    });
                  });

                  if (monthSet.size > 0) {
                    pdfSetStatus((t('pdfJsonMonthsFound')||'✅ Schichtplan JSON: {n} hónap találva').replace('{n}', monthSet.size), 'success');
                  } else {
                    pdfSetStatus(t('pdfJsonNoData')||'⚠️ Schichtplan JSON: nem találtam beosztásadatokat', 'warning');
                  }
                } else {
                  pdfSetStatus((t('pdfJsonNotFormat')||'⚠️ Nem CHRONOS Schichtplan JSON:') + ' ' + file.name, 'warning');
                }
              } catch(jsonErr) {
                pdfSetStatus('❌ JSON hiba: ' + file.name, 'error');
              }
            } else if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
              pdfSetStatus((t('pdfReadingXlsx')||'⏳ XLSX betöltése:') + ' ' + file.name, 'info');
              await loadXlsx();
              await processExcelFile(file, true);
            } else if (name.endsWith('.csv') || name.endsWith('.txt')) {
              pdfSetStatus((t('pdfReadingCsv')||'⏳ CSV betöltése:') + ' ' + file.name, 'info');
              await processCsvFile(file, true);
            } else {
              pdfSetStatus((t('pdfUnknownType')||'⚠️ Ismeretlen fájltípus:') + ' ' + file.name, 'warning');
            }
          } catch (e) {
            console.warn('Error processing file (' + file.name + '):', e);
            anyError = e.message || 'Ismeretlen hiba';
            // Ne álljon meg – folytassa a többi fájllal
          }
        }

        // For Schichtplan PDFs: process all texts combined
        if (hasPdfSchichtplan && pdfMode === 'schichtplan') {
          // Combine all texts with page separator so month detection still works per-file
          // But for name detection, use names found across all files
          if (pdfAllExtractedTexts.length === 1) {
            pdfExtractedText = pdfAllExtractedTexts[0];
            processSchichtplanText(false);
          } else {
            // Multiple PDF files: collect names from all, then search across all texts
            const allNames = new Set();
            pdfAllExtractedTexts.forEach(txt => {
              pdfExtractedText = txt;
              const names = pdfDetectNames(txt);
              names.forEach(n => allNames.add(n));
            });

            if (allNames.size > 0) {
              // Show name picker; pdfExtractedText will be searched across all files
              // Store a combined text map for name search
              pdfExtractedText = pdfAllExtractedTexts.join('\n\n--- NEXT FILE ---\n\n');

              document.getElementById('pdfNameSection').style.display = 'block';
              const chips = document.getElementById('pdfNameChips');
              chips.innerHTML = '';

              const sortedNames = Array.from(allNames).sort();
              sortedNames.forEach(name => {
                const ch = document.createElement('div');
                ch.className = 'pdf-chip';
                ch.textContent = name;
                ch.onclick = () => {
                  // Teljes nevet normalizálva beírjuk (pl. "Takacs, Zoltan" → "Takacs Zoltan")
                  const fullName = name.replace(/,\s*/g, ' ').trim();
                  document.getElementById('pdfNameInput').value = fullName;
                  const arrow = document.getElementById('pdfNamesAccordionArrow');
                  if (arrow) { arrow.textContent = '▶'; arrow.style.transform = 'rotate(0deg)'; }
                  pdfSearchName();
                };
                chips.appendChild(ch);
              });

              const accordion = document.getElementById('pdfNamesAccordion');
              if (accordion) {
                accordion.style.display = 'block';
                const label = document.getElementById('pdfNamesAccordionLabel');
                if (label) label.textContent = `👥 ${sortedNames.length} ${t('namesFound') || 'names found'}`;
              }

              pdfAllMonths = [{ _nameSearchPending: true, year: new Date().getFullYear(), month: new Date().getMonth() + 1, shifts: [] }];
              pdfSetStatus(`✅ ${sortedNames.length} ${t('namesFound')}`, 'success');
              pdfSetProgress(100, '');
              return;
            } else {
              // No names found, process each file individually
              pdfAllMonths = [];
              pdfAllExtractedTexts.forEach(txt => {
                pdfExtractedText = txt;
                processSchichtplanText(true);
              });
            }
          }
        }

        pdfSetProgress(100, '');

        // ── Rotáció elemzés (ha van Schichtplan PDF szöveg) ──
        if (pdfAllExtractedTexts.length > 0 && typeof window.rotAnalyzePdfTexts === 'function') {
          try {
            const textObjs = pdfAllExtractedTexts.map((txt, i) => ({
              text: txt,
              fileName: selectedFiles.filter(f=>f.name.toLowerCase().endsWith('.pdf'))[i]?.name || ('file'+i+'.pdf')
            }));
            window.rotAnalyzePdfTexts(textObjs);
            // ── Automatikus átküldés a rotation widget DB-be is ──
            if (typeof window.rwFeedPdfTexts === 'function') {
              window.rwFeedPdfTexts(textObjs);
            }
          } catch(e) { /* rotáció hiba ne törje az importot */ }
        }

        const realMonths = pdfAllMonths.filter(m => !m._nameSearchPending);
        const zeusCount = pdfZeusMonths.length;
        const schichtCount = realMonths.length;

        if (zeusCount > 0 || schichtCount > 0) {
          renderPdfMonthList(pdfMode === 'zeus' ? pdfZeusMonths : realMonths, pdfMode);
          const count = pdfMode === 'zeus' ? zeusCount : schichtCount;
          pdfSetStatus('✅ ' + count + ' ' + (t('monthsProcessed') || 'hónap feldolgozva'), 'success');
        } else if (anyError) {
          pdfSetStatus('❌ ' + anyError, 'error');
        } else if (!pdfAllMonths.some(m => m._nameSearchPending)) {
          pdfSetStatus('❌ ' + (t('noDataFound') || 'Nem találhatók adatok a fájlban'), 'error');
        }
      }

      // ── BEÁGYAZOTT PDF SZÖVEG-KINYERŐ (CDN nélkül, offline is működik) ──
      // Lightweight pure-JS megközelítés: a PDF bináris struktúrájából kinyeri a szöveget
      // BT...ET blokkokból, (text) Tj / [(text)] TJ operátorokból
      function extractPdfTextInline(arrayBuffer) {
        const bytes = new Uint8Array(arrayBuffer);
        // Convert to latin1 string for regex parsing
        let raw = '';
        for (let i = 0; i < bytes.length; i++) {
          raw += String.fromCharCode(bytes[i]);
        }

        let allText = '';

        // Strategy 1: Extract text from BT...ET blocks (standard PDF text blocks)
        const btBlocks = raw.match(/BT[\s\S]*?ET/g) || [];
        for (const block of btBlocks) {
          // Tj operator: (text)Tj or (text) Tj
          const tjMatches = block.match(/\(([^)]*)\)\s*Tj/g) || [];
          for (const m of tjMatches) {
            const inner = m.match(/\(([^)]*)\)/);
            if (inner) allText += decodePdfString(inner[1]) + ' ';
          }
          // TJ operator: [(text) offset (text)] TJ
          const tjArrMatches = block.match(/\[([^\]]*)\]\s*TJ/g) || [];
          for (const m of tjArrMatches) {
            const parts = m.match(/\(([^)]*)\)/g) || [];
            for (const p of parts) {
              const inner = p.slice(1, -1);
              allText += decodePdfString(inner);
            }
            allText += ' ';
          }
          // New line markers - add newline after Td/TD/T*/Tm
          if (/\bT[dDm*]\b/.test(block)) allText += '\n';
        }

        // Strategy 2: If strategy 1 yielded little, try stream-level text extraction
        if (allText.trim().length < 50) {
          // Try to find text in compressed/uncompressed streams
          // Look for readable ASCII sequences (works for uncompressed streams)
          const streamMatch = raw.match(/stream([\s\S]*?)endstream/g) || [];
          for (const s of streamMatch) {
            // Extract readable text patterns from stream
            const readable = s.replace(/[^\x20-\x7E\n]/g, ' ');
            // Find (text) patterns
            const found = readable.match(/\(([A-Za-z0-9äöüáéíóúőűÄÖÜÁÉÍÓÚŐŰß ,.\-:\/]+)\)/g) || [];
            for (const f of found) {
              const inner = f.slice(1, -1).trim();
              if (inner.length > 1) allText += inner + ' ';
            }
          }
        }

        return allText;
      }

      function decodePdfString(s) {
        // Handle PDF escape sequences and common encodings
        return s
          .replace(/\\n/g, '\n')
          .replace(/\\r/g, '\r')
          .replace(/\\t/g, '\t')
          .replace(/\\\(/g, '(')
          .replace(/\\\)/g, ')')
          .replace(/\\\\/g, '\\')
          // WinAnsi common chars
          .replace(/\xc4/g, 'Ä').replace(/\xe4/g, 'ä')
          .replace(/\xd6/g, 'Ö').replace(/\xf6/g, 'ö')
          .replace(/\xdc/g, 'Ü').replace(/\xfc/g, 'ü')
          .replace(/\xdf/g, 'ß')
          .replace(/\xc1/g, 'Á').replace(/\xe1/g, 'á')
          .replace(/\xc9/g, 'É').replace(/\xe9/g, 'é')
          .replace(/\xcd/g, 'Í').replace(/\xed/g, 'í')
          .replace(/\xd3/g, 'Ó').replace(/\xf3/g, 'ó')
          .replace(/\xfa/g, 'ú').replace(/\xda/g, 'Ú')
          .replace(/\x91/g, 'ő').replace(/\x92/g, 'Ő')
          .replace(/\x96/g, 'ű').replace(/\x97/g, 'Ű');
      }

      // ── KÖNYVTÁR BETÖLTÉS ──
      // PDF.js CDN-ről töltődik be ha elérhető. Ha nem, inline fallback használatos.

      function loadScriptFromUrl(url) {
        return new Promise(function(resolve, reject) {
          // Ha már betöltődött
          if (url.includes('pdf') && window.pdfjsLib) { resolve(); return; }
          if (url.includes('xlsx') && window.XLSX) { resolve(); return; }

          // Timeout: ha 8 mp alatt nem töltődik be, feladjuk (offline/WebView)
          const timeout = setTimeout(function() {
            reject(new Error('TIMEOUT'));
          }, 8000);

          var s = document.createElement('script');
          s.src = url;
          s.crossOrigin = 'anonymous';
          s.onload = function() { clearTimeout(timeout); resolve(); };
          s.onerror = function() {
            clearTimeout(timeout);
            reject(new Error('LOAD_ERROR'));
          };
          document.head.appendChild(s);
        });
      }

      async function loadPdfJs() {
        if (pdfLibLoaded) return;
        try {
          await loadScriptFromUrl(PDFJS_CDN);
          if (window.pdfjsLib) {
            // Worker CDN URL beállítása – ez a megbízható módszer
            // Ha a worker URL nem töltődik be, a getDocument disableWorker:true opcióval fut
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
            pdfLibLoaded = true;
          }
        } catch(e) {
          console.info('[CHRONOS] PDF.js CDN nem elérhető, inline parser aktív');
          pdfLibLoaded = false;
        }
      }

      async function loadXlsx() {
        if (xlsxLibLoaded || window.XLSX) { xlsxLibLoaded = true; return; }
        await loadScriptFromUrl(XLSX_CDN);
        if (!window.XLSX) throw new Error('XLSX könyvtár nem töltődött be');
        xlsxLibLoaded = true;
      }

      async function extractPdfText(file) {
        const buf = await file.arrayBuffer();

        // Ha PDF.js betöltve: teljes minőségű kinyerés
        if (window.pdfjsLib) {
          // disableWorker:true = fő szálon fut, nincs worker hiba (content:// kompatibilis)
          const loadingTask = window.pdfjsLib.getDocument({ data: buf, disableWorker: true });
          const pdf = await loadingTask.promise;
          let allText = '', allItems = [];

          for (let p = 1; p <= pdf.numPages; p++) {
            const page = await pdf.getPage(p);
            const content = await page.getTextContent();

            for (const item of content.items) {
              if (item.str && item.str.trim()) {
                allItems.push({
                  str: item.str,
                  x: Math.round(item.transform[4]),
                  y: Math.round(item.transform[5]),
                  page: p
                });
              }
            }

            const sorted = [...content.items].sort((a, b) => {
              const dy = b.transform[5] - a.transform[5];
              return Math.abs(dy) > 5 ? dy : a.transform[4] - b.transform[4];
            });

            let lastY = null;
            for (const item of sorted) {
              if (!item.str || !item.str.trim()) continue;
              if (lastY !== null && Math.abs(item.transform[5] - lastY) > 5) allText += '\n';
              allText += item.str + ' ';
              lastY = item.transform[5];
            }
            allText += '\n';
          }

          pdfExtractedText = allText;
          pdfExtractedItems = allItems;
        } else {
          // Inline fallback: CDN nélküli pure-JS parser (offline/WebView kompatibilis)
          pdfExtractedText = extractPdfTextInline(buf);
          pdfExtractedItems = [];
        }
      }

      // ==================== EXCEL/CSV FELDOLGOZÁS (v2 widget logika) ====================

      // Kódolásjavítás – pontosan a v2-ből
      function spwFixEncoding(text) {
        if (!text) return '';
        let s = text.toString();
        // Hungarian + German special chars (including ä for Spät/Früh)
        [['Ã¤','ä'],['Ã¡','á'],['Ã©','é'],['Ã­','í'],['Ã³','ó'],['Ã¶','ö'],['Å\'','ő'],['Ãº','ú'],['Ã¼','ü'],['Å±','ű'],['Ã¼','ü'],['Ã\x9f','ß']].forEach(([w,c]) => {
          s = s.replace(new RegExp(w, 'g'), c);
        });
        return s;
      }

      // Szövegből kód – pontosan a v2-ből (F/S/N/URL/V/X-et ad)
      function spwCodeFromLabel(raw) {
        if (!raw) return 'X';
        const lower = raw.toString().toLowerCase().replace(/[äöüáéíóúőű]/g,
          c => ({'ä':'a','ö':'o','ü':'u','á':'a','é':'e','í':'i','ó':'o','ú':'u','ő':'o','ű':'u'})[c] || c);
        // Freiwillig előbb (tartalmaz f/s/n betűket)
        if (lower.includes('freiwillig') || lower.startsWith('fw')) {
          if (lower.includes('spat') || lower.endsWith('s')) return 'FS';
          if (lower.includes('nacht') || lower.endsWith('n')) return 'FN';
          return 'FF';
        }
        if (lower.startsWith('feiertag') || lower.startsWith('fei')) {
          if (lower.includes('spat') || lower.endsWith('s')) return 'FEI_S';
          if (lower.includes('nacht') || lower.endsWith('n')) return 'FEI_N';
          return 'FEI_F';
        }
        if (lower.includes('urlaub') || lower === 'url' || lower === 'u') return 'URL';
        if (lower === 'k' || lower.includes('krank')) return 'K';
        if (lower === 'x' || lower === 'frei' || lower === '-') return 'X';
        // Dupla kódok
        if (lower === 'ff' || lower === 'fwf') return 'FF';
        if (lower === 'fs' || lower === 'fws') return 'FS';
        if (lower === 'fn' || lower === 'fwn') return 'FN';
        // Früh – f, fr, fru, fruh + bármilyen fruh-val kezdődő
        if (lower === 'f' || lower === 'fr' || lower === 'fru' || lower.startsWith('fruh')) return 'F';
        // Spät – s, sp, spa, spat + bármilyen spat-tal kezdődő
        if (lower === 's' || lower === 'sp' || lower === 'spa' || lower.startsWith('spat')) return 'S';
        // Nacht – n, na + bármilyen nacht-tal kezdődő
        if (lower === 'n' || lower === 'na' || lower.startsWith('nacht')) return 'N';
        return raw.trim();
      }

      // v2 kód → Chronos műszak ID
      function spwCodeToChronosId(code) {
        if (!code) return null;
        const map = {
          'F': 'Früh', 'S': 'Spät', 'N': 'Nacht',
          'URL': 'Urlaub', 'U': 'Urlaub', 'K': 'Krank',
          'FF': 'Freiwillig Früh', 'FS': 'Freiwillig Spät', 'FN': 'Freiwillig Nacht',
          'FEI_F': 'Fei Fr', 'FEI_S': 'Fei Sp', 'FEI_N': 'Fei Na',
          'V': 'Freiwillig Früh', 'X': null
        };
        if (code in map) return map[code];
        if (typeof code === 'string' && code.includes('+')) {
          return code.split('+').map(c => map[c] || null).filter(Boolean).join('+') || null;
        }
        return null;
      }

      async function processExcelFile(file, append = false) {
        const data = await file.arrayBuffer();
        const wb = window.XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = window.XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });

        // Fejléc sor keresése – pontosan a v2 logikája
        let headerRow = 0;
        for (let i = 0; i < Math.min(10, rows.length); i++) {
          const f = rows[i][0] ? rows[i][0].toString().toLowerCase() : '';
          if (f.includes('dátum') || f.includes('datum') || f.includes('date')) { headerRow = i; break; }
        }

        const monthMap = new Map();
        for (let i = headerRow + 1; i < rows.length; i++) {
          const row = rows[i];
          if (!row || row.length < 3) continue;
          const dateStr = spwFixEncoding(row[0] || '').trim();
          const muszakRaw = spwFixEncoding(row[2] || '').trim();
          if (!dateStr || !muszakRaw) continue;
          const parts = dateStr.split('.');
          if (parts.length < 3) continue;
          const ev = parseInt(parts[0]), ho = parseInt(parts[1]), nap = parseInt(parts[2]);
          if (!ev || !ho || !nap) continue;
          const key = `${ev}-${ho}`;
          if (!monthMap.has(key)) monthMap.set(key, { year: ev, month: ho, shifts: new Array(31).fill(null) });
          // Kód konverzió: v2 kód → Chronos ID
          const codes = muszakRaw.split('+').map(spwCodeFromLabel);
          const chronosId = codes.length === 1 ? spwCodeToChronosId(codes[0]) : codes.map(spwCodeToChronosId).filter(Boolean).join('+') || null;
          if (chronosId) monthMap.get(key).shifts[nap - 1] = chronosId;
        }

        const newMonths = Array.from(monthMap.values()).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
        if (append) pdfAllMonths = [...pdfAllMonths, ...newMonths];
        else pdfAllMonths = newMonths;
      }

      async function processCsvFile(file, append = false) {
        const text = await file.text();
        const monthMap = new Map();
        // Pontosan a v2 CSV logikája
        for (const line of text.split('\n').slice(1)) {
          if (!line.trim()) continue;
          const vals = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
          if (vals.length < 3) continue;
          const dateStr = vals[0].replace(/"/g, '').trim();
          const muszakRaw = vals[2].replace(/"/g, '').trim();
          const parts = dateStr.split('.');
          if (parts.length < 3) continue;
          const ev = parseInt(parts[0]), ho = parseInt(parts[1]), nap = parseInt(parts[2]);
          if (!ev || !ho || !nap) continue;
          const key = `${ev}-${ho}`;
          if (!monthMap.has(key)) monthMap.set(key, { year: ev, month: ho, shifts: new Array(31).fill(null) });
          const codes = muszakRaw.split('+').map(spwCodeFromLabel);
          const chronosId = codes.length === 1 ? spwCodeToChronosId(codes[0]) : codes.map(spwCodeToChronosId).filter(Boolean).join('+') || null;
          if (chronosId) monthMap.get(key).shifts[nap - 1] = chronosId;
        }
        const newMonths = Array.from(monthMap.values()).sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
        if (append) pdfAllMonths = [...pdfAllMonths, ...newMonths];
        else pdfAllMonths = newMonths;
      }

      // ==================== SCHICHTPLAN SZÖVEG FELDOLGOZÁS ====================
      // Hónap/év detektálás – pontosan a v2 widget _detectMonthYear logikája
      function pdfDetectMonthYear(text) {
        // ── 0. Legmegbízhatóbb: fejléc dátumtartomány DD.MM.YY formátumban ──
        // pl. "So 01.02.26 - Sa 28.02.26" vagy "So 01.03.26 - Di 31.03.26"
        const headerRange = text.match(/\b\d{1,2}\.(0?[1-9]|1[0-2])\.(\d{2})\s*[-–]\s*\w+\s+\d{1,2}\.(0?[1-9]|1[0-2])\.(\d{2})\b/);
        if (headerRange) {
          const mo = parseInt(headerRange[1]);
          const yr = 2000 + parseInt(headerRange[2]);
          if (yr >= 2020 && yr <= 2040) return { month: mo, year: yr };
        }

        // ── 0b. Fejléc: DD.MM.YYYY tartomány ──
        const headerRange2 = text.match(/\b\d{1,2}\.(0?[1-9]|1[0-2])\.(20\d{2})\s*[-–]/);
        if (headerRange2) {
          return { month: parseInt(headerRange2[1]), year: parseInt(headerRange2[2]) };
        }

        // ── 1. Hónapnév + évszám (pl. "März 2026", "Jänner 2025") ──
        const m1 = text.match(/([A-Za-z\u00C0-\u024F]+)\s+(202\d)/);
        if (m1) {
          const mn = PDF_MONTH_MAP[m1[1].toLowerCase()] ||
                     PDF_MONTH_MAP[m1[1].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')];
          if (mn > 0) return { month: mn, year: parseInt(m1[2]) };
        }

        // ── 2. Numerikus: MM.YYYY (de NEM DD.MM.YYYY ahol DD=01-31!) ──
        // Kizárjuk a nap.hónap.yyyy mintát (ahol az előző token egy napszám)
        const m2a = text.match(/(?<!\d\d\.)\b(0?[1-9]|1[0-2])\.(202\d)\b/);
        if (m2a) return { month: parseInt(m2a[1]), year: parseInt(m2a[2]) };

        const m2b = text.match(/\b(202\d)[\/\.\-](0?[1-9]|1[0-2])\b/);
        if (m2b) return { month: parseInt(m2b[2]), year: parseInt(m2b[1]) };

        // ── 3. Minden szóból hónapnév keresés ──
        let foundMonth = 0;
        for (const w of text.split(/\s+/)) {
          const cleaned = w.toLowerCase().replace(/[^a-z\u00E0-\u024F]/g, '');
          const cleanedNFD = cleaned.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
          const mn = PDF_MONTH_MAP[cleaned] || PDF_MONTH_MAP[cleanedNFD];
          if (mn) { foundMonth = mn; break; }
        }
        const ym = text.match(/\b(202\d)\b/);
        const foundYear = ym ? parseInt(ym[1]) : new Date().getFullYear();
        if (foundMonth > 0) return { month: foundMonth, year: foundYear };

        // ── 4. DD.MM.YYYY dátumokból majority vote ──
        const allDates = [...text.matchAll(/\b(\d{1,2})\.(0?[1-9]|1[0-2])\.(20\d{2})\b/g)];
        if (allDates.length > 0) {
          const votes = {};
          allDates.forEach(m => {
            const mo = parseInt(m[2]), yr = parseInt(m[3]);
            const k = `${yr}-${mo}`;
            votes[k] = (votes[k] || 0) + 1;
          });
          const best = Object.entries(votes).sort((a, b) => b[1] - a[1])[0][0];
          const [yr, mo] = best.split('-').map(Number);
          return { month: mo, year: yr };
        }

        // ── 4b. DD.MM.YY majority vote ──
        const allDates2 = [...text.matchAll(/\b(\d{1,2})\.(0?[1-9]|1[0-2])\.(\d{2})\b/g)];
        if (allDates2.length > 0) {
          const votes2 = {};
          allDates2.forEach(m => {
            const mo = parseInt(m[2]), yr = 2000 + parseInt(m[3]);
            if (yr >= 2020 && yr <= 2040) {
              const k = `${yr}-${mo}`;
              votes2[k] = (votes2[k] || 0) + 1;
            }
          });
          const entries2 = Object.entries(votes2);
          if (entries2.length > 0) {
            const best2 = entries2.sort((a, b) => b[1] - a[1])[0][0];
            const [yr2, mo2] = best2.split('-').map(Number);
            return { month: mo2, year: yr2 };
          }
        }

        // ── 5. Utolsó esély ──
        if (foundYear) return { month: new Date().getMonth() + 1, year: foundYear };
        return { month: new Date().getMonth() + 1, year: new Date().getFullYear() };
      }

      function pdfDetectNames(text) {
        const found = new Set();
        for (const line of text.split('\n')) {
          // 1. S-I token előtti névkinyerés
          const siIdx = line.indexOf('S-I');
          if (siIdx > 0) {
            const header = line.substring(0, siIdx).trim();
            // Csoportszám + részleg levágása: "210 - GL Bereich 2 Takacs Zoltan" -> "Takacs Zoltan"
            const afterDash = header.replace(/^[\d]+(?:[.\-][\d]+)*\s*[-–]\s*/, '');
            // A név az utolsó 1-3 nagybetűs szó (opcionálisan vesszővel elválasztva)
            // Vesszős forma: "Stuwe, Florian"
            const commaMatch = afterDash.match(/([A-ZÄÖÜ][a-zA-Z\u00C0-\u024F\-]+(?:\s+[A-ZÄÖÜ][a-zA-Z\u00C0-\u024F\-]+)*),\s*([A-ZÄÖÜ][a-zA-Z\u00C0-\u024F\-]+(?:-[A-ZÄÖÜ][a-zA-Z\u00C0-\u024F\-]+)*)\s*$/);
            if (commaMatch) {
              found.add((commaMatch[1] + ', ' + commaMatch[2]).trim());
              continue;
            }
            // Szóköz alapú forma: utolsó 2+ nagybetűs szó = "Takacs Zoltan"
            const words = afterDash.split(/\s+/).filter(Boolean);
            const nameWords = [];
            for (let wi = words.length - 1; wi >= 0; wi--) {
              if (/^[A-ZÄÖÜ][a-zA-Z\u00C0-\u024F\-]+$/.test(words[wi])) {
                nameWords.unshift(words[wi]);
              } else break;
            }
            if (nameWords.length >= 2) {
              found.add(nameWords.join(' '));
              continue;
            }
          }
          // 2. Fallback: hagyományos "Csn, Kn" regex (bármely sorban)
          const m = line.match(/([A-ZÄÖÜ][a-zA-Z\u00C0-\u024F]+),\s*([A-ZÄÖÜ][a-zA-Z\u00C0-\u024F]+(?:-[A-ZÄÖÜ][a-zA-Z\u00C0-\u024F]+)*)/g);
          if (m) m.forEach(n => found.add(n.trim()));
        }
        return [...found].sort((a, b) => a.localeCompare(b));
      }

      // Egységes névnormalizáló: kisbetű, ékezet nélkül, vessző/pont → szóköz
      function nameNorm(s) {
        return (s||'').toLowerCase()
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
          .replace(/[,.;\-]/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();
      }
      // Globálisan elérhetővé tesszük a rotation widget számára is
      function pdfFuzzyMatch(queryRaw, targetRaw) {
        const q = nameNorm(queryRaw);
        const t = nameNorm(targetRaw);

        // 1. Összes query-szó megvan a célsorban (eredeti sorrend)
        const qParts = q.split(' ').filter(Boolean);
        // Ha a query legalább 2 szóból áll, mindkét szónak meg kell lennie
        if (qParts.length >= 2 && qParts.every(w => t.includes(w))) return true;

        // 2. Egyszavas keresés: csak pontos szóhatár egyezés (pl. "Stuwe" ne egyezzen "Stuweflora"-val)
        if (qParts.length === 1) {
          const word = qParts[0];
          if (word.length < 3) return false;
          // Szóhatárral ellenőrzünk
          const wordRegex = new RegExp('(?:^|\\s)' + word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:\\s|,|$)');
          if (wordRegex.test(t)) return true;
        }

        // 3. Fordított sorrend: pl. "Zoltan Takacs" is megtalálja
        if (qParts.length >= 2) {
          const qRev = qParts.slice().reverse();
          if (qRev.every(w => t.includes(w))) return true;
        }

        // 4. A célsor nevei megvannak a queryban (fordított keresés) – csak ha elég specifikus
        const tParts = t.split(' ').filter(Boolean).filter(w => w.length > 3);
        if (tParts.length >= 2 && tParts.every(w => q.includes(w))) return true;

        return false;
      }
      function spShiftToId(code) {
        if (!code) return null;
        
        const map = {
          'F': 'Früh',
          'S': 'Spät',
          'N': 'Nacht',
          'URL': 'Urlaub',
          'U': 'Urlaub',
          'K': 'Krank',
          'V': 'Freiwillig Früh',
          'FF': 'Freiwillig Früh',
          'FS': 'Freiwillig Spät',
          'FN': 'Freiwillig Nacht',
          'FWF': 'Freiwillig Früh',
          'FWS': 'Freiwillig Spät',
          'FWN': 'Freiwillig Nacht',
          'FEI F': 'Fei Fr',
          'FEI S': 'Fei Sp',
          'FEI N': 'Fei Na',
          'X': null,
          'FREI': null
        };
        
        const up = code.toString().toUpperCase().trim();
        
        // Közvetlen egyezés
        if (map.hasOwnProperty(up)) {
          return map[up];
        }
        
        // Tartalmazás alapján
        if (up.includes('FRÜH') || up.includes('FRUH') || up === 'F') {
          if (up.includes('FREIWILLIG') || up.includes('FW')) return 'Freiwillig Früh';
          if (up.includes('FEI') || up.includes('FEIERTAG')) return 'Fei Fr';
          return 'Früh';
        }
        
        if (up.includes('SPÄT') || up.includes('SPAT') || up === 'S') {
          if (up.includes('FREIWILLIG') || up.includes('FW')) return 'Freiwillig Spät';
          if (up.includes('FEI') || up.includes('FEIERTAG')) return 'Fei Sp';
          return 'Spät';
        }
        
        if (up.includes('NACHT') || up === 'N') {
          if (up.includes('FREIWILLIG') || up.includes('FW')) return 'Freiwillig Nacht';
          if (up.includes('FEI') || up.includes('FEIERTAG')) return 'Fei Na';
          return 'Nacht';
        }
        
        if (up.includes('URLAUB') || up.includes('URL') || up === 'U') return 'Urlaub';
        if (up.includes('KRANK') || up === 'KRA' || up === 'KR' || up === 'K') return 'Krank';
        if (up === 'EZ' || up.includes('ELTERNZEIT')) return null; // Elternzeit – kihagyás
        if (up.includes('FREI') || up === 'X') return null;
        
        return code;
      }

      // ---------------------------------------------------------------
      // SCHICHTPLAN TOKEN FELISMERŐ
      // Maximálisan befogadó – a névsor utáni kontextusban a Fr=Früh,
      // nem Freitag. Visszatér: CHRONOS ID / null (szabad) / undefined (kihagyás)
      // ---------------------------------------------------------------
      // ── v2 token → Chronos ID (javított, Früh/Spät/Nacht egyaránt felismeri) ──
      function tokenToShiftId(tok) {
        const raw = tok.replace(/[.,;:!?()\[\]{}'"`]/g, '').trim();
        if (!raw || /^\d+$/.test(raw)) return undefined; // szám → kihagyás

        // Ékezet levétel + kisbetűsítés
        const lower = raw.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const u = lower; // használjuk kisbetűsen

        // ── Freiwillig – ELŐBB (tartalmaz F/S/N-t) ──
        if (u === 'ff' || u === 'fwf') return 'Freiwillig Früh';
        if (u === 'fs' || u === 'fws') return 'Freiwillig Spät';
        if (u === 'fn' || u === 'fwn') return 'Freiwillig Nacht';
        if (u.startsWith('freiwillig')) {
          if (u.endsWith('s') || u.includes('spat')) return 'Freiwillig Spät';
          if (u.endsWith('n') || u.includes('nacht')) return 'Freiwillig Nacht';
          return 'Freiwillig Früh';
        }
        if (u.startsWith('fw') && u.length > 2) {
          if (u.includes('s')) return 'Freiwillig Spät';
          if (u.includes('n')) return 'Freiwillig Nacht';
          return 'Freiwillig Früh';
        }

        // ── Ünnepnapi ──
        if (u.startsWith('feiertag') || u === 'fei') {
          if (u.includes('spat') || u.endsWith('s')) return 'Fei Sp';
          if (u.includes('nacht') || u.endsWith('n')) return 'Fei Na';
          return 'Fei Fr';
        }

        // ── Urlaub / Krank / EZ / Szabad ──
        if (u === 'url' || u === 'ur' || u.startsWith('urlaub')) return 'Urlaub';
        if (u === 'u') return 'Urlaub';
        if (u === 'k' || u === 'kr' || u === 'kra' || u === 'krank' || u.startsWith('krank')) return 'Krank';
        if (u === 'ez' || u === 'elternzeit' || u === 'eltern') return null; // Elternzeit – nem fizetett, kihagyás
        if (u === 'x' || u === 'frei') return null;
        if (u === '-' || u === '--') return undefined; // kötőjel az elválasztójel (pl. "234 - GL"), nem szabad nap

        // ── FRÜH – összes ismert forma ──
        if (u === 'f' || u === 'fr' || u === 'fru' || u === 'fruh' ||
            u === 'fruhschicht' || u === 'fruhsch' || u === 'frs') return 'Früh';
        if (u.startsWith('fruh')) return 'Früh';

        // ── SPÄT – összes ismert forma ──
        if (u === 's' || u === 'sp' || u === 'spa' || u === 'spat' ||
            u === 'spatschicht' || u === 'spatsch' || u === 'sps') return 'Spät';
        if (u.startsWith('spat')) return 'Spät';

        // ── NACHT – összes ismert forma ──
        if (u === 'n' || u === 'na' || u === 'nacht' ||
            u === 'nachtschicht' || u === 'nachtsch' || u === 'nas') return 'Nacht';
        if (u.startsWith('nacht')) return 'Nacht';

        // ── Minden más → kihagyás ──
        return undefined;
      }

      // ---------------------------------------------------------------
      // Műszakok kinyerése a névsor utáni sorokból
      // Standalone findShifts() portja – nincs DAY_ABBR szűrő,
      // a tokenToShiftId kihagyja a naprövidítéseket.
      // DEBUG: az első 8 sor tokeneit és eredményeit logolja.
      // ---------------------------------------------------------------
      function pdfExtractShiftsAfterLine(lines, workerLine, daysInMonth) {
        const shifts = [];
        let collected = 0;

        // ── 1. SAJÁT SOR: a névsor tokeneit is megvizsgáljuk ──
        // Sok Schichtplan-ban: "Mustermann, Max  F  S  N  X  F ..."
        // A névkereső megtalálja a sort, de a műszakok a sor jobb felén vannak.
        {
          const tokens = lines[workerLine].split(/\s+/).filter(Boolean);
          let pastName = false;
          for (const tok of tokens) {
            if (!pastName) {
              // Amíg vesszős vagy egybetűs nagybetűs token jön, az a név
              const id = tokenToShiftId(tok);
              if (id !== undefined) {
                pastName = true;
                shifts.push(id);
                collected++;
              }
            } else {
              const id = tokenToShiftId(tok);
              if (id !== undefined) {
                shifts.push(id);
                collected++;
              }
            }
            if (collected >= daysInMonth) break;
          }
        }

        // ── 2. KÖVETKEZŐ SOROK: ha saját soron nem volt elég ──
        let i = workerLine + 1;
        while (i < lines.length && collected < daysInMonth) {
          const line = lines[i];

          // Következő dolgozó nevénél megállunk
          if (/^[A-ZÄÖÜ][a-zäöüß]+(,\s*[A-ZÄÖÜ]|\s+[A-ZÄÖÜ][a-zäöüß])/.test(line)) {
            break;
          }

          const tokens = line.split(/\s+/).filter(Boolean);
          for (const tok of tokens) {
            const id = tokenToShiftId(tok);
            if (id !== undefined) {
              shifts.push(id);
              collected++;
              if (collected >= daysInMonth) break;
            }
          }
          i++;
        }

        if (shifts.length === 0) {
          // Fallback: supershift elemzés
          const fullText = lines.join('\n');
          const { month, year } = pdfDetectMonthYear(fullText);
          return pdfParseSupershiftText(fullText, month, year);
        }

        while (shifts.length < daysInMonth) shifts.push(null);
        return shifts.slice(0, daysInMonth);
      }

      function pdfParseSupershiftText(text, month, year) {
        const lines = text.split('\n');
        const dayMap = {};

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].toLowerCase();

          const weekMatch = line.match(/(?:kw|woche|week|hét)\s*(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})\s+(\d{1,2})/i);

          if (weekMatch && i + 1 < lines.length) {
            const dates = [
              parseInt(weekMatch[2]), parseInt(weekMatch[3]), parseInt(weekMatch[4]),
              parseInt(weekMatch[5]), parseInt(weekMatch[6]), parseInt(weekMatch[7]), parseInt(weekMatch[8])
            ];
            
            const nextLine = lines[i + 1].toLowerCase();
            const shiftParts = nextLine.split(/\s+/);

            dates.forEach((d, j) => {
              if (d >= 1 && d <= 31) {
                const shiftWord = shiftParts[j + 1] || shiftParts[j] || '';
                
                if (shiftWord.includes('früh') || shiftWord.includes('fruh')) {
                  dayMap[d] = 'F';
                } else if (shiftWord.includes('spät') || shiftWord.includes('spat')) {
                  dayMap[d] = 'S';
                } else if (shiftWord.includes('nacht')) {
                  dayMap[d] = 'N';
                } else if (shiftWord.includes('url') || shiftWord.includes('urlaub')) {
                  dayMap[d] = 'URL';
                } else if (shiftWord.includes('freiwillig') || shiftWord.includes('fw')) {
                  if (shiftWord.includes('früh') || shiftWord.includes('f')) {
                    dayMap[d] = 'FF';
                  } else if (shiftWord.includes('spät') || shiftWord.includes('s')) {
                    dayMap[d] = 'FS';
                  } else if (shiftWord.includes('nacht') || shiftWord.includes('n')) {
                    dayMap[d] = 'FN';
                  } else {
                    dayMap[d] = 'V';
                  }
                } else {
                  dayMap[d] = 'X';
                }
              }
            });
          }

          const numbers = line.match(/\b(\d{1,2})\b/g) || [];
          for (const num of numbers) {
            const n = parseInt(num);
            if (n >= 1 && n <= 31 && !dayMap[n]) {
              if (line.includes('früh') || line.includes('fruh')) {
                dayMap[n] = 'F';
              } else if (line.includes('spät') || line.includes('spat')) {
                dayMap[n] = 'S';
              } else if (line.includes('nacht')) {
                dayMap[n] = 'N';
              } else if (line.includes('url') || line.includes('urlaub')) {
                dayMap[n] = 'URL';
              } else if (line.includes('freiwillig')) {
                dayMap[n] = 'V';
              }
            }
          }
        }

        const daysInMonth = month > 0 ? new Date(year, month, 0).getDate() : 31;
        const shifts = [];

        for (let d = 1; d <= daysInMonth; d++) {
          shifts.push(spShiftToId(dayMap[d] || 'X'));
        }

        return shifts;
      }

      function processSchichtplanText(append = false) {
        const { month, year } = pdfDetectMonthYear(pdfExtractedText);
        const text = pdfExtractedText;
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

        const names = pdfDetectNames(text);

        // Ha több dolgozó neve van → mindig névkereső
        if (names.length >= 1) {
          document.getElementById('pdfNameSection').style.display = 'block';
          const chips = document.getElementById('pdfNameChips');
          chips.innerHTML = '';

          // Betűrendbe rendezés (már rendezve jön pdfDetectNames-ből, de biztosra)
          const sortedNames = names;

          sortedNames.forEach(name => {
            const ch = document.createElement('div');
            ch.className = 'pdf-chip';
            ch.textContent = name;
            ch.onclick = () => {
              // Teljes nevet normalizálva beírjuk (pl. "Takacs, Zoltan" → "Takacs Zoltan")
              const fullName = name.replace(/,\s*/g, ' ').trim();
              document.getElementById('pdfNameInput').value = fullName;
              // Accordion bezárása keresés előtt
              const chipsDiv = document.getElementById('pdfNameChips');
              const arrow = document.getElementById('pdfNamesAccordionArrow');
              if (chipsDiv) chipsDiv.style.maxHeight = chipsDiv.scrollHeight + 'px';
              if (arrow) { arrow.textContent = '▶'; arrow.style.transform = 'rotate(0deg)'; }
              pdfSearchName();
            };
            chips.appendChild(ch);
          });

          // Accordion megjelenítése
          const accordion = document.getElementById('pdfNamesAccordion');
          if (accordion) {
            accordion.style.display = 'block';
            const label = document.getElementById('pdfNamesAccordionLabel');
            if (label) label.textContent = `👥 ${sortedNames.length} ${t('namesFound') || 'names found'}`;
          }

          // Jelöljük, hogy névkeresős üzemmód van (ne mutassa a noDataFound hibát)
          if (!append || pdfAllMonths.length === 0) {
            pdfAllMonths = [{ _nameSearchPending: true, year, month, shifts: [] }];
          }

          pdfSetStatus(`✅ ${names.length} ${t('namesFound')}`, 'success');
          return;
        }

        // Névkereső nem sikerült → közvetlen tokenizálás (pl. saját beosztás kép/PDF)
        const daysInMonth = month > 0 ? new Date(year, month, 0).getDate() : 31;
        const mappedShifts = [];

        for (const line of lines) {
          const tokens = line.split(/\s+/);
          for (const tok of tokens) {
            const id = tokenToShiftId(tok);
            if (id !== undefined) {
              mappedShifts.push(id);
              if (mappedShifts.length >= daysInMonth) break;
            }
          }
          if (mappedShifts.length >= daysInMonth) break;
        }

        // Ha kevés adat → supershift fallback
        if (mappedShifts.length < 5) {
          const supers = pdfParseSupershiftText(text, month, year);
          while (supers.length < daysInMonth) supers.push(null);
          const newMonths = [{ year, month, shifts: supers.slice(0, daysInMonth) }];
          if (append) pdfAllMonths = [...pdfAllMonths, ...newMonths];
          else pdfAllMonths = newMonths;
          return;
        }

        while (mappedShifts.length < daysInMonth) mappedShifts.push(null);
        const newMonths = [{ year, month, shifts: mappedShifts.slice(0, daysInMonth) }];

        if (append) pdfAllMonths = [...pdfAllMonths, ...newMonths];
        else pdfAllMonths = newMonths;
      }

      window.togglePdfNamesAccordion = function() {
        const chips = document.getElementById('pdfNameChips');
        const arrow = document.getElementById('pdfNamesAccordionArrow');
        const btn = document.getElementById('pdfNamesAccordionBtn');
        if (!chips) return;
        const isOpen = chips.style.display !== 'none';
        chips.style.display = isOpen ? 'none' : 'flex';
        if (arrow) arrow.textContent = isOpen ? '▶' : '▼';
      };

      window.pdfSearchName = function() {
        const name = document.getElementById('pdfNameInput').value.trim();
        if (!name) return;

        // ── Automatikus tükrözés a rotation widget névkeresőjébe ──
        const rwSearch = document.getElementById('name-search');
        if (rwSearch) {
          rwSearch.value = name;
          if (typeof window._rwRenderGroupList === 'function') {
            window._rwRenderGroupList(name);
          } else {
            rwSearch.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }

        const foundMonths = [];
        const seenKeys = new Set();

        // Search across each file's text separately for correct month detection
        const textsToSearch = pdfAllExtractedTexts.length > 1 ? pdfAllExtractedTexts : [pdfExtractedText];

        textsToSearch.forEach(fileText => {
          const lines = fileText.split('\n').map(l => l.trim()).filter(Boolean);

          const workerLines = [];
          for (let i = 0; i < lines.length; i++) {
            if (pdfFuzzyMatch(name, lines[i])) {
              workerLines.push(i);
            }
          }

          if (workerLines.length === 0) return;

          for (const workerLine of workerLines) {
            const contextStart = Math.max(0, workerLine - 80);
            const contextText = lines.slice(contextStart, workerLine + 5).join('\n');
            let { month, year } = pdfDetectMonthYear(contextText);

            if (month === new Date().getMonth() + 1 && year === new Date().getFullYear()) {
              const wholeResult = pdfDetectMonthYear(fileText);
              if (wholeResult.month !== new Date().getMonth() + 1 || wholeResult.year !== new Date().getFullYear()) {
                month = wholeResult.month;
                year = wholeResult.year;
              }
            }

            const key = `${year}-${month}`;
            if (seenKeys.has(key)) continue;
            seenKeys.add(key);

            const daysInMonth = month > 0 ? new Date(year, month, 0).getDate() : 31;
            const shifts = pdfExtractShiftsAfterLine(lines, workerLine, daysInMonth);
            const validCount = shifts.filter(s => s !== null && s !== undefined).length;

            if (validCount > 0) {
              foundMonths.push({ year, month, shifts });
            }
          }
        });

        if (foundMonths.length === 0) {
          pdfSetStatus('❌ ' + t('notFound') + ': "' + name + '"', 'error');
          return;
        }

        foundMonths.sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);

        pdfAllMonths = foundMonths;
        renderPdfMonthList(pdfAllMonths, 'schichtplan');

        const total = foundMonths.reduce((s, m) =>
          s + m.shifts.filter(x => x !== null && x !== undefined).length, 0);
        pdfSetStatus(`✅ ${name}: ${foundMonths.length} ${t('months')}, ${total} ${t('shiftsWord')}`, 'success');
      };

      // ==================== ZEUS FELDOLGOZÁS ====================

      // Kezdési időpont → CHRONOS műszak-ID
      // Freiwillig TM kódok (Zeus Monatsjournal)
      const _ZEUS_FREIWILLIG_TM = new Set(['70','71','72','73','74','75','76','77','78']);

      function zeusTimeToShiftId(kommt, isFeiertag, isFreiwillig) {
        if (!kommt) return null;
        const h = parseInt(kommt.split(':')[0], 10);
        if (isFeiertag) {
          if (h >= 4 && h <= 8)   return 'Fei Fr';
          if (h >= 12 && h <= 16) return 'Fei Sp';
          if (h >= 20 || h <= 3)  return 'Fei Na';
          return null;
        }
        if (isFreiwillig) {
          if (h >= 4 && h <= 8)   return 'Freiwillig Früh';
          if (h >= 12 && h <= 16) return 'Freiwillig Spät';
          if (h >= 20 || h <= 3)  return 'Freiwillig Nacht';
          return null;
        }
        if (h >= 4 && h <= 8)   return 'Früh';
        if (h >= 12 && h <= 16) return 'Spät';
        if (h >= 20 || h <= 3)  return 'Nacht';
        return null;
      }

      function processZeusText(append = false) {
        const text = pdfExtractedText;
        const { month, year } = pdfDetectMonthYear(text);

        const days = [];
        // ── 2.HT / 1.HT előfeldolgozás ──
        // A Zeus PDF-ben egyes napok két sorból állnak:
        //   "Mi 21 320 | 5:22 - 10:14 | |"          ← fősor (nap+munkaidő)
        //   "21 320 | 2.HT 0:00+ *ZA |4:Zeitausgleich |"  ← folytatósor (fél napos jel.)
        // A folytatósornak nincs nap-rövidítés-előtag, csak szám. Felismerjük és
        // hozzáfűzzük az előző napsorhoz, hogy a döntési logika egyszerre láthassa.
        const rawLines = text.split('\n');
        const mergedLines = [];
        for (const line of rawLines) {
          const isContinuation = /^\s*\d{1,2}\s+\d+\s+\|.*(?:1\.HT|2\.HT|HT\s*\d)/.test(line)
                               || /^\s*\d{1,2}\s+\d+\s+\|\s*(?:1\.HT|2\.HT)/.test(line);
          if (isContinuation && mergedLines.length > 0) {
            // Hozzáfűzzük az előző sorhoz egy szóközzel elválasztva
            mergedLines[mergedLines.length - 1] += ' ' + line.trim();
          } else {
            mergedLines.push(line);
          }
        }
        const lines = mergedLines;

        for (const line of lines) {
          // ZEUS napsor: "Mo 01 320 | 05:45 - 14:15 ..." VAGY "Fr 05 321 | Urlaub ..."
          const m = line.match(/^(Mo|Di|Mi|Do|Fr|Sa|So)\s+(\d{1,2})\s+(\d{2,5})\s*\|/);
          if (!m) continue;

          const dayNum = parseInt(m[2]);
          const tmCode = m[3];

          // Freiwillig TM kód alapján (megbízhatóbb mint a beosztással való összehasonlítás)
          const isFreiwilligTM = _ZEUS_FREIWILLIG_TM.has(tmCode);

          // Valódi munkaidő pl. "05:45 - 14:15" (de NEM "0:00+" placeholder)
          const timeMatch = line.match(/(\d{1,2}:\d{2})\s*[-–]\s*\d{1,2}:\d{2}/);
          const kommt = timeMatch ? timeMatch[1] : null;
          // hasRealWork: van illeszkedő idő ÉS a kezdési idő nem 0:00
          const hasRealWork = !!kommt && kommt !== '0:00';

          const isUrlaub    = line.includes('Urlaub');
          const isKrank     = line.includes('Krank');
          const isFeiertag  = line.includes('Feiertag');
          const isZeit      = line.includes('Zeitausgleich') || line.includes('Zeitkonto');
          const isHalfDay   = line.includes('1.HT') || line.includes('2.HT');
          const isFirst     = line.includes('1.HT');

          let shiftId = null;

          if (isUrlaub && !hasRealWork) {
            // Szabadság (egész vagy fél nap)
            shiftId = isHalfDay ? (isFirst ? 'Urlaub1' : 'Urlaub2') : 'Urlaub';
          } else if (isUrlaub && hasRealWork && isHalfDay) {
            // Dolgozik + Urlaub félnap (2.HT URL = munkaidő + szabad 2.fél)
            shiftId = isFirst ? 'Urlaub1' : 'Urlaub2';
          } else if (isKrank && !hasRealWork) {
            shiftId = 'Krank';
          } else if (isZeit && !hasRealWork) {
            // Zeitausgleich (ZA) egész vagy fél nap → ZK / ZK1 / ZK2
            shiftId = isHalfDay ? (isFirst ? 'ZK1' : 'ZK2') : 'ZK';
          } else if (isZeit && hasRealWork && isHalfDay) {
            // Dolgozik + ZA félnap (pl. 5:22-10:14 + 2.HT ZA) → [Früh/Spät/Nacht, ZK1/ZK2]
            const _zkHalfId = isFirst ? 'ZK1' : 'ZK2';
            const _workShiftId = zeusTimeToShiftId(kommt, false);
            if (_workShiftId) {
              days.push({ dayNum, shiftId: _workShiftId, _zkHalf: _zkHalfId });
              continue;
            } else {
              shiftId = _zkHalfId;
            }
          } else if (isFeiertag && hasRealWork) {
            // Ünnepnapon dolgozott → idő alapján Fei Fr / Fei Sp / Fei Na
            shiftId = zeusTimeToShiftId(kommt, true, false);
          } else if (hasRealWork && !isZeit) {
            // DiffNt oszlop: a "| |" blokk utáni 3. szám
            // Ha DiffNt != 0 → Zeitkonto (időszámla), nem UE túlóra
            // Sor formátum: "... | BrArb Soll DiffNt ..."
            // A két || közötti részt keressük, utána a számokat
            const afterPipes = line.match(/\|\s*\|\s*([\+\-]?\d+[\.,]\d+)\s+([\+\-]?\d+[\.,]\d+)\s+([\+\-]?\d+[\.,]\d+)/);
            const diffNt = afterPipes ? parseFloat(afterPipes[3].replace(',', '.')) : 0;
            const soll   = afterPipes ? parseFloat(afterPipes[2].replace(',', '.')) : 8;
            const isZeitkonto = diffNt !== 0;
            // Szabadnapos önkéntes munka: Soll=0 ÉS DiffNt=0 → valódi Freiwillig
            // (TM kód lehet normál 320/321/322, nem csak a dedikált 70-78 FW kódok)
            const isFreeDay = soll === 0 && !isZeitkonto;
            // Normál munkanap → idő alapján Früh / Spät / Nacht (vagy Freiwillig ha FW)
            shiftId = zeusTimeToShiftId(kommt, false, isFreiwilligTM || isFreeDay);
            // Ha Zeitkonto (nem valódi UE), maradjon Früh/Spät/Nacht (nem Freiwillig)
            if (isZeitkonto && !isFreiwilligTM) {
              // Zeitkonto napot explicit jelöljük hogy ne váltson Freiwillig-re az import
              days.push({ dayNum, shiftId, isZeitkonto: true });
              continue;
            }
          }
          // Szabad szombat/vasárnap, Feiertag (szabad), Zeitausgleich → nincs import

          if (shiftId) {
            days.push({ dayNum, shiftId });
          }
        }

        if (days.length === 0) return;

        const newMonths = [{ year, month, days }];
        if (append) {
          pdfZeusMonths = [...pdfZeusMonths, ...newMonths];
        } else {
          pdfZeusMonths = newMonths;
        }
      }

      // ==================== HÓNAP LISTA MEGJELENÍTÉS ====================
      function renderPdfMonthList(months, mode) {
        const container = document.getElementById('pdfMonthItems');
        container.innerHTML = '';

        const realMonths = months.filter(m => !m._nameSearchPending);
        realMonths.sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);

        const shiftColors = {
          'Früh': '#00aa00', 'Spät': '#ff3333', 'Nacht': '#0066ff',
          'Urlaub': '#6b7280', 'Krank': '#fbbf24',
          'Freiwillig Früh': '#86efac', 'Freiwillig Spät': '#fca5a5', 'Freiwillig Nacht': '#93c5fd',
          'Fei Fr': '#86efac', 'Fei Sp': '#fca5a5', 'Fei Na': '#93c5fd'
        };

        // Helyes shift lista lekérés
        const allShiftsForPreview = getAllShifts();

        realMonths.forEach(function(monthData, idx) {
          const monthName = ((TRANSLATIONS[state.currentLang]||TRANSLATIONS.de).monthNames||[])[monthData.month-1] || ('Month ' + monthData.month);
          const count = mode === 'zeus'
            ? (monthData.days || []).filter(function(d) { return d.shiftId; }).length
            : (monthData.shifts || []).filter(function(s) { return s !== null && s !== undefined; }).length;

          // --- Sor wrapper ---
          const wrapper = document.createElement('div');
          wrapper.style.cssText = 'border-radius:8px; margin-bottom:2px; background:var(--surface2); flex-shrink:0;';

          // --- Sor ---
          const row = document.createElement('div');
          row.style.cssText = 'display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:8px; min-height:40px; width:100%; box-sizing:border-box;';

          // Checkbox
          const cb = document.createElement('input');
          cb.type = 'checkbox';
          cb.checked = true;
          cb.dataset.idx = idx;
          cb.style.cssText = 'flex-shrink:0; width:18px; height:18px; accent-color:var(--accent); cursor:pointer;';
          cb.addEventListener('click', function(e) { e.stopPropagation(); });

          // Hónapnév
          const nameSpan = document.createElement('span');
          nameSpan.style.cssText = 'flex:1; font-weight:600; font-size:13px;';
          nameSpan.textContent = monthName + ' ' + monthData.year;

          // Darabszám
          const countSpan = document.createElement('span');
          countSpan.style.cssText = 'font-size:11px; color:var(--text2); flex-shrink:0; margin-right:4px;';
          countSpan.textContent = count + ' ' + (t('entries')||'bejegyzés');

          // Szem gomb
          const eyeBtn = document.createElement('button');
          eyeBtn.style.cssText = 'background:none; border:none; font-size:18px; cursor:pointer; padding:4px 6px; flex-shrink:0; line-height:1; color:var(--text2); border-radius:6px;';
          eyeBtn.title = t('preview')||'Előnézet';
          eyeBtn.textContent = '👁';

          row.appendChild(cb);
          row.appendChild(nameSpan);
          row.appendChild(countSpan);
          row.appendChild(eyeBtn);

          // --- Előnézet panel ---
          const previewPanel = document.createElement('div');
          previewPanel.style.cssText = 'display:none; background:var(--surface); border-top:2px solid var(--accent); border-radius:0 0 8px 8px; padding:10px; max-height:240px; overflow-y:auto;';

          // Preview tartalom összerakása – saját scope, helyes változóhivatkozásokkal
          function buildPreview() {
            previewPanel.innerHTML = '';
            var items;
            try {
              items = mode === 'zeus'
                ? (monthData.days || []).map(function(d) { return { dayNum: d.dayNum, shiftId: d.shiftId, isZeitkonto: d.isZeitkonto, asOvertime: d.asOvertime }; })
                : (monthData.shifts || []).map(function(s, i) { return { dayNum: i + 1, shiftId: s }; });
            } catch(e) {
              previewPanel.innerHTML = `<div style="color:var(--red);font-size:12px;padding:4px;">${t('loadError')||'Hiba a betöltésnél'}</div>`;
              return;
            }

            var filtered = items.filter(function(item) { return item.shiftId; });

            if (filtered.length === 0) {
              previewPanel.innerHTML = `<div style="color:var(--text2);font-size:12px;padding:4px;text-align:center;">${t('noPreviewEntries')||'Nincs megjeleníthető bejegyzés'}</div>`;
              return;
            }

            var shown = 0;
            for (var i = 0; i < filtered.length; i++) {
              var item = filtered[i];
              var shiftObj = null;
              for (var j = 0; j < allShiftsForPreview.length; j++) {
                if (allShiftsForPreview[j].id === item.shiftId) { shiftObj = allShiftsForPreview[j]; break; }
              }
              var label = shiftObj ? getShiftName(shiftObj) : item.shiftId;
              var color = shiftColors[item.shiftId] || '#6b7280';

              var row2 = document.createElement('div');
              row2.style.cssText = 'display:flex; align-items:center; gap:8px; padding:4px 6px; border-radius:5px; font-size:12px;';
              row2.innerHTML = '<span style="font-weight:700; color:var(--text2); min-width:24px; font-size:11px;">' + item.dayNum + '.</span>'
                + '<span style="width:9px;height:9px;border-radius:50%;background:' + color + ';display:inline-block;flex-shrink:0;"></span>'
                + '<span style="flex:1;">' + label + '</span>';

              // Zeitkonto naphoz túlóra toggle
              if (mode === 'zeus' && item.isZeitkonto) {
                var zkWrap = document.createElement('label');
                zkWrap.style.cssText = 'display:flex; align-items:center; gap:4px; cursor:pointer; font-size:11px; color:var(--accent); white-space:nowrap; flex-shrink:0;';
                var zkCb = document.createElement('input');
                zkCb.type = 'checkbox';
                zkCb.checked = !!item.asOvertime;
                zkCb.style.cssText = 'accent-color:var(--accent); cursor:pointer;';
                zkCb.dataset.dayNum = item.dayNum;
                zkCb.dataset.monthIdx = idx;
                (function(cb, dayItem) {
                  cb.addEventListener('change', function(e) {
                    dayItem.asOvertime = e.target.checked;
                  });
                })(zkCb, item);
                zkWrap.appendChild(zkCb);
                zkWrap.appendChild(document.createTextNode(' Túlóra'));
                row2.appendChild(zkWrap);
              }

              previewPanel.appendChild(row2);
              shown++;

              if (shown >= 31) {
                var more = document.createElement('div');
                more.style.cssText = 'font-size:11px; color:var(--text2); padding:4px 6px; text-align:center; border-top:1px solid var(--border); margin-top:4px;';
                more.textContent = (t('moreEntriesFmt')||'+ {n} további bejegyzés').replace('{n}', filtered.length - shown);
                previewPanel.appendChild(more);
                break;
              }
            }
          }

          // Szem gomb click handler
          var previewOpen = false;
          (function(eyeB, prevPanel, rowEl) {
            eyeB.addEventListener('click', function(e) {
              e.stopPropagation();
              previewOpen = !previewOpen;
              if (previewOpen) {
                buildPreview();
                prevPanel.style.display = 'block';
                eyeB.textContent = '🔍';
                eyeB.style.color = 'var(--accent)';
                eyeB.style.background = 'var(--accent-light)';
                rowEl.style.borderRadius = '8px 8px 0 0';
              } else {
                prevPanel.style.display = 'none';
                eyeB.textContent = '👁';
                eyeB.style.color = 'var(--text2)';
                eyeB.style.background = 'none';
                rowEl.style.borderRadius = '8px';
              }
            });
          })(eyeBtn, previewPanel, row);

          wrapper.appendChild(row);
          wrapper.appendChild(previewPanel);
          container.appendChild(wrapper);
        });

        document.getElementById('pdfMonthList').style.display = 'block';
        // pdfImportBtn megjelenítését a smart rotation dönti el (ha elérhető)
        if (window._checkSmartRot) {
          // Kis késleltetés, hogy a rotAnalyzePdfTexts előbb fusson
          setTimeout(window._checkSmartRot, TIMING.SMART_ROT_CHECK);
        } else {
          document.getElementById('pdfImportBtn').style.display = 'block';
        }
        var oldPreview = document.getElementById('pdfPreview');
        if (oldPreview) oldPreview.style.display = 'none';
      }

      function renderPdfPreview(monthData, mode) {
        // Visszafelé kompatibilitás – már az inline panel kezeli
      }

      window.pdfSelectAll = function(val) {
        document.querySelectorAll('#pdfMonthItems input[type=checkbox]').forEach(cb => cb.checked = val);
      };

      // ══════════════════════════════════════════════════════════════
      //  ROTÁCIÓ WIDGET – beágyazva a PDF import modálba
      // ══════════════════════════════════════════════════════════════
      (function() {
        'use strict';

        // ── Konstansok ──
        const SHIFT_VALS = ['F','S','N','X'];
        const MN_HU = ['Január','Február','Március','Április','Május','Június',
                       'Július','Augusztus','Szeptember','Október','November','December'];
        const DN_SHORT = ['H','K','Sz','Cs','P','Sz','V'];
        const MONTH_MAP = {
          januar:1,jänner:1,februar:2,märz:3,maerz:3,april:4,mai:5,juni:6,
          juli:7,august:8,september:9,oktober:10,november:11,dezember:12,
          január:1,február:2,március:3,április:4,május:5,június:6,július:7,
          augusztus:8,szeptember:9,október:10,december:12
        };

        // ── State ──
        let rotDB = {};           // dept_id → {id, dept, names, blocks, pattern}
        let rotSelected = null;   // kiválasztott csoport
        let rotAnchorShift = null;
        let rotPhaseOffset = null;
        const rotCal = { year: new Date().getFullYear(), month: new Date().getMonth(), startDate: null, endDate: null };

        // ── Helpers ──
        function rotRawToBlocks(shifts) {
          if (!shifts.length) return [];
          const res = []; let cur = shifts[0], cnt = 1;
          for (let i = 1; i < shifts.length; i++) {
            if (shifts[i] === cur) cnt++;
            else { res.push({shift:cur,count:cnt}); cur=shifts[i]; cnt=1; }
          }
          res.push({shift:cur,count:cnt}); return res;
        }
        function rotBlocksToPat(blocks) {
          const p = []; blocks.forEach(b=>{ for(let i=0;i<b.count;i++) p.push(b.shift); }); return p;
        }
        function rotDetectCycle(shifts) {
          // ── Erős ciklus-felismerő (rotation_claude_11 algoritmusa) ──
          const clean = shifts.filter(s=>SHIFT_VALS.includes(s));
          if (clean.length < 4) return null;

          // Minden bejelölt nap lineáris offszete az első naptól
          const totalKnown = clean.length;
          // knownArr: {off, s} – itt az offset egyszerűen az index (nincs dátum-hézag a PDF-sorokban)
          const knownArr = clean.map((s,i)=>({off:i,s}));
          const knownShifts = {};
          clean.forEach((s,i)=>{ knownShifts[i]=s; });
          const spanDays = clean.length;

          function scorePhase(pattern, phase) {
            let hits=0, misses=0;
            for(const {off,s} of knownArr) {
              const idx = ((phase+off)%pattern.length+pattern.length)%pattern.length;
              if(pattern[idx]===s) hits++; else misses++;
            }
            return {hits,misses};
          }

          function findBestPhase(pattern) {
            let best={hits:-1,misses:9999,phase:0};
            for(let ph=0;ph<pattern.length;ph++) {
              const sc=scorePhase(pattern,ph);
              if(sc.hits>best.hits||(sc.hits===best.hits&&sc.misses<best.misses))
                best={...sc,phase:ph};
            }
            return best;
          }

          let bestPattern=null, bestHits=0, bestMisses=9999, bestPatLen=9999;

          function contest(pattern) {
            const fit=findBestPhase(pattern);
            if(fit.hits===0) return;
            const better =
              fit.hits>bestHits ||
              (fit.hits===bestHits&&fit.misses<bestMisses) ||
              (fit.hits===bestHits&&fit.misses===bestMisses&&pattern.length<bestPatLen);
            if(better){
              bestHits=fit.hits; bestMisses=fit.misses; bestPatLen=pattern.length;
              bestPattern=pattern.slice();
            }
          }

          // 1. Standard 3-műszakos sablonok (ORDERS × PAIRS + ASYM)
          const ORDERS=[
            ['F','S','N'],['S','N','F'],['N','F','S'],
            ['F','N','S'],['S','F','N'],['N','S','F']
          ];
          const PAIRS=[[5,2],[7,0],[6,1],[4,3],[5,4],[7,2],[4,2],[3,4],[6,2],[7,3]];
          const ASYM=[
            [7,3,7,3,7,3],[7,3,6,3,7,4],[7,3,7,4,6,3],[6,3,7,3,7,4],[7,4,6,3,7,3],
            [6,4,7,3,7,3],[7,3,6,4,7,3],[6,3,6,3,7,5],[7,4,7,3,6,3],
            [7,2,7,2,7,3],[7,3,7,2,7,2],[7,2,7,3,7,2],
            [5,2,5,2,5,4],[7,0,7,0,7,2],[5,3,5,3,5,3],[5,2,7,0,5,2],
            [7,7,7,7,7,7],[5,9,5,9,5,9]
          ];
          const pats=new Set();
          function tryPat(p){const k=p.join('');if(pats.has(k))return;pats.add(k);contest(p);}
          ORDERS.forEach(ord=>{
            PAIRS.forEach(([w,r])=>{
              const p=[];
              for(let si=0;si<3;si++){for(let k=0;k<w;k++)p.push(ord[si]);for(let k=0;k<r;k++)p.push('X');}
              tryPat(p);
            });
            ASYM.forEach(cfg=>{
              const p=[];
              for(let si=0;si<3;si++){const w=cfg[si*2],r=cfg[si*2+1];for(let k=0;k<w;k++)p.push(ord[si]);for(let k=0;k<r;k++)p.push('X');}
              tryPat(p);
            });
          });

          // 2. Direkt sorozat-felismerés (ha nincs hézag)
          if(bestMisses>0) {
            for(let clen=5;clen<=clean.length-1;clen++){
              const cand=clean.slice(0,clen);
              let hits=0;
              for(let i=0;i<clean.length;i++) if(clean[i]===cand[i%clen]) hits++;
              if(hits===clean.length){ contest(cand); break; }
            }
          }

          // 3. Blokk-alapú fallback (eredeti logika)
          if(!bestPattern){
            const rawB=rotRawToBlocks(clean);
            let fallbackBest=null, fallbackScore=-1;
            for(let cb=2;cb<=Math.min(rawB.length,20);cb++){
              const cand=rawB.slice(0,cb);
              const cPat=rotBlocksToPat(cand);
              if(cPat.length<3||cPat.length>clean.length) continue;
              let pos=0,matches=0,total=0;
              while(pos+cPat.length<=clean.length){
                let hit=0;
                for(let j=0;j<cPat.length;j++) if(clean[pos+j]===cPat[j]) hit++;
                if(hit/cPat.length>=0.70) matches++;
                total++; pos+=cPat.length;
              }
              if(!total) continue;
              const conf=Math.round(matches/total*100);
              const score=conf*matches*(cPat.length*0.8);
              if(score>fallbackScore&&conf>=50&&matches>=1){fallbackScore=score;fallbackBest={pattern:cPat,blocks:cand,confidence:conf};}
            }
            return fallbackBest;
          }

          if(!bestPattern) return null;
          const blocks=rotRawToBlocks(bestPattern);
          const matchPct=Math.round(bestHits/totalKnown*100);
          return {pattern:bestPattern, blocks, confidence:matchPct};
        }
        function rotShiftOnDate(pattern, cycleStart, target) {
          const diff = Math.round((target - cycleStart)/86400000);
          return pattern[((diff%pattern.length)+pattern.length)%pattern.length];
        }
        function rotCalcCycleStart(anchorDate, offset) {
          const d = new Date(anchorDate); d.setDate(d.getDate()-offset); return d;
        }
        function rotDKey(d) { return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
        function rotDLabel(d) { return d?`${d.getFullYear()}. ${MN_HU[d.getMonth()]} ${d.getDate()}.`:'–'; }

        // Shift string (F/S/N/X) → CHRONOS shift ID
        function rotShiftToId(s) {
          if (s==='F') return 'Früh';
          if (s==='S') return 'Spät';
          if (s==='N') return 'Nacht';
          return null; // X = szabad, nem importáljuk
        }

        // Helyi normalizeShifts a rotation widgethez (SHIFT_VALS/SPECIAL_CODES nem érhető el itt)
        const _rotSpecialCodes = new Set(['URL','KOL','ZA','U','U2','KR','FR','FE','BU','SU','GU','AZ','TZ','AB','AV','EL','PK','OK','WE','WT']);
        function _rotNormalizeShifts(shiftStr) {
          return shiftStr.trim().split(/\s+/).map(t => {
            if (['F','S','N','X'].includes(t)) return t;
            if (_rotSpecialCodes.has(t)) return 'SKIP';
            if (/^[A-ZÄÖÜ]{2,6}$/.test(t)) return 'SKIP';
            return null;
          }).filter(t => t !== null);
        }

        // ── PDF szöveg → csoport lista ──
        function rotParsePdfGroups(text, sourceName, dateInfo) {
          const lines = text.split('\n').map(l=>l.trim()).filter(Boolean);
          const groups = {};
          for (const line of lines) {
            // S-I szétválasztás
            const siIdx = line.indexOf('S-I');
            if (siIdx < 0) continue;
            const header   = line.substring(0, siIdx).trim();
            const shiftStr = line.substring(siIdx + 3);
            const shifts   = _rotNormalizeShifts(shiftStr);
            if (shifts.filter(s => ['F','S','N','X'].includes(s)).length < 5) continue;

            let gid = null, dept = '', name = null;

            // B2 formátum: "210 - GL Bereich 2 Stuwe, Florian"
            const b2m = header.match(/^(\d{2,4})\s*[-–]\s*(.+)$/);
            if (b2m) {
              gid = b2m[1];
              const rest = b2m[2].trim();
              const commaIdx = rest.indexOf(',');
              if (commaIdx >= 0) {
                const lastSpace = rest.substring(0, commaIdx).lastIndexOf(' ');
                dept = lastSpace >= 0 ? rest.substring(0, lastSpace).trim() : '';
                name = lastSpace >= 0 ? rest.substring(lastSpace + 1).trim() : rest.trim();
              }
            }
            // B1 formátum: "1.1 - H9/G2 Erkaya, Omer"
            if (!gid) {
              const b1m = header.match(/^(\d+\.\d+)\s*[-–]\s*(.+)$/);
              if (b1m) {
                gid = b1m[1].replace(/\./g,'_');
                const rest = b1m[2].trim();
                const commaIdx = rest.indexOf(',');
                if (commaIdx >= 0) {
                  const lastSpace = rest.substring(0, commaIdx).lastIndexOf(' ');
                  dept = lastSpace >= 0 ? rest.substring(0, lastSpace).trim() : '';
                  name = lastSpace >= 0 ? rest.substring(lastSpace + 1).trim() : rest.trim();
                }
              }
            }

            if (!gid || !name) continue;
            if (!groups[gid]) groups[gid] = {id:gid, dept, names:[], rawShifts:[], memberShifts:{}};
            if (!groups[gid].names.includes(name)) groups[gid].names.push(name);
            const newClean = shifts.filter(s=>['F','S','N','X'].includes(s)).length;
            const oldClean = groups[gid].rawShifts.filter(s=>['F','S','N','X'].includes(s)).length;
            if (newClean > oldClean) groups[gid].rawShifts = shifts;
            // ── Minden tag saját shifts-sorát is eltároljuk (sub-variant detektáláshoz) ──
            if (!groups[gid].memberShifts[name]) groups[gid].memberShifts[name] = shifts;
            else {
              const exClean = groups[gid].memberShifts[name].filter(s=>['F','S','N','X'].includes(s)).length;
              if (newClean > exClean) groups[gid].memberShifts[name] = shifts;
            }
          }
          const result = [];
          for (const gid of Object.keys(groups)) {
            const g = groups[gid];
            const clean = g.rawShifts.filter(s=>['F','S','N','X'].includes(s));
            if (clean.length < 8) continue;

            // monthlyData összerakása dátuminfo alapján (SKIP-ekkel együtt)
            const monthlyData = {};
            let cycleStart = null;
            let det = null;

            if (dateInfo) {
              const ym = dateInfo.year + '-' + String(dateInfo.month).padStart(2,'0');
              monthlyData[ym] = g.rawShifts;

              // ── Dátum-alapú ciklus detektálás egyetlen hónapból ──
              // A rawShifts tömb 1:1 megfelel a naptári napoknak:
              // rawShifts[0] = hónap 1. napja, rawShifts[1] = 2. napja, stb.
              // Az epoch-offsetek így pontosan ismertek → brute-force minden ciklushosszon
              const epoch = new Date(2000, 0, 1);
              const monthStart = new Date(dateInfo.year, dateInfo.month - 1, 1);
              const baseOffset = Math.round((monthStart - epoch) / 86400000);

              // Csak az F/S/N/X napokat indexeljük, de megőrizzük a naptári pozíciójukat
              const dated = [];
              for (let d = 0; d < g.rawShifts.length; d++) {
                const s = g.rawShifts[d];
                if (['F','S','N','X'].includes(s)) {
                  dated.push({ dayOffset: baseOffset + d, shift: s });
                }
              }

              if (dated.length >= 8) {
                const presentShifts = ['F','S','N'].filter(s => dated.some(e => e.shift === s));
                let bestDet = null, bestScore = -1;

                // Próbálunk minden ciklushosszt 10-től 63-ig
                // (rövidebbet nem érdemes, az egészséges rotáció legalább 10 nap)
                for (let clen = 10; clen <= 63; clen++) {
                  // Minden lehetséges cycleStart-offsetet kipróbálunk (0..clen-1)
                  // azaz: a hónap 1. napja a ciklus hányadik napja
                  for (let startOff = 0; startOff < clen; startOff++) {
                    // pattern[i] = mi a műszak a ciklus i-edik napján
                    const pattern = new Array(clen).fill(null);
                    let conflicts = 0;
                    for (const e of dated) {
                      const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
                      if (pattern[idx] === null) {
                        pattern[idx] = e.shift;
                      } else if (pattern[idx] !== e.shift) {
                        conflicts++;
                      }
                    }
                    // Elég adat kell + minimális konfliktus
                    const filled = pattern.filter(x => x !== null).length;
                    if (filled < Math.min(clen, dated.length)) continue;
                    if (conflicts > dated.length * 0.08) continue;
                    // Minden aktív műszaknak kell a mintában
                    if (!presentShifts.every(s => pattern.includes(s))) continue;
                    // Találati arány
                    let hits = 0;
                    for (const e of dated) {
                      const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
                      if (pattern[idx] === e.shift) hits++;
                    }
                    const pct = hits / dated.length;
                    if (pct < 0.90) continue;
                    // Score: találati arány × ciklushossz (hosszabb jobb, de csak ha valóban ismétlődik)
                    const score = pct * clen;
                    if (score > bestScore) {
                      bestScore = score;
                      // Ciklus kezdete: a baseOffset - startOff nap (azaz hány nappal a hónap 1. előtt kezdődött a ciklus)
                      const csEpoch = new Date(epoch.getTime() + (baseOffset - startOff) * 86400000);
                      bestDet = {
                        pattern: pattern.map(s => s || 'X'), // null pozíciók X-ként kezelve
                        blocks: rotRawToBlocks(pattern.map(s => s || 'X')),
                        confidence: Math.round(pct * 100),
                        _cycleStart: csEpoch
                      };
                    }
                  }
                }
                if (bestDet) {
                  det = bestDet;
                  cycleStart = bestDet._cycleStart;
                }
              }

              // Fallback ha a dátum-alapú nem sikerült
              if (!cycleStart) cycleStart = new Date(dateInfo.year, dateInfo.month - 1, 1);
            }

            // Ha nincs dateInfo vagy nem sikerült: sima szekvencia-alapú
            if (!det) det = rotDetectCycle(clean);

            const finalPattern = det ? det.pattern : clean;
            const finalBlocks  = det ? det.blocks  : rotRawToBlocks(clean);

            // ── Tagok 3 variációba rendezése (mindig 3 mini-naptár ajánlat csoportonként) ──
            // Egy hónapos adatból a pontos klaszterszám nem határozható meg megbízhatóan,
            // ezért mindig pontosan 3 reprezentatív variációt ajánlunk: a leggyakoribb
            // szekvenciát (és az azzal 100%-ban egyezőket), majd a két leginkább eltérő
            // fennmaradó tagot (k-medoids-szerű görög választással), a maradékot pedig
            // a hozzá legközelebb eső variációhoz soroljuk.
            const memberCycleStarts = {};
            const memberVariants = [];
            {
              const mNames = Object.keys(g.memberShifts || {});

              function seqMatch(a, b) {
                const len = Math.min(a.length, b.length);
                let compared = 0, matches = 0;
                for (let i = 0; i < len; i++) {
                  const x = a[i], y = b[i];
                  if (!['F','S','N','X'].includes(x) || !['F','S','N','X'].includes(y)) continue;
                  compared++; if (x === y) matches++;
                }
                return compared >= 5 ? matches / compared : 0;
              }

              if (mNames.length > 0) {
                // 1. medoid: az a tag, akinek a legtöbb 100%-os egyezése van másokkal
                let exactGroups = mNames.map(n => ({
                  name: n,
                  exactCount: mNames.filter(o => o!==n && seqMatch(g.memberShifts[n], g.memberShifts[o]) >= 0.999).length
                }));
                exactGroups.sort((a,b)=>b.exactCount-a.exactCount);
                const medoids = [exactGroups[0].name];

                // 2. és 3. medoid: a már kiválasztott medoidoktól legtávolabb eső tagok
                while (medoids.length < 3 && medoids.length < mNames.length) {
                  let farName = null, farDist = -1;
                  for (const n of mNames) {
                    if (medoids.includes(n)) continue;
                    const minSimToMedoids = Math.min(...medoids.map(m => seqMatch(g.memberShifts[n], g.memberShifts[m])));
                    const dist = 1 - minSimToMedoids;
                    if (dist > farDist) { farDist = dist; farName = n; }
                  }
                  if (farName) medoids.push(farName);
                  else break;
                }

                // Minden tag a hozzá leginkább hasonló medoidhoz kerül
                const groups = medoids.map(m => ({medoid: m, names: []}));
                mNames.forEach(n => {
                  let bestIdx = 0, bestSim = -1;
                  medoids.forEach((m, idx) => {
                    const sim = seqMatch(g.memberShifts[n], g.memberShifts[m]);
                    if (sim > bestSim) { bestSim = sim; bestIdx = idx; }
                  });
                  groups[bestIdx].names.push(n);
                });

                // cycleStart minden variációhoz a medoid szekvenciájából
                if (dateInfo && finalPattern && finalPattern.length >= 5) {
                  const epoch = new Date(2000, 0, 1);
                  const monthStart = new Date(dateInfo.year, dateInfo.month - 1, 1);
                  const baseOffset = Math.round((monthStart - epoch) / 86400000);
                  const plen = finalPattern.length;
                  groups.forEach(grp => {
                    const leadSeq = g.memberShifts[grp.medoid];
                    const dated = [];
                    for (let d = 0; d < leadSeq.length; d++) {
                      const s = leadSeq[d];
                      if (['F','S','N','X'].includes(s)) dated.push({off: d, shift: s});
                    }
                    let bestStart = null, bestHits = -1;
                    for (let startOff = 0; startOff < plen; startOff++) {
                      let hits = 0;
                      for (const e of dated) {
                        const idx = ((e.off + startOff) % plen + plen) % plen;
                        if (finalPattern[idx] === e.shift) hits++;
                      }
                      if (hits > bestHits) { bestHits = hits; bestStart = startOff; }
                    }
                    let csISO = null;
                    if (bestStart !== null && dated.length) {
                      const csEpoch = new Date(epoch.getTime() + (baseOffset - bestStart) * 86400000);
                      csISO = csEpoch.toISOString();
                      grp.names.forEach(mName => { memberCycleStarts[mName] = csISO; });
                    }
                    memberVariants.push({
                      names: grp.names.slice().sort((a,b)=>a.localeCompare(b)),
                      rawShifts: leadSeq,
                      cycleStart: csISO
                    });
                  });
                } else {
                  groups.forEach(grp => {
                    memberVariants.push({
                      names: grp.names.slice().sort((a,b)=>a.localeCompare(b)),
                      rawShifts: g.memberShifts[grp.medoid],
                      cycleStart: null
                    });
                  });
                }
              }
            }

            result.push({
              id:g.id, dept:g.dept, names:g.names,
              blocks: finalBlocks,
              pattern: finalPattern,
              confidence: det?det.confidence:0, source:sourceName,
              dateInfo, monthlyData,
              _cycleStart: cycleStart,
              memberCycleStarts,
              memberVariants
            });
          }
          return result;
        }

        // ── DB merge ──
        function rotDbMerge(groups) {
          let added=0, updated=0;
          groups.forEach(g => {
            const key = g.dept+'_'+g.id;
            if (!rotDB[key]) {
              rotDB[key]={id:g.id,dept:g.dept,names:g.names,blocks:g.blocks,pattern:g.pattern,confidence:g.confidence,
                          _cycleStart: g._cycleStart||null, monthlyData: g.monthlyData||{},
                          memberCycleStarts: g.memberCycleStarts||{}, memberVariants: g.memberVariants||[]};
              added++;
            } else {
              const ns=new Set([...rotDB[key].names,...g.names]); rotDB[key].names=[...ns];
              // Havi adatok egyesítése
              if (!rotDB[key].monthlyData) rotDB[key].monthlyData={};
              if (g.monthlyData) Object.assign(rotDB[key].monthlyData, g.monthlyData);
              // memberCycleStarts egyesítése (új hónap adata felülírja a régit, ha van)
              if (!rotDB[key].memberCycleStarts) rotDB[key].memberCycleStarts={};
              if (g.memberCycleStarts) Object.assign(rotDB[key].memberCycleStarts, g.memberCycleStarts);
              // memberVariants: legújabb hónap 3-variációs ajánlata felülírja a régit
              if (g.memberVariants && g.memberVariants.length) rotDB[key].memberVariants = g.memberVariants;
              // Ha elég havi adat áll rendelkezésre, dátum-alapú ciklus detektálás
              const monthCount = Object.keys(rotDB[key].monthlyData).length;
              if (monthCount >= 2 && typeof detectCycleFromMonthlyData === 'function') {
                const det = detectCycleFromMonthlyData(rotDB[key].monthlyData);
                if (det && det.confidence >= 85) {
                  rotDB[key].blocks = det.blocks;
                  rotDB[key].pattern = det.pattern;
                  rotDB[key].confidence = det.confidence;
                  rotDB[key]._cycleStart = det._cycleStart;
                } else if (g.pattern.length > 0) {
                  rotDB[key].blocks=g.blocks; rotDB[key].pattern=g.pattern; rotDB[key].confidence=g.confidence;
                }
              } else if (g.pattern.length>0) {
                rotDB[key].blocks=g.blocks; rotDB[key].pattern=g.pattern; rotDB[key].confidence=g.confidence;
              }
              // cycleStart átvétele ha még nincs
              if (g._cycleStart && !rotDB[key]._cycleStart) rotDB[key]._cycleStart = g._cycleStart;
              updated++;
            }
          });
          return {added,updated};
        }

        // ── Sub-variant lekérés: mindig a tárolt 3 variációt adja vissza ──
        // (a variációkat a PDF-importnál már kiszámoltuk – itt csak visszaadjuk,
        //  és a usernév-egyezést jelezzük, hogy a picker kiemelhesse)
        function detectSubVariants(g, searchName) {
          const variants = (g.memberVariants || []).filter(v => v.names && v.names.length);
          if (variants.length < 2) return [];
          const norm = s => (s||'').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
          const qn = norm(searchName);
          return variants.map(v => ({
            cycleStart: v.cycleStart ? new Date(v.cycleStart) : null,
            count: v.names.length,
            names: v.names,
            rawShifts: v.rawShifts,
            nameMatch: qn ? v.names.some(n => norm(n).includes(qn) || qn.includes(norm(n))) : false
          })).sort((a,b)=>{
            if (a.nameMatch !== b.nameMatch) return a.nameMatch ? -1 : 1;
            return b.count - a.count;
          });
        }

        // ── UI helpers ──
        function rotSetStatus(msg, type='info') {
          const el = document.getElementById('rotStatus');
          if (!el) return;
          el.textContent=msg; el.style.display='block';
          const colors = {
            info:  'rgba(95,158,247,0.12)',
            ok:    'rgba(74,222,128,0.1)',
            error: 'rgba(255,80,80,0.1)',
            warn:  'rgba(255,179,71,0.1)'
          };
          const borderColors = {
            info:  'rgba(95,158,247,0.25)',
            ok:    'rgba(74,222,128,0.25)',
            error: 'rgba(255,80,80,0.25)',
            warn:  'rgba(255,179,71,0.25)'
          };
          el.style.background=colors[type]||colors.info;
          el.style.border=`1px solid ${borderColors[type]||borderColors.info}`;
          el.style.color='var(--text)';
        }

        // ── Csoport lista renderelés ──
        window.rotRenderGroups = function(filter) {
          const list = document.getElementById('rotGroupList');
          if (!list) return;
          list.innerHTML='';
          const all = Object.values(rotDB);
          // Ékezetmentes, vesszőmentes, fordított sorrendű névkeresés
          const q = nameNorm((filter||'').trim());
          const qParts = q.split(' ').filter(Boolean);
          const qRev = qParts.slice().reverse().join(' ');

          function rotNameMatch(name) {
            const n = nameNorm(name);
            // Összes query-szó megvan
            if (qParts.every(w => n.includes(w))) return true;
            // Fordított sorrendű query szavai megvannak
            const qrParts = qRev.split(' ').filter(Boolean);
            if (qrParts.every(w => n.includes(w))) return true;
            return false;
          }

          const filtered = q ? all.filter(g =>
            nameNorm(g.id).includes(q) ||
            nameNorm(g.dept).includes(q) ||
            g.names.some(n => rotNameMatch(n))
          ) : all;
          filtered.sort((a,b)=>a.id.localeCompare(b.id,undefined,{numeric:true}));
          filtered.forEach(g => {
            const card = document.createElement('div');
            card.className='rot-group-card'+(rotSelected&&rotSelected.id===g.id?' rot-selected':'');
            const patPrev = g.pattern.slice(0,12).map(s=>{
              const c={F:'#ffb347',S:'#4dd6f0',N:'#a78bfa',X:'#606070'}[s]||'#888';
              return `<span style="color:${c};font-weight:700;font-family:monospace;font-size:11px;">${s}</span>`;
            }).join(' ');
            card.innerHTML=`
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px;">
                <span style="font-size:13px;font-weight:700;font-family:monospace;color:var(--text);">${g.id}</span>
                <span style="font-size:10px;color:var(--text2);font-family:monospace;">${g.dept}</span>
                <span style="font-size:10px;color:${g.confidence>=75?'#4ade80':g.confidence>=50?'#ffb347':'#ff6a6a'};font-family:monospace;">${g.confidence}%</span>
              </div>
              <div style="font-size:10px;color:var(--text2);margin-bottom:4px;">${g.names.slice(0,3).join(', ')}${g.names.length>3?' +'+( g.names.length-3):''}</div>
              <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">${patPrev}${g.pattern.length>12?'<span style="color:var(--text2);font-size:10px;">…</span>':''}<span style="font-size:9px;font-family:monospace;background:rgba(95,158,247,0.15);color:var(--accent);padding:1px 5px;border-radius:4px;">${g.pattern.length}d</span></div>`;
            card.addEventListener('click',()=>{
              document.querySelectorAll('.rot-group-card').forEach(c=>c.classList.remove('rot-selected'));
              card.classList.add('rot-selected');
              rotSelectGroup(g);
            });
            list.appendChild(card);
          });
          if (!filtered.length) {
            list.innerHTML=`<div style="font-size:11px;color:var(--text2);text-align:center;padding:12px;font-family:monospace;">${(window._currentTranslations&&window._currentTranslations.noResults)||'Nincs találat'}</div>`;
          }
        };

        function rotSelectGroup(g) {
          rotSelected=g; rotPhaseOffset=null;

          const hasMonthlyData = g.monthlyData && Object.keys(g.monthlyData).length > 0;
          const hasCycleStart = g._cycleStart && !isNaN(new Date(g._cycleStart));

          // ── Sub-variant ellenőrzés: a csoporton belül mindig 3 variációt ajánlunk ──
          const searchInput = document.getElementById('rotNameSearch');
          const searchName = searchInput ? searchInput.value : '';
          const subVariants = detectSubVariants(g, searchName);
          if (subVariants.length >= 2) {
            rotShowSubVariantPicker(g, subVariants);
            return;
          }

          if (hasCycleStart) {
            const cs = g._cycleStart instanceof Date ? g._cycleStart : new Date(g._cycleStart);
            rotSelected._cycleStart = cs;
            try {
              localStorage.setItem(LS.cycleStart, cs.toISOString());
              localStorage.setItem(LS.userShiftGroup, g.id || '');
              localStorage.setItem(LS.groupPattern, JSON.stringify(g.pattern || []));
              localStorage.setItem(LS.groupDept, g.dept || '');
            } catch(e) {}
            setTimeout(function(){ if(window._arUpdateBtnVisibility) window._arUpdateBtnVisibility(); }, TIMING.AR_BTN_UPDATE);
          }

          if (hasMonthlyData || hasCycleStart) {
            document.getElementById('rotAnchorSection').style.display='none';
            document.getElementById('rotPhaseResult').style.display='none';
            const gs=document.getElementById('rotGenSection');
            gs.style.display='block';

            // Időtartomány: legkorábbi ismert hónap elejétől 6 hónapra előre
            let rangeStart = new Date(); rangeStart.setHours(0,0,0,0);
            let rangeEnd = new Date(rangeStart);
            if (hasMonthlyData) {
              const months = Object.keys(g.monthlyData).sort();
              const [y0,m0] = months[0].split('-').map(Number);
              rangeStart = new Date(y0, m0-1, 1);
              // Vége: ha van ciklus → 6 hónap előre, ha nincs → csak az ismert hónapok vége
              const [yL,mL] = months[months.length-1].split('-').map(Number);
              const lastMonthEnd = new Date(yL, mL, 0); // hónap utolsó napja
              if (hasCycleStart) {
                rangeEnd = new Date(rangeStart);
                rangeEnd.setMonth(rangeEnd.getMonth()+6);
              } else {
                rangeEnd = lastMonthEnd;
              }
            } else if (hasCycleStart) {
              rangeEnd.setMonth(rangeEnd.getMonth()+6);
            }
            rotCal.startDate=rangeStart; rotCal.endDate=rangeEnd;
            rotCal.year=rangeStart.getFullYear(); rotCal.month=rangeStart.getMonth();
            rotUpdateRangeDisplay();
            rotRenderCalGrid();
            const gb=document.getElementById('rotGenBtn');
            if(gb){gb.disabled=false;gb.style.opacity='1';}
            const monthCount = hasMonthlyData ? Object.keys(g.monthlyData).length : 0;
            const cycleNote = hasCycleStart ? `, ciklus felismerve (${g.confidence}%)` : ' – több PDF = pontosabb jövő generálás';
            rotSetStatus(((window._currentTranslations&&window._currentTranslations.rotMonthsReady)||'{n} ismert hónap – kész az importáláshoz').replace('{n}', monthCount) + cycleNote, 'ok');
            gs.scrollIntoView({behavior:'smooth',block:'nearest'});
            return;
          }

          // Nincs semmilyen adat: kézi referencia dátum bekérése
          document.getElementById('rotAnchorSection').style.display='block';
          document.getElementById('rotPhaseResult').style.display='none';
          document.getElementById('rotGenSection').style.display='none';
          const genBtn=document.getElementById('rotGenBtn'); if(genBtn) genBtn.disabled=true;
          if (!document.getElementById('rotAnchorDate').value) {
            document.getElementById('rotAnchorDate').value=new Date().toISOString().split('T')[0];
          }
          rotCheckAnchorReady();
        }

        // ── Sub-variant mini-naptáras választó ──
        // Mindig 3 variációt ajánlunk fel csoportonként; mindegyik egy mini-naptárral
        // jeleníti meg az AKTUÁLIS hónapot a saját fázisa szerint. Ha névegyezés van,
        // az a kártya kiemelve (felül, kiemelt kerettel) jelenik meg.
        function rotShowSubVariantPicker(g, variants) {
          document.getElementById('rotAnchorSection').style.display='none';
          document.getElementById('rotPhaseResult').style.display='none';
          document.getElementById('rotGenSection').style.display='none';

          let host = document.getElementById('rotSubVariantSection');
          if (!host) {
            host = document.createElement('div');
            host.id = 'rotSubVariantSection';
            host.style.marginBottom = '10px';
            host.style.padding = '12px';
            host.style.background = 'var(--surface2)';
            host.style.border = '1px solid var(--border)';
            host.style.borderRadius = '12px';
            const gs = document.getElementById('rotGenSection');
            gs.parentNode.insertBefore(host, gs);
          }
          host.style.display = 'block';

          const SHIFT_COLOR = {F:'#ffb347',S:'#4dd6f0',N:'#a78bfa',X:'#606070'};
          const today = new Date();
          const calYear = today.getFullYear(), calMonth = today.getMonth();
          const daysInMonth = new Date(calYear, calMonth+1, 0).getDate();
          const firstWeekday = new Date(calYear, calMonth, 1).getDay(); // 0=Sun

          function buildMiniCalHtml(cycleStart) {
            if (!cycleStart) return '<div style="font-size:10px;color:var(--text2);">Nincs elég adat a naptárhoz</div>';
            const cells = [];
            // üres cellák a hónap eleje előtt (hétfő-induló hét: vasárnap=0 → balra 6)
            const leadEmpty = (firstWeekday + 6) % 7;
            for (let i=0;i<leadEmpty;i++) cells.push('<div></div>');
            for (let day=1; day<=daysInMonth; day++) {
              const d = new Date(calYear, calMonth, day);
              const diff = Math.round((d - cycleStart)/86400000);
              const plen = g.pattern && g.pattern.length ? g.pattern.length : 1;
              const idx = ((diff % plen) + plen) % plen;
              const s = (g.pattern && g.pattern[idx]) || 'X';
              const isToday = day === today.getDate();
              cells.push(`<div style="text-align:center;font-size:9px;font-family:monospace;padding:2px 0;border-radius:3px;${isToday?'border:1px solid var(--accent);':''}">
                <div style="color:var(--text2);">${day}</div>
                <div style="color:${SHIFT_COLOR[s]||'#888'};font-weight:700;">${s}</div>
              </div>`);
            }
            return `<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:1px;">${cells.join('')}</div>`;
          }

          const MNL = MN_HU || ['Január','Február','Március','Április','Május','Június','Július','Augusztus','Szeptember','Október','November','December'];
          let html = `<div style="font-size:10px;color:var(--text2);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:8px;font-family:monospace;">
            ${g.id} – válaszd ki, melyik beosztás a tiéd (${MNL[calMonth]} ${calYear}):
          </div>`;

          // Névegyezéses variáció előre, kiemelve
          variants.forEach((v, idx) => {
            const highlight = v.nameMatch;
            html += `
              <div class="rot-subvariant-card" data-idx="${idx}" style="margin-bottom:8px;padding:10px;background:var(--surface);border:${highlight?'2px solid var(--accent)':'1.5px solid var(--border)'};border-radius:10px;cursor:pointer;${highlight?'box-shadow:0 0 0 1px var(--accent);':''}">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                  <span style="font-size:12px;font-weight:700;color:${highlight?'var(--accent)':'var(--text)'};">${highlight?'⭐ ':''}Variáció ${idx+1}</span>
                  <span style="font-size:10px;color:var(--text2);font-family:monospace;">${v.count} fő</span>
                </div>
                ${buildMiniCalHtml(v.cycleStart)}
                <div style="font-size:10px;color:var(--text2);margin-top:6px;">${v.names.slice(0,4).join(', ')}${v.names.length>4?' +'+(v.names.length-4):''}</div>
              </div>`;
          });

          host.innerHTML = html;
          host.querySelectorAll('.rot-subvariant-card').forEach(card => {
            card.addEventListener('click', () => {
              host.querySelectorAll('.rot-subvariant-card').forEach(c=>{c.style.borderColor='var(--border)';c.style.boxShadow='none';});
              card.style.borderColor = 'var(--accent)';
              const idx = parseInt(card.dataset.idx, 10);
              rotConfirmSubVariant(g, variants[idx]);
            });
          });

          host.scrollIntoView({behavior:'smooth', block:'nearest'});
        }

        // A user kiválasztotta a saját fázisát → folytatjuk a generálási folyamatot ezzel a cycleStart-tal
        function rotConfirmSubVariant(g, variant) {
          const host = document.getElementById('rotSubVariantSection');
          if (host) host.style.display = 'none';

          const gOverride = Object.assign({}, g, { _cycleStart: variant.cycleStart });
          rotSelected = gOverride;
          rotPhaseOffset = null;

          const hasMonthlyData = gOverride.monthlyData && Object.keys(gOverride.monthlyData).length > 0;
          const cs = variant.cycleStart instanceof Date ? variant.cycleStart : new Date(variant.cycleStart);
          rotSelected._cycleStart = cs;
          try {
            localStorage.setItem(LS.cycleStart, cs.toISOString());
            localStorage.setItem(LS.userShiftGroup, gOverride.id || '');
            localStorage.setItem(LS.groupPattern, JSON.stringify(gOverride.pattern || []));
            localStorage.setItem(LS.groupDept, gOverride.dept || '');
          } catch(e) {}
          setTimeout(function(){ if(window._arUpdateBtnVisibility) window._arUpdateBtnVisibility(); }, TIMING.AR_BTN_UPDATE);

          document.getElementById('rotAnchorSection').style.display='none';
          document.getElementById('rotPhaseResult').style.display='none';
          const gs=document.getElementById('rotGenSection');
          gs.style.display='block';

          let rangeStart = new Date(); rangeStart.setHours(0,0,0,0);
          let rangeEnd = new Date(rangeStart);
          if (hasMonthlyData) {
            const months = Object.keys(gOverride.monthlyData).sort();
            const [y0,m0] = months[0].split('-').map(Number);
            rangeStart = new Date(y0, m0-1, 1);
            rangeEnd = new Date(rangeStart);
            rangeEnd.setMonth(rangeEnd.getMonth()+6);
          } else {
            rangeEnd.setMonth(rangeEnd.getMonth()+6);
          }
          rotCal.startDate=rangeStart; rotCal.endDate=rangeEnd;
          rotCal.year=rangeStart.getFullYear(); rotCal.month=rangeStart.getMonth();
          rotUpdateRangeDisplay();
          rotRenderCalGrid();
          const gb=document.getElementById('rotGenBtn');
          if(gb){gb.disabled=false;gb.style.opacity='1';}
          rotSetStatus(((window._currentTranslations&&window._currentTranslations.rotPhaseSelected)||'Fázis kiválasztva ({n} fős variáció) – kész az importáláshoz').replace('{n}', variant.count), 'ok');
          gs.scrollIntoView({behavior:'smooth',block:'nearest'});
        }

        window.rotSelectShift = function(btn) {
          document.querySelectorAll('.rot-pill').forEach(p=>p.classList.remove('rot-active'));
          btn.classList.add('rot-active');
          rotAnchorShift=btn.dataset.rs;
          rotCheckAnchorReady();
        };

        function rotCheckAnchorReady() {
          const hasDate=!!document.getElementById('rotAnchorDate').value;
          const hasShift=!!rotAnchorShift;
          const btn=document.getElementById('rotCalcPhaseBtn');
          if (btn) {
            btn.disabled=!(hasDate&&hasShift);
            btn.style.opacity=hasDate&&hasShift?'1':'0.4';
            btn.style.background=hasDate&&hasShift?'var(--accent)':'var(--surface)';
            btn.style.color=hasDate&&hasShift?'#fff':'var(--text2)';
            btn.style.borderColor=hasDate&&hasShift?'transparent':'var(--border)';
          }
        }

        document.getElementById('rotAnchorDate').addEventListener('change', rotCheckAnchorReady);

        window.rotCalcPhase = function() {
          if (!rotSelected||!rotAnchorShift) return;
          const dateStr=document.getElementById('rotAnchorDate').value;
          if (!dateStr) return;
          const anchorDate=new Date(dateStr+'T00:00:00');
          const pattern=rotSelected.pattern;
          if (!pattern.length) { rotSetStatus((window._currentTranslations&&window._currentTranslations.rotNoCyclePattern)||'⚠️ Nincs ciklus mintáz a csoporthoz','warn'); return; }

          const matches=[];
          for (let i=0;i<pattern.length;i++) if (pattern[i]===rotAnchorShift) matches.push(i);
          if (!matches.length) { rotSetStatus(`⚠️ A ${rotAnchorShift} nem szerepel a ciklusban`,'warn'); return; }

          const resultDiv=document.getElementById('rotPhaseResult');
          if (matches.length===1) {
            rotApplyPhase(matches[0], anchorDate, pattern, resultDiv);
          } else {
            // Több lehetséges fázis – chipek
            resultDiv.innerHTML=`<strong>${matches.length} ${(window._currentTranslations&&window._currentTranslations.rwPossiblePhases)||'lehetséges fázis – válassz:'}<br><br>` +
              matches.map(o=>{
                const next4=Array.from({length:4},(_,j)=>{
                  const s=pattern[(o+1+j)%pattern.length];
                  const c={F:'#ffb347',S:'#4dd6f0',N:'#a78bfa',X:'#606070'}[s]||'#888';
                  return `<span style="color:${c};font-weight:700;">${s}</span>`;
                }).join(' ');
                return `<span data-offset="${o}" style="cursor:pointer;display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:7px;background:var(--surface2);border:1.5px solid var(--border);margin:3px;font-size:11px;color:var(--text);">
                  Poz. ${o+1}: <span style="color:${rotAnchorShift==='F'?'#ffb347':rotAnchorShift==='S'?'#4dd6f0':'#a78bfa'}">${rotAnchorShift}</span> → ${next4}
                </span>`;
              }).join('');
            resultDiv.style.display='block';
            resultDiv.querySelectorAll('[data-offset]').forEach(el=>{
              el.addEventListener('click',()=>{
                resultDiv.querySelectorAll('[data-offset]').forEach(e=>e.style.borderColor='var(--border)');
                el.style.borderColor='#4ade80';
                rotApplyPhase(parseInt(el.dataset.offset), anchorDate, pattern, null);
              });
            });
          }
          resultDiv.style.display='block';
        };

        function rotApplyPhase(offset, anchorDate, pattern, resultDiv) {
          rotPhaseOffset=offset;
          rotSelected._cycleStart=rotCalcCycleStart(anchorDate, offset);
          // Mentés localStorage-ba a ⟳ auto-rot számára
          try {
            localStorage.setItem(LS.cycleStart, rotSelected._cycleStart.toISOString());
            localStorage.setItem(LS.userShiftGroup, rotSelected.id || '');
            localStorage.setItem(LS.groupPattern, JSON.stringify(rotSelected.pattern || []));
            localStorage.setItem(LS.groupDept, rotSelected.dept || '');
          } catch(e) {}
          setTimeout(function(){ if(window._arUpdateBtnVisibility) window._arUpdateBtnVisibility(); }, TIMING.AR_BTN_UPDATE);
          // Előnézet
          const prev=Array.from({length:5},(_,i)=>{
            const d=new Date(anchorDate); d.setDate(d.getDate()+i);
            const s=rotShiftOnDate(pattern,rotSelected._cycleStart,d);
            const c={F:'#ffb347',S:'#4dd6f0',N:'#a78bfa',X:'#606070'}[s]||'#888';
            return `<span style="color:${c};font-weight:700;">${d.getDate()}.${d.getMonth()+1}:${s}</span>`;
          }).join('  ');
          if (resultDiv) {
            resultDiv.innerHTML=`✓ ${(window._currentTranslations&&window._currentTranslations.rwCyclePos)||'Cikluspozíció:'} <strong>${offset+1}/${pattern.length}</strong><br>${(window._currentTranslations&&window._currentTranslations.rwNext5Days)||'Következő 5 nap:'} ${prev}`;
          }
          // Generáló szekció megjelenítése
          const gs=document.getElementById('rotGenSection');
          gs.style.display='block';
          const today=new Date(); today.setHours(0,0,0,0);
          const sixM=new Date(today); sixM.setMonth(sixM.getMonth()+6);
          rotCal.startDate=today; rotCal.endDate=sixM;
          rotCal.year=today.getFullYear(); rotCal.month=today.getMonth();
          rotUpdateRangeDisplay();
          rotRenderCalGrid();
          const gb=document.getElementById('rotGenBtn');
          if(gb){gb.disabled=false;gb.style.opacity='1';}
          gs.scrollIntoView({behavior:'smooth',block:'nearest'});
        }

        // ── Mini naptár ──
        window.rotCalPrev = function() {
          rotCal.month--; if(rotCal.month<0){rotCal.month=11;rotCal.year--;} rotRenderCalGrid();
        };
        window.rotCalNext = function() {
          rotCal.month++; if(rotCal.month>11){rotCal.month=0;rotCal.year++;} rotRenderCalGrid();
        };

        function rotRenderCalGrid() {
          const grid=document.getElementById('rotCalGrid');
          if (!grid) return;
          grid.innerHTML='';
          document.getElementById('rotCalTitle').textContent=MN_HU[rotCal.month]+' '+rotCal.year;
          DN_SHORT.forEach((d,i)=>{
            const h=document.createElement('div');
            h.textContent=d;
            h.style.cssText=`text-align:center;font-size:9px;padding:2px 0;color:${i>=5?'var(--accent)':'var(--text2)'};font-family:monospace;`;
            grid.appendChild(h);
          });
          const offset=(new Date(rotCal.year,rotCal.month,1).getDay()+6)%7;
          for(let i=0;i<offset;i++) grid.appendChild(document.createElement('div'));
          const days=new Date(rotCal.year,rotCal.month+1,0).getDate();
          for(let d=1;d<=days;d++) {
            const date=new Date(rotCal.year,rotCal.month,d);
            const isStart=rotCal.startDate&&rotDKey(date)===rotDKey(rotCal.startDate);
            const isEnd=rotCal.endDate&&rotDKey(date)===rotDKey(rotCal.endDate);
            const inRange=rotCal.startDate&&rotCal.endDate&&date>rotCal.startDate&&date<rotCal.endDate;
            const isWe=((date.getDay()+6)%7)>=5;
            const cell=document.createElement('div');
            cell.textContent=d;
            let bg='transparent',color=isWe?'var(--accent)':'var(--text)',fw='normal',br='6px';
            if(isStart||isEnd){bg='var(--accent)';color='#fff';fw='700';}
            else if(inRange){bg='rgba(95,158,247,0.18)';br='2px';}
            cell.style.cssText=`text-align:center;padding:5px 2px;cursor:pointer;border-radius:${br};background:${bg};color:${color};font-size:12px;font-weight:${fw};`;
            cell.addEventListener('click',()=>{
              const clicked=new Date(rotCal.year,rotCal.month,d);
              if(!rotCal.startDate||(rotCal.startDate&&rotCal.endDate)||clicked<=rotCal.startDate){
                rotCal.startDate=clicked;rotCal.endDate=null;
              } else { rotCal.endDate=clicked; }
              rotUpdateRangeDisplay();
              rotRenderCalGrid();
            });
            grid.appendChild(cell);
          }
        }

        function rotUpdateRangeDisplay() {
          const rs=document.getElementById('rotRangeStart');
          const re=document.getElementById('rotRangeEnd');
          if(rs){rs.textContent='Kezdet: '+rotDLabel(rotCal.startDate);rs.style.borderColor=rotCal.startDate?'var(--accent)':'var(--border)';}
          if(re){re.textContent=(t('endLabel')||'Vége: ')+rotDLabel(rotCal.endDate);re.style.borderColor=rotCal.endDate?'#4ade80':'var(--border)';}
        }

        // ── Generálás + importálás a CHRONOS state-be ──
        window.rotGenerate = function() {
          if(!rotSelected||!rotCal.startDate||!rotCal.endDate){
            rotSetStatus((window._currentTranslations&&window._currentTranslations.rotSelectGroupPeriod)||'⚠️ Válassz csoportot és időszakot!','warn'); return;
          }
          let imported=0, skipped=0;

          // ── 1. lépés: ismert hónapok direktben a PDF adatból ──
          // A monthlyData[YYYY-MM] = rawShifts tömb, ahol index = nap-1
          // Ez 100% pontos, nem kell ciklus hozzá
          const monthlyData = rotSelected.monthlyData || {};
          const importedDays = new Set(); // nyilvántartjuk mely napokat töltöttük fel direktben

          for (const [ym, shifts] of Object.entries(monthlyData)) {
            const [y, m] = ym.split('-').map(Number);
            for (let d = 0; d < shifts.length; d++) {
              const date = new Date(y, m-1, d+1);
              if (date < rotCal.startDate || date > rotCal.endDate) continue;
              const s = shifts[d];
              if (!['F','S','N'].includes(s)) continue; // X és SKIP kihagyva
              const shiftId = rotShiftToId(s);
              if (!shiftId) continue;
              const key = `${y}-${m}-${d+1}`;
              importedDays.add(key);
              if (!state.schedules[key]) state.schedules[key] = [];
              if (!state.schedules[key].includes(shiftId)) {
                state.schedules[key].push(shiftId);
                imported++;
              } else { skipped++; }
            }
          }

          // ── 2. lépés: jövőbeli napok ciklussal – csak ha van megbízható cycleStart ──
          // Csak olyan napokra fut ahol nincs direkt PDF adat
          const pattern = rotSelected.pattern;
          const cycleStart = rotSelected._cycleStart;
          const hasCycle = cycleStart && pattern && pattern.length > 0;

          if (hasCycle) {
            let cur = new Date(rotCal.startDate);
            while (cur <= rotCal.endDate) {
              const key = `${cur.getFullYear()}-${cur.getMonth()+1}-${cur.getDate()}`;
              if (!importedDays.has(key)) {
                // Nincs direkt adat erre a napra → ciklusból számoljuk
                const shiftCode = rotShiftOnDate(pattern, cycleStart, cur);
                const shiftId = rotShiftToId(shiftCode);
                if (shiftId) {
                  if (!state.schedules[key]) state.schedules[key] = [];
                  if (!state.schedules[key].includes(shiftId)) {
                    state.schedules[key].push(shiftId);
                    imported++;
                  } else { skipped++; }
                }
              }
              cur.setDate(cur.getDate()+1);
            }
          }

          saveState();
          state.year=rotCal.startDate.getFullYear();
          state.month=rotCal.startDate.getMonth();
          renderCalendar(); updateVacation(); updateStats();
          const days=Math.round((rotCal.endDate-rotCal.startDate)/86400000)+1;
          const cycleNote = hasCycle ? '' : ' (csak ismert hónapok – több PDF-fel pontosabb jövő generálás)';
          rotSetStatus(((window._currentTranslations&&window._currentTranslations.rotImported)||'{n} nap importálva ({total} napból, {skipped} már volt)').replace('{n}', imported).replace('{total}', days).replace('{skipped}', skipped) + cycleNote, 'ok');
          const gb=document.getElementById('rotGenBtn');
          if(gb){gb.textContent=t('importedDoneBtn')||'✅ Importálva!';gb.disabled=true;gb.style.opacity='0.6';}
          setTimeout(()=>{
            window.closePdfImport();
            const calBtn = document.querySelector('.nav-item[data-view="calendar"]');
            if (calBtn) calBtn.click();
          }, 1200);
        };

        // ── Integrálás a processAllFiles pipeline-ba ──
        // Az eredeti processAllFiles lefutása után futtatjuk ezt
        const _origProcessAllFiles = window._rotOrigProcessAllFiles;

        // Publikus API: PDF szövegek rotáció elemzése
        window.rotAnalyzePdfTexts = function(texts) {
          // rotDB NEM törlődik – PDF-ek halmozódnak!
          const allGroups=[];
          texts.forEach(({text,fileName})=>{
            // Dátuminfó kinyerése a PDF-ből → pontos fázis kiszámításhoz
            const dateInfo = (typeof pdfDetectMonthYear === 'function') ? pdfDetectMonthYear(text) : null;
            const groups=rotParsePdfGroups(text,fileName,dateInfo);
            allGroups.push(...groups);
          });
          if(!allGroups.length) {
            document.getElementById('rotSection').style.display='none';
            return;
          }
          rotDbMerge(allGroups);
          // ── PDF névtérkép feltöltése a rotDB tartalmából ──
          // Így a _checkSmartRot 2. lépése (PDF névtérkép) is megtalálja a neveket
          window._pdfNameToGroupMap = window._pdfNameToGroupMap || {};
          Object.values(rotDB).forEach(g => {
            g.names.forEach(name => {
              if (!window._pdfNameToGroupMap[name]) window._pdfNameToGroupMap[name] = [];
              if (!window._pdfNameToGroupMap[name].includes(g.id))
                window._pdfNameToGroupMap[name].push(g.id);
            });
          });
          document.getElementById('rotSection').style.display='block';
          document.getElementById('rotGroupSection').style.display='block';
          rotRenderGroups('');
          rotSetStatus((window._currentTranslations&&window._currentTranslations.rcGroupsDetected||'🔄 {n} csoport felismerve – válaszd ki a tiédet a rotáció importáláshoz').replace('{n}', allGroups.length), 'info');
          // Smart rotation ajánlat aktiválása
          window._rotDBSnapshot = rotDB;
          window._checkSmartRot && window._checkSmartRot();
        };

        // ── Globális exportok a Smart Rotation logikához ──
        window._rotGetDB = () => rotDB;
        window._rotGetSelected = () => rotSelected;
        window._rotSelectGroupById = function(deptId) {
          const g = rotDB[deptId];
          if (g) rotSelectGroup(g);
        };
        window._rotShiftOnDateFn = rotShiftOnDate;
        window._rotCalcCycleStartFn = rotCalcCycleStart;
        window._rotShiftToIdFn = rotShiftToId;
        window._rotSetCalRange = function(startDate, endDate) {
          rotCal.startDate = startDate;
          rotCal.endDate = endDate;
          rotCal.year = startDate.getFullYear();
          rotCal.month = startDate.getMonth();
          rotUpdateRangeDisplay();
          rotRenderCalGrid();
          const gb = document.getElementById('rotGenBtn');
          if (gb) { gb.disabled = false; gb.style.opacity = '1'; }
        };
        window._rotGenerateFn = window.rotGenerate;

      })(); // end rotation IIFE

      // Smart Rotation kikapcsolva – Import gomb közvetlenül jelenik meg
      window._checkSmartRot = null;

      window.pdfDoImport = function(forceOverwrite = false) {
        // Ha névkeresés még folyamatban van (nem lett kiválasztva chip), 
        // automatikusan futtatjuk a keresést a beírt névvel
        const hasPending = pdfAllMonths.some(m => m._nameSearchPending);
        if (hasPending) {
          const nameInput = document.getElementById('pdfNameInput');
          const nameVal = nameInput && nameInput.value.trim();
          if (nameVal && typeof pdfSearchName === 'function') {
            // Szinkron keresés után újra hívjuk az importot
            pdfSearchName();
            // pdfSearchName async – várunk 800ms-t amíg feldolgoz
            setTimeout(() => window.pdfDoImport(forceOverwrite), TIMING.PDF_SEARCH_WAIT);
            return;
          } else if (!nameVal) {
            pdfSetStatus(t('pdfSelectNameFirst')||'⚠️ Először válassz nevet a listából vagy írd be a nevedet!', 'warning');
            document.getElementById('pdfNameSection').style.display = 'block';
            return;
          }
        }

        const checked = [...document.querySelectorAll('#pdfMonthItems input[type=checkbox]')]
          .filter(cb => cb.checked)
          .map(cb => parseInt(cb.dataset.idx));

        if (checked.length === 0) {
          pdfSetStatus(t('selectAtLeastOneMonth'), 'warning');
          return;
        }

        // Csak a valódi (nem placeholder) hónapok
        const allMonths = pdfMode === 'zeus' ? pdfZeusMonths : pdfAllMonths;
        const months = allMonths.filter(m => !m._nameSearchPending)
          .sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);

        // ── Felülírás ellenőrzés ──
        if (!forceOverwrite) {
          const conflictMonths = [];
          checked.forEach(idx => {
            const monthData = months[idx];
            if (!monthData) return;
            const prefix = `${monthData.year}-${monthData.month}-`;
            const hasData = Object.keys(state.schedules).some(k => k.startsWith(prefix) && state.schedules[k].length > 0);
            if (hasData) {
              const monthName = ((TRANSLATIONS[state.currentLang]||TRANSLATIONS.de).monthNames||[])[monthData.month-1] || monthData.month;
              conflictMonths.push(`${monthName} ${monthData.year}`);
            }
          });

          if (conflictMonths.length > 0) {
            // Megerősítő dialógus megjelenítése
            const overlay = document.getElementById('pdfOverwriteOverlay');
            if (overlay) {
              document.getElementById('pdfOverwriteList').textContent = conflictMonths.join(', ');

              const isZeus = pdfMode === 'zeus';
              const lang = TRANSLATIONS[state.currentLang] || TRANSLATIONS.de;

              // ZEUS: speciális figyelmeztetés piros gombbal
              document.getElementById('pdfOverwriteIcon').textContent = isZeus ? '🏢' : '⚠️';
              document.getElementById('pdfOverwriteTitle').textContent = isZeus
                ? (lang.overwriteTitleZeus || 'ZEUS Napló felülírás')
                : (t('overwriteTitle') || 'Már vannak műszakok!');
              document.getElementById('pdfOverwriteMsg').textContent = isZeus
                ? (lang.overwriteMsgZeus || 'ZEUS adatok találhatók ezekben a hónapokban:')
                : (t('overwriteMsg') || 'A következő hónap(ok)ban már vannak bejegyzések:');
              document.getElementById('pdfOverwriteQuestion').textContent =
                t('overwriteQuestion') || 'Felülírjuk a meglévő adatokat?';

              // ZEUS note megjelenítése/elrejtése
              document.getElementById('pdfOverwriteZeusNote').style.display = isZeus ? 'block' : 'none';

              // ZEUS: piros felülírás gomb
              const confirmBtn = document.getElementById('pdfOverwriteConfirmBtn');
              confirmBtn.style.background = isZeus ? 'var(--red)' : 'var(--accent)';
              confirmBtn.textContent = isZeus
                ? (lang.overwriteYesZeus || '🏢 Felülírás ZEUS adattal')
                : (t('overwriteYes') || '✅ Felülírás');

              overlay.style.display = 'flex';
              return;
            }
          }
        }

        let total = 0;
        let firstMonth = null;

        checked.forEach(idx => {
          const monthData = months[idx];
          if (!monthData) return;

          // Az első importált hónap – ide navigálunk
          if (!firstMonth) firstMonth = monthData;

          if (pdfMode === 'schichtplan') {
            // Felülírás esetén töröljük az adott hónap meglévő adatait
            if (forceOverwrite) {
              const prefix = `${monthData.year}-${monthData.month}-`;
              Object.keys(state.schedules).forEach(k => { if (k.startsWith(prefix)) delete state.schedules[k]; });
            }

            if (monthData._isSchichtplanJson) {
              // JSON export formátumból importálás (nap → műszakok objektum)
              // Egyedi műszakokat is integráljuk ha vannak
              if (monthData._customShifts && monthData._customShifts.length > 0) {
                if (!state.customShifts) state.customShifts = [];
                monthData._customShifts.forEach(cs => {
                  if (!state.customShifts.find(s => s.id === cs.id)) {
                    state.customShifts.push(cs);
                  }
                });
              }
              Object.entries(monthData.shifts || {}).forEach(([day, shiftArr]) => {
                // Skip public holidays – only manual entry allowed
                if (isPublicHoliday(monthData.year, monthData.month, parseInt(day))) return;
                const key = `${monthData.year}-${monthData.month}-${day}`;
                state.schedules[key] = shiftArr;
                total += shiftArr.length;
              });
            } else {
              (monthData.shifts || []).forEach((shiftId, i) => {
                if (!shiftId) return;
                const day = i + 1;
                // Ünnepnapokat átugorjuk – ott mindig manuális jelölés kell
                if (isPublicHoliday(monthData.year, monthData.month, day)) return;
                const key = `${monthData.year}-${monthData.month}-${day}`;
                if (!state.schedules[key]) state.schedules[key] = [];
                if (!state.schedules[key].includes(shiftId)) {
                  state.schedules[key].push(shiftId);
                  total++;
                }
              });
            }
          } else {
            // ZEUS import – intelligens összehasonlítás a meglévő beosztással
            // Ha a ZEUS nap megegyezik a beosztással → skip
            // Ha a beosztásban nincs erre a napra műszak de ZEUS dolgoztat → Freiwillig
            // Ha eltérés van (beteg, szabadság, félnap) → felülírja

            // Freiwillig megfelelők: Früh→Freiwillig Früh, Spät→Freiwillig Spät, Nacht→Freiwillig Nacht
            const toFreiwillig = {
              'Früh': 'Freiwillig Früh',
              'Spät': 'Freiwillig Spät',
              'Nacht': 'Freiwillig Nacht'
            };
            // Szabadság/betegség jelzők – ezek mindig felülírják a beosztást
            const isAbsence = id => id === 'Urlaub' || id === 'Urlaub1' || id === 'Urlaub2' || id === 'Krank';

            (monthData.days || []).forEach(d => {
              if (!d.shiftId) return;
              const key = `${monthData.year}-${monthData.month}-${d.dayNum}`;
              const existing = state.schedules[key];
              const hasScheduled = existing && existing.length > 0;

              if (isAbsence(d.shiftId)) {
                // Beteg/szabadság: mindig felülírja amit a beosztás mond
                if (!state.schedules[key]) state.schedules[key] = [];
                if (!state.schedules[key].includes(d.shiftId)) {
                  state.schedules[key] = [d.shiftId];
                  total++;
                }
              } else if (d._zkHalf) {
                // Fél napos ZA + munkaidő: [Früh/Spät/Nacht, ZK1/ZK2]
                if (!state.schedules[key]) state.schedules[key] = [];
                const zkArr = [d.shiftId, d._zkHalf];
                state.schedules[key] = zkArr;
                total++;
              } else if (!hasScheduled) {
                // Nincs beosztás erre a napra:
                // - Zeitkonto (nem túlóra) → normál Früh/Spät/Nacht (pótlékok járnak, UE nem)
                // - Zeitkonto + asOvertime → Freiwillig (UE is számolódik)
                // - Valódi UE (DiffNt=0) → Freiwillig
                const freiwilligId = (!d.isZeitkonto || d.asOvertime)
                  ? (toFreiwillig[d.shiftId] || d.shiftId)
                  : d.shiftId;  // Zeitkonto: normál shift, nincs UE pótlék
                state.schedules[key] = [freiwilligId];
                total++;
              } else if (Object.values(toFreiwillig).includes(d.shiftId)) {
                // Freiwillig nap: mindig felülírja a beosztott normál műszakot
                state.schedules[key] = [d.shiftId];
                total++;
              } else if (!existing.includes(d.shiftId)) {
                // Beosztásban más műszak van → felülírja (pl. rotáció eltérés)
                // Megjegyzés: Freiwillig felülírás (pl. Früh→Freiwillig Früh) a megelőző ágban van kezelve
                state.schedules[key] = [d.shiftId];
                total++;
              }
              // Ha a beosztás megegyezik a ZEUS-szal → nem nyúl hozzá
            });
          }
        });

        saveState();

        // ── Importált beosztásból rotáció adat kimentése ──
        // Ha a Smart Rotation már felismerte a csoportot + fázist, tároljuk localStorage-ba
        // hogy a ⟳ gomb azonnal elérhetővé váljon
        (function() {
          try {
            // 1. forrás: _smartSelectedGroup (Smart Rotation IIFE)
            if (window._smartSelectedGroupRef && window._smartSelectedGroupRef._cycleStart) {
              const g = window._smartSelectedGroupRef;
              localStorage.setItem(LS.cycleStart, g._cycleStart.toISOString());
              localStorage.setItem(LS.userShiftGroup, g.id || '');
              localStorage.setItem(LS.groupPattern, JSON.stringify(g.pattern || []));
              localStorage.setItem(LS.groupDept, g.dept || '');
            }
            // 2. forrás: rotSelected (rotation IIFE)
            const rs = window._rotGetSelected ? window._rotGetSelected() : null;
            if (rs && rs._cycleStart && rs.pattern && rs.pattern.length) {
              localStorage.setItem(LS.cycleStart, rs._cycleStart instanceof Date
                ? rs._cycleStart.toISOString() : new Date(rs._cycleStart).toISOString());
              if (rs.id) localStorage.setItem(LS.userShiftGroup, rs.id);
              localStorage.setItem(LS.groupPattern, JSON.stringify(rs.pattern));
              if (rs.dept) localStorage.setItem(LS.groupDept, rs.dept);
            }
            if (window._arUpdateBtnVisibility) setTimeout(window._arUpdateBtnVisibility, TIMING.AR_BTN_UPDATE);
            // Detektálás újrafuttatása az importált adatokra
            if (window._arDetectFromSchedule) setTimeout(window._arDetectFromSchedule, TIMING.AR_DETECT_AFTER_IMPORT);
          } catch(e) {}
        })();

        // ── Navigálás az importált hónapra ──
        if (firstMonth) {
          state.year = firstMonth.year;
          state.month = firstMonth.month - 1; // firstMonth.month 1-alapú, state.month 0-alapú
        }

        // ── Zeus importált hónapok megjelölése ──────────────────────────
        // Ha Zeus PDF-ből importáltunk, a hónapokat zeusImportedMonths-ba jegyezzük
        // Ez alapján dönt a Zeus sync script hogy kell-e visszamenőleg keresni
        checked.forEach(idx => {
          const monthData = months[idx];
          if (!monthData || pdfMode !== 'zeus') return;
          const yearMo = monthData.year + '-' + String(monthData.month).padStart(2, '0');
          if (!state.zeusImportedMonths) state.zeusImportedMonths = [];
          if (state.zeusImportedMonths.indexOf(yearMo) === -1) {
            state.zeusImportedMonths.push(yearMo);
          }
        });

        renderCalendar();
        updateVacation();
        updateStats();
        saveState(); // Drive-ra is menti a zeusImportedMonths frissítést

        pdfSetStatus(`✅ ${total} ${t('daysImported')}`, 'success');
        document.getElementById('pdfImportBtn').style.display = 'none';

        // Azonnali bezárás import után, majd naptár fülre ugrás
        setTimeout(() => {
          closePdfImport();
          const calBtn = document.querySelector('.nav-item[data-view="calendar"]');
          if (calBtn) calBtn.click();
        }, 800);
      };

      window.pdfOverwriteConfirm = function(yes) {
        document.getElementById('pdfOverwriteOverlay').style.display = 'none';
        if (yes) pdfDoImport(true);
      };

      // ==================== PIN KEZELÉS ====================
      function updatePinDots(input) {
        document.querySelectorAll('#pinDots .pin-dot').forEach((d, i) => {
          if (input.length === 0) {
            // Azonnali törlés – transition kikapcsolása
            d.style.transition = 'none';
            d.classList.remove('filled');
            // Következő frame után visszakapcsoljuk
            requestAnimationFrame(() => { d.style.transition = ''; });
          } else {
            d.style.transition = '';
            d.classList.toggle('filled', i < input.length);
          }
        });
      }

      // ==================== BIOMETRIA ====================
      // APK: natív AndroidBridge (mint a MONYK appban)
      // PWA / böngésző: WebAuthn platform authenticator (Touch ID / Windows Hello /
      //   Android ujjlenyomat a böngészőből). HTTPS kell (Firebase Hosting adja).
      // FONTOS: mindkét ág csak UX-szintű védelem — nincs szerver-oldali
      //   kriptográfiai ellenőrzés (ugyanúgy, mint a PIN). A credential ID
      //   eszközhöz kötött, nem kerül a felhőbe.
      function _b64urlEncode(buf) {
        var bytes = new Uint8Array(buf);
        var s = '';
        for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
        return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      }
      function _b64urlDecode(str) {
        var s = str.replace(/-/g, '+').replace(/_/g, '/');
        while (s.length % 4) s += '=';
        var bin = atob(s);
        var bytes = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return bytes.buffer;
      }
      function _randomChallenge(len) {
        var a = new Uint8Array(len || 32);
        crypto.getRandomValues(a);
        return a.buffer;
      }

      async function isBiometricAvailable() {
        try {
          // 1) Natív APK híd
          if (window.AndroidBridge && typeof window.AndroidBridge.isBiometricAvailable === 'function') {
            return !!window.AndroidBridge.isBiometricAvailable();
          }
          // 2) PWA / böngésző: WebAuthn platform authenticator
          if (window.PublicKeyCredential &&
              typeof PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
            return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
          }
        } catch(e) {
          console.warn('isBiometricAvailable:', e);
        }
        return false;
      }

      async function triggerBiometric(reason) {
        // 1) Natív APK
        if (window.AndroidBridge && typeof window.AndroidBridge.showBiometricPrompt === 'function') {
          return new Promise(function(resolve) {
            try {
              var cbName = '_chronosBioCallback_' + Date.now();
              window[cbName] = function(success) {
                delete window[cbName];
                resolve(!!success);
              };
              window.AndroidBridge.showBiometricPrompt('CHRONOS', reason || 'Azonosítás szükséges', cbName);
            } catch(e) { resolve(false); }
          });
        }
        // 2) PWA WebAuthn
        try {
          if (!window.PublicKeyCredential || !navigator.credentials) return false;
          var rpId = (location.hostname === 'localhost' || location.hostname === '127.0.0.1')
            ? location.hostname
            : location.hostname;
          var storedId = (state && state.webauthnCredentialId) || '';

          if (!storedId) {
            // Első bekapcsolás: credential regisztráció
            var userId = _randomChallenge(16);
            var createOpts = {
              publicKey: {
                challenge: _randomChallenge(32),
                rp: { id: rpId, name: 'CHRONOS' },
                user: {
                  id: userId,
                  name: 'chronos-local-user',
                  displayName: 'CHRONOS'
                },
                pubKeyCredParams: [
                  { type: 'public-key', alg: -7 },   // ES256
                  { type: 'public-key', alg: -257 }  // RS256
                ],
                authenticatorSelection: {
                  authenticatorAttachment: 'platform',
                  userVerification: 'required',
                  residentKey: 'preferred'
                },
                timeout: 60000,
                attestation: 'none'
              }
            };
            var cred = await navigator.credentials.create(createOpts);
            if (!cred || !cred.rawId) return false;
            state.webauthnCredentialId = _b64urlEncode(cred.rawId);
            // Ne mentsünk itt automatikusan — a hívó (bioSwitch) saveState()-el
            return true;
          }

          // Meglévő credential: assertion
          var getOpts = {
            publicKey: {
              challenge: _randomChallenge(32),
              rpId: rpId,
              allowCredentials: [{
                type: 'public-key',
                id: _b64urlDecode(storedId),
                transports: ['internal']
              }],
              userVerification: 'required',
              timeout: 60000
            }
          };
          var assertion = await navigator.credentials.get(getOpts);
          return !!(assertion && assertion.rawId);
        } catch(e) {
          // User cancel / NotAllowedError / stb. → false
          console.warn('triggerBiometric WebAuthn:', e && (e.name || e.message) || e);
          return false;
        }
      }

      // Biometria vagy PIN feloldás
      async function unlockWithBiometricOrPin(mode) {
        if (state.biometricEnabled) {
          const bioAvail = await isBiometricAvailable();
          if (bioAvail) {
            const ok = await triggerBiometric('Azonosítsd magad a CHRONOS apphoz');
            if (ok) return true;
            // Ha biometria sikertelen, fallback PIN-re ha van
            if (state.pinEnabled && state.pinHash) {
              showPinOverlay(mode);
            }
            return false;
          }
        }
        // Biometria nem elérhető/nem engedélyezett → PIN
        if (state.pinEnabled && state.pinHash) {
          showPinOverlay(mode);
        }
        return false;
      }

      function showPinOverlay(mode) {
        const overlay = document.getElementById('pinOverlay');
        if (overlay) {
          overlay.dataset.mode = mode || 'verify';
          buildPinPad(mode || 'verify');
          overlay.classList.add('visible');
        }
      }

      function renderBioSwitches() {
        const bs = document.getElementById('bioSwitch');
        const bsStart = document.getElementById('bioOnStartSwitch');
        const bsLock = document.getElementById('bioOnAutoLockSwitch');
        const bsPay = document.getElementById('bioOnPayrollSwitch');
        const rowStart = document.getElementById('bioOnStartRow');
        const rowLock = document.getElementById('bioOnAutoLockRow');
        const rowPay = document.getElementById('bioOnPayrollRow');

        if (bs) { if (state.biometricEnabled) bs.classList.add('on'); else bs.classList.remove('on'); }
        if (rowStart) rowStart.style.display = state.biometricEnabled ? '' : 'none';
        if (rowLock)  rowLock.style.display  = state.biometricEnabled ? '' : 'none';
        if (rowPay)   rowPay.style.display   = state.biometricEnabled ? '' : 'none';
        if (bsStart) { if (state.biometricOnStart)    bsStart.classList.add('on'); else bsStart.classList.remove('on'); }
        if (bsLock)  { if (state.biometricOnAutoLock) bsLock.classList.add('on');  else bsLock.classList.remove('on'); }
        if (bsPay)   { if (state.biometricOnPayroll)  bsPay.classList.add('on');   else bsPay.classList.remove('on'); }
        // Biometria sor: mindig látszik (elérhetőség csak bekapcsoláskor ellenőrzött)
        const bioRow = document.getElementById('bioRow');
        if (bioRow) bioRow.style.display = '';
      }

      function buildPinPad(mode) {
        const overlay = document.getElementById('pinOverlay');
        const errEl = document.getElementById('pinError');
        const pad = document.getElementById('pinPad');

        // 'unlock' = indítás/auto-zár: nincs mégse gomb (biztonsági zárolás)
        // 'verify' = egyéb helyen (bér, privát nézet): mégse engedélyezett
        let title = t('pinEnter') || 'Add meg a PIN-t';
        if (mode === 'verify' || mode === 'unlock') title = t('pinEnter') || 'Add meg a PIN-t';
        else if (mode === 'setup' && setupPhase === 'confirm') title = t('pinConfirm') || 'Confirm your PIN!';
        else if (mode === 'disable') title = t('pinDisable') || 'Enter PIN to disable';

        if (errEl) errEl.textContent = title;
        updatePinDots('');

        pad.innerHTML = '';

        // ── ripple helper: kis kör expandál a kattintás pontjából ──
        const _pinDoRipple = (btn, e) => {
          const sp = document.createElement('span');
          sp.className = 'pin-ripple-fx';
          const r = btn.getBoundingClientRect();
          const cx = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
          const cy = (e.touches ? e.touches[0].clientY : e.clientY) - r.top;
          sp.style.left = cx + 'px';
          sp.style.top  = cy + 'px';
          btn.appendChild(sp);
          setTimeout(() => sp.remove(), 500);
        };

        for (let i = 1; i <= 9; i++) {
          const btn = document.createElement('div');
          btn.className = 'pin-key pin-btn';
          btn.dataset.digit = i;
          btn.textContent = i;
          btn.onclick = (e) => {
            if (pinInput.length >= 4) return;
            btn.classList.add('pressed');
            _pinDoRipple(btn, e);
            setTimeout(() => btn.classList.remove('pressed'), TIMING.PIN_PRESS_ANIM);
            pinInput += btn.dataset.digit;
            updatePinDots(pinInput);
            if (pinInput.length === 4) { updatePinDots(''); setTimeout(() => handlePin(mode), TIMING.PIN_EVAL_DELAY); }
          };
          pad.appendChild(btn);
        }

        const clearBtn = document.createElement('div');
        clearBtn.className = 'pin-key pin-btn';
        clearBtn.dataset.action = 'del';
        clearBtn.textContent = '⌫';
        clearBtn.onclick = (e) => {
          clearBtn.classList.add('pressed');
          _pinDoRipple(clearBtn, e);
          setTimeout(() => clearBtn.classList.remove('pressed'), TIMING.PIN_PRESS_ANIM);
          pinInput = pinInput.slice(0, -1);
          updatePinDots(pinInput);
        };
        pad.appendChild(clearBtn);

        const zeroBtn = document.createElement('div');
        zeroBtn.className = 'pin-key pin-btn';
        zeroBtn.dataset.digit = 0;
        zeroBtn.textContent = '0';
        zeroBtn.onclick = (e) => {
          if (pinInput.length >= 4) return;
          zeroBtn.classList.add('pressed');
          _pinDoRipple(zeroBtn, e);
          setTimeout(() => zeroBtn.classList.remove('pressed'), TIMING.PIN_PRESS_ANIM);
          pinInput += '0';
          updatePinDots(pinInput);
          if (pinInput.length === 4) { updatePinDots(''); setTimeout(() => handlePin(mode), TIMING.PIN_EVAL_DELAY); }
        };
        pad.appendChild(zeroBtn);

        // ── Cancel / mégse gomb ──
        // 'unlock' módban (startup + auto-lock) NEM lehet megkerülni a PIN-t!
        // → üres placeholder tartja a grid layoutot, nem kattintható
        if (mode === 'unlock') {
          const phBtn = document.createElement('div');
          phBtn.className = 'pin-key';
          phBtn.style.cssText = 'background:transparent;border-color:transparent;pointer-events:none;';
          pad.appendChild(phBtn);
        } else {
          const cancelBtn = document.createElement('div');
          cancelBtn.className = 'pin-key pin-btn';
          cancelBtn.dataset.action = 'cancel';
          cancelBtn.textContent = '✕';
          cancelBtn.onclick = () => {
            overlay.classList.remove('visible');
            overlay.dataset.mode = '';
            pinInput = '';
            firstPin = '';
            setupPhase = 'first';
          };
          pad.appendChild(cancelBtn);
        }
      }

      async function hashPin(pin) {
        const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('chronos_v1_' + pin));
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
      }

      // Brute-force védelem
      let pinFailedAttempts = parseInt(localStorage.getItem(LS.pinFails) || '0');
      let pinLockoutUntil = parseInt(localStorage.getItem(LS.pinLockout) || '0');

      function updatePinAttemptsInfo() {
        const el = document.getElementById('pinAttemptsInfo');
        if (!el) return;
        if (pinFailedAttempts > 0) {
          el.textContent = (t('pinFailedAttemptsFmt')||'{n}/5 sikertelen kísérlet').replace('{n}', pinFailedAttempts);
          el.style.color = pinFailedAttempts >= 3 ? 'var(--red)' : 'var(--yellow)';
        } else {
          el.textContent = t('pinNotSet')||'✅ Nincs rögzítve';
          el.style.color = 'var(--text2)';
        }
      }

      function isPinLockedOut() {
        if (pinLockoutUntil > Date.now()) {
          const secs = Math.ceil((pinLockoutUntil - Date.now()) / 1000);
          return secs;
        }
        return 0;
      }

      async function handlePin(mode) {
        const errEl = document.getElementById('pinError');
        const overlay = document.getElementById('pinOverlay');
        const h = await hashPin(pinInput);

        if (mode === 'verify' || mode === 'unlock' || mode === 'disable') {
          // Brute-force lockout ellenőrzés
          const lockSecs = isPinLockedOut();
          if (lockSecs > 0) {
            if (errEl) errEl.textContent = (t('pinLockedSecs')||'🔒 Zárolva {n} másodpercig').replace('{n}', lockSecs);
            pinInput = '';
            updatePinDots('');
            return;
          }
          if (h === state.pinHash) {
            // Sikeres – visszaállítjuk a számlálót
            pinFailedAttempts = 0;
            localStorage.removeItem(LS.pinFails);
            localStorage.removeItem(LS.pinLockout);
            updatePinAttemptsInfo();
            // ── Sikeres animáció: zöld pontok + glow ──
            document.querySelectorAll('#pinDots .pin-dot').forEach(d => d.classList.add('filled', 'pin-ok'));
            const _pdeSuc = document.getElementById('pinDots');
            if (_pdeSuc) { _pdeSuc.classList.remove('pin-success'); void _pdeSuc.offsetWidth; _pdeSuc.classList.add('pin-success'); setTimeout(() => _pdeSuc.classList.remove('pin-success'), 560); }
            if (navigator.vibrate) navigator.vibrate(40);
            if (mode === 'disable') {
              state.pinEnabled = false;
              state.pinHash = '';
              const sw = document.getElementById('pinSwitch');
              if (sw) sw.classList.remove('on');
              updateLockBtnVisibility();
              saveState();
              if (errEl) errEl.textContent = t('pinOffSuccess')||'✅ PIN kikapcsolva';
            }
            setTimeout(() => {
              overlay.classList.remove('visible');
              pinInput = '';
              updatePinDots('');
              // Welcome screen visszatérő indításnál (unlock mód)
              if (mode === 'unlock' && typeof window.showWelcomeScreen === 'function') {
                window.showWelcomeScreen(false);
              }
              // Ha bér nézet megnyitás volt a cél
              if (window._pendingPayrollReveal && mode === 'verify') {
                window._pendingPayrollReveal = false;
                payrollUnlockedThisSession = true;
                payrollVisible = true;
                calculatePayroll();
                unmaskPayroll();
                document.getElementById('payrollToggle').textContent = '🙈';
                // Auto-zárolás timer eltávolítva – csak lapváltáskor zárol
              }
            }, mode === 'disable' ? 800 : 0);
            // Privát nézet feloldás callback
            if (mode === 'verify' && window._privateModeUnlockCallback) {
              const cb = window._privateModeUnlockCallback;
              window._privateModeUnlockCallback = null;
              setTimeout(cb, mode === 'disable' ? TIMING.BIO_CB_DISABLE : TIMING.BIO_CB_ENABLE);
            }
          } else {
            pinFailedAttempts++;
            localStorage.setItem(LS.pinFails, pinFailedAttempts);
            // ── Rázás + piros villanás ──
            const _pde = document.getElementById('pinDots');
            const _pbe = overlay?.querySelector('.pin-box');
            const _trigAnim = (el, cls) => { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), 500); };
            _trigAnim(_pde, 'pin-shake');
            _trigAnim(_pbe, 'pin-err-flash');
            if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
            if (pinFailedAttempts >= 5) {
              pinLockoutUntil = Date.now() + 60000; // 1 perces zár
              localStorage.setItem(LS.pinLockout, pinLockoutUntil);
              pinFailedAttempts = 0;
              localStorage.setItem(LS.pinFails, '0');
              if (errEl) errEl.textContent = t('pinMaxAttempts')||'🔒 5 sikertelen kísérlet – 1 perc zárolás';
            } else {
              if (errEl) errEl.textContent = `❌ ${t('pinWrong')||'Wrong PIN!'} (${pinFailedAttempts}/5)`;
            }
            updatePinAttemptsInfo();
            pinInput = '';
            updatePinDots('');
          }
        } else if (mode === 'setup') {
          if (setupPhase === 'first') {
            firstPin = pinInput;
            pinInput = '';
            setupPhase = 'confirm';
            if (errEl) errEl.textContent = t('pinConfirm') || 'Confirm your PIN!';
            updatePinDots('');
          } else {
            if (pinInput === firstPin) {
              state.pinHash = h;
              state.pinEnabled = true;
              const sw = document.getElementById('pinSwitch');
              if (sw) sw.classList.add('on');
              const _lbEl = document.getElementById('lockBtn'); if (_lbEl) _lbEl.style.display = '';
              updateLockBtnVisibility();
              saveState();
              if (errEl) errEl.textContent = '✅ ' + (t('pinSet')||'PIN set!');
              setTimeout(async () => {
                overlay.classList.remove('visible');
                pinInput = '';
                updatePinDots('');
                firstPin = '';
                setupPhase = 'first';
                // Biometria felkínálása:
                // - ha az onboardingban bio-t választott (_obWantsBio), automatikusan aktiváljuk
                // - ha csak PIN-t választott (_obWantsBio=false), NEM kínáljuk fel itt
                //   (a bio a Beállításokban bármikor bekapcsolható)
                // Ez megakadályozza, hogy PIN-only választásnál véletlenül bio is bekapcsol.
                if (!state.biometricEnabled) {
                  const wantsBio = window._obWantsBio === true;
                  window._obWantsBio = false;

                  const doBioSetup = async () => {
                    const avail = await isBiometricAvailable();
                    if (!avail) {
                      showNotification(t('biometricNotAvailable') || '⚠️ A biometria nem elérhető ezen az eszközön.', 3000, 'warning');
                      return;
                    }
                    const ok = await triggerBiometric('Biometria aktiválásához azonosítsd magad');
                    if (ok) {
                      state.biometricEnabled = true;
                      state.biometricOnStart = true;
                      saveState();
                      renderBioSwitches();
                      showNotification('✅ ' + (t('biometricEnabled') || 'Biometria bekapcsolva!'), 2500);
                    }
                  };

                  if (wantsBio) {
                    // Onboardingban bio-t választott → közvetlenül aktiváljuk
                    await doBioSetup();
                  }
                  // A wizard lefutott és PIN/bio beállítva. Az init() auth blokkja
                  // (setTimeout(0)) szintén le fog futni, és újra kérne bio-t/PIN-t.
                  // A _chronos_from_boot flag-gel jelezzük, hogy auth már megtörtént.
                  try { localStorage.setItem('_chronos_from_boot', '1'); } catch(e) {}
                  // PIN-only vagy nincs védelem esetén: welcome screen azonnal, nincs bio dialog
                  if (typeof window.showWelcomeScreen === 'function') window.showWelcomeScreen(true);
                } else {
                  // Bio már be volt kapcsolva vagy nincs bio ajánlat → welcome screen azonnal
                  try { localStorage.setItem('_chronos_from_boot', '1'); } catch(e) {}
                  if (typeof window.showWelcomeScreen === 'function') window.showWelcomeScreen(true);
                }
              }, 800);
            } else {
              if (errEl) errEl.textContent = '❌ ' + (t('pinMismatch')||'Mismatch! Try again.');
              // ── Rázás + piros villanás ──
              const _pdeMm = document.getElementById('pinDots');
              const _pbeMm = overlay?.querySelector('.pin-box');
              const _trigMm = (el, cls) => { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), 500); };
              _trigMm(_pdeMm, 'pin-shake');
              _trigMm(_pbeMm, 'pin-err-flash');
              if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
              pinInput = '';
              firstPin = '';
              setupPhase = 'first';
              updatePinDots('');
            }
          }
        }
      }

      // ==================== EGYÉB UI FUNKCIÓK ====================
      function initScrollHandler() {
        const headerWrapper = document.getElementById('headerWrapper');
        const navWrapper = document.getElementById('navWrapper');
        let lastY = window.scrollY;
        let ticking = false;
        let seqTimer = null;

        window.addEventListener('scroll', () => {
          if (ticking) return;
          ticking = true;

          requestAnimationFrame(() => {
            const y = window.scrollY;
            const diff = y - lastY;
            const importOpen = !!(document.getElementById('importCardBody') &&
                                   document.getElementById('importCardBody').classList.contains('open'));

            if (y < 20) {
              // Tetején: mindkettő azonnal visszajön
              clearTimeout(seqTimer);
              headerWrapper.classList.remove('hidden');
              navWrapper.classList.remove('hidden');
            } else if (diff > 8) {
              // Lefelé: fejléc elrejtése, majd 80ms múlva nav is
              headerWrapper.classList.add('hidden');
              clearTimeout(seqTimer);
              seqTimer = setTimeout(() => navWrapper.classList.add('hidden'), 80);
            } else if (diff < -8) {
              // Felfelé: nav először, fejléc 80ms késéssel
              navWrapper.classList.remove('hidden');
              clearTimeout(seqTimer);
              seqTimer = setTimeout(() => headerWrapper.classList.remove('hidden'), 80);
            }

            lastY = y;
            ticking = false;
          });
        }, { passive: true });
      }

      function setNavPosition(pos) {
        state.navPosition = pos;
        const nav = document.getElementById('mainNav');
        const navWrapper = document.getElementById('navWrapper');
        const appEl = document.getElementById('app');

        if (pos === 'bottom') {
          // Nav ki a navWrapper-ből, fixed pozícióba
          if (nav.parentElement === navWrapper) {
            appEl.appendChild(nav);
          }
          nav.className = 'nav-bottom';
          navWrapper.style.display = 'none';
          document.body.style.paddingBottom = 'calc(90px + env(safe-area-inset-bottom, 0px))';
        } else {
          // Nav vissza a navWrapper-be
          if (nav.parentElement !== navWrapper) {
            navWrapper.appendChild(nav);
          }
          nav.className = 'nav-top';
          navWrapper.style.display = '';
          document.body.style.paddingBottom = '0';
        }
      }


      function setFontSize(size, userAction = false) {
        state.fontSize = size;
        if (userAction) state._fontSizeSetByUser = true;
        document.body.classList.remove('fs-normal', 'fs-large', 'fs-xlarge');
        document.body.classList.add('fs-' + size);
        // Update button styles
        ['normal','large','xlarge'].forEach(s => {
          const btn = document.getElementById('fsBtn' + s.charAt(0).toUpperCase() + s.slice(1));
          if (!btn) return;
          if (s === size) {
            btn.style.background = 'var(--accent)';
            btn.style.borderColor = 'var(--accent)';
            btn.style.color = 'white';
          } else {
            btn.style.background = 'transparent';
            btn.style.borderColor = 'var(--border)';
            btn.style.color = 'var(--text)';
          }
        });
        saveState();
        fitNavLabels();
      }
      window.setFontSize = setFontSize;

      function setTheme(theme) {
        state.currentTheme = theme;
        document.body.setAttribute('data-theme', theme);
        const icons = { default: '🌑', light: '☀️', dark: '🌙', oled: '⬛' };
        const tr = TRANSLATIONS[state.currentLang] || TRANSLATIONS.hu;
        const themeBtnEl = document.getElementById('themeBtn');
        if (themeBtnEl) themeBtnEl.textContent = icons[theme] + ' ' + (tr.theme || 'Theme');
        // Megjelenés fülön a téma-választó gombok kiemelése
        ['default', 'light', 'dark', 'oled'].forEach(function(t) {
          const btn = document.getElementById('themeBtn_' + t);
          if (!btn) return;
          if (t === theme) {
            btn.style.background = 'var(--accent)';
            btn.style.borderColor = 'var(--accent)';
            btn.style.color = '#fff';
          } else {
            btn.style.background = 'transparent';
            btn.style.borderColor = 'var(--border)';
            btn.style.color = 'var(--text)';
          }
        });
        saveState();
      }
      window.setTheme = setTheme;

      function fitNavLabels() {
        const nav = document.getElementById('mainNav');
        const btn = nav && nav.querySelector('.nav-item[data-view="settings"]');
        if (!nav || !btn) return;

        // Reset
        btn.style.fontSize = '';

        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            // Átmenetileg flex:none hogy a természetes szélesség látszódjon
            const allBtns = nav.querySelectorAll('.nav-item');
            allBtns.forEach(b => b.style.flex = '0 0 auto');

            requestAnimationFrame(() => {
              const overflows = nav.scrollWidth > nav.offsetWidth;
              allBtns.forEach(b => b.style.flex = '');
              if (overflows) {
                const current = parseFloat(getComputedStyle(btn).fontSize);
                btn.style.fontSize = (current - 2) + 'px';
              }
            });
          });
        });
      }

      function setLanguage(lang) {
        state.currentLang = lang;
        document.getElementById('langSelect').value = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.documentElement.lang = lang;
        // RTL body class
        document.body.classList.toggle('rtl-layout', lang === 'ar');
        applyTranslations();
        renderCalendar();
        renderShifts();
        renderPotlek();
        renderExtras();
        updateVacation();
        updateStats();
        renderVacationHistory();
        calculatePayroll();
        fitNavLabels();
        // ── ZEUS nyelv szinkron ─────────────────────────────────────────────
        try {
          const msg = { type: 'setLanguage', lang };
          document.querySelectorAll('iframe').forEach(f => {
            try { f.contentWindow.postMessage(msg, '*'); } catch(_) {}
          });
          if (window.parent && window.parent !== window) {
            window.parent.postMessage(msg, '*');
          }
          if (window._zeusWindow && !window._zeusWindow.closed) {
            window._zeusWindow.postMessage(msg, '*');
          }
        } catch(_) {}
      }

      function initDeleteMenu() {
        const btn = document.getElementById('deleteMenuBtn');
        const menu = document.getElementById('deleteMenu');

        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          menu.classList.toggle('visible');
        });

        document.addEventListener('click', (e) => {
          if (!btn.contains(e.target) && !menu.contains(e.target)) {
            menu.classList.remove('visible');
          }
        });

        document.getElementById('deleteCurrentMonth').addEventListener('click', () => {
          menu.classList.remove('visible');
          if (!confirm(t('confirmDeleteMonth'))) return;

          const key = `${state.year}-${state.month + 1}`;
          Object.keys(state.schedules).forEach(k => {
            if (k.startsWith(key)) delete state.schedules[k];
          });

          saveState();
          renderCalendar();
          updateVacation();
          updateStats();
        });

        document.getElementById('deleteYear').addEventListener('click', () => {
          menu.classList.remove('visible');
          if (!confirm(t('confirmDeleteYear') ? t('confirmDeleteYear').replace ? t('confirmDeleteYear').replace('{y}', state.year) : `${state.year} év törlése?` : `${state.year} év törlése?`)) return;

          Object.keys(state.schedules).forEach(k => {
            if (k.startsWith(state.year + '-')) delete state.schedules[k];
          });

          saveState();
          renderCalendar();
          updateVacation();
          updateStats();
        });

        document.getElementById('deleteAll').addEventListener('click', () => {
          menu.classList.remove('visible');
          if (!confirm(t('confirmDeleteAll') || 'Delete ALL data?')) return;

          state.schedules = {};
          state.customShifts = [];
          state.resturlaub.years = {};

          saveState();
          renderCalendar();
          updateVacation();
          updateStats();
        });
      }

      function initImport() {
        const importBtn = document.getElementById('importBtn');
        const fileInput = document.getElementById('importFileInput');

        importBtn.addEventListener('click', () => fileInput.click());

        fileInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;

          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const importedState = JSON.parse(event.target.result);
              if (typeof importedState !== 'object' || importedState === null) {
                throw new Error(t('invalidFile') || 'Invalid CHRONOS file');
              }

              const currentTheme = state.currentTheme;
              const currentLang = state.currentLang;
              const currentNavPos = state.navPosition;

              state = {
                ...DEFAULT,
                ...importedState,
                currentTheme,
                currentLang,
                navPosition: currentNavPos,
                pinHash: state.pinHash,
                pinEnabled: state.pinEnabled
              };

              if (!state.resturlaub) state.resturlaub = { years: {} };
              if (!state.resturlaub.years) state.resturlaub.years = {};
              if (!state.customShifts) state.customShifts = [];
              if (!state.potlekRules) state.potlekRules = DEFAULT.potlekRules;
              if (!state.otherDeductions) state.otherDeductions = [];
              if (state.otherDeductionsEnabled === undefined) state.otherDeductionsEnabled = state.otherDeductions.length > 0;
              if (!state.birthYear) state.birthYear = 1990;
              if (!state.bundesland) state.bundesland = 'BW';
              if (!state.krankenkasse) state.krankenkasse = 'AOK_BW';
              if (!state.manualHours) state.manualHours = {};
              if (!state.zeusData) state.zeusData = {};
              if (!state.zeitkonto) state.zeitkonto = { enabled: false, monthly: 0, balance: 0, withdrawals: [] };
              if (!state.zeitkonto.withdrawals) state.zeitkonto.withdrawals = [];
              if (!state.zeitkonto.monthlyOverrides) state.zeitkonto.monthlyOverrides = [];
              if (!state.darlehen) state.darlehen = { enabled: false, monthly: 0, balance: 0 };
              if (!state.einmalzahlung) state.einmalzahlung = { enabled: false, payments: [] };
              if (!state.einmalzahlung.payments) state.einmalzahlung.payments = [];
              if (!state.weihnachtsgeld) state.weihnachtsgeld = { enabled: false, satz: 0.5 };
              if (!state.payrollDisplayMode) state.payrollDisplayMode = 'leistung';
              if (!state.shiftSurcharges) state.shiftSurcharges = {};
              if (!state.shiftSurchargeRuleIdxs) state.shiftSurchargeRuleIdxs = {};
              if (!state.builtinOverrides) state.builtinOverrides = {};

              // Sanitize quickIds and hiddenShifts – keep only IDs that exist in current builtin+custom
              const validIds = new Set([...BUILTIN_SHIFTS.map(s => s.id), ...(state.customShifts || []).map(s => s.id)]);
              const defaultQuickIds = ['Früh', 'Spät', 'Nacht', 'Freiwillig Früh', 'Freiwillig Spät', 'Freiwillig Nacht', 'Urlaub', 'Krank', 'ZK'];
              if (!state.quickIds || !Array.isArray(state.quickIds) || state.quickIds.length === 0) {
                state.quickIds = [...defaultQuickIds];
              } else {
                const filtered = state.quickIds.filter(id => validIds.has(id));
                if (filtered.length < 4) {
                  // Ha gyanúsan kevés maradt (pl. véletlen törlés miatt), alapértelmezetteket töltjük be
                  // Az egyéni custom műszakokat megtartjuk, ha vannak
                  const customInQ = filtered.filter(id => !BUILTIN_SHIFTS.find(b => b.id === id));
                  state.quickIds = [...defaultQuickIds, ...customInQ];
                } else {
                  state.quickIds = filtered;
                }
              }
              if (!state.hiddenShifts || !Array.isArray(state.hiddenShifts)) {
                state.hiddenShifts = [];
              } else {
                state.hiddenShifts = state.hiddenShifts.filter(id => validIds.has(id));
              }

              saveState();
              renderCalendar();
              renderShifts();
              renderPotlek();
              renderExtras();
              updateVacation();
              updateStats();
              renderVacationHistory();
              calculatePayroll();
              renderBioSwitches();

              document.getElementById('grundlohn').value = state.grundlohn || '';
              document.getElementById('feststunden').value = state.feststunden || 174;
              document.getElementById('taxClass').value = state.taxClass || 1;
              document.getElementById('kinder').value = state.kinder || 0;
              document.getElementById('kirche').value = state.kirche || 0;
              document.getElementById('birthYear').value = state.birthYear || 1990;
              document.getElementById('bundesland').value = state.bundesland || 'BW';
              if (document.getElementById('krankenkasse')) { document.getElementById('krankenkasse').value = state.krankenkasse || 'AOK_BW'; document.getElementById('kkCustomRow').style.display = state.krankenkasse === 'custom' ? 'flex' : 'none'; }

              const stl = (state.grundlohn || 0) / (state.feststunden || 174);
              document.getElementById('stundenlohn').textContent = stl.toFixed(2) + ' €';

              alert(t('importSuccess') || 'Data restored!');
            } catch (error) {
              alert('Hiba: ' + error.message);
            } finally {
              fileInput.value = '';
            }
          };
          reader.readAsText(file);
        });
      }

      // ==================== GLOBÁLIS SEGÉDFÜGGVÉNYEK ====================
      // ── ZK / Urlaub bottom-sheet modal functions ──
      let _shiftSheetSel = { zk: 'full', urlaub: 'full' };

      window.openShiftSheet = function(type) {
        if (type === 'zk') {
          // Frissítjük a saldo pill-t
          const balH = state.zeitkonto && state.zeitkonto.balance > 0
            ? state.zeitkonto.balance : 0;
          const hh = Math.floor(Math.abs(balH));
          const mm = Math.round((Math.abs(balH) - hh) * 60);
          const sign = balH >= 0 ? '+' : '−';
          document.getElementById('zkSheetSaldo').textContent =
            sign + hh + ':' + String(mm).padStart(2,'0');
          _shiftSheetSel.zk = 'full';
          // Reset opt styles
          ['full','h1','h2'].forEach(v => {
            const el = document.getElementById('zks-' + v);
            if (el) { el.classList.toggle('sel', v === 'full'); el.style.borderColor=''; el.style.color=''; el.style.background=''; }
          });
          document.getElementById('zks-full').style.borderColor = '#a78bfa';
          document.getElementById('zks-full').style.color = '#a78bfa';
          document.getElementById('zks-full').style.background = '#a78bfa18';
          _updateZKSheetInfo(balH, 'full');
          document.getElementById('zkSheetOverlay').classList.add('open');
        } else {
          // Urlaub: maradék napok
          const cur = getCurrentYearVacation();
          const used = calculateVacationUsed(state.year);
          const left = (cur.base + cur.carried) - used;
          const dayUnit = (window._currentTranslations && window._currentTranslations.sheetDayUnit) || 'nap';
          document.getElementById('urlaubSheetSaldo').textContent = left + ' ' + dayUnit;
          _shiftSheetSel.urlaub = 'full';
          ['full','h1','h2'].forEach(v => {
            const el = document.getElementById('urs-' + v);
            if (el) { el.classList.toggle('sel', v === 'full'); el.style.borderColor=''; el.style.color=''; el.style.background=''; }
          });
          document.getElementById('urs-full').style.borderColor = '#94a3b8';
          document.getElementById('urs-full').style.color = '#94a3b8';
          document.getElementById('urs-full').style.background = '#94a3b818';
          _updateUrlaubSheetInfo(left, 'full');
          document.getElementById('urlaubSheetOverlay').classList.add('open');
        }
      };

      function _updateZKSheetInfo(balH, val) {
        const deductH = val === 'full' ? 8 : 4;
        const deductStr = val === 'full' ? '−8:00 h' : '−4:00 h';
        const remainH = balH - deductH;
        const sign = remainH >= 0 ? '+' : '−';
        const abs = Math.abs(remainH);
        const rh = Math.floor(abs); const rm = Math.round((abs-rh)*60);
        document.getElementById('zkSheetDeduct').textContent = deductStr;
        document.getElementById('zkSheetRemain').textContent =
          sign + rh + ':' + String(rm).padStart(2,'0');
      }

      function _updateUrlaubSheetInfo(left, val) {
        const deduct = val === 'full' ? 1 : 0.5;
        const dayUnit = (window._currentTranslations && window._currentTranslations.sheetDayUnit) || 'nap';
        document.getElementById('urlaubSheetDeduct').textContent =
          val === 'full' ? ('−1 ' + dayUnit) : ('−0.5 ' + dayUnit);
        document.getElementById('urlaubSheetRemain').textContent =
          (left - deduct) + ' ' + dayUnit;
      }

      window.selectShiftSheetOpt = function(type, val, el) {
        const prefix = type === 'zk' ? 'zks' : 'urs';
        const color  = type === 'zk' ? '#a78bfa' : '#94a3b8';
        const bgCol  = type === 'zk' ? '#a78bfa18' : '#94a3b818';
        ['full','h1','h2'].forEach(v => {
          const b = document.getElementById(prefix + '-' + v);
          if (b) { b.classList.remove('sel'); b.style.borderColor=''; b.style.color=''; b.style.background=''; }
        });
        el.classList.add('sel');
        el.style.borderColor = color; el.style.color = color; el.style.background = bgCol;
        _shiftSheetSel[type] = val;
        if (type === 'zk') {
          const balH = state.zeitkonto && state.zeitkonto.balance > 0
            ? state.zeitkonto.balance : 0;
          _updateZKSheetInfo(balH, val);
        } else {
          const cur = getCurrentYearVacation();
          const used = calculateVacationUsed(state.year);
          const left = (cur.base + cur.carried) - used;
          _updateUrlaubSheetInfo(left, val);
        }
      };

      window.confirmShiftSheet = function(type) {
        const val = _shiftSheetSel[type];
        if (type === 'zk') {
          if (val === 'full') state.selectedShift = 'ZK';
          else if (val === 'h1') state.selectedShift = 'ZK1';
          else state.selectedShift = 'ZK2';
        } else {
          if (val === 'full') state.selectedShift = 'Urlaub';
          else if (val === 'h1') state.selectedShift = 'Urlaub1';
          else state.selectedShift = 'Urlaub2';
        }
        closeShiftSheet(type);
        renderShifts();
      };

      window.closeShiftSheet = function(type) {
        const id = type === 'zk' ? 'zkSheetOverlay' : 'urlaubSheetOverlay';
        document.getElementById(id).classList.remove('open');
      };

      window.saveZK = function() {
        state.zeitkonto.monthly = parseFloat(document.getElementById('zk_monthly')?.value) || 0;
        saveState();
        calculatePayroll();
        if (window.updateStatPrognosis) window.updateStatPrognosis();
      };

      window.saveZKSaveAll = function() {
        if (!state.zeitkonto) state.zeitkonto = { enabled: false, monthly: 0, balance: 0, withdrawals: [], saveAllOvertime: false };
        state.zeitkonto.saveAllOvertime = document.getElementById('zk_save_all')?.checked || false;
        // Havi levonás sor vizuális dimming frissítése
        const _mRow = document.getElementById('zk_monthly_row');
        if (_mRow) {
          _mRow.style.opacity = state.zeitkonto.saveAllOvertime ? '0.35' : '';
          _mRow.style.pointerEvents = state.zeitkonto.saveAllOvertime ? 'none' : '';
        }
        saveState();
        calculatePayroll();
        if (window.updateStatPrognosis) window.updateStatPrognosis();
      };

      window.saveZKBal = function() {
        state.zeitkonto.balance = parseFloat(document.getElementById('zk_balance')?.value) || 0;
        saveState();
        calculatePayroll();
        if (window.updateStatPrognosis) window.updateStatPrognosis();
      };

      window.saveZKMax = function() {
        state.zeitkonto.maxBalance = parseFloat(document.getElementById('zk_max_balance')?.value) || 0;
        saveState();
        if (window.updateStatPrognosis) window.updateStatPrognosis();
      };

      // ── Visszajelzés, ha egy "+" gomb hatástalan maradt (kötelező mező üres) ──
      // Rövid piros keret + remegés animáció a hiányzó mezőn, hogy a felhasználó
      // lássa: a hozzáadás NEM történt meg (korábban ez teljesen csendben
      // hiúsult meg, "miért nem csinál semmit" jellegű hibákat okozva).
      function _flashFieldError(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('input-error');
        void el.offsetWidth; // reflow, hogy az animáció ismételten lefusson
        el.classList.add('input-error');
        setTimeout(() => el.classList.remove('input-error'), TIMING.INPUT_ERROR_FLASH);
      }

      window.addZkMonthlyOverride = function() {
        const monthVal = document.getElementById('zk_mo_month')?.value;
        const hoursVal = parseFloat(document.getElementById('zk_mo_hours')?.value) || 0;
        if (!monthVal) { _flashFieldError('zk_mo_month'); return; }
        if (hoursVal < 0) { _flashFieldError('zk_mo_hours'); return; }
        if (!state.zeitkonto.monthlyOverrides) state.zeitkonto.monthlyOverrides = [];
        // Ha már van bejegyzés erre a hónapra, felülírjuk
        const existing = state.zeitkonto.monthlyOverrides.findIndex(o => o.month === monthVal);
        if (existing >= 0) {
          state.zeitkonto.monthlyOverrides[existing].hours = hoursVal;
        } else {
          state.zeitkonto.monthlyOverrides.push({ month: monthVal, hours: hoursVal });
        }
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.delZkMonthlyOverride = function(idx) {
        if (!state.zeitkonto.monthlyOverrides) return;
        state.zeitkonto.monthlyOverrides.splice(idx, 1);
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.addZkWithdrawal = function() {
        const monthVal = document.getElementById('zk_w_month')?.value;
        const hoursVal = parseFloat(document.getElementById('zk_w_hours')?.value) || 0;
        if (!monthVal) { _flashFieldError('zk_w_month'); return; }
        if (hoursVal <= 0) { _flashFieldError('zk_w_hours'); return; }
        if (!state.zeitkonto.withdrawals) state.zeitkonto.withdrawals = [];
        if (!state.zeitkonto.monthlyOverrides) state.zeitkonto.monthlyOverrides = [];
        // Ha már van bejegyzés erre a hónapra, felülírjuk
        const existing = state.zeitkonto.withdrawals.findIndex(w => w.month === monthVal);
        if (existing >= 0) {
          state.zeitkonto.withdrawals[existing].hours = hoursVal;
        } else {
          state.zeitkonto.withdrawals.push({ month: monthVal, hours: hoursVal });
        }
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.delZkWithdrawal = function(idx) {
        if (!state.zeitkonto.withdrawals) return;
        state.zeitkonto.withdrawals.splice(idx, 1);
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.saveDA = function() {
        state.darlehen.monthly = parseFloat(document.getElementById('da_monthly')?.value) || 0;
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.saveDABal = function() {
        state.darlehen.balance = parseFloat(document.getElementById('da_balance')?.value) || 0;
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.saveWG = function() {
        state.weihnachtsgeld.satz = parseFloat(document.getElementById('wg_satz')?.value) || 0;
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.setWG = function(satz) {
        state.weihnachtsgeld.satz = satz;
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.saveWGPercent = function() {
        const v = document.getElementById('wg_percent')?.value;
        state.weihnachtsgeld.percent = v || '50';
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.togglePayrollMode = function() {
        state.payrollDisplayMode = (state.payrollDisplayMode === 'zahlung') ? 'leistung' : 'zahlung';
        saveState();
        calculatePayroll();
      };

      window.addEZ = function() {
        const name = (document.getElementById('ez_name')?.value || '').trim() || (t('payment')||'Payment');
        const amount = parseFloat(document.getElementById('ez_amount')?.value) || 0;
        const type = document.getElementById('ez_type')?.value || 'brutto';
        const month = document.getElementById('ez_month')?.value;

        if (amount) {
          state.einmalzahlung.payments.push({ name, amount, type, month });
          saveState();
          renderExtras();
          calculatePayroll();
        } else {
          _flashFieldError('ez_amount');
        }
      };

      window.delEZ = function(i) {
        state.einmalzahlung.payments.splice(i, 1);
        saveState();
        renderExtras();
        calculatePayroll();
      };

      window.addOther = function() {
        const name = (document.getElementById('other_name')?.value || '').trim();
        const amount = parseFloat(document.getElementById('other_amount')?.value) || 0;
        const month = document.getElementById('other_month')?.value;

        // Csak az összeg kötelező (a megjelenítés 'Levonás'-ra esik vissza, ha
        // nincs név megadva) - korábban a name && amount feltétel miatt egy
        // kitöltött összeg, üres név esetén a + gomb csendben nem csinált semmit.
        if (amount) {
          state.otherDeductions.push({ name, amount, month });
          state.otherDeductionsEnabled = true; // automatikusan bekapcsol ha elemet adunk hozzá
          saveState();
          renderExtras();
          calculatePayroll();
        } else {
          _flashFieldError('other_amount');
        }
      };

      window.delOther = function(i) {
        state.otherDeductions.splice(i, 1);
        if (state.otherDeductions.length === 0) state.otherDeductionsEnabled = false;
        saveState();
        renderExtras();
        calculatePayroll();
      };

      



            // ==================== INICIALIZÁLÁS ====================
      function init() {
        loadState();
        // Mindig az aktuális hónapot mutassuk induláskor
        const _now = new Date();
        state.year = _now.getFullYear();
        state.month = _now.getMonth();

        document.body.setAttribute('data-theme', state.currentTheme);
        setFontSize(state.fontSize || 'large');
        setLanguage(state.currentLang);
        setNavPosition(state.navPosition);

        renderCalendar();
        renderShifts();
        renderPotlek();
        renderExtras();
        updateVacation();
        updateStats();
        renderVacationHistory();
        maskPayroll();
        updateLockBtnVisibility();
        // Ha privát módban volt, visszaállítjuk
        if (state.privateMode) {
          state.privateMode = false; // reset, majd újra bekapcsol
          applyPrivateMode(true);
        }

        initScrollHandler();
        initDeleteMenu();
        initImport();
        initPdfUploadZone();
        fitNavLabels();

        // PDF.js előtöltés háttérben (hogy import-kor már kész legyen)
        // Ha most betöltődik, a böngésző cache-eli – következő alkalommal offline is működik
        setTimeout(function() { loadPdfJs().catch(function(){}); }, TIMING.INIT_PDFJS);

        // Havi biztonsági mentés emlékeztető
        checkBackupReminder();

        // Drive szinkron induláskor — 2 mp delay után betölt, ha van frissebb adat.
        // FONTOS: ennek itt kell lennie (nem egy külső DOMContentLoaded-ben),
        // mert a loadStateFromDrive ebben a closure-ben definiált függvény —
        // máshonnan hívva 'typeof loadStateFromDrive === function' csendben
        // false-ra futott, így a Drive-betöltés sosem indult el induláskor.
        setTimeout(function() { loadStateFromDrive(); }, TIMING.INIT_DRIVE_LOAD);

        // Alapadatok inputok és órabér inicializálása state-ből
        const _glEl = document.getElementById('grundlohn');
        const _fsEl = document.getElementById('feststunden');
        if (_glEl) _glEl.value = state.grundlohn || '';
        if (_fsEl) _fsEl.value = state.feststunden || 174;
        const _stlInit = (parseFloat(state.grundlohn) || 0) / (parseFloat(state.feststunden) || 174);
        const _stlEl = document.getElementById('stundenlohn');
        if (_stlEl) _stlEl.textContent = _stlInit.toFixed(2) + ' €';
        const _tcEl = document.getElementById('taxClass');
        if (_tcEl && state.taxClass) _tcEl.value = state.taxClass;
        const _kdEl = document.getElementById('kinder');
        if (_kdEl) _kdEl.value = (state.kinder != null && state.kinder !== 0) ? state.kinder : '';
        const _kkEl = document.getElementById('kirche');
        if (_kkEl && state.kirche != null) _kkEl.value = state.kirche;
        const _byEl = document.getElementById('birthYear');
        if (_byEl && state.birthYear) _byEl.value = state.birthYear;
        const _blEl = document.getElementById('bundesland');
        if (_blEl && state.bundesland) _blEl.value = state.bundesland;
        const _kknEl = document.getElementById('krankenkasse');
        if (_kknEl && state.krankenkasse) { _kknEl.value = state.krankenkasse; const _kkCR = document.getElementById('kkCustomRow'); if (_kkCR) _kkCR.style.display = state.krankenkasse === 'custom' ? 'flex' : 'none'; }

        // Biometria / PIN indításkor
        // setTimeout(0): Capacitor window.location.replace() utáni localStorage.setItem()
        // néha csak a következő event loop tick-ben válik olvashatóvá az új oldalon.
        // A delay garantálja, hogy a _chronos_from_boot flag biztosan olvasható legyen.
        setTimeout(async function() {
          // Ha közvetlenül a bootloaderből jöttünk (fresh boot), kihagyjuk az
          // auth kérést – a bootloader2 már elvégezte az azonosítást.
          // Elsődleges jelzés: ?bl2=1 URL paraméter (megbízható Capacitorban).
          // Fallback: _chronos_from_boot localStorage flag.
          try {
            const _urlParams = new URLSearchParams(window.location.search);
            const _fromBootUrl = _urlParams.get('bl2') === '1';
            const _fromBootLs = localStorage.getItem('_chronos_from_boot') === '1';
            if (_fromBootUrl || _fromBootLs) {
              localStorage.removeItem('_chronos_from_boot');
              // URL-t tisztítjuk a paramétertől (history módosítás nélkül)
              if (_fromBootUrl && window.history && window.history.replaceState) {
                window.history.replaceState(null, '', 'index.html');
              }
              return;
            }
          } catch(e) {}

          if (state.pinEnabled && state.pinHash) {
            if (state.biometricEnabled && state.biometricOnStart) {
              const avail = await isBiometricAvailable();
              if (avail) {
                const ok = await triggerBiometric('Azonosítsd magad a CHRONOS apphoz');
                if (!ok) {
                  // Sikertelen biometria → PIN fallback
                  showPinOverlay('unlock');
                } else {
                  // Bio sikeres → welcome screen (visszatérő indítás)
                  if (typeof window.showWelcomeScreen === 'function') window.showWelcomeScreen(false);
                }
                return;
              }
            }
            // Biometria nem elérhető/nem engedélyezett → PIN
            showPinOverlay('unlock');
          }
        }, 0);

        const navRadio = document.querySelector('input[name="navPosition"][value="' + (state.navPosition || 'top') + '"]');
        if (navRadio) navRadio.checked = true;

        // Eseménykezelők
        document.getElementById('themeBtn').addEventListener('click', () => {
          const themes = ['default', 'light', 'dark', 'oled'];
          const next = themes[(themes.indexOf(state.currentTheme) + 1) % 4];
          setTheme(next);
          saveState();
        });

        // 🔒 Privát nézet gomb (lockBtn eltávolítva a fejlécből – null check)
        const _lockBtnEl = document.getElementById('lockBtn');
        if (_lockBtnEl) _lockBtnEl.addEventListener('click', () => {
          togglePrivateMode();
        });

        document.getElementById('langSelect').addEventListener('change', (e) => {
          setLanguage(e.target.value);
          saveState();
        });

        document.querySelectorAll('input[name="navPosition"]').forEach(r => {
          r.addEventListener('change', (e) => {
            setNavPosition(e.target.value);
            saveState();
          });
        });

        // Naptár navigáció
        // ── Swipe naptár hónap-váltás ──
        (function() {
          const _calEl = document.getElementById('calendar-view');
          if (!_calEl) return;
          let _swipeStartX = null, _swipeStartY = null, _swipeLocked = false;
          _calEl.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            _swipeStartX = e.touches[0].clientX;
            _swipeStartY = e.touches[0].clientY;
            _swipeLocked = false;
          }, { passive: true });
          _calEl.addEventListener('touchmove', (e) => {
            if (_swipeStartX === null || _swipeLocked) return;
            const dx = e.touches[0].clientX - _swipeStartX;
            const dy = e.touches[0].clientY - _swipeStartY;
            if (Math.abs(dy) > Math.abs(dx) + 8) { _swipeStartX = null; return; }
            if (Math.abs(dx) > 12) _swipeLocked = true;
          }, { passive: true });
          _calEl.addEventListener('touchend', (e) => {
            if (_swipeStartX === null) return;
            const dx = e.changedTouches[0].clientX - _swipeStartX;
            _swipeStartX = null; _swipeLocked = false;
            if (Math.abs(dx) < 50) return;
            if (dx < 0) {
              document.getElementById('btnNext').click();
            } else {
              document.getElementById('btnPrev').click();
            }
          }, { passive: true });        })();

        // ── Swipe bér fül hónap-váltás ──
        (function() {
          const _payEl = document.getElementById('payroll-view');
          if (!_payEl) return;
          let _swipeStartX = null, _swipeStartY = null, _swipeLocked = false;
          _payEl.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            _swipeStartX = e.touches[0].clientX;
            _swipeStartY = e.touches[0].clientY;
            _swipeLocked = false;
          }, { passive: true });
          _payEl.addEventListener('touchmove', (e) => {
            if (_swipeStartX === null || _swipeLocked) return;
            const dx = e.touches[0].clientX - _swipeStartX;
            const dy = e.touches[0].clientY - _swipeStartY;
            if (Math.abs(dy) > Math.abs(dx) + 8) { _swipeStartX = null; return; }
            if (Math.abs(dx) > 12) _swipeLocked = true;
          }, { passive: true });
          _payEl.addEventListener('touchend', (e) => {
            if (_swipeStartX === null) return;
            const dx = e.changedTouches[0].clientX - _swipeStartX;
            _swipeStartX = null; _swipeLocked = false;
            if (Math.abs(dx) < 50) return;
            const prevBtn = document.getElementById('payrollPrev');
            const nextBtn = document.getElementById('payrollNext');
            if (dx < 0) {
              if (nextBtn) nextBtn.click();
            } else {
              if (prevBtn) prevBtn.click();
            }
          }, { passive: true });
        })();

        document.getElementById('btnPrev').addEventListener('click', () => {
          state.month--;
          if (state.month < 0) {
            state.month = 11;
            state.year--;
          }
          if (state.payrollSync !== false) {
            state.payrollYear = state.year;
            state.payrollMonth = state.month;
            renderExtras();
            calculatePayroll();
          }
          renderCalendar('prev');
          updateVacation();
          updateStats();
        });

        document.getElementById('btnNext').addEventListener('click', () => {
          state.month++;
          if (state.month > 11) {
            state.month = 0;
            state.year++;
          }
          if (state.payrollSync !== false) {
            state.payrollYear = state.year;
            state.payrollMonth = state.month;
            renderExtras();
            calculatePayroll();
          }
          renderCalendar('next');
          updateVacation();
          updateStats();
        });

        document.getElementById('btnToday').addEventListener('click', () => {
          const t = new Date();
          state.year = t.getFullYear();
          state.month = t.getMonth();
          if (state.payrollSync !== false) {
            state.payrollYear = state.year;
            state.payrollMonth = state.month;
            renderExtras();
            calculatePayroll();
          }
          renderCalendar();
        });

        // Bér navigáció
        document.getElementById('payrollPrev').addEventListener('click', () => {
          state.payrollMonth--;
          if (state.payrollMonth < 0) {
            state.payrollMonth = 11;
            state.payrollYear--;
          }
          renderExtras();
          calculatePayroll();
        });

        document.getElementById('payrollNext').addEventListener('click', () => {
          state.payrollMonth++;
          if (state.payrollMonth > 11) {
            state.payrollMonth = 0;
            state.payrollYear++;
          }
          renderExtras();
          calculatePayroll();
        });

        document.getElementById('payrollToday').addEventListener('click', () => {
          const t = new Date();
          state.payrollYear = t.getFullYear();
          state.payrollMonth = t.getMonth();
          renderExtras();
          calculatePayroll();
        });

        // Szinkron kapcsoló: bér fül kövesse a naptárt
        function renderPayrollSyncBtn() {
          const btn = document.getElementById('payrollSyncToggle');
          if (!btn) return;
          const on = state.payrollSync !== false;
          btn.textContent = on ? '🔗' : '🔓';
          btn.title = on ? 'Naptárral szinkronizálva – kattints a leválasztáshoz' : 'Önálló hónap – kattints a szinkronizáláshoz';
          btn.style.opacity = on ? '1' : '0.45';
        }
        renderPayrollSyncBtn();
        document.getElementById('payrollSyncToggle').addEventListener('click', () => {
          state.payrollSync = (state.payrollSync === false) ? true : false;
          if (state.payrollSync) {
            state.payrollYear = state.year;
            state.payrollMonth = state.month;
            calculatePayroll();
          }
          renderPayrollSyncBtn();
          saveState();
        });

        document.getElementById('btnPanel').addEventListener('click', () => {
          document.getElementById('shiftPanel').classList.toggle('visible');
        });



        // Bérek panel alapból maszkolt
        maskPayroll();

        document.getElementById('payrollToggle').addEventListener('click', async () => {
          if (payrollVisible) {
            payrollVisible = false;
            maskPayroll();
            document.getElementById('payrollToggle').textContent = '👁️';
            if (payrollTimer) clearTimeout(payrollTimer);
          } else {
            const lockMode = state.incognitoLockMode || 'app';
            // 'app' módban: ha már egyszer feloldottuk az app megnyitása óta, ne kérdezzen újra
            const alreadyUnlockedThisSession = (lockMode === 'app') && payrollUnlockedThisSession;
            if (!alreadyUnlockedThisSession) {
              // Ha biometria engedélyezett a bér nézethez → azonosítás
              if (state.biometricEnabled && state.biometricOnPayroll) {
                const bioAvail = await isBiometricAvailable();
                if (bioAvail) {
                  const ok = await triggerBiometric('Bér megtekintéséhez azonosítsd magad');
                  if (!ok) return;
                }
              } else if (state.privateLockRequired && state.pinEnabled && state.pinHash) {
                // PIN fallback bér nézethez: csak ha a privát zárolás be van kapcsolva
                window._pendingPayrollReveal = true;
                showPinOverlay('verify');
                return;
              }
            }
            payrollUnlockedThisSession = true;
            payrollVisible = true;
            calculatePayroll();
            unmaskPayroll();
            document.getElementById('payrollToggle').textContent = '🙈';
            // Időzített mód: 30 másodperc után visszazár
            if (state.incognitoLockMode === 'timed') {
              if (payrollTimer) clearTimeout(payrollTimer);
              payrollTimer = setTimeout(() => {
                payrollVisible = false;
                maskPayroll();
                const ptEl = document.getElementById('payrollToggle');
                if (ptEl) ptEl.textContent = '👁️';
                payrollTimer = null;
              }, 30000);
            }
          }
        });

        // Alapadatok
        document.getElementById('grundlohn').addEventListener('input', (e) => {
          state.grundlohn = e.target.value ? parseFloat(e.target.value) : null;
          const stl = (state.grundlohn || 0) / (state.feststunden || 174);
          document.getElementById('stundenlohn').textContent = stl.toFixed(2) + ' €';
          // Ha még nincs initial grundlohn mentve (pl. onboarding előtt kézzel állítja be), mentsük el
          if (state.grundlohn > 0 && !localStorage.getItem('chronos_raise_initial_grundlohn')) {
            localStorage.setItem('chronos_raise_initial_grundlohn', state.grundlohn);
          }
          saveState();
          calculatePayroll();
          if (window.updateStatPrognosis) window.updateStatPrognosis();
          // Auto-bezárás szándékosan KIKAPCSOLVA – ne zárja be gépelés közben
        });

        (function() {
          function _onFeststundenChange(e) {
            const val = parseFloat(e.target.value);
            state.feststunden = (val > 0) ? val : 174;
            if (!val || val <= 0) e.target.value = 174;
            const stl = (state.grundlohn || 0) / state.feststunden;
            document.getElementById('stundenlohn').textContent = stl.toFixed(2) + ' €';
            saveState();
            calculatePayroll();
          }
          document.getElementById('feststunden').addEventListener('input', _onFeststundenChange);
          document.getElementById('feststunden').addEventListener('change', _onFeststundenChange);
        })();

        document.getElementById('vacBase').addEventListener('input', (e) => {
          const current = getCurrentYearVacation();
          current.base = parseFloat(e.target.value) || 0;
          updateVacation();
          saveState();
          calculatePayroll();
        });

        document.getElementById('taxClass').addEventListener('change', (e) => {
          state.taxClass = parseInt(e.target.value);
          saveState();
          calculatePayroll();
        });

        document.getElementById('kinder').addEventListener('input', (e) => {
          state.kinder = parseFloat(e.target.value) || 0;
          saveState();
          calculatePayroll();
        });

        document.getElementById('kirche').addEventListener('change', (e) => {
          state.kirche = parseInt(e.target.value);
          saveState();
          calculatePayroll();
        });

        document.getElementById('birthYear').addEventListener('input', (e) => {
          state.birthYear = parseInt(e.target.value) || 1990;
          saveState();
          calculatePayroll();
        });

        document.getElementById('bundesland').addEventListener('change', (e) => {
          state.bundesland = e.target.value;
          saveState();
          calculatePayroll();
        });

        if (document.getElementById('krankenkasse')) {
          document.getElementById('krankenkasse').addEventListener('change', (e) => {
            state.krankenkasse = e.target.value;
            document.getElementById('kkCustomRow').style.display = e.target.value === 'custom' ? 'flex' : 'none';
            saveState();
            calculatePayroll();
          });
        }

        document.getElementById('addPotlekBtn').addEventListener('click', () => {
          state.potlekRules.push({
            name: '',
            start: '00:00',
            end: '01:00',
            percent: 25,
            type: 'normal',
            taxFree: false
          });
          renderPotlek();
          saveState();
          renderShifts();
        });

        document.getElementById('pinSwitch').addEventListener('click', function() {
          if (state.pinEnabled && state.pinHash) {
            const overlay = document.getElementById('pinOverlay');
            overlay.dataset.mode = 'disable';
            buildPinPad('disable');
            overlay.classList.add('visible');
          } else {
            pinInput = '';
            firstPin = '';
            setupPhase = 'first';
            const overlay = document.getElementById('pinOverlay');
            overlay.dataset.mode = 'setup';
            buildPinPad('setup');
            overlay.classList.add('visible');
          }
        });

        // Globálisan elérhető PIN setup – pl. terms elfogadás után
        window.openPinSetup = function() {
          if (state.pinEnabled && state.pinHash) return; // már van PIN
          pinInput = '';
          firstPin = '';
          setupPhase = 'first';
          const overlay = document.getElementById('pinOverlay');
          overlay.dataset.mode = 'setup';
          buildPinPad('setup');
          overlay.classList.add('visible');
        };

        // Biometria kapcsolók
        renderBioSwitches();
        // Privát zárolás kapcsoló
        renderPrivateLockSwitch();
        document.getElementById('incognitoLockModeSelect').addEventListener('change', function() {
          state.incognitoLockMode = this.value;
          saveState();
          // Ha 'timed' mód van és a bér látható → indítsuk el a timert
          if (this.value === 'timed' && payrollVisible) {
            if (payrollTimer) clearTimeout(payrollTimer);
            payrollTimer = setTimeout(() => {
              payrollVisible = false;
              maskPayroll();
              const ptEl = document.getElementById('payrollToggle');
              if (ptEl) ptEl.textContent = '👁️';
              payrollTimer = null;
            }, 30000);
          } else if (this.value !== 'timed' && payrollTimer) {
            clearTimeout(payrollTimer);
            payrollTimer = null;
          }
        });

        document.getElementById('privateBtnSwitch').addEventListener('click', function() {
          state.showPrivateBtn = (state.showPrivateBtn === false) ? true : false;
          saveState();
          renderPrivateLockSwitch();
          updateLockBtnVisibility();
        });

        // Haptikus visszajelzés kapcsoló
        const hapticsSw = document.getElementById('hapticsSwitch');
        if (hapticsSw) {
          hapticsSw.classList.toggle('on', state.hapticsEnabled !== false);
          hapticsSw.addEventListener('click', function() {
            state.hapticsEnabled = (state.hapticsEnabled === false) ? true : false;
            hapticsSw.classList.toggle('on', state.hapticsEnabled);
            saveState();
            if (state.hapticsEnabled) haptic('medium'); // azonnali visszajelzés bekapcsoláskor
          });
        }

        document.getElementById('bioSwitch').addEventListener('click', async function() {
          if (state.biometricEnabled) {
            state.biometricEnabled = false;
            state.webauthnCredentialId = ''; // PWA credential is törlődik
            saveState();
            renderBioSwitches();
          } else {
            const avail = await isBiometricAvailable();
            if (!avail) {
              showNotification(t('biometricNotAvailable') || '⚠️ A biometria nem elérhető ezen az eszközön.', 3000, 'warning');
              return;
            }
            // PWA: triggerBiometric create-ággal regisztrálja a credentialt (state.webauthnCredentialId)
            const ok = await triggerBiometric('Biometria aktiválásához azonosítsd magad');
            if (ok) {
              state.biometricEnabled = true;
              saveState();
              renderBioSwitches();
            }
          }
        });

        document.getElementById('bioOnStartSwitch').addEventListener('click', function() {
          state.biometricOnStart = !state.biometricOnStart;
          saveState(); renderBioSwitches();
        });
        document.getElementById('bioOnAutoLockSwitch').addEventListener('click', function() {
          state.biometricOnAutoLock = !state.biometricOnAutoLock;
          saveState(); renderBioSwitches();
        });
        document.getElementById('bioOnPayrollSwitch').addEventListener('click', function() {
          state.biometricOnPayroll = !state.biometricOnPayroll;
          saveState(); renderBioSwitches();
        });

        document.getElementById('exportBtn').addEventListener('click', async () => {
          const defaultName = `chronos_${new Date().toISOString().slice(0, 10)}`;
          const name = prompt(t('exportFilename')||'File name:', defaultName);
          if (name === null) return;

          const filename = (name || defaultName).replace(/\.json$/, '') + '.json';
          const data = JSON.stringify(state, null, 2);

          // ── 1. Capacitor (Android APK) – natív "Mentés másként" dialógus ──
          // Az AndroidBridge.saveFileWithPicker() az Android Storage Access
          // Framework-öt használja (Intent.ACTION_CREATE_DOCUMENT): a
          // felhasználó kiválasztja a mappát és a fájlnevet, pontosan úgy,
          // mint PC-n. Ez tényleges mentés, nem megosztás.
          if (window.Capacitor) {

            if (window.AndroidBridge && typeof window.AndroidBridge.saveFileWithPicker === 'function') {
              const b64 = btoa(unescape(encodeURIComponent(data)));
              const callbackName = '__chronosSaveCb_' + Date.now();

              const savedOk = await new Promise((resolve) => {
                window[callbackName] = (success, message) => {
                  delete window[callbackName];
                  if (!success && message !== 'cancelled') {
                    console.warn('saveFileWithPicker failed:', message);
                  }
                  resolve(success);
                };
                try {
                  window.AndroidBridge.saveFileWithPicker(filename, b64, callbackName);
                } catch (e) {
                  delete window[callbackName];
                  console.warn('saveFileWithPicker exception:', e);
                  resolve(false);
                }
              });

              if (savedOk) {
                localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
                return;
              }
              // Ha a felhasználó "Mégse"-t nyomott a dialógusban, ne ajánljunk
              // fel rögtön egy másik mentési módot — egyszerűen nem történt semmi.
            }

            // 1b. Fallback: AndroidBridge.shareFile() – megosztás más appnak
            if (window.AndroidBridge && typeof window.AndroidBridge.shareFile === 'function') {
              try {
                const b64 = btoa(unescape(encodeURIComponent(data)));
                const result = window.AndroidBridge.shareFile(filename, b64);
                if (result === 'ok') {
                  localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
                  return;
                }
                console.warn('AndroidBridge.shareFile failed:', result);
              } catch (e) {
                console.warn('AndroidBridge.shareFile exception:', e);
              }
            }

            // 1c. Capacitor Filesystem + Share plugin (ha esetleg telepítve van)
            const Plugins = window.Capacitor.Plugins || {};
            if (Plugins.Filesystem && Plugins.Share) {
              try {
                const b64 = btoa(unescape(encodeURIComponent(data)));
                const writeResult = await Plugins.Filesystem.writeFile({
                  path: filename,
                  data: b64,
                  directory: 'CACHE',
                  encoding: null
                });
                await Plugins.Share.share({
                  title: filename,
                  url: writeResult.uri,
                  dialogTitle: filename
                });
                localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
                return;
              } catch (e) {
                if (e.name === 'AbortError' || (e.message && e.message.includes('cancel'))) return;
                console.warn('Filesystem+Share failed, trying next method:', e);
              }
            }

            // 1d. Web Share API fájlmegosztással (Share API + File object)
            if (navigator.canShare) {
              try {
                const file = new File([data], filename, { type: 'application/json' });
                if (navigator.canShare({ files: [file] })) {
                  await navigator.share({ files: [file], title: filename });
                  localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
                  return;
                }
              } catch (e) {
                if (e.name === 'AbortError') return;
                console.warn('Web Share API failed, trying data URI fallback:', e);
              }
            }

            // 1e. Data URI fallback
            try {
              const b64uri = 'data:application/json;base64,' + btoa(unescape(encodeURIComponent(data)));
              const a = document.createElement('a');
              a.href = b64uri;
              a.download = filename;
              a.style.display = 'none';
              document.body.appendChild(a);
              a.click();
              setTimeout(() => document.body.removeChild(a), TIMING.DOWNLOAD_CLEANUP);
              localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
              return;
            } catch (e) {
              console.warn('Data URI download failed:', e);
            }

            // 1f. Végső fallback: szöveg megjelenítése kézi mentéshez
            try {
              const ta = document.createElement('textarea');
              ta.value = data;
              ta.style.cssText = 'position:fixed;top:10px;left:10px;right:10px;bottom:10px;z-index:99999;font-size:10px;white-space:pre;';
              document.body.appendChild(ta);
              ta.select();
              const closeBtn = document.createElement('button');
              closeBtn.textContent = t('exportCloseBtn')||'✖ Bezárás (másold ki a tartalmat)';
              closeBtn.style.cssText = 'position:fixed;top:10px;right:10px;z-index:100000;padding:8px 14px;background:#e74c3c;color:#fff;border:none;border-radius:6px;font-size:13px;cursor:pointer;';
              closeBtn.onclick = () => { document.body.removeChild(ta); document.body.removeChild(closeBtn); };
              document.body.appendChild(closeBtn);
            } catch(e2) {}
            return;
          }

          // ── 2. Böngésző / PWA fallback – anchor download ──
          const blob = new Blob([data], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          setTimeout(() => { URL.revokeObjectURL(url); document.body.removeChild(a); }, TIMING.DOWNLOAD_CLEANUP);
          localStorage.setItem(LS.lastBackupReminder, Date.now().toString());
        });

        document.getElementById('deleteAllDataBtn').addEventListener('click', () => {
          if (confirm(t('confirmDeleteAll') || 'Delete ALL data?')) {
            state.schedules = {};
            state.customShifts = [];
            state.resturlaub.years = {};
            saveState();
            renderCalendar();
            updateVacation();
            updateStats();
            renderVacationHistory();
          }
        });

        // Telepítési útmutató gomb a Beállításokban
        const installGuideBtn = document.getElementById('showInstallGuideBtn');
        if (installGuideBtn) {
          installGuideBtn.addEventListener('click', () => {
            const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
            const isAndroid = /android/i.test(navigator.userAgent);
            const isStandalone = window.navigator.standalone || window.matchMedia('(display-mode: standalone)').matches;
            if (isStandalone) {
              alert(t('alreadyInstalled') || '✅ Az app már telepítve van!');
              return;
            }
            if (isIOS) {
              document.getElementById('iosInstallModal').style.display = 'flex';
            } else if (isAndroid && window._androidInstallPrompt) {
              window._androidInstallPrompt.prompt();
            } else {
              const banner = document.getElementById('pwaInstallBanner');
              if (banner) { banner.style.display = 'flex'; }
              else { alert(t('installManual') || '📲 Telepítés: Böngésző menü → Hozzáadás a főképernyőhöz'); }
            }
          });
        }

        // Szerkesztési állapot
        let _editingShiftId = null;

        window.openShiftEdit = function(s) {
          _editingShiftId = s.id;
          document.getElementById('modalTitle').textContent = t('editModalTitle')||'✏️ Szerkesztés';
          document.getElementById('modalName').value = s.name || '';
          document.getElementById('modalNameDe').value = s.nameDe || '';
          document.getElementById('modalNameEn').value = s.nameEn || '';
          document.getElementById('modalColor').value = s.color || '#4ade80';
          // Builtin esetén a name mezők readonly
          document.getElementById('modalNameDe').style.display = s.builtin ? 'none' : '';
          document.getElementById('modalNameEn').style.display = s.builtin ? 'none' : '';
          document.getElementById('shiftModal').classList.add('visible');
        };

        document.getElementById('modalSave').addEventListener('click', () => {
          const name = document.getElementById('modalName').value.trim();
          if (!name) return;

          if (_editingShiftId) {
            // Szerkesztés módban
            const allShifts = getAllShifts();
            const existing = allShifts.find(s => s.id === _editingShiftId);
            if (existing) {
              existing.name = name;
              existing.color = document.getElementById('modalColor').value;
              if (!existing.builtin) {
                existing.nameDe = document.getElementById('modalNameDe').value || name;
                existing.nameEn = document.getElementById('modalNameEn').value || name;
                const idx2 = (state.customShifts || []).findIndex(cs => cs.id === _editingShiftId);
                if (idx2 !== -1) {
                  state.customShifts[idx2].name = name;
                  state.customShifts[idx2].nameDe = existing.nameDe;
                  state.customShifts[idx2].nameEn = existing.nameEn;
                  state.customShifts[idx2].color = existing.color;
                }
              } else {
                // Beépített: csak szín + display neve
                if (!state.builtinOverrides) state.builtinOverrides = {};
                state.builtinOverrides[_editingShiftId] = {
                  name: name,
                  color: document.getElementById('modalColor').value
                };
              }
            }
            _editingShiftId = null;
          } else {
            // Új műszak
            state.customShifts.push({
              id: 'custom_' + Date.now(),
              name: name,
              nameDe: document.getElementById('modalNameDe').value || name,
              nameEn: document.getElementById('modalNameEn').value || name,
              color: document.getElementById('modalColor').value,
              builtin: false
            });
          }

          // Reset modal title
          document.getElementById('modalTitle').textContent = t('newShiftTitle') || 'New shift';
          document.getElementById('modalNameDe').style.display = '';
          document.getElementById('modalNameEn').style.display = '';
          saveState();
          renderShifts();
          document.getElementById('shiftModal').classList.remove('visible');
        });

        document.getElementById('modalCancel').addEventListener('click', () => {
          _editingShiftId = null;
          document.getElementById('modalTitle').textContent = t('newShiftTitle') || 'New shift';
          document.getElementById('modalNameDe').style.display = '';
          document.getElementById('modalNameEn').style.display = '';
          document.getElementById('shiftModal').classList.remove('visible');
        });

        // Event delegation: document szinten figyeljük, így DOM mozgatás után sem veszik el
        const _viewOrder = ['calendar','payroll','stats','settings'];
        let _activeViewIdx = 0;
        document.addEventListener('click', (e) => {
          const btn = e.target.closest('.nav-item');
          if (!btn) return;
          {
            const newView = btn.dataset.view;
            const newIdx = _viewOrder.indexOf(newView);
            const slideDir = newIdx > _activeViewIdx ? 'r' : 'l';
            _activeViewIdx = newIdx >= 0 ? newIdx : _activeViewIdx;

            document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Bounce animáció az ikonon
            const iconWrap = btn.querySelector('.nav-icon-wrap');
            if (iconWrap) {
              iconWrap.classList.remove('bouncing');
              void iconWrap.offsetWidth; // reflow
              iconWrap.classList.add('bouncing');
              iconWrap.addEventListener('animationend', () => iconWrap.classList.remove('bouncing'), { once: true });
            }

            // Tab slide animáció
            document.querySelectorAll('.tab-content').forEach(v => {
              v.classList.remove('active', 'slide-in-r', 'slide-in-l');
            });
            const targetView = document.getElementById(newView + '-view');
            if (targetView) {
              targetView.classList.add('active', slideDir === 'r' ? 'slide-in-r' : 'slide-in-l');
            }

            // Ha elhagyják a bér fület → csak 'tab' módban zárol vissza azonnal
            if (btn.dataset.view !== 'payroll' && payrollVisible) {
              const lockMode = state.incognitoLockMode || 'app';
              if (lockMode === 'tab') {
                payrollVisible = false;
                payrollUnlockedThisSession = false;
                maskPayroll();
                document.getElementById('payrollToggle').textContent = '👁️';
                if (payrollTimer) { clearTimeout(payrollTimer); payrollTimer = null; }
              }
              // 'app' és 'timed' módban NEM zárol vissza lapváltáskor – csak app bezáráskor / timer lejártakor
            }

            if (btn.dataset.view === 'payroll') {
              // Szinkronizálás a naptár aktuális hónapjával (csak ha nincs payrollSync=false)
              if (state.payrollSync !== false) {
                state.payrollYear = state.year;
                state.payrollMonth = state.month;
              }
              renderExtras();
              calculatePayroll();
              // Ha nincs alapbér VAGY születési év megadva, nyissa ki az Alapadatok fület
              const _by = parseInt(document.getElementById('birthYear')?.value || '0');
              const _baseDataComplete = (state.grundlohn > 0) && (_by >= 1900 && _by <= 2010);
              if (!_baseDataComplete) {
                const acc = document.getElementById('baseDataAccordion');
                if (acc && !acc.classList.contains('open')) {
                  acc.classList.add('open');
                }
                // Első megnyitásnál értesítő üzenet
                if (!localStorage.getItem(LS.lohnFirstVisited)) {
                  localStorage.setItem(LS.lohnFirstVisited, '1');
                  showNotification('⚠️ ' + (t('lohnNoBaseData') || 'Kérlek töltsd ki az alapadatokat a bérkiszámításhoz!'), 4000, 'warning');
                }
                setTimeout(() => {
                  if (acc) acc.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  const inp = document.getElementById('grundlohn');
                  if (inp) {
                    inp.focus();
                    inp.classList.add('highlight-pulse');
                    setTimeout(() => inp.classList.remove('highlight-pulse'), TIMING.HIGHLIGHT_PULSE);
                  }
                }, 150);
              }
            }
            if (btn.dataset.view === 'stats') {
              updateStats();
              renderVacationHistory();
            }
            if (btn.dataset.view === 'settings') {
              // Névmező szinkron a mentett névvel
              if (typeof window._syncSettingsNameInput === 'function') {
                window._syncSettingsNameInput();
              }
              // Personal Nr. mező szinkron
              if (typeof window._syncSettingsPersonalNrInput === 'function') {
                window._syncSettingsPersonalNrInput();
              }
              // Csoportmező szinkron
              if (typeof window._syncSettingsGroupInput === 'function') {
                window._syncSettingsGroupInput();
              }
              // Profil badge frissítés a frissen beszinkronizált értékekkel
              if (typeof window.checkProfileBadge === 'function') {
                window.checkProfileBadge();
              }
              // Téma-választó gombok kiemelésének szinkronja
              if (typeof window.setTheme === 'function' && state.currentTheme) {
                window.setTheme(state.currentTheme);
              }
              // Órabér frissítés
              const _stl = (parseFloat(state.grundlohn) || 0) / (parseFloat(state.feststunden) || 174);
              document.getElementById('stundenlohn').textContent = _stl.toFixed(2) + ' €';
            }
          }
        });

        document.querySelectorAll('.accordion-header').forEach(h => {
          h.addEventListener('click', function() {
            const acc = this.parentElement;
            acc.classList.toggle('open');
            const wrap = acc.querySelector('#addPotlekWrap');
            if (wrap) wrap.style.display = acc.classList.contains('open') ? 'block' : 'none';
          });
        });

        document.querySelector('.card-title span')?.addEventListener('click', () => {
          alert(t('payrollDisclaimer') || 'Informational data only! Exact calculation may differ from your employer\'s payroll.');
        });

        document.getElementById('autoLockSelect')?.addEventListener('change', (e) => {
          state.autoLock = parseInt(e.target.value);
          saveState();
          initAutoLock();
        });

        // ── AUTO-ZÁROLÁS IMPLEMENTÁCIÓ ──
        let autoLockTimer = null;
        let lastActivityTime = Date.now();

        function resetAutoLockTimer() {
          lastActivityTime = Date.now();
          if (autoLockTimer) clearTimeout(autoLockTimer);
          if (!state.autoLock || !state.pinEnabled || !state.pinHash) return;
          autoLockTimer = setTimeout(triggerAutoLock, state.autoLock * 1000);
        }

        function triggerAutoLock() {
          if (!state.pinEnabled || !state.pinHash) return;
          const overlay = document.getElementById('pinOverlay');
          if (overlay && !overlay.classList.contains('visible')) {
            if (state.biometricEnabled && state.biometricOnAutoLock) {
              unlockWithBiometricOrPin('unlock');
            } else {
              overlay.dataset.mode = 'unlock';
              buildPinPad('unlock');
              overlay.classList.add('visible');
            }
          }
        }

        function initAutoLock() {
          if (autoLockTimer) clearTimeout(autoLockTimer);
          if (!state.autoLock || !state.pinEnabled || !state.pinHash) return;
          // Aktivitás figyelés
          ['touchstart', 'mousedown', 'keydown', 'scroll'].forEach(ev => {
            document.removeEventListener(ev, resetAutoLockTimer);
            document.addEventListener(ev, resetAutoLockTimer, { passive: true });
          });
          // Lap elrejtésnél azonnal zárol
          document.removeEventListener('visibilitychange', onVisibilityChange);
          document.addEventListener('visibilitychange', onVisibilityChange);
          resetAutoLockTimer();
        }

        function onVisibilityChange() {
          if (document.hidden && state.pinEnabled && state.pinHash && state.autoLock > 0) {
            // Ha a lap elrejted, zárolj a visszatéréskor
            triggerAutoLock();
          }
        }

        // Indítás után auto-lock beállítása
        initAutoLock();

        // Fázis 4: meglévő felhasználóknak fiók-ajánlat (ha firebase + nincs login)
        if (typeof window.checkAndOfferCloudAccount === 'function') {
          window.checkAndOfferCloudAccount();
        }

        // Firebase: auth változáskor (késői bejelentkezés / másik eszköz) töltsük újra
        if (window.CLOUD_BACKEND === 'firebase' && window.ChronosCloud && typeof window.ChronosCloud.onAuthChange === 'function') {
          window.ChronosCloud.onAuthChange(function(user) {
            if (user) {
              console.log('Chronos: auth user → felhő betöltés');
              loadStateFromCloud();
            }
          });
        }
      }

      // Indítás
      document.addEventListener('DOMContentLoaded', () => {
        init();
        checkMonthlyTaxRates();
        checkOnboarding();
      });

      // ─── Globális hozzáférés a rotáció szkript számára ──────────────────────────
      window._chronosState         = () => state;
      window._chronosAllShifts     = () => getAllShifts();
      window._chronosShiftName     = (s) => getShiftName(s);
      window._chronosSaveState     = () => { saveState(); setTimeout(function(){ if(window._arDetectFromSchedule) window._arDetectFromSchedule(); else if(window._arUpdateBtnVisibility) window._arUpdateBtnVisibility(); }, TIMING.AR_BTN_AFTER_SAVE); };
      window._chronosRender        = () => { renderCalendar(); updateVacation(); updateStats(); };
      window._chronosIsHoliday     = (y,m,d) => isPublicHoliday(y,m,d);
      window._chronosTranslations  = TRANSLATIONS;

      // ── Pontos havi nettó közelítés (offline, DOM-mentes) ──
      // Ugyanaz a SV + Lohnsteuer logika mint a Bér fülön, de bármely hónapra hívható.
      window._chronosCalcMonthNetto = function(yr, mo) {
        try {
          const r = calcMonthBruttoFull(yr, mo);
          if (!r || r.brutto == null) return null;
          const brutto = r.brutto;
          // SV rates (same as calculatePayroll)
          const kkId   = state.krankenkasse || 'AOK_BW';
          const KK_R   = {'AOK_BW':2.99,'AOK_BY':2.69,'AOK_PLUS':3.10,'TK':2.69,'DAK':3.20,'BARMER':3.29,'KKH':3.78,'IKK_BW':3.40,'BKK':3.50};
          const kkZ    = (kkId==='custom' ? 1.70 : (KK_R[kkId]||1.70)) / 100;
          const kinder = parseFloat(state.kinder) || 0;
          const bYear  = parseInt(state.birthYear) || 1990;
          const kindlos = kinder===0 && (new Date().getFullYear()-bYear)>=23 ? 0.006 : 0;
          const _svL   = window._svLiveRates || {};
          const BBG_RV = _svL.BBG_RV  || 8450;
          const BBG_KV = _svL.BBG_KV  || 5812.50;
          const SV     = { rv:0.093, kv:0.073+kkZ/2, pv:(_svL.pv_base||0.018)+kindlos, av:0.013 };
          const sv     = Math.min(brutto,BBG_RV)*(SV.rv+SV.av) + Math.min(brutto,BBG_KV)*(SV.kv+SV.pv);
          // Offline Lohnsteuer (replicated calcLohnsteuerLocal)
          const tc   = parseInt(state.taxClass) || 1;
          const gfB  = _svL.grundfreibetrag || 12348;
          const kfbH = _svL.kinderfreibetragHalb || 4872;
          const _lp  = _svL.lohnsteuerParams || {
            s1_to:17799, s2_to:69878, s3_to:277825,
            s1_a:914.51, s1_b:1400,
            s2_a:172.31, s2_b:2397, s2_c:1025.38,
            s3_k:0.42, s3_d:10908.16, s4_k:0.45, s4_d:19470.38,
            grundfreibetrag: gfB
          };
          const freib = ({1:gfB, 2:Math.round(gfB*1.12+144), 3:gfB*2, 4:gfB, 5:0, 6:0})[tc] || gfB;
          const WERBK = tc===3 ? 2460 : (tc>=5 ? 0 : 1230);
          const z  = brutto * 12;
          const rvJ = Math.min(z, BBG_RV*12), kvJ = Math.min(z, BBG_KV*12);
          let vp = 0;
          if (tc===3) { vp = rvJ*SV.rv*2 + rvJ*SV.av*2 + kvJ*(SV.kv+SV.pv); }
          else if (tc<=4) { vp = rvJ*SV.rv + rvJ*SV.av + kvJ*(SV.kv+SV.pv); }
          const zvE  = Math.max(0, Math.floor(z - kinder*kfbH - vp - WERBK));
          let steuer = 0;
          if (zvE<=freib) { steuer=0; }
          else if (zvE<=_lp.s1_to) { const y=(zvE-_lp.grundfreibetrag)/10000; steuer=(_lp.s1_a*y+_lp.s1_b)*y; }
          else if (zvE<=_lp.s2_to) { const z2=(zvE-_lp.s1_to)/10000; steuer=(_lp.s2_a*z2+_lp.s2_b)*z2+_lp.s2_c; }
          else if (zvE<=_lp.s3_to) { steuer=_lp.s3_k*zvE-_lp.s3_d; }
          else { steuer=_lp.s4_k*zvE-_lp.s4_d; }
          if (tc===5) steuer=Math.max(0,steuer*1.35);
          if (tc===6) steuer=zvE*0.42;
          const lst = Math.max(0, steuer/12);
          const SOLI_FR = 20350/12;
          const soli = lst>SOLI_FR ? Math.min(lst*0.055,(lst-SOLI_FR)*0.119) : 0;
          const bl   = state.bundesland||'BW';
          const kirche = (typeof state.kirche==='boolean') ? state.kirche : (parseInt(state.kirche)>0);
          const kst  = lst * (kirche ? (bl==='BY'||bl==='BW' ? 0.08 : 0.09) : 0);
          // Egyéb levonások
          let otherD = 0;
          if (state.darlehen && state.darlehen.enabled) {
            const _dm=parseFloat(state.darlehen.monthly)||0, _db=parseFloat(state.darlehen.balance)||0;
            if (_dm>0) otherD += _db>0 ? Math.min(_dm,_db) : _dm;
          }
          if (state.otherDeductionsEnabled && state.otherDeductions) {
            state.otherDeductions.forEach(d => {
              if (!d.month || parseInt(d.month)===mo) otherD += parseFloat(d.amount)||0;
            });
          }
          let ezNet = 0;
          if (state.einmalzahlung && state.einmalzahlung.enabled) {
            (state.einmalzahlung.payments||[]).forEach(p => {
              const pm=p.month?parseInt(p.month):null;
              if ((!pm||pm===mo) && p.type==='netto') ezNet += parseFloat(p.amount)||0;
            });
          }
          const netto = Math.max(0, brutto - sv - lst - soli - kst - otherD) + ezNet;
          return { brutto, netto };
        } catch(e) { return null; }
      };
      window._chronosSetSchedule   = (key, val) => { if(val===null) delete state.schedules[key]; else state.schedules[key]=val; };
      window._chronosEnsureSchedules = () => { if(!state.schedules) state.schedules={}; };
      window._chronosSetYearMonth  = (y,m) => { state.year=y; state.month=m; };

      // ── §4.35 Globális fordítás-helper (window._t) ────────────────────────────
      // Minden külső scope (RotWidget, ZeusWidget, PWA, AutoRot) ezt használhatja
      // az ismétlődő `window._currentTranslations&&window._currentTranslations[k]`
      // mintázat helyett. Lookup-sorrend:
      //   1. _currentTranslations (setLanguage() által beállított aktív fordítás)
      //   2. TRANSLATIONS[state.currentLang]  (IIFE-belső fallback)
      //   3. TRANSLATIONS.hu                  (magyar végső fallback)
      //   4. maga a kulcs (nincs fordítás)
      window._t = function(key) {
        if (window._currentTranslations && window._currentTranslations[key] !== undefined)
          return window._currentTranslations[key];
        var lang = state ? state.currentLang : 'hu';
        var tr = TRANSLATIONS[lang] || TRANSLATIONS.hu;
        return (tr && tr[key] !== undefined) ? tr[key] : key;
      };

      // ── Közös status-helper (_chronosSetStatus) ───────────────────────────────
      // Egyesíti a pdfSetStatus / rotSetStatus / showStatus ismétlődő logikáját.
      // Paraméterek:
      //   elementId  – a célelem ID-ja (pl. 'pdfStatus', 'rotStatus', 'status')
      //   msg        – megjelenítendő szöveg (üres → elrejti az elemet)
      //   type       – 'info' | 'ok' | 'success' | 'warn' | 'warning' | 'error' | 'err'
      // CSS osztály/szín a típus alapján – az egyes widgetek saját setStatus-ai
      // továbbra is működnek, de hívhatnak idekalibrálva.
      window._chronosSetStatus = function(elementId, msg, type) {
        var el = document.getElementById(elementId);
        if (!el) return;
        el.textContent = msg || '';
        el.style.display = msg ? 'block' : 'none';
        var t = (type || 'info').replace('success','ok').replace('warning','warn').replace('err','error');
        var bg = { info:'rgba(95,158,247,0.12)', ok:'rgba(74,222,128,0.1)',
                   warn:'rgba(255,179,71,0.1)',  error:'rgba(255,80,80,0.1)' };
        var bd = { info:'rgba(95,158,247,0.25)', ok:'rgba(74,222,128,0.25)',
                   warn:'rgba(255,179,71,0.25)', error:'rgba(255,80,80,0.25)' };
        el.style.background = bg[t] || bg.info;
        el.style.border     = '1px solid ' + (bd[t] || bd.info);
        el.style.color      = 'var(--text)';
      };

    })();


// ════════════════════════════════════════════════════════════════════
//  CHRONOS UI KIEGÉSZÍTÉSEK (eredetileg külön script-blokk)
// ════════════════════════════════════════════════════════════════════
// ════════════════════════════════════════════════════════════════════
//  CHRONOS UI KIEGÉSZÍTÉSEK
//  Drive dialog, Gmail toggle, Profil accordion, Statisztika prognózis
// ════════════════════════════════════════════════════════════════════

// ── Drive Dialog ──
window.openDriveDialog = function() {
  const el = document.getElementById('drvSyncOverlay');
  if (el) el.style.display = 'flex';
};
window.closeDriveDialog = function() {
  const el = document.getElementById('drvSyncOverlay');
  if (el) el.style.display = 'none';
};

// ── Fázis 4: Fiók-ajánlat meglévő felhasználóknak ──────────────────
// Megjelenik egyszer init() után, ha firebase backend aktív, user nincs
// bejelentkezve, onboarding kész, és még nem láttuk az ajánlatot.
// "Később" csak elrejti (flag beállítva) — a Beállítások → Fiók továbbra is elérhető.
var _acctOfferMode = false;

window.checkAndOfferCloudAccount = function() {
  try {
    if (window.CLOUD_BACKEND !== 'firebase') return;
    if (!window.ChronosCloud || !window.ChronosCloud.isConfigured()) return;
    if (window.ChronosCloud.isLoggedIn()) return;
    var onboardingDone = localStorage.getItem((window.LS && window.LS.onboardingDone) || 'chronos_onboarding_done');
    if (onboardingDone !== '1') return;
    var offerKey = (window.LS && window.LS.cloudOfferShown) || 'chronos_cloud_offer_shown';
    if (localStorage.getItem(offerKey) === '1') return;
    // Kis késleltetés, hogy az UI és a Drive-load elindulhasson előbb
    setTimeout(function() {
      if (window.ChronosCloud && window.ChronosCloud.isLoggedIn()) return;
      _acctOfferMode = true;
      // Felirat: ajánlat szöveg
      var sub = document.getElementById('acctLoggedOutSub');
      var tr = window._currentTranslations || {};
      if (sub) sub.textContent = tr.accountOfferSub || 'Mostantól fiókkal védheted és szinkronizálhatod az adataidat az eszközök között.';
      // "Mégse" gombok → "Később" szöveg (csak a logged-out boxban lévő cancel)
      var cancelBtns = document.querySelectorAll('#acctLoggedOutBox .drv-cancel[onclick*="closeAccountDialog"]');
      cancelBtns.forEach(function(b) {
        b.textContent = tr.accountOfferLater || 'Később';
      });
      // Flag azonnal — ne zavarjon minden indításkor; user a Beállításokból bármikor megnyithatja
      localStorage.setItem(offerKey, '1');
      if (typeof window.openAccountDialog === 'function') {
        window.openAccountDialog();
      }
    }, 2500);
  } catch (e) {
    console.warn('checkAndOfferCloudAccount:', e);
  }
};

// ── Fiók Dialog (Settings → Adatkezelés → ☁️ Fiók) ──────────────────
// Ugyanaz a ChronosCloud API-t használja, mint az onboarding Fiók-lépés.
// Ha CLOUD_BACKEND nem 'firebase' vagy nincs konfigurálva, figyelmeztet
// és nem nyitja meg a dialógust (nincs mit csinálni).
var _acctMode = 'login'; // 'login' | 'register' — Settingsben alapból login, mert itt inkább visszatérő usereket várunk

window.openAccountDialog = function() {
  if (!window.ChronosCloud || !window.ChronosCloud.isConfigured()) {
    if (typeof showNotification === 'function') {
      showNotification((window._currentTranslations && window._currentTranslations.accountNotAvailable) || '⚠️ A felhő-fiók még nincs beállítva.');
    } else {
      alert((window._currentTranslations && window._currentTranslations.accountNotAvailable) || 'A felhő-fiók még nincs beállítva.');
    }
    return;
  }
  var errEl = document.getElementById('acctError');
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  var emailIn = document.getElementById('acctEmailInput');
  var pwIn = document.getElementById('acctPasswordInput');
  var pwIn2 = document.getElementById('acctPasswordInput2');
  if (emailIn) emailIn.value = '';
  if (pwIn) pwIn.value = '';
  if (pwIn2) pwIn2.value = '';
  if (pwIn2) pwIn2.style.display = (_acctMode === 'register') ? '' : 'none';
  _acctSyncBoxes();
  var el = document.getElementById('acctOverlay');
  if (el) el.style.display = 'flex';
};

window.closeAccountDialog = function() {
  const el = document.getElementById('acctOverlay');
  if (el) el.style.display = 'none';
  if (window.acctDeleteCancel) window.acctDeleteCancel();
  // Offer mód: állítsuk vissza a normál feliratokat
  if (_acctOfferMode) {
    _acctOfferMode = false;
    var sub = document.getElementById('acctLoggedOutSub');
    var tr = window._currentTranslations || {};
    if (sub) sub.textContent = tr.accountDialogSub || 'Jelentkezz be a felhő-szinkronhoz';
    var cancelBtns = document.querySelectorAll('#acctLoggedOutBox .drv-cancel[onclick*="closeAccountDialog"]');
    cancelBtns.forEach(function(b) {
      b.textContent = tr.driveCancel || 'Mégse';
    });
  }
};

function _acctSyncBoxes() {
  var loggedIn = window.ChronosCloud && window.ChronosCloud.isLoggedIn();
  var outBox = document.getElementById('acctLoggedOutBox');
  var inBox  = document.getElementById('acctLoggedInBox');
  if (outBox) outBox.style.display = loggedIn ? 'none' : 'block';
  if (inBox)  inBox.style.display  = loggedIn ? 'block' : 'none';
  if (loggedIn) {
    var u = window.ChronosCloud.currentUser();
    var emailEl = document.getElementById('acctLoggedInEmail');
    if (emailEl) emailEl.textContent = (u && u.email) || '–';
  }
}

window.acctToggleMode = function() {
  _acctMode = (_acctMode === 'login') ? 'register' : 'login';
  var errEl = document.getElementById('acctError');
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  var pwIn2 = document.getElementById('acctPasswordInput2');
  if (pwIn2) pwIn2.style.display = (_acctMode === 'register') ? '' : 'none';
  if (pwIn2 && _acctMode !== 'register') pwIn2.value = '';
  var submitBtn = document.getElementById('acctSubmitBtn');
  var toggleBtn = document.getElementById('acctToggleModeBtn');
  var tr2 = window._currentTranslations || {};
  if (submitBtn) submitBtn.textContent = (_acctMode === 'login')
    ? (tr2.accountLoginBtn || 'Bejelentkezés')
    : (tr2.accountRegisterBtn || 'Regisztráció');
  if (toggleBtn) toggleBtn.textContent = (_acctMode === 'login')
    ? (tr2.accountToggleToRegister || 'Nincs még fiókom – Regisztráció')
    : (tr2.accountToggleToLogin || 'Már van fiókom – Bejelentkezés');
};

function _acctErrText(e) {
  var tr2 = window._currentTranslations || {};
  var code = (e && e.code) || '';
  var msgs = {
    'auth/email-already-in-use': tr2.accountErrInUse,
    'auth/invalid-email':        tr2.accountErrInvalidEmail,
    'auth/weak-password':        tr2.accountErrWeakPw,
    'auth/wrong-password':       tr2.accountErrWrongPw,
    'auth/invalid-credential':   tr2.accountErrWrongPw,
    'auth/user-not-found':       tr2.accountErrNotFound,
    'auth/too-many-requests':    tr2.accountErrTooMany
  };
  return (msgs[code] || tr2.accountErrGeneric || 'Hiba történt, próbáld újra.') + (e && e.nativeDetail ? ' [' + e.nativeDetail + ']' : '');
}

window.acctSubmit = async function() {
  var errEl = document.getElementById('acctError');
  var btn = document.getElementById('acctSubmitBtn');
  var email = (document.getElementById('acctEmailInput').value || '').trim();
  var pw = document.getElementById('acctPasswordInput').value || '';
  var pw2 = document.getElementById('acctPasswordInput2') ? (document.getElementById('acctPasswordInput2').value || '') : '';
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  if (!email || !pw) {
    if (errEl) { errEl.textContent = (window._currentTranslations && window._currentTranslations.accountErrMissing) || 'Add meg az e-mail címet és a jelszót.'; errEl.style.display = 'block'; }
    return;
  }
  if (_acctMode === 'register' && pw !== pw2) {
    if (errEl) { errEl.textContent = (window._currentTranslations && window._currentTranslations.accountErrPwMismatch) || 'A két jelszó nem egyezik.'; errEl.style.display = 'block'; }
    return;
  }
  var origText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '…';
  try {
    if (_acctMode === 'register') {
      await window.ChronosCloud.register(email, pw);
    } else {
      await window.ChronosCloud.login(email, pw);
    }
    // Bejelentkezés után azonnal megpróbáljuk betölteni/migrálni a felhő-állapotot
    if (typeof loadStateFromDrive === 'function') loadStateFromDrive();
    _acctSyncBoxes();
  } catch (e) {
    console.warn('Chronos Fiók dialog hiba:', e);
    if (errEl) { errEl.textContent = _acctErrText(e); errEl.style.display = 'block'; }
  } finally {
    btn.disabled = false;
    btn.textContent = origText;
  }
};

window.acctLoginGoogle = function() { return _acctSocialLogin(function() { return window.ChronosCloud.loginWithGoogle(); }); };
window.acctLoginApple  = function() { return _acctSocialLogin(function() { return window.ChronosCloud.loginWithApple(); }); };

async function _acctSocialLogin(fn) {
  var errEl = document.getElementById('acctError');
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  try {
    var user = await fn();
    if (user) {
      // Bejelentkezés után azonnal megpróbáljuk betölteni/migrálni a felhő-állapotot
      if (typeof loadStateFromDrive === 'function') loadStateFromDrive();
      _acctSyncBoxes();
    } // null = signInWithRedirect folyamatban, az oldal navigál el
  } catch (e) {
    console.warn('Chronos Fiók social login hiba:', e);
    if (errEl) { errEl.textContent = _acctErrText(e); errEl.style.display = 'block'; }
  }
}

window.acctLogout = async function() {
  try {
    await window.ChronosCloud.logout();
  } catch (e) { console.warn('Chronos Fiók kijelentkezési hiba:', e); }
  _acctSyncBoxes();
};

window.acctDeleteConfirm = function() {
  var el = document.getElementById('acctDeleteOverlay');
  if (el) el.style.display = 'flex';
};

window.acctDeleteCancel = function() {
  var el = document.getElementById('acctDeleteOverlay');
  if (el) el.style.display = 'none';
};

window.acctDeleteExecute = async function() {
  if (!window.ChronosCloud || typeof window.ChronosCloud.deleteAccount !== 'function') {
    alert((window._currentTranslations && window._currentTranslations.accountErrGeneric) || 'Hiba történt, próbáld újra.');
    return;
  }
  var confirmBtn = document.getElementById('acctDeleteConfirmBtn');
  var cancelBtn = document.getElementById('acctDeleteOverlay') ? document.getElementById('acctDeleteOverlay').querySelector('.drv-cancel:not(#acctDeleteConfirmBtn)') : null;
  var origText = confirmBtn ? confirmBtn.textContent : '';
  if (confirmBtn) { confirmBtn.disabled = true; confirmBtn.textContent = '…'; }
  if (cancelBtn) cancelBtn.disabled = true;
  try {
    await window.ChronosCloud.deleteAccount();
    window.acctDeleteCancel();
    _acctSyncBoxes();
    window.closeAccountDialog();
  } catch (e) {
    console.warn('Chronos Fiók törlési hiba:', e);
    var errMsg = _acctErrText(e);
    if (e && e.code === 'auth/requires-recent-login') {
      errMsg = (window._currentTranslations && window._currentTranslations.accountDeleteNeedsRelogin) || 'Biztonsági okból jelentkezz ki és be újra, majd próbáld újra a törlést.';
    }
    window.acctDeleteCancel();
    alert(errMsg);
  } finally {
    if (confirmBtn) { confirmBtn.disabled = false; confirmBtn.textContent = origText; }
    if (cancelBtn) cancelBtn.disabled = false;
  }
};

// ── App megosztása Dialog ──────────────────────────────────────────
window.CHRONOS_SHARE_CONFIG = {
  title: 'CHRONOS',
  text: 'CHRONOS – ' + ((window._currentTranslations && window._currentTranslations.logoSub) || 'Schicht · Lohn · Statistik') + ' App',
  apkUrl: 'https://chronos-b8002.web.app/',
  pwaUrl: 'https://chronos-b8002.web.app/',
  apkQrDataUri: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABAAAAASuCAYAAABcC1sdAAAQAElEQVR4Aey9+ZstzVHnV8k/dm//6N/8J8zYjw3j8fPYMPYsLNPdfjD2sAyLBxiQxLAPEkhCQggQgr4tgdCGQCwDgmGThCQESCOE9qXdn+6b954+Xacql8iqqKzvqzfuqVMVGRnxicilsvu9+pob/SMCIiACIiACIiACIiACIiACIiACItA7gZuvGfSPCIiACIiACIiACIiACIiACIiACIhA5wSGQQcA3adYAYqACIiACIiACIiACIiACIiACOyewC0AHQDcQtC/IiACIiACIiACIiACIiACIiACItAzAWLTAQAUJCIgAiIgAiIgAiIgAiIgAiIgAiLQL4G7yHQAcIdBf4iACIiACIiACIiACIiACIiACIhArwTu49IBwD0H/SkCIiACIiACIiACIiACIiACIiACfRJ4HpUOAJ6D0IcIiIAIiIAIiIAIiIAIiIAIiIAI9EggxqQDgEhCnyIgAiIgAiIgAiIgAiIgAiIgAiLQH4EXEekA4AUKXYiACIiACIiACIiACIiACIiACIhAbwRexqMDgJcsdCUCIiACIiACIiACIiACIiACIiACfRE4iEYHAAcwdCkCIiACIiACIiACIiACIiACIiACPRE4jEUHAIc0dC0CIiACIiACIiACIiACIiACIiAC/RB4EIkOAB7g0BcREAEREAEREAEREAEREAEREAER6IXAwzh0APCQh76JgAiIgAiIgAiIgAiIgAiIgAiIQB8EjqLQAcAREH0VAREQAREQAREQAREQAREQAREQgR4IHMegA4BjIvouAiIgAiIgAiIgAiIgAiIgAiIgAtsn8CgCkwOAi4uL4enTp5KOGZDjR9Xj8MazZ89e1OHFbV06dDHLJeIhjqe3tcVnVmNjZXyJfqzti3FoMvecADkmtzHPz29v9qO3eDwlwhNbfKFmEerXE6cSX3qMh7wg5KhUaB+lhKtVG/KD4EtpLLSjfRTsWfmXa4e+8SP6lNvemz7xIDEm4ioVbCDY8xbnmD/4Whqr2j198f7w9HbP7VXI8Vjup+89fmpyAMDAuL6+HiT9MiDHj8vHzx38Y7CenZ29qMPLy8shhDBYDZYloz2MhzgYW3yGsHw88AshDJEtfiAhLO/LkjnYU19z9UYNbIlHb/F4Yj/HdklfqcsQXs5Na86TFnEfsiUWZMtz7WE8xIEQU6nQPkoI9+sPNWDBPsXGYTysh/hSGgvtaB8Fe+xh1ooHP6JPIdyzTWHiScc6P5EHbMhPCP65wAC/JXofezA2R76YHACM2NUtEViMAIsmkzMT3linTN4h+J+4o+9sADzEw0ICW/hF344/eRZCGNA9fqbv2yCQUm/kGb0tRISfc+NnS/F4Yp7CNoT2cy3zzdOnTwfyOJz4h2chbGduIp65ug2hn3hOpC3rNjlGqMushgXKc/kpMPmoCXuYpeKBWUq9offIUYc38HMqHiuXl8qPlb+yIwIQGBMdAIxR0b3NEGBRZtFMcXgLEzfx4Ofa8bDBzllM0aVNit/S8UOATZOHerMi0ls8Vlws7Hhiy3yTOu+j631uCiHc/eZaSp62EA/rWGp+UmKe02EOoz7n9EqfrxEPfZb6O9cOVjCb0+M5euhz7VXwDz+X8o++WuZnqTjUz24IjAaqA4BRLLq5BQJM+rmbDCZur5tBT/HgS24NlLTJ7UP6dgTIF+MhxyL6tMtps5QufuFfTn/o0y6nzR51YQSrnNjRbzHXlmy8eWnO8X1J3dJ4WrC1iJtayV2XLfql3ujbwtahDWyuEQ990vehLxbX2IRVji30Pdcb/uXEY6FLfkrGrkXfsiECeQTGtXUAMM5Fd50TKFnEYki0jddePvGpdBGjrWUc2GNxy7VJG9rmtpP+OgRK6620XesoS/2indfNbWtmqfZhlKp7qGc9H2CPeeawj9Rrj5v1mnhomxr7Unr4VForFj7St+VY7i0eGMOIz1yBRW6bJfRL47HwjbnIst4sfJINEXhE4MQNHQCcAKPb/RLobdK2jqdmQa1p22/F+YusdjNX296aSK0/te2t4/Fkr4aNp7kJXzxxxZea+ZJ4vL18ePCnpl7JiTexjKfGlsd6q4nHKs8efLCKRXb6JHAqKh0AnCKj+64J1GycCMzbpO0lHgsuHjaB5FhymkBtjmrbn/ZMT7wR8DI3WdSchQ2r/HjyxSomXhKtbHmwU1v7FjFYMq2Nx2J/YMEk2qiNJ9qp+bTMT40faisCJwicvK0DgJNo9MArgd42Tr3F422T4LWO1/SrdtNS29469tqNIPH0Ng4tGFswga0XXzzNTRZse4vHok6s6q03thb1ZpGfHm2IbY9Z7SWm03HoAOA0Gz1xSkCTbbvEWLD1+N/atiO2X8sWtbJfeopcBETAMwGtY4+zY3W48thy/h2tP/nM1GKHBCZC1gHABBw96peAp4XMYqNhYYNse/qpB/5I7Alo42TPVBZFQAT6ImC1pvZFxU80nvKjNdVPXciThwSmvukAYIqOnonAQgSePHmyUE/T3VgsqjpEmGaspyIgAiLQGwHWDg/r2Pn5uRlaD/GYBdOhIeWnw6QqJEsCk7Z0ADCJRw9FYBkCtS/Nte0Po6zZQNW0PfRB1yIgAiIgAtsiYLkOlUZu6YOlrdJ41O40AeXnNBs9EYFhmGagA4BpPnoqAosQqPnpifVLN4tq6ck6bRcBpk5EQAREQARcEahZxywCsV4L147HgknPNsiPdc575qXYdkZgJlwdAMwA0mMRWIoA/x1Z7os3i1+Ll+4Sm1dXV0uhUj8iIAIiIAIOCZSsYxZhtFoL14rHgskebLBXyd037YGLYhSBOQI6AJgjpOcisCABNhtsZFK6RI/FL0U3V4eT9ZwXenRpk9uP9EVABERABPoiwDq25EtZy7WQzCwdD31K0gmQH2ogvYU0RaB7ArMB6gBgFpEURGBZArzUTy1mbKx44UavpWe80N/c3AxzvqCDbktfZFsEREAERGA7BJZ4KVtqLYT6EvHQj6SMwMXFxeRepcyqWonAVgnM++3qAIDJXPJksGYwXwbS8EaAxYwXa16+o/DSj7ARWfKF+9gX6hM/8A9fStiVtivpa4k2xGMhS/hq1YdFvFY2rGLaih24bcVX/MTfWsHOViQl1q3Egp/Ew2eujK0drB+1wprIGoRfa66F+DEXSy6zMX3itJAx27n3UvzItWmlH+uN2iA3yBL5sfLfi505Znpe/p62WI4TOnJzAEBBpUws0nk2PHv2LEuYBBNqQSoOCVzcnmpHefr06fD0VtZyM/rx7NmzIj9iuxDCcHZ2NoQQhovn8a0VU02/x/EQU62EEF5wqfFtibaXl5d3eayN2aL9EvGu3cdxvYUQ7sYhY2ht3+b6t8gx9TbXz5rPj/MzF/PW4gmhfG6iRhEYWQi2PKyF+DEXj0VNUitz9TT3HBsWvsz1w/MQ1p2bqA1ygyyRHwuunmzAb46bnj8bnj17li286y6R65Q+3BwApDgrHREQge0ReHY7ST59+vTuZfH6+vpBAJe3L5HIxe1BwIMHjr9MxWPlNkxCuD8gsbIpO9skMFVvjCfVyvp5fXpiflvfszIPmI95kaO+ji2o3o6J6PsYAWpHtTJGRvdEoDmBpA50AJCESUoiIAIlBKY2kof24kaBl53D+96uU+Ox8hsu9GllT3a2RYDxcOpF7DgS1coxkWW+8/LPy84yvbXvhXiopbme0NHcNEdJzyGgWoGCRASWIpDWjw4A0jhJSwREIJMAm0MW/pxmvOzk6C+py8tYbjwW/tEnLC1syca2COSOB2qFOt1WlNv1lpfl3l7+c+Kh3jQ3bbd+l/ScWtHctCRx9bVbAomB6wAgEZTUREAE8giw4Oe1uNdmU31/5evP3JcxS+9hqc2TJVH/tkpfrNasU/9U7TwkPzkvy3Y9t7FUGo/mpjb56NGq5qYes6qYvBFI9UcHAKmkpCcCIpBMgM1ksvKRIptqby+7NfEchVf81YMPxc6rYTYBXqyyGz1voFp5DqLhR01+GrpVbLomHtVbMfbdNVSt7C7lCnhZAsm96QAgGZUURUAEUgnUvsB72yTUxpPKbUqPg5Gp53rWD4Ha+vdQr/1k43Ektfl5bHHdO7XxaG5aN39b6l1z05ayJV+3RyDdYx0ApLOSpgiIQCKB3jaEXuLR5imxADeuVptn6rXWxsYRyv2FCajeFga+0e40N200cXJ7GwQyvNQBQAYsqYqACMwTsNgIskmY72kZDYt4lvFUvfRCwFP998KUOKz+fpHe5gSLeCxskCOJCIiACIhAGYGcVjoAyKElXREQgVkCFpvsJ0+ezPazlIJFPFa+apNtRfKxHU95tqh/i3gsbDwmvf07Xg5olB//tWQxlv1Hmeeh6jaPl7RFIJFAlpoOALJwSVkERCCFQO2mx9sGoTaeFGbSWY/A+fn5ep2P9Fxb/5b1amlrJNRFb9VyXdRZddYFAdXcwzT2NJ88jEzfRGBtAnn96wAgj5e0RUAEEgjU/qVSte0TXMxS8eZPlvNS3hyB2peG2vaHwHqpfQ55LLkcMlrrupfcrMVviX57q7laZuJRS1DtReAEgczbOgDIBCZ1ERCBeQIs8qUn/WzU53tYVqMmnmU9VW+5BKg3by9S1Bt+5caCPuPOMh58wSa2JX4IlNaHnwj24QnjR7l6mWvLuemlVV2JgAjkEtABQC4x6YuACCQRKFnoedEoaZfkUKWSV78qw9p9c695xS/GQ26CaJfbZk6/hc25Pi2f8wK29RgOefQWz2FsPV5TeyVjuTcWV1dXvYWkeETAC4FsP3QAkI1MDURABFII8JOPnAWfDZLnv+QuN54URtJZl0BOfa7hKeOBcZHaN/FQp6n6qXrYxHaqvie93l6We4vHU6209CV3LLf0ZQ3bzB/MI2v0rT5FoH8C+RHqACCfmVqIgAgkEmDBv7m5Gdi0TjXhORukKR0Pz1Lj8eCrfDhNgJdq6pJ8ntby8YRxwfiY8oZ4Wm+wYUUfc75M+bn0M3y9uLhYuttm/fUWTzNQTg2njGWnrhe7tcTcVOycGopALwQK4tABQAE0NREBEcgjwCaczSsSW7IxQHip4Hm8v4VP/CUWZAv+ysdhoNYQ6o2N+JaYUG8cWFBvxIDvfCIxHl7Qud9S6ANf8ANp2Vep7cgEXvhaasdLu97i8cJ1LT+oSWqT8UNu1/Kjdb/EtuTc1Doe2RcBzwRKfNMBwAw1NopM2AibnyghhCFe8yzKjDk9PkEAzpEnnyGEIYRxuby8PGFFt1sROMxPCGGg3rmX0x9tEDY/CO0R8p1jx0I39kvfIdzHg285ttFHiCVFcmzvRZdNcAo7Cx1yjpDzpfnSL0LfIZTVGz5Tb9iBB58INnmWKrEN7UK494V7qe3Rww8EP1KENrWSWivEQmy5/cV2tA1hfO0J4f5+ru0xfU/xXF9fj7mYde/ydl0O4Z5PCPv4pFYYB0gWrFtl2lBzKeOHl+nbJlX/3RqnUAAAEABJREFUYiOlLysdYoNPjtOxDe2QENrXUY5/0l2XAPXBuKE2TgnPEXTX9XbR3os60wHACDYKh+IKIQxnZ2cDCxvCIhmFZvGaZ1FCuN9QUYDoSKYJRNZwjjz5nG6lp0sRGMsPfVPv5Iw6R4d7WxB8ZWzjO3WG4DfxIMSDcE8iAhYEYr3FmsMmtYaEcL9ecK+1TNU+vlH36LT2w5t94g7hfq1nPkC8+ZjjT2/x5MS+tC61wjhGQlhuLC8dZ+v+mHfiPAnTKK37lX3fBKgLhNoI4X6OZqzF+hj75DnCmhbC/ZhkTvQdaa13Ze11AHDAjSIJ4b7IKKyDR1mXFB8Swn3xZTXekTK8GaQ1rHeEa/FQU/JDnZNDdBd3MLNDFhJ8nao34kG2EE9m+FJfmAD1xsZlqt5waYl6o55Tah8ddPGrd4n5gX8vsVJvPcWztbzAfi/jxyo38GLemZsnrfqTHf8E4txMXSA1tcGYRELo+H2sMKU6ALgFxwQUQrj7Sf/tV9N/VXjjOGEOm/Gnurs2gdz8kEvarO33qf7xjYXk1PPj+97jOfZX3/0RoN5SNy4t643ax34qIXRpk6q/VT1iTM3PFmLk5b+neLbAfMzHvYyfsdhz7zEG4ZXbTvp9Ejh88W8xl1FrIYS7/4S1J4Klsez6AIDJJ4TQ5MX/OCEqvJdE4A6Pl3d05Y1ASX5owwTuLRb8wTc+c4Q2XuPJiUO6yxPgZSy311b1hl0vvuT60UqfNajFBrOVv3N2e4tnLl7vzxlzWjvmswSneS1p7IEAc1jOoXkNE+ouhNDLQUAxit0eAFBsFEExucKG9Enfhc3VTASaE6ipz5q2rQKr8ammbat4ZNc3AWqm9OWStpbR1diraWsZg7Ut4mIdtra7pr3e4lmTpVXf1JmVrR7tiE+PWS2LiQPzNeYw+tx+HZYxp9UuDwDWKjaAIxQdPuzxhJiYiR8OEp8EavLDiw859hRZb/F4YitfHhOoqX/r8aPaf5yf3u7seQPrOZfWY9lzrCW+1cxNJf2pjT8CrJW8CzFW1vKOOtz0HFoBblcHAB6KLeaKgufXXfZWeOQgMtCnPwK91WNv8firGHl0TIC5/fheznermrWyk+P7FnTZ8G3Bz1Qfe4snNe4t6GkMjmdJXMa57Oku7wK8A9WulxbMmENDCAM+Wdhb0kZNX7s6APBSbIcJo/D2VHR7ivUwz3u67m1xt4rnyZMnLsrg6dOnLvzo0QmrWvHCprd4tP54qSz5IQIisFcCzMO8j3mLf4PrXRXC3RwAeE6sZ9+qqkuNN0eAibnWaU8vmBa+WNioZRrbe/Il+qTPlwQ85ae3sfyScvmVp/yUR/GypUWOX1rTlQiIgAi0J+Dx5Z+o+W2Eba0ReF0uuzgA4AWbn7SXY2rbcm9F15amrNcQYKzUtKftniZQ4k0VT2y9/DZCKrut6FnUvoUNeHmqN/zxIqp9L5no3w+rsdwbKR1c9ZbR9Hi8jwnexyzWznQiFZqVTbs/ACCRnl/+Y/72VHQxZn36I8DkXLtBxoaXyPClNh7mEA/xnJ+fm7nhJSazgBwZqq03atYiHOx48cUiHisbcLGyJTsiMEVAtTZFR8/2RoB9B+863uPmnRFfvftZ61/3BwAkshbSUu3xVSejS9FWP6cI1Ex8li+pp/zLve8lHjaDtS9kubGf0vfkyykft3q/tt7IjVXstb5Y+eHJTg0TT3HIF98EWAstx7LvaOWdCEwTYN7lHWday8/TDfhaDavrAwAKrprQwga26PPCiNRdYwJsWkpeVGnjsX49xcMBH5xyU8hm0pqttb3cmHrVp97IV0l81jnBFy/1VsKjVZvS/LTyR3b7I2A9lvsjpIhEwDcB32O4nl3XBwBbPMHh12N4SahPrSyIQDkBajDnxQFd2pT32LYlvuFjTi+0ydFP1c1dVHhZyW2T4gsvh9hO0ZVOHgHylcs2Vz/VI+o4p/bRxf9U+1vUI75WvLfIQz7bEri6urI1KGsisGECzLdbfB9z7bNBPXR7AEDBGfBZxcSWfV8FmDptQoAXh5RNMi8M6DZxwtAoPqbGc3NzY9jzQ1O8eLNBhNvDJ4+/4W/L+QDb9PG4Z92pJZDKljqgHtCv7fNU+5zaR/eUnZ7uw1u131NG148ljmXm+PW9kQciIAK1BFgnam20aG9hs9sDgC2f3Oi3ACxKWzYsCDD5sUlGju3Fzc6WXhi8xMMGEW5jXOEc2eIv31sKfXDgccqXln33bnuKLTmGOXVAPbRmgS/0hxz3hS8cQuDL8bOev8NEtd9zhpeJjfHDuGL8LDGWl4lKvYhAPQHm2C2/jzn1vT4xtxa6PACg4G5j2/S/PcTgPQEwXkrYGKzJg/5jrLl+xHZxo8yLAoLNLW52DuMhjiil8dAu2ixhC1eEDSS+cI3NXLa0QfCFz1Jf8AFf5oRNb24fx/r4ib9LyXH/S30nPvIK2ygx9lwfYjts5ralDYIv5BdfuMZmbr3RN+2wNyfo1kpqX+jl9oX/cIAHXOYk17700wnMsff0nHpBqDlqKD3KdTTxMUXW8S6/V4tayO9VLfZGgPHtK2Ybb7o8ALBBIyu9E+Bkbyk5OzsbQggDi++SXNnUhxAG+o+xhnDvR4kvtMEmsmQcrfoijig5fbAg0C6EcbY5tqJuZBu/p35GX8gxQp75DOE+z6l2oh5x4cucRP2aT37bCX+XkhDKmNTEeNgWtlEO789dxxyHMF5v5GrOxvFz2uDL8f2576d8mcrhnM2U56m1spXaT4l5jzrU5VaE8YNsIU+p44dxHMK682QKTw6gLeokpS/plBOgnspb+2hJnfnw5LkXRh9dHgD0UHBM1my0jPIsM04IUJtLbBionRDCQB2NhY4fSK8T21jMVvdgxkvGFNsQltlAUUspvlAPVvFv3Q51H8Iy+bFgRe7mckxM1KVFf1M26GPKl6m2Sz+DCeNj6X7Vnwj0QIDxE8J25skemPcWA2tXDzGd2uutFZtVv90dAPRScFYJlh1/BJhMQgjNHIub9JQOWOTRT9GVzjDACmYpLNBDP0W3RIeXG2oppS0vbZobH5JqnZ+HvZV9o37IXUrr1vHgC32k+OJFh/ERQhhU+14yIj+2RoAxz9jfmt/yd30CPc27jmIxS6wOAMxQ2hvSpGvP1JPFp0+fmrvDJMWCnWMYfdXaPDEYwWpe86UG+uTk5R2bK3zh5SbHWuqLZI7NreuSH1h6jIO6wb8c39BvEQ82sZ3jiydd/Pfkj3wRgS0RYOwzH23JZ/m6PoGeasZPLHZ57e4AwA6NLIlAWwK8wFlPKqX2tMDP5xpG81qPNaxfPrBX6kuLQ6fHEW/rTinL1lGS55I+iKd0HjjVHzZPPdvCfebaUp5biE8+ikBrAho/rQnLvmcC1mtqcayGDbs7AOgpSWxaDHMtUw4JWC6q2KrZqNPeISIXLtWwYRxbzks1tqx9cZEcAydq8mvQ/SMT+EOuHj1IvEH7RNVZNUtbs501VKiZGxu6JdMisAkCzEc1a88mgpSTpgSoGVODMjZYIujuAMASjmyJQGsCTJBeFlV8aR3vVu3X5sjyJUp5sq+i2vzae1Rn0bJGenpx7i3PdVWi1iKQR8ByHcvrWdoiIALDMJhC6O4AwHLjY0paxkTgBAGrRdVio64N8niSaueV2vbRK4tasbAR/enl0yo/Vjy8jOXe5gPVvlWFyo4IiIAIiMCyBGx76+4AwBaPrImACOydQG8vQXvPp+IXAREQgS0R8PJ3t1gdlFrEY2FjSzUgX9clYFX7VVEYN+7uAODJkyfGiGROBNoSsFrILGrfype2xGRdBERABERABPZBoLd1ubd49lGF+47SYn9dS9C6fXcHANaAZE8EWhOw+rXUWjvn5+etQ5V9EXBJQLXvMi1ySgRE4JZAby/MFvHU7ndusepfEdgSAXNfdQBgjtTOYI8nTnZ0+rBk+eLBoqqa6aMuFMWyBLSZXJa3ehMBEcgj0NvaXrP3qWmbR13aNQR6qln21zUs6tvaW+juAKDHJNmnXRa9ELB+8Si1x4Ja2tYLS/khAiUEqP2SdmojAiIgAksR6G19romnpu1S+VI/ImBKoIExHQA0gGplUocZViR92rm6ujJ3jJrJfaHhlFYLqnkqZHADBFT7G0iSXBQBERhY21vsGdZEWxJP7v5mzfjUtwhYEWhhRwcALaga2WTCNzIlM84IsPC1yi8v86mLJC9A+lvunRWH3FmEgGp/EczqRAREwIgAe4bUtd2oy6ZmcuNh38T+pqlTMm5GoKdcrRyLWU4ODXV3AEBwbOz43LowOW49Bvn/kAC1ySLWOrdMVnMbBZ7r5f9hfvRtHwRU+/vIs6IUgd4IsLbf3NwMzGE9xHZxcTHMxbPUvqkHnp5iaL3PXSpW6m+pvsb7aXO3ywMAJpQ2uJaz2svk3oIYg3Frwks/wgv3UpMi44CFlX6pp8iM79zneYv8LGkTnkvIkjEt0ZcFsyX8TO0j1vbcp4faT2GfGveUXko/KTpTfWzxWUrMczoWcc/1kfrcwpe5cZPy3MIPbKTGXatHX1sW1m/W8cO1fS5PFvHOcS/t4zCeGBPzNUKfS+2bSv1Xu3EC1OT4k+3cXb32GqHq8gCgESuZdUKAwciCsCXBZ2QNhPTL4hp58T3XD9rTLoQwhBDu/ntE7uXaqdUnBvxAQgjD2dlZc7m8vKx121X76+trE2bY8RIYdZEi1M0aPuMbfYeQVrMWPl7e1m3t+MCGhS9ebFCztUxobxGPhS9W+WEup0ZrhJc2Cy7wXUJCCKutYxacoo3U3KEX29R8zuUmhLo9An4i1CJzJlLjr9quS4BcrutBfe9rx1AfwbiFLg8AmDC2furUa8GNl6HueiVAHYYQBjaabFijn1xzL4QwoBPvt/xkXLP5oG+kZV+yLQIWBOImNtathU3ZEAERsCHAOrL0OmbjuX8rh2yZB/17LA9bEGDftuX3MauDzQq2zZp2eQAAraVeSujLWnouOGtWsteOAGOIzdFcD+igO6dX85xFhA1FjQ21FYElCTAm9OK/JHH1JQLlBJZYx8q923ZL5kHmw21HIe9LCWw59+v7Xkp9vl23BwC8MGz11KnngpsvSWl4IEANsiFK9QVd2qTq5+gxlvXyn0NMumsTYCwwJtb2Q/2LgAikE2DMMnbTW0gzlQBs9ZsAqbT60mMPt8X3MRc/jG1YCt0eAMBsixN57wVHXiS+CTBuWKxzvaSN9QKPL3r5z82E9NcmwFhY2wf1LwIikE+AsWu9juV70WcLfhOgz8gU1RwB9nJzOt6ee/C5JZOuDwA4ddrSCzUnZL0XXMtilu31CVjXL5ux9aOSByKQTsB6DKT3LE0REAELAhrDFhTHbYjtOJfe7/I+xjvOVuJ08u7YFFfXBwCQY7LZStHp1JmMSdYmUPPSzU/rreqYsbs2C/UvArkEasZPbl/SFwERsCfAOmZvVRYhYLU/wJZkW7XSFmgAABAASURBVAS2knveGX3sP9vmt/sDAPBRdCSUa69ydXXl1TX5tSMCe5j0dpROhbowAdaahbtUdyIgAg0IaCw3gHprksMVsb0FsdN/t/Cu46Y+G9fILg4AYOj5xYZfNeHXY/BTIgJbJ2A11vYyCW893/JfBERABHojoPWnt4yOx+P9h4PjXm/3Lu86vPN4jcDTAUVrRrs5APBadAwEqxem1sUi+/0T8LTp4ScF/RPPi5B5LK+FtJck4Gn8LBm3+hIBERCBVAK9rWO9xZOax1I93nl49ylt36odPjnKZaswX9jdzQEAEVN0nk53KDZ8wre9iEW8Fjb2wltx+iDAWLfwZE+LkwUv2RABERCBEgK97TNYO/TT7seVYJFn2D62rDtTBOButS+a6if1Ge+G+JSq316vfQ+7OgAAJwP15uZmWHsi3GOxRf417D1NGMQjEYGlCdSMn6V9VX8iIAIisDUCve4z2P+unQtvbGuZeItn7fzm9M8LN+9COW2sddlP8U5YWwfWfg0LGNzdAUBkyq9qrjFw91xskT2DPl7nfta0ze1L+iJgQYB5xrJuLW1ZxCcbIiACItATgV7nWOJiD7pmrvBhzf7H+maNHrufcs9jPCl+e9HhxZsX8DXqkrzzLuiFxaEfS1zv9gAAuAxcCgDhe0uhuDnp2nOxRb4M+BLmJW1in/oUgbUIMM9Y9l06fix9kC0REAER6JFA7/sM6/Uopwa8soUJe/ScWND1Gg++bU14N1qKJ7nmfYy8O+W0iFu7PgCAMAWAUHgUBfcsBZsUGsXNxt3S9pZtReapMZAf2qTqS08EPBBg7Lfwg7HAmGhhWzZFQAREYI8EmFOZW3uOnX0ocS4dI316Zssenf16Khfv8aTG4UmP+uC3AWDbwi/yy56MXDMOWvRhY3MZK7s/AIiYKTyKgsJD4v3STxXaPDmYp7BGB915i9IQAR8EGP8sZC0XGcYEY8NHxPJCBERABLZLgLmUOXW7EaR7Tpy8CKW3KNdkLaQv+iy3skzL+A4w1duW4pmKw/MzaoX9E2MSqfU15oz8ttyT1fr5ov1CFzoAOAJN4SEUH5MWxUfxIEeqL77yLAptaKtCe4Fn8iKyhvOhIjwjS3QOn+laBLwSiHXL+F/CR8YG8w3jh76X6FN9iIAIiEAPBJgz97rP4EUorh2sH9b5jGxZC+nL2n4re4dr6mEfW43nMIatXZMLhDplnFKn5AE5FQvPEHRpQ9ut1eCp2Kzv6wBggiiTFsVH8SAUUpRYWHznWRTaTJjUoxME4AzLKPBci2Xsm/6thPhOhN7d7evr68GCmxcwLCaM9ympqdvDeqNOkNzYaYOd6MeUr56ewTY31jF9i3qzsEEOxvzLvecpRxa+5MbfSp966ymeVpzWtGuRnxQbzJWMV8b9mvHW9I3/CDEgrAO59miDwANJYTelgw0k+pXjD20QYrESYkNy/ECXNsRBrHxGv3gmWZ4A9UBOyANCThDyg3CN8AxBlzbLe1rd42IGdABQiFqFVQjOcTMmDfJ6dnY28BJrKZeXl0MIYWBScozAzDULdmbOGBiiLqakpIuxeqNOkBDqamXKV2/PStgdt7GoNysbx76VfPeWo1p/Shi0alMbC+1b+Sa7wwDfJWTLrA/XjsP9ioe1o4TrqXgs5mSYICGUranUYklMarMMAfKDLNPbEr0s14cOAJZjrZ4cE+DFPC6kLd2sWYha+iXbyxJIqbdYK2yOlvVOvYmACIiACHgkwHowt1eJawfrjMcYDn1KiedQv+YaLltgUhOj2m6cwILu6wBgQdjqyicBFgQWhiW9oz8WviX7VF8+COTWG5s91YqP3MkLERABEViLAGsH60Fq/973GaxrOfGkxj2lBxM4TunomQisRWDJfnUAsCRt9eWOAAsBC8Iaji298K0Ro/p8SKC03mj30JK+iYAIiIAI7IlAyV6FfQYv2h454dsafsFRa+oa5NXnDIFFH+sAYFHc6swbARaCNX3SIrQm/e30zX8L6XUTtx2K8lQEREAEtkmgZq9Q07YVrbV9Wnvv14qr7G6ZwLK+6wBgWd7qzRGBtRcgUGgRgsI+hHqryTft90FKUYqACIiACBwSqFk7OEA+tOXhuiYeK/91qG5FUnZMCCxsRAcACwNXd34IeJn8vfjhJzPyZIwAmzjVyhgZ3RMBERCBfglYHP56Wjss4rHIthc/LGKRje0TWDoCHQAsTVz9uSHAC5UHZ7QIechCex88/MSjfZR5Pej/viePl7R9EHjy5IkPR4y88DIOe+NqlB4TM54OALz44mUPaJJgGdk6gcX91wHA4sjVoQg8JOBl8/XQK32LBJSfSEKfIrBtAhrL7fIntu3YWrwwW9hoF6Esi8DeCSwfvw4AlmeuHkXgAQFtnB7g6PbL1dVVdWy91Upv8VQnWAY2QaCnurX6qbsFEwsbmyignTup33rceQEo/McEVrijA4AVoKtLETgkoE3PIQ1/1142K+fn5/7gGHhk9QJi4IpMdE7Aaiz3NGdbxlI7lq3y03kZbz48aq62VjYPQQGIwAGBNS51ALAGdfUpAs8J9PpS9zy8zX9Y5kebnvFy0KZ/nIvu2hLQWB7naTn+amxZ5mc8Ut31RKCmVjzFIV9EwIDAKiZ0ALAKdnUqAsPACbgWQb+V0CI/pflmc1za1i/he884GCG++2/6UwTsCXgay/bRlVu0Hnc1Y7nX+a08O323pFYYl31HqehEIIXAOjo6AFiHu3rdOQEWPv2lPL6LoMWGlE1P7t8FQK208MUTfeIjTk8+yZd+CFBf1tGUjGVrH2rs8fLfggs2c8dy7pxYE7fa+iHAHii3Vvx4L09EwIjASmZ0ALASeHW7XwIseCx8+yXgO3Lyw4aUDX4LT7GL/RTbbNL3UivESbwpXKQjAikEPI3lFH+X0mGc8aLeqr+cscxcyJzYyhfZ9U2AWmGc+vZS3olAOwJrWdYBwFrk1e/uCLDIsdlhwdtd8BsI+DA/rTek2L+5uRnYiI+hib5cXFyMPe72HvHCBOk2SAXWnEAcP8y1jLWWHWJ/aiy37DvXduTCOMttm6tPH4xjZKwt9+EGv7HnurcfAoxT6mE/EStSEXhBYLULVwcALBiSi+Hi4sJUmFxXq7CMjvEzSkazVVXZULFwTQkv/QixlWx2aBdl1WAzOp/ikfoso7uTqin5wZ+18nNxO9bZBNN/9INr8l1TKyeBLPQA/6PkdgkTBC4wSZHcPsb0U2tlyh9sjNn2di/mhk9vvp3yB7ZT7HnG2EGIq2b80P6UH6fux5qlf3yZE+I5ZSvn/lw/PMcnxhNx5XKhTZQcv9CFCULf+IFEX7iPTo5EP/jMaddCFx+itLC/RZuRB5+5/lMP1AlCnaRIbh9r6cMDWav/3H7xlXxILkzfxS5u93vX19dH6Vjvq5sDAKBcXl4OEnsGsF2vxOZ7ZrJhU3J2djZECSG8GHjzFtbTYEDPCbEhOV5GJiGEF0xgE8I9lxxbS+uysZ1jkvLcwm+4p/SFXk5/1vmhf/zkE6n1JYQwhLB8rUQu1GqUEO79IL6cuNClTYqgWysp/czp5Oau1ufc9qfyg9/ElmtvSf3oI36eEnSQHL8ikxBs5lr6P+Xf4X30cvwc002da0v6ilziOOYzhPqxXOIL3EKwyc8Yx9R7kUkI6/uS6vMSeuSHvFIjUUK4r5WS/rE3J/RXYnupNmO1EsI663JuzLwz6F3M/l0Mpo9yseINNwcAKzJQ1ysSYBJnwWDCOXaDwYKwEBw/6/k78Z5iQtwwCSEMLDB8lyxLIDU/6LX2jD7mauXp06et3RioxadPn94dVmksN8dd1MHTifyQM+YV6qnI+EYbEe/c+Amh/EVmi1g8jWV8CSHc/WBojCU1G0IYyOPYc8t79JFSK/hs2a9nW8QaQrjLD3PIsa9L5ue47zW/p9QK8/GaPqpvHwTW9EIHAGvS33HfceEYWzSOsbCI7GWyZOEg3mMGY9/ZjMBx7JnutSGQkx/yiH4bT4aBMUEfc/YZYyG0OzCiBqlF+pnzBX/xe05Pz20JwFz5eciUsUk9Prw7/g099Mef9nPX01iGN/NKCt3W+cEX+kjxBZ/hmKK7ZR2YEGtKDLBDP0V36zrMtcQ7FwfzcQjt1uW5/vXcBYFVndABwKr499t57mLAZJnbZmt0iS9l4TiMiwV4D5uNw5jXui7JD/lskR98YUzksKBNjn6qbq5d/M5tk+qL9B4TYEMK88dPxu+gS5vxp33cpf4YmznRoN9iLOf40FqX9SSnD2oFljltUnThDO8U3aiDfgtfsInt2E/KJxyJIUV3izrElssEfVhuMd5Un4mPMZGqjx5t+JTskcC6MesAYF3+u+ydCS93kgQUCwgLD9c9CvGVxAXPknZqk0fAS37Id4kvjDnrFzt8wW4eyeHuV0Z7Hsu5PFrpl+aHnPacn5LxQ47gyWePUhobLK1rhRfoEsb4UtJuqk2pzVKeU754eVaab1iWtvUS+yk/yDfxnXp+6j5zLW1PPdf9jgmsHJoOAFZOwB67L5kkI6deJ8qauFhAel1UY97X/uwlP9a1orG8dmVO96/8PObTy1h+HFndHS+1UpMfCNS2x0aUGlvWc230ae1PmHiplbVZHPZfswer4Xnog663RWBtb3UAsHYGdtY/i0dNyL0uqrULQC3XmpzsoW3N4g4fy/zU1gr+WEhtTL2OZQu2FjZqa7bX/NRyqa17i9xa26iNyVOt1Ob3kG3tXFvL9dCXXq6plV5iOYyjNi7Luj30S9duCazumA4AVk+BHNg7AU38/iugdnGvbR8JWWwoLWxEf/Tpl4DFvNJjrdSOxdr2fivGh2e1L91W+emt9q3+8y+LecXCho9qvffColYsbNx7oz+3QWB9L3UAsH4OduWBxcRvYaM36FabHk9cnjx5Uu2OxaZH9TaeBgsuFjbGvdNdC7YW48dTJiyYeIrHyhcLLhY2rOKxsGNR+1brsoUvFkywYRUTtiQisFsCDgLXAYCDJOzJBYuFzMIGzL28YFrEc35+TkiSIwIWbC1sWNQaoVn4YmHDmy/4I3lIQD9ResiDbxa1bzWW8UfymEBPfK3WZYu6fUx623csmFjVmoUvFja2ndF9ee8hWh0AeMjCjnywmOQsbIC8doNstbjji9VChK1epDY/lkxrbVnVrIUdCxvUmIUdCxv4InlMwIJt7Rh87NX6d7yM5fVJ9OmB1brM+KmtFU+ENZYfZ4McP76bf8fCjoWNfM/VYiUCLrrVAYCLNOzHCSa5mkXVanGHOL7w6UFqF+fa9h4YHPtAfmpqhfbHNku/1/KtbX/od80YoK0VF+zU5AdfDuPStT0B5ecx09qxWNv+sUe6c0jAE99aX2rbRy6aayOJh5+1fGvbH3pTs57Rlhwf2tN1zwR8xKYDAB952JUXNZNuTdsxyEy8Y/fn7tHO0hcm/9LNOr7M+bvV56WMYVnadoyVp/xYxjUUZMSIAAAQAElEQVQWa869Gl9q2ub4uGfdGsY1bT0z9zSWPXNayzfyU7qm0c6ybvGFtaSEBb6UtDvVpiaumran/PFwv5f8eGApHxYk4KQrHQA4ScSe3GDSLlkcr66uzDGxMOYu8OjTztqZkr9ECY4tfLGOrdReaa2UsJzzEZvkfk7v8Hmr/JSMhRa+lOanxP9DrrpOI0B+SlhTK2k9bFPL01jeJsG2XrOm5c616NPO2rMSm4yfknZTvjOWsTulM/aspM2YHa/3PI3l0rnWula85kp+3RPw8qcOALxkYmd+MOHlLExMrCyALTCxgKT60mqTEeMiTvqI36c+8RmOUzo9PCNGYk2JBXYwTNEt0aFW6COlLXr4nqKbq8NYSGWCbXRb+YJd7NNPipAf/E/RlU49AVjn5Addclrfs28LXsayb0rreUd+qMUUD5hr0U/RzdVh/DBnpbbD51bjB7vY9+BLqg9L6JF7aiClL/TgmKKbq0OtKD+51Han7yZgHQC4ScX+HGESZrJETkXPZM3iy8R6SsfifvRlyhZ+stC09AXb9EFfp3yJTPD5lE5v94l1ignxwgV2MOR7K6GPOV94jl4rH7ALk5ubm4G++D4mMGH8XFxcjD02u4d9/KC/U0Z5hi+t83Oq/z3fJz+wJ0enOMT8oHtKp7f7jNEpJsTLc/S4lixLgFqE/1SvPG+dH+YsT3OtxvLjiqAGqIXHT17e4Tl6L+/YX1GzXmrFPjpZrCfgx4IOAPzkYpeeMFkiTMwIENiIcs0ix2TN4sv91oIfceKmf/rDF/zgPs+5t4TQF31GP+gz+rIkE/r1IodMIpfIhBzBZSlfp3whbzxfw5fYZ+QCkyXHD/2RGwRf8IPrmJ+lfKFvyUMCsKcuyQU5iU/JEffIHTrx/l4+YcKYhQlC3JEJ93nOPck6BOBPHsgNghdr5efQF/xAoi9Ljh/GKb4wbiOTtXyhXy8CE0+1ovx4qQxHfjhyxeQAgImPQSe5GXplQI5b1i0TNwI/+uKaRS6nT9rRJoQwhBAGrrGTYwNd2iDRF+xwP0eOfcEekmMDXdrgBxJtct+zXF9f3/EP4T4PIZz+JL7cWGiDHDLJzVFkGcK9b7THpoUvuTas9PEfJkiMz8p2jh38QKIfXMM3x0b0P4T7/IQw/Zlj+5Tu2dlZct2GMO7P5eXlKfNu7pMLckJ+kMjajYMnHIFtCOPcQ3h5P8Z3wszJ2zBBSpnAkfb0H8JLf0IYvyaek85s8AHxhDAeawgv78MHTrkh0gYpzQ/9kSP6D+HeH+whPMsR2uAHEm3mtLfSJRYvvuTElDrXxvhybKMLE6Q0PzGn9B9Cea3QPvpR6gvx5Ai+05fE5/uYRV7IcU5NnNI1OQA4ZVz3RWAJAgwGJloWFV4+Y59cx00Jk3C83/KTfkIIw7Ev+IGEEAZ0WvqwJdtLM/FUK1vK01K+nsrPUv2rn+0TWGveZ85nPqP/7VNsFwF84BTCcmsha24IWpfbZbWN5bVqhbFM30iMjJpFQggD61S8r08RyCDgSlUHAK7SIWdyCbCwx8l6qi0TN7pTOrXPsE8/c3bQQXdOb0/PYfL06dOmIcPcS600DXSjxlPzs9Hw5PYKBJhXqKuWXTNv0U/LPnq1DbfW+cE+/cwxRAfdOT09X4fAEvlJHcvsI1Qr69TBtnv15b0OAHzlQ95kEGACZlFIbYIuE3yqfo5eiS+0yemjd11O25Wf3rM8Hh9jgfE5/lR3RaCcAHVFfZVbON0Su8xbpzX0ZI4A+dG8P0dJzyFArTDmuLYW7OaMZXzRbwJYZ6Fze87C0wGAs4TInXQCTMDp2veaTPBM9PffbP7EXokvtNEC8jAHLfJDD7DmM0doo/zkECvXhXV5a7UUgWkC1Jf1WC6d96c93edT5n0v+WlRK/vMapuoW+SndCzzmwBtopTVHgl4i0kHAN4yIn+SCDBhJymOKLGAjNxe5VZNHKs4vECn5MdyM1jDuKbtAqi66EKMu0ij+yCs64x5yn3QG3LQ+mWqJj/WtbKhNGzCVev8qFY2kfatO+nOfx0AuEuJHEohUDNhY9/qBRM7Nb60+MkH8W1dLBd45cd3NdTkx3dk8s4TAcu51nJ+8sRobV9YTy18qLVDrVj4IRttCJCf2hxHz2rHspUf0R999krAX1w6APCXE3k0Q8Biwq2d9KOLFr5EW/q0J2CRZ+XYPi/RothGEvpcgoDqbQnK5X1YzNf0bpFnCxv4IumbgOVhRN+kdh6dw/B1AOAwKXJpmkBvC7OneFr9ZUzTGX38lEX18d117njKzzoE1KsI9EHAaizrt1Z814NFni1s+Ka0be+sDos0lrddB1vx3qOfOgDwmBX51JyA1QumxSbBwoYVMC8HAFbxyI4IiIAIRAJW89uTJ0+iSX2KgAhsmIDG8oaTtx3XXXqqAwCXaZFTIrBvAufn5/sGsJPorV7IdoJLYVYSsKo3q58+VoZj1txLPFYH8xbxWNgwS5AMNSNgkWereaVZkDK8MgGf3esAwGde5JUIrEKAhUwn4qug322nqrfdpn7xwJnfLDq1smPhi4WNHuOpmVd0AG1RVfuwoVrZR56ronTaWAcAThMjt0RgLQIWJ+I1vrOgru1Djf9qm0dAuc7jJe0yAswrZS3HW1nbG+9lubu9xaN5Zbna2XJPHH7V1L7qbMvZX8Z3r73oAMBrZuSXCKxEoHZBrHVbC2otwW21X7vetkVL3pYQYINvPa9gr+anzCVxtGzTWzzMKyX5aVErLfMm2/UESmufWqnvXRY6J+A2PB0AuE2NHBOB9QiwIK6xuF1dXa0XtHpejcBa9bZawOp4MQK8BFJfLTrELvZb2F7DJn8h7Z7jYc0jp2uwV5/rEiDvObWvWlk3X9vp3a+nOgDwmxt5JgKrEmBBZJFbwgkWXl7++anNEv2pD38Elqw3f9HLoxYEmL94qW1hG5vMV9inH773IHuNhxwyB/WQQ8WQTyBnLKtW8vnutoXjwHUA4Dg5ck0E1ibAhujm5mZgwWvhS3zxZ9PJAtyiD9ncDoGLi4sh1hu1sR3P5aknAtQOB4rU0xJ+0Q9zJLJEf637IB749RRPnFcO2VEnCLES8+EzXe+TAHVA3SOHBKgT7lFH6Bw+07UInCLg+X7zA4C4sWdz70UYvIjnxMz5BlfEC9Ml/SDuOT5bes7/9dFS/Kh7JJcPbVj4EDZLFoItcknsuf70pA8DBA5wRtaKDz/oH18sBFtIbjy0wRdqJKXWcu1717dg78mGBW823ym1QM1QO8Rv0W+qDWoWof8UP3mhSLW9hh78eooHhjGemCPqBCFWnu9VYAAbOMzJHhjBAol1wmdklBs/7eaYpj7HJwSbuX540sd/4kiNewk9/EGMObk21+wAAJAhhOHs7GzgBceTXF5eDkgIYcBP1xk6co6Bw2CAK+KJ65K+HGHZ/Nel2FH3SAjltU/9Wcjmk1YZwNhYJjdICOX5KXHr0Bf6t6pHbCEhlMeTUmslMXtuY8Xfix0r1luphRQ/0bHi0toOvqZIaz8s7ROPpb0t2iqZ97cYZ43PpXXCu0UIwfQdiLUUYe8fQvmaWsOjpm1JvS21hsEVCeGeK77WxHrf1vef5gcAQAsh3L1g+w793jsSXjrA7y0s9ycTCgOfAbFcr+qpVwLUPjXVa3ye44L73FgmP0vMTSm+WLCM8bBGWNiTDREQAREQgTICrC1za1CZ5X23Yn2DLetdaxL0wfrduh8L+/i5lXqDK77ic1XszhubHgBQ+EBzHvMj93ihZsA+euDoBoVIUTpySa50QICa8l77HWB+EELOWGZuCiE8aG/5JccXi36JhzWCtcLCnmyIgAiIgAjkEWDNZy7OayXtOQKsa6xvS7JlD8c6Pufbms/xDz/X9KGkb3zG95K2tPEupgcAFL73gE/5x4BlUjz1fM37TCoU4po+qO9+CVD7PU9ynjJXOpZbzE3kfK15hb495UW+iIAIiMAeCDD3subvIdalY4Tt0n3SH+v4Wn3T/5TgF/5N6Xh+hu/s2wp8dN/E7ACAJLuPdsZBJkWPifbo0wxKPd4YgZ4nOU+pKB3LLeYmcr4WmxbxrBWL+hUBERCBLRBgn77mvL8FRqU+wpZ1rbR9bTuvefXqVw5vcpujf6/r/0+zA4Aekky6vCWaF4Ze2MJX4peAt9r3S6rMs9qxbJkfS1tlNIbBgw+lvqudCIiACIiACEQCHvbp7DGiPx4+e1njOdjJZushATM+mBwA9JJkWJFoPr1Ij0Xnha38eEjAW+0/9G7732rHMvmptREpWtmJ9ko+LeMp6V9tREAERGBPBDy8pPbI28N6Cldv72JeuMCmVnLZ1va3RHuTA4AlHF2yD09F68mXJXOgvtYhoHprx90TW16+20UqyyIgAiIgAp4IeFp/PHGx8MULW0/rOkw8+WOR5wwbm1DVAcAm0iQnrQk8efLE2qTsdUqgxV/AV4qKRbW0rcd2vcXjkbF8EgEREIHeCHhalz350luetxnPNrw2OQDobRPnKZ4ef+3Ew9DQhO0hC+198JRnL6fhnua39hWgHkRABERABERgHwS8rO/svXr6QRvxJFfQRhRNDgA2EqvcFIEXBHoczC+C08ULAuS5dhHSIdwLnLoQAREQAREQgdUJeFqXLfYZqwNt4ICnHNWGR45TbWxFTwcAzjNF0dW+wDgPcXH3zs/PB7gu3rE6XIVAzSJErazitDoVAREQAREQARF4RMDjulyzz3gUYCc3etlnU28ZsWwmezoA2ECqNLHYJqnHgWxLqC9r5Lv0EE1jr69aUDQiIAIiIALbJuBxXa7ZZ2w7G9Pe8/I8reH/KblN93I7mjoA2ECuKL6rq6sNeOrfRSYjePr3VB5aEij57+I05iwzIFsiIAIiIAIiUEfA87pcss+oo+G/NYc17Lv9ezruIb5nvTOMm3F5VwcALtPy2CkKkEJ8/ER3UgmwcDAZpepLry8CNzc3Q8pvAqBDrTDm+iKgaERABERABERgewS2si6n7jO2l4Fyj9l3b/H9hX0gvudEviVdHQBsKFsUIpPLFgfSmpi3snCsyWgvfXNCPzV+eIaOXv73UhGKUwREQAREwDOBra3L7CHw2TPTpX3j/QUmyNJ95/ZX8c6Q29Wq+q4OACiMWrGgyeClWFsL/ZT4i1/xIKCWV8/tOb2DE5z1QpdWabCivloL/aR5ZK9FbNQF9RHrn2vu8cy+R1k8RYA6gHmtnLK/9H02DrGmaj6X9nuqv5o4Ytsp+6nPrGqlttas2hNPaux70rPiO2UH9sjaXPEhypS/Vs/Wjjf2nzpPeliXI/voe+on7dhTEEOcB+c+U21vVQ8mCFzmWMTn1EptvNiI9qY+yRW+MSbL3hlqPR0G+CD1luYtuDkAIEEEXSvzIc9rXF9fD5eXl83l7OxsCCHcCXHPe/ZQgzaSixcD5uLi4sH1WgP4YZa29W2JuqePWPvk6OI2b2tQin3TP9drkyK3ogAAEABJREFU+LD3Pq3mWi8cqSPqqVa8xLPHdZn5aQmh9r3k2ZMfS7Bn/UFCCHd7Bjb8SzKgP+YKfIjSOm5P9ZY6P8JoybzEvmJ+Qggv3gNCCHe1EnVSP4khJV70Um32oJfCBB2LWGGLrTlBr6q/wsZT9YbPhWZnm7k5AJj1tHMFJv8QwkAhdB6qwhOBFwTYlKj2X+DQhQiIgAiIwIIEWH94CW+50Y7hsL97+vTpQH+sffG+Pn0QmMsPtRJC2UGAjwjlRUsCJbafTswH1BvSam7SAUBJxhq2YWFoleyGbsu0CFQToPZZgKsNyYAIiIAIiIAIZBBoudHGDfZ1rHF68YeGP2HvkZqf1rXij448SiCQrcLLf8p8QL2hm93BTAMdAMwAWuMxyWYyWqNv9SkCaxJgAVbtr5kB9S0CIiAC+yTA3osXdevoWdOwbW1X9uwIsPfIsUY+W9RKjg/S9UQgzxdqJ+XlP1pFlzbxu8WnDgAsKDawYZ3oBi7KpAg0IaDab4JVRkVABERABGYI8GLHC/uMWtZja3tZnUt5lkDpnqNFrcw6KwWfBDK8ot6onYwmd6q0sZxLdABwh9XfH5z2WCbaX4TySATGCaj2x7norgiIgAiIQHsCbNCtesEWG3cre7JjT6AmP+TX3iNZ3BqBHH+91JsOAHKytrCuJpaFgas7NwRU+25SIUdEQAREYFcEdAi9n3TX7jWolf3QUqQnCCTfrv3BLvVWayM6qwOASMLhp2WiHYYnl0RgVwT4v1TbVcAKVgREQAR2TqDmp307R7dI+BYvUxY2FglWnTQikG7WolYsbOCxyQGAxd9OaGGDgCQiIALbJ8Dh1/ajUAQisG0CVuuyDr+2XQd79N5qk71HdluK2WKvoVrZUsYb+LqwSat6c3MAsDC/zXRntQHbTMAbc7T218c2Fu5i7uqFYRy15oNxLr3dVf33llHFs1cCGsuPM+9pHbPIj/aBj3O8pzs5sVrUvoUNfHZzAKABRDoeyvn5+cMb+iYCOyFgNcF5wmUxx/XIxVOOvPhiUSsWsVj5YWXHIibZEIEUAlY1qzn7IW2LF+6HFuu+WeW5zgu13jCBxV23qlmTAwCirxnUetGF4GOxSvJjy7pjRYDFvab2rfzozU6PtV9bK5one6vy0/FQK6efLvPEst48xLMMNfXSAwHL2u9xLavJsbe5AH9q9nCWtVLDVW3XIpDXr6d6MzsA0CSXVwRz2ppU5gj5ea7at81Fz7VfUys1bW0zJGtLEFh7HFjX29rxLJEz9dEHAdV+mzzyom3N1sLTGp9q2lr4LhsrEyjovqZmatoeu2p2AMCpRskCTxvLgI4D3OJ3r5PkFlku4XNp7S/h29b66H0+KK2Vq6urraVS/lYSYF1kLag0U9SccVjUcKIR8bSwO9GlHolANoEWNUrtrzWWswE0bACHhuaLTWtdLka3+4YlAErrzXpuMjsAAAKDO8dBdGlDW8k9ARYJq7/h8d6i/lyCAHVMPS/RV699UPtw7DW+GBcx5tQKL/8sGLG9PvdDgLUgp1YsyNAfNWph69gGdrF/fF/fRcADAWqTGm3hyxpjuUUcpTa9r2Pknfynxuc9ntQ4pFdFoLhxbr1Rm7Qp7nCkoekBAPZxEEfZzPN9THjG4EF37Ple78GNRWKv8W89buqZHG49jjX8h9ueaj+lVuI8qZf/NSrST58ptWLhbaw3+rOwd8oG9hnvp57rvggsTUC13444bG9uboYtrGMpcxPx8P6yhXjaZVWW7wnU/ZlTb+jW9fa4tfkBAF3gKJt5FnmEAROFgcMzDR5IDQNcYILA7f6u/twqAXLIYkfdI+R3q7G09BsuCHUPL7i17M+jbWImduoEwUeYIHDRPAkRCQTGaoX7tUKtIUvXW6t4anmo/X4IUPeIat8+53BFIlv7HtpZHJubiAWJ8ej9pR3/TVk2cPa43qizKK3rrckBQGRCYAgb2ShbGDhsxtmYLyFwgQkSuS31edh3CGEgV8hS/R/2E30JIQwh+BHyUsKENghxzdURg/yQRen1XD+ensMFgW9uvLFdCH7qJIRw9xMOcp4bD20Q8kNsSAmX3H5r9albfPYgtbFspT11glgxp9aQ3HqLbWgXgk3tz8XEulybJzZWc/2kPK/1w6r99fW1m/Xy8vLSKqxqOylzEzWMUMPVHRYYYBwjKfVG3RZ00aRJir9wRdZgG/ul7xBs5iZsIthsAtXQ6NnZ2eycQBzUHmLYtVtTzE0hzO8X4YGkBmKpR78IdRaFPFn2cWyr6QHAcWf67oMAxUVhMVGwgUDwjEGChBDuDgO411qOfWndX6592CzNJNfHvegzOYYQhli33uJWrXjLiPxpQWBs7VDttyAtmyIgAjkENDel0YrzNXtb9lXsw9Na9q0FDySEpHegzcPQAcDmU5gXAIM95QWKQYBunvU8beyn+JJntZ02TEIIgybLdoxPWX769OkA/2Ej/+ArPm/EXbkpArMEmPdCCAObxyllap+5fUpHz0RABETAigBzE+ttytyEnlW/PdhhvmYfrjn7YTbhMs3kof4Wv+kAYItZK/SZYqaoU5ujS5tU/Rw97GI/p40XXSZLL77swQ9qZW5h98gBn7XZ8JgZ+VRCIGfeY25X7ZdQVhsREIFcAsxNrLcp7dDT3PSYFHM2BymPn+z3DkzYf44S6OCmDgA6SGJqCBRzqm7Uo431pMCAwm7sY4ufWkCWydrWa4XNBjEsQ0u9iEAbAiXznWq/TS5kVQRE4CWBkvVVc9NLfodXHKQcftf1cPebp2M11gMbHQD0kMWEGGoKuKbtmGvWBwpjfbS+xwLSQxytOdXa3/pBEfETg2oFEpItEmD+Z74r8Z3aL2mnNiIgAiIwR4C5qXSOoZ3W5ceEYfr47r7vUCtHBLr4qgOALtI4H0RNAbP5s5oosYO9eY/9a2iibJujnvj2FEvbrMu6NwLM2TU+1bav6VttRUAEROAUAa3Lj8nUvCs8ttbPnYfrWB9x6QCgjzxORmFRuFYTpYUvk8Eu+LCXg4wFkakrERCBjRGonees1o6NYZO7IiACjQnoZbUN4J726VaEHqxjVkZXtqMDgJUTsET3ngazJ18s2PcWjwUTKxs9Le61L1FWTGVHBHIIWMxvPdb+kydPcjBKVwREwJiA5iZjoDKXTKAXRR0A9JLJiThK/gKnY3MWNo5t6rsITBHQJnuKjp6JwL4IWKxBFjb2RX2b0SrPbfLmaU3uLcee4rE4XGlTgetZPTjIXs8J4551AGAM1KM5TxNLj79G4zHnPfjkqW574KkYRCCXAGOwdtN/fn6e2617fa1jflNUW69+I1vfM+aD9b146UFtrr3NTbXxvCSjq3YE+rGsA4B+cjkZSe3EYrXh8baATELTw1UJqFZWxa/OReCOgJdxiB9e1rE7MPrDJQHqxKVjHTjlja03f2pTbLXPrvVD7ScIdPRIBwAdJXMqlJqJxfqU1NreVNx6tl0CLO61G/7tRi/PRcAHgdq1o6b9MYEaW5brjuam48z4+V5TI36i8OcJ44e69+RZTa6Jp6Z9Cw7w1Z6nBVk7mz1Z0gFAT9mciIWJhQlvQmX0EZOR9SSJPeyOdqibInBAgP8WTbVyAESXIrACgZK1AzeZ6/m0ktJ1DP+tfdHcZJVVOzvk2c6aLB0SsB4/h7Zrrq+uroqaM5cUNWzcyCvnxmFvxXxXfuoAoKt0TgfDxJKzQPLixSZn2mrZU+xiv6y1Wu2JAHW7p3gVqwh4I8AYzFk78L90Y07bKcn1hXWGNlM2S5+1slvqz57bUZ/KR5sKaDWWLbzlRZ7c59hCn3Y5bZbSxS/8W6o/9ZNDoC9dHQD0lc/ZaFggUyYXNk28pM8arFDAfoovFV2oaQcEWBBvbm4GarKDcBSCCGySQM7awQsD47ZVoKm+sL6wzrTygxiZm+inVR+yO0+AeqMm5jWlkUOANRe21HlOu6V1yX3KGIzxoL+0jzn94V9KPDk2pWtAoDMTOgDoLKEp4TC5nNq0xAmy5abp0Ed8YaJDDu/rWgSOCVCT1Ak1evxM30VABNoTYL5OWTuWeGFI8QWd9lSGgX40Ny1B+mUfrAMwpx6XqLeXPfd/BVte/Flzt8KWMUgtUBPHGeotnuP49H0ZAr310vwAgAmEgckksoRYJOjy8nKY8pV4olj0V2oDtviJL1zn2qEdEyYTPcI1drCZa6tGHz8Q+sePOWEyr+nPsi1+w6tGsGHhU40PqW3xNYqFz7k26Jsa3WKt5MbqXZ9cTNUNzxHy5T0WK//m1o4pXks/IzdRcuOn3eEY5Jo8E0OurVp9K1/wH1vEwGeuX7TBBizm1jCr52MvO7l+e9NPZQNrmOf6H9uR563I9fV1bpiP9Nk3pbClfmEEm0dGNnCDmiAGJMbbWzwxrrFP8lybpsuZdyBqYymxqP1aHs/bd/fR7ACAQRhCGM7OzgaKiSQuIVYZmvKVeKKEEO5O/636nbMTJ7IQ7tniJ77AOYQyX+JAnut7iefRl7nPJXxJ6QP+FpLS15yOhR9zNqi1KCGU1dtcHKnP52okPk+1J708Aqm1UjM35XnkQ3uOi5fncRzzGULZWPY0xkp9iWsqdQoL8sNnCPdM2MvkVlb0ZYnPXN+866cyy42DPIZwv28iv+R5K5Ib6yn9FLan2m7xfox3i76P+Rzjmfoca1dyz8vYKPG9TZv+rJofAMTFlAm2P1zjERFrCGEg9nENm7vYZ5PCwDxlEV+ePn166rHui4ApAeothPa1b+q0jK1CgFrR3LQK+qROY35YZ5IadKDES+HUmgoTBL0Owt1lCNRzCOHuB1G7BKCgRUAE6gl0aMH0AICJdmox7ZDfg5CIHQYPbhp9YQOC/RRzHBBoo51CSjpWBKjNVrVv5aPsrE+AuSmEsL4j8mCUAPnZy1hmTeXlfhTE0U300D+6ra/OCbAmUc/O3ZR7IiACzgn06J7pAYAWyOHuP3lg0bEuFjYgOTbZyOkQIIeYdGsJaPzXEtxPe81NvnPd+1gmvtw1Ff0Wa7vvSti2d3r533b+5L0IOCHQpRtmBwAsqLx0dkkpMyhYZDaZVC+1Rz60YZlEq4eGBKi30lo1dEOmNkCAWtHc5DdR5KfnsczLfAn9npmU8PDcRrnynB35JgJbItCnr2YHAKULao9Y2TxZbW6xU8NWi2CPFeY3pppa9RuVPGtBQHNTC6p2NnsdyzV1Z7m222VKlsYI9Fq/Y7HqngiIQEMCnZo2OQDgJbVTPquHVctWG5bVU7g7B2prdnfAdhqw5ib/ie9xLNe+GNYcIPjPeB8eKkd95FFRiIAHAr36oAOARpm1WoB63IA1Qi6zTghY1b6TcOSGCOyWgMby49RzcPX4ru6IgAiIgAh0SKDbkEwOALqlUxGYp7/kSocIFYlU02wCnmo/2/kdNPCUH81NvgvOU61YkFK9WVD0b0N59p8jeSgC2yDQr5cmBwCabNsViMUGTJg7NEwAABAASURBVD/FaZcfWRaBLRJ48uSJC7ct5jcC8RIPvkj8EqDeamultr1fOv14pj1PP7lUJHkEmOPyWkh7kkDHD00OADrmUxya1QKkwVycAjVciYBV7a/k/i669TKvWPmhmmtTtuL6mKtVzT62rDsiIAIiUEdA81Mdv+PWPX/XAUCD7J6fn5tZZTDX/MTB0hezoGSoWwKqt22k1sOLnWWtME9ug/x2vLTMj6eoa2u/tr0nFr36wnxQs2/qlYvi6p+Aat80x10b0wFAg/RabxBK7bEAlrZtgEUmd0BA9badJK/5gtdibloznu1kPd3TXscyG+TSWiltl05dmlYEeq1fKz6y0y8B1b5Vbvu2owMA4/y22CCUblj0dzMYJ1fmJglcXV1NPtdDXwTYJLSYr1KibDE3rRlPSsxb0ul9LFMrHELl5ISxQrucNtJdjwD7pt7reD266tkzAWqf+cqzj5vwrXMndQBgmGAWm1YbBOymDmg2NvhiGJpMicAkAeqNRWdSSQ/dEciZVyycbz03LR2PBRNvNvYyljmESl1T0aO2vOVK/kwTYE0id9NaeioC/RFgvlLt1+W199Y6ADDIcNzUstgYmDtpggF9c3MzTA1qnrGxae3LSSf1YFcEqDdqUvW23bRfXFzczSnMYy2joFaWmJtiPPTXMp7ebMNrb2M51sqpXDImOBBB75SO7vsmQO6oa+rbt6fyTgRsCaj2q3h239jVAQCLba1YZCzFBxYTNgYsLEtsag/jOhzU+IFEX3h2qJtyjf9Iiq50+iaQW/uqN1/1wDhGcr0ij7RjHmE+QVJqYU4HO9hknqSPXL/wCcltR18IfeMDMudrbh9j+nN9eHsOFxjV5occ1coYzyXuUSfEDwd4IFwjxFRyuEm7pcSCkUVdWvjR0kbMM/lFLGJOsdEyplzbKTWZa1P6yxEgfyW95dZ+SR9jbVLGxxI6Y77N33usAf85edzK7x03BwAUwRzYlOcWqFnw5/piQKFn0V+pDXyIUuILbWl3dnY2ICGEgXtIqU9qt20C5L5V7WP7uN74zv1tU1vfezgijGMkhLKxjA3ygczVQcpz7GAzl1BsRyxICO3jYQ3K9fNYn1hTuHjRiZyP45j7HtuRGysJIQwh3Od5rv8Wz8kdcSFcIzn9kFPahBDu1lMrLlN2Li8vc1w8qUvM+F8jvFSf7MDRA2JFamLNaesl9Ovr66S6DCEM1DGMvPi+Zz+oNfIRQrjLXwihOD/kFMHmlFiMZdbTqT6WfFYUz0jRTc3F8VkI5fkZ6bLpLTcHAE2jlPEHBJgAQgjD5e3mgUXh8CH3EHQO7+taBEoJMNGHMF5v1B/1xgJXan/P7RinIYQBjsghC7gi6Bze93yNryGM1wqxIOh4jqFn36bGslXc5DiEcHcYbWWztR3mLzaAx2Owdb+yLwItCFDHjEPNtS3optlkrj01r8T8hBAG9NIsSiuHQI3uYX48jyEdANRkeYNtKUYm9jnX0Xn69Omcmp6LwCQB6o2N8aTS7UMmzBC0mN2iSP4XtozTuQbobGEs58QTgmplLu/Wz8lPyli26pe6pU8re63sMLaYv1rZl10RWIsAYzAEzbVL82feY65NmVfQ0yGAeYbMDDKGyKeZQUNDOgAwhOndFEVIMab6yeTD5iZVX3oicEggt95oy2LGp2SaQC5b72M5Nx7o0IZPSXsCsM5ZO6w8ok/6trJnbYf1kbFlbVf2RMATAc9j0BMnC194mWfey7HFvol2OW2kO0XA9hn59JgfHQDY5tm1NYow10E2N5r8c6lJHwIl9UY7NtV8Sk4TKGHreSz3Fs/pzG3zSUl+rCJds++pGFgXGVNTOnomAj0QoM61Li+TSV7mS3piPipppzYjBBrc8pgfHQA0SLRHkzXF53UD5pGzfLonUFNvbDY8npbeR7b+nzVsPY7l2nhUK21rsiY/Vp558OE4Fo9j6dhHfRcBKwJal61InrZTM88pP6e55j5poU9+avLbwicdALSg6tBm7WZFm2yHSXXsUm29eJsoPaHubSzXxuMpNz364iE/tfOJdV40P1kTlb0tEFDd+86S8mOSn2ZGvK1jOgBolmo/hi2KThOLn3xuwRNOO7fg59Z8tBiHFjasuGlusiLZtx3mE4ta6ZuSohMBEdgygdrDVubJLcfvw/d2XnjLj8kBgMV/G2Rhg7Q9efKEjyqx8qXKCTUWgY0SsNioe5soN5oK925b1Ir7IDfsoPIznrzeuGjPM55n3X1IQOvyQx69futtPsiKp3FSPa0dbg4AGjOX+UoCngZQZShqLgIi0BEBbUo7SuZGQlHNbSRRDty0+KGUgzDkQmMCVi+GVnZqw93qO0Nt3HPtPXExOQCYCzjluRUUi19vtfIlJe4ldHqLZwlm6kMELAmcn59bmpMtEdgdAS8b297Aa25qm1Htv9rylXV7Ar3VLPEkHsTZwzyw6MGHA3cGkwOAWrgsQNg4dKz0utYOvpT27bldbVwWByue+cg3EWhJQOOnJV3ZFgEREAGfBGr3pD6jkle9E+jtnSFtHLbNqgcfDiM0OQDAoKcNbk3heooDrlZSE1cNTyv/ZUcEtkpA42ermZPfItA3Aeammr1B33RsomPTD2cba7IiAssQqJkXPNZ7UjwN0fLT/7V9OA7P7ACgdJKjUKyhYA/Yx8HOfb+6uppT2fTzkvha5GfTEOW8CGQQYB5iPspoIlUREAERWISA5qZFMA9wZi1Ypjf1IgI2BHp7Z5iLx4bauBWP/wmb2QEAITPJ8cLIdYqgS5sU3VwdYGM/tR26HGKk6m9Rj/iIM9V3dFvlJ9UH6YnAVgmw4dP42Wr25LcI9EuAuWnNzXC/ZE9Hxp4U7qc19EQEfBHIfWegvj3veWbiaQbf61xregAAPZLPiyPXUwIQdKd0ap9hf84XCnYJX2pjsWoPE+Kdswc3dOf09FwEROAxAeYVNnwsOI+f6o4IiIAIrENAc9M63OmVNYG9FdcSEdgCAd4DUt8ZqG/vMcV4Ho9De8+Za2HndR9ofgAAQgDf3NwMAEa4h0QYPFsKyMXFxUB/+EH/+IFwTWIo2KV8oV8PQryRCVyiT5EJz+AW7+tTBERgngDjB4nzynwLaYiACIhAewLMS4jmpvas53pgb8Uei70XOZnT13MRWJtAb+8MxMM4ZAwid3yN/mBMI3GupS8j0+ZmmhwARC8BjDDZISUv27RBgBhCuPtvqbAZ+0j9pA128APhGpup7dGLbWiHhBCGEMoFG/iFYH9poV8EHkiMb2k/6C/2DZMQppleXl7SpBthsoB/rVgAOTs7q6rpEMKADQtfQpiugxDmn1vUSmp+qGGEGs6JP7ahXQjTMVnEk+ObdH0RyKmVEKZrKYT551Zj2RfFfrxpPTf1Q8pfJOy9GM+1635qe15ILCiEMD9vhFCvw3oII8TC7zVskF/iiBLCaS5bmGvJBRJrLsaXyza2g0sIp5mEkPYMO/iF3RxfaIMQj5XgA4JPOb7ENrRD8It7OTZydZseAOQ6c6wPBAYFcn19fff48vblDwkh3B0G3N1s/AdJiL7gR5TabrFDLEgIy8VT67dl+zG2lvZlSwS8ElDte82MP7/YDIRwf7jGuoH481IeiYAIiIANAeY49sYI8x9iY7m9lbG1nXja9+y7B3IYgv06BlvqhHdF+oB/JonV1PF17P1yiXhcHgBEICR1KisAItlTOrXP8IWimvOlth/aLxEP/XgRcrcUWy8xyw8RgIBqHwqSFALUCmtDiq50REAERKA3Asx/CHOh99iWfGfwzuLQP15yyeHhvRbX9MF7RV6ttPBk3iY+4uvU+2XLeFweAMwBOcQKHArr8J7VdUyOlb0UOy3jSel/KR3YEutS/akfEfBCQLXvJRP+/VCt+M+RPBQBEViGAHtG5sRlesvvBd94f8lv2XcL3tGmXnJbRE+tcBiTZHsFJWoFH1O7Rtc6HncHAEBJBRL1KKySdrH9qU+An3rW8n6reFr6nGObXK3FNsdP6YqANQHVvjXRfu2pVvrNrSITAREoI8De0fpFqMyTx63w7fHdfd9hHeOdZg0KqYcxa/hWUivEY1n7rg4AKJQSKCSvtB1txwRfxu4vdY94LBO9lN/qRwRE4DQBxvXpp3oiAi8JqFZestCVCIiACEQCa+/Pox+Hnx59OvRvreu117GEvCyOpsanmrbHgbo6ADh2Lve75Qvz2kVL7JaJxp4HIUce2HpgIR/2RaDH8byvDC4XrWplOdbqSQREYFsE+Ikye0lPXmtf+zgbHtax+bw89rv1nRqfqH0r/1wdANRAAYhVsVnZwSfJQwLeJu2H3umbCIiACKxPQPPk+jmQByIgAiKQQkDvDOOUat/pxq3m351cT/PNVbWwqBWreNwcAFgEZHkyUpVho8a9xQMWizxjRyICWyOg2t9axtbzt8e5fz2a6lkERKA3AhYvUr0xIR7+wj0+1xZP+50pX9bmVNK/Ve27OQAogdCqjZcBRHy9FS4xSURABNYj4Gl+W4+C756fPHni20F554KAxrKLNMgJERCBbRLYpNdW874OADaZ/u06bXVytV0C8nyvBPRT3b1mXnGLgAiIgAiIQFsC5+fnbTvIsM5LqpeD7NPvHRkBGanCpdaUhQ180AEAFI4EuF4K98i1zX+F7eaDUAAisGECnhbDDWNs6rpy1BRvN8ZVJ92kUoGIQHcEPMxPk+9yKxC3eAeysEHoOgCAwoh4KNwRt7q45emUsgugCkIEEglo7CWCWlmNBd7bxmVlJOr+iIDG8hEQfRWBnRPw9t7iYR3Dh1Nlsdb9mrm7pu1xvDoAOCby/DtFYwn6uVl93BJgktLm9haE/hWBBQkw5hh7C3aprioIKFcV8DpvqrHceYIVnghkEri6uspssYz6musY73AT/S8DYKQXfGIOH3k0ecs6Hh0ATOAuTdKEST16TgC2zy/1IQIisAABjbkFIBt2wSG0102dYZgyVUBAY7kAmpqIQKcEeDFkvfAYHn7h39K+8YI9PU8u7dHD/nL/gvcW8egA4GFOHn0jSWsU7yNHOrvBpHBzczNQ1J2FpnBEwBUBxhhjjTHnyjE5M0uAnOkQYBbTbhQ0lneTagUqAkkEWB88v+gSBP4t+R5FX7y70fdJcfCAfRm+zrmCTot4dAAwR/72eSxeknD7Vf8aEqCo4crGxtCsTInA7gkwptgcMMZ2D2PDADgESN0obDhMuT5BQGN5Ao4eicAOCbBvZl1gfdhC+LxH4S9+t/I3zpP0NdeHl+f4ChN8P/aJe+zh0Dl+ZvFdBwCJFEkAQgGTEBI2J4mmJ9XYvNPvlmQyoJGHxEacOWzn2Kc8H3Fl97eYcFLYzensHmQjAHP5YW6Kwpgq2RzQjjGJNApDZgsIkI84R5LjuTFo9bzA1SZNDusSFmuKRYBLjGULP3uz0aKO1mSUE4+FnxbzCrVv4cuac8Bh3+TAIp45tsz7COsA/Vv0ubSzNlMNAAAQAElEQVQN/MZ/4piLN+U5dhBskofEPY952PRNbEiucdrQnhiIeal4dACQm6lbfQqMhE0JOreq1f9eXl4OW5MQwgCbkuDhRtslpMS/3ttYcCeHvXNaKz7YTuWI51FyfGTxoV0IYTg7O3sx54RQPpZz+pduOgHyhEzVgdUz+kn3rK3m9fX1i7q8XHldtIgUtlN54nkUi/72bgPWITyc36zqKITl50nm7BDS42H8WNQAHGvFwg/iscpfrR18qY2JQ5E5rj3NB8QyF2/Kc+wgefxttBmD9B3Cw3EYwv18gP+5PdEGm7ntSvR1AFBCTW1mCTChhnA/CGaVpSACIrAaARYcXvpPbWI0lldLjToWARGoJBA36cxjlaYmm2M/hPZ7nhgPc/akQ3ooAiIwTsDgbsq+iTkBPYPumpjQAUATrDIaCXgfANFPfYrAHgmwODFGU2JHD/0UXemIgAiIwNoEeFnmRfnU4WYL/5gn6beFbWwuHQ99SkSgJwK1sbAPYpyn2EEP/RTdpXV0ALA08R3253kA7DAdClkE7giwKDE2774k/oE+7RLVpSYCIiACqxHgZXmNzum3xSHAUr8avAYz9SkCCxGo6ob9D/ugHCPo0y6nzRK6OgBYgrL6uPtvN4VBBETADwEWpRJvStuV9KU2IiACIlBCYO0Nt3X/2FvyNxlKmKuNCPgnUOdh6f6Hdi0OBWui0QFADT21zSLAApbVQMoiIAJNCNSORW8LWRNIMioCIrBZAmy413Sel3XLeXLteNZkqb5FwIxAhaHafVNt+wrXR5vqAGAUi262IGC5GLbwTzZFYC8Easeit4VsL3lTnCIgAvMEvMxPVn5Y2ZknJw0R6JuAontJQAcAL1noqjEBTsQbdyHzIuCWAP83P16cqx2Lte29cJAfIiACfgh4miP9UJEnIiACRgSqzNT+Fg77ptofvlQFcNRYBwBHQKy+6i9rsSIpOyIgApYEPC1AFvOkXhosq0O2liJgUftL+ZrSj6d4vMxxbPhT2M3peIlnzs/U555qJdVn6fVAQDEcEtABwCEN42ttTI2BypwI7JyAxa+CsvnqaW4iHouysGBr4YcnG1ZsPcXkxRexfZwJKya9jWUv8Zyfnz9OWsEdqzwXdK0meyag2B8Q0AHAAxz60pKA1eLR0kfZFoFWBLxs4izisxrLbAR7OozoKcexTnrKT4xJn/YELMYyNuw9277F3rj0Fs/2K2wfESjKhwR0APCQh+m3HjeDNYDEo4ae2m6dAJuempcpq5duONaOxdr2+BClxhZMatpHH/j0lB/88SJWfL3E48EP6taDH9Y+1NQKTBiDFj5hp2autfDB2oaHeGrye8yDfB/f03cRaEhApo8I6ADgCIjlVxYhTXL3RMXhnoP+3DeB0g0Um7/StmPEa+Ym67GML8Q35ufS92oY17RdOs6c/jzlJ8dvr7rUumqlfXZ6Y7x2PNbz/trxtK9A9eCLgLw5JqADgGMixt+Z5Fjwjc1uyhwLBxw25bScFYEGBHiZYjzkmm7xl0AxJnPnJnynXa7/c/ol8bXwhfxcXV3NufvoeUmbR0Yc3yA/ubXiOJxVXYPlqg407rxkfmg1lrHbONzFzJfOTRYOwrEkr3N99z5vzsWv5wsSUFePCOgA4BES+xss+Eyg9pb9W2TT2GLh8B+5PBSBcQKMh9T5gPHTcpOUMzfhM76PR1V/lziJN8VSS1/YaGM/xQ908Js2XPcs1EpqfnrmUBob7KiV0vZbacdYIE7iTfGZsdZqXsEu9lP82IIObJeOh/7g2IIP8VArLWzLpggcEtD1YwI6AHjMpMkdJlAm0ibGHRpl8WdiZ9Po0D25JAKrEojzwdScwDPGD5ukls5GX071Eccyeqd0LO4TJ/ES9yl7S/lCrDc3N8OcL+jg9yl/e7s/l5/e4rWKhzqC3V5qhTiJl7hPMfQ0lk/56PH+xcXFwLwzxdbC76XyQ60sEY8FE9nYLAE5PkKguwMAFp05GeGwyK3DiZvJmwm2R4kv/kzsi4Ad6WSuBng+0ky3HBGwGBtW4VAvU1LSD/MBwng5nA/4zoaIZyV2S9rQF33iBxLZ4wtxLzmWx3zBp7V8oV/6P2TCPbiUsN56m7H8RDYtP624tfTx2DZ1wriCWYn/1FitlPRr1Ya4iZ/xg8CHT7gQV8m8QrsS//CFfukfP+akpI8l2xDPMdu5mFKfwwnOJfkpZdAyntS4S/VKY1a7pQionzEC3R0AnJ2dDXMSQhiY2JhwxqC0vke/CBNsjwLb1gzH7MOSvkMIszVAjYzZ0D0/BMhnrbDZq43o+vp6tp5CCEMIYWBcIzl9UrO0ibHyPac9urSlXQj3foRw7wvPcgQ/EOwh2MxpH9vQLoR7X7jGZo4ddGmDYJNP7HB/aaFf+scPhO/I0n546w8mCEyWEIuxzAZ/CV9jHyV1QlvahZC2jrGWTUkI9+OQXCFr1BH9IsTGJ/Hl+EE72oRwzySE+/kNWzl2sEEb7M2JRb3l+FaqSzzIXDw5z+FU6k9tO2JBcvxdW9d7rcCHnCIh3M8HXMO5Nl9rtM+OZw0nN9BndwcAqczZ1F9eXr7YtKe2k54/AnEyYBNEXv15KI/2QoA5BVlqYaWfEO43xce1jx8h3G+Ul+CPL3EMHvrC9dK+LBGv+hABSwKMnxDGx7JFP4xBhH4s7C1hY2ptJxYkhDCgt4Q/6kMEtkaA8d7TulwSz9ZytpS/uz0AOATMIkJRHd7T9TYIkLc4uW3DY3m5BwLMKSG03ZhS+/QzxxOdp0+fzqlVPcc+/cwZQQe/5/T0XAT2RIAxwdhYImb6CaHt3GQRBy/1qWs7euhb9CsbItALgd7W5cJ4ekmneRw6AHiOlEVRC8hzGBv5WHLTtBEkctMZATamLVzKrX1+Cs/i2coX7KfaZq7F/1R96YlAzwQYC4yJpWNkbvK858G/HCboe44nJxbpikAtAeaVntbl8nhqSfbbXgcAB7llATn4qkvnBNbYNDlHIvccEmjx4l1S+2wGWEQtEWGvxBfaaLNumQnZ2ioBxsJavjN+1+p7qt9Sv0rbTfmiZyKwNQKMg5J5hTYe1+WqeJ4921r6FvNXBwBHqC8uLo7u6KtHAsqTx6zIpzECvHhbLqo1tc8CP+Zj6b0aezVxlPqrdiLgicDaY8B6brJgC5PSecVjPBZMZEMEcgiUjh/6YPzx6Ulq4vEYjxe2OgA4ykRNoR2Z0teGBJSnhnBl2pyA5SJUW/tWhxG1MbFZNwctgyKwIQK1Y9ki1NpxbOGDpY3e4rFkI1v9E6itf2/rcmU8g7d4PFWgDgBGsmG1QR4xrVsGBHrLT4tfETfALBMOCdQuhoRkYQM7FtLbWLZgIhv7IOBlHHrbINceiniLZx/VrCh7ItDPunyfld7iuY+q/k8dAIwwVLGMQNEtERCBYgI9bkot5kkLG8VJUcPdEdBh63jKexuHFvFY1MqTJ0/GgeuuCDQiYFH7Fjaswqvy5bkTFjaem+rqQwcAI+m0mPhHzOqWCOyCgMX40cZpF6WiIEUgmYDFvJLc2QKKnuLx5IvF3O8lHi9+LFDO6kIE3BGwdqinuQk2OgCAwpFo0j4C4uxrb/nx8quglmmunSh7y/H5+bklXtkSAREoIOBpXvHiS29zk1U85Kd2HSsoUTURARE4IFCxP35hxcLGC2MVF97mEx0AHCXTavE4MquvxgR6yVMvcRynt3bCrW1/7I++i4AIbJuAxQsZNjxR8LYh9MDG09xfWy+eYvGQW/kgArkEGINl8+R9T5Z77NrxTCz3Xvn4UwcAR3moTfCROX1tREB5agTWyCwTXemkbTlhG4VTZYZ4VK9VCNVYBO4I1IwjxuGdEUd/1MRjEQZM1vbhOI6atYM1xzKeGluwPY5N30VABPIJFI3D593UtH1u4sVHzdyEEUtfsFcrOgA4IKgJ+wDGBi6vrq424OVpF6k3bxPCaW/zn5TEZr2By/favkUJB3svZFEEtk+ADRjzZm4ktPE4DkvjyY3/lL5HJvjKX9rFWsB1jrSIp2Sfge8tfMlhIV0R6IVAyTxJ7Mz7fFpK6dxUMo9Y+j1mSwcAz6lQKJqwn8PYyEfppOAhvD3UW25+etw0eZz0PdS/fBCBUgKs08yfqe3RpU2q/tJ6+IaPS/frfW6CSw4T4mHNyWmToovNnPywjvGSkGJbOiIgAmkEmA8yxuGALm3SrOdp5dptNTflef1Ye/cHAEzWJCc3oY9R6s4aBMgbA32Nvkv7xF/8Lm2/pXbEyfhinE35zXM2TWy2pvS28ox4bm5uhl7i2Qp3+bkPAswrzKNz0aKD7pze2s/xEV+X8GMrcxNzJ3PoHBfiYY1BvxU/8kMfc/bxlXVsTk/PRUAE8gkwDhljcy3Pz88HdOf0Sp8z13iZm0pjoN1uDwDiosFkTTKBIdkmAQZ6HIwpk8MaUcZ6w0/8XcOHtfpkfDHOyA0S/YAJwsaK5/H+lj97i2fLuZDvfRNgHmU+ZU5h3MVoueYez9CJ971/4is+4zsxWPuLzS3OtXCBCXLI5DAe1pjDZy2u6SPm59AX/EBgi68t+pZNERCBewKMsTgOGXf3d4eBa8Ygzy4uLuLtpp/4wlyAHHYUfWFfy7xx+MzTddMDAIJHADAngLQAQwFMCcWBRL8s+lzDRvR/jmvOc3KA3TXisegT/xHyi0zVwVLP8AOBK7nIjTO2o+2c5NpeWp/cIPCAP7EhxLW0Lzn9xckcn08JMSFbiCcn9ta6l5eXd78lQQ1sRajh1lxO2Y/1ZcmKeLB7qk/v96P/jD/GJ7Fwz7vfp/zDd2IgHoSYagQbCDapm1P9trpPvwh9IzG+nP5ogxAHLPiMNnPs0AY7+IFwndMeXdog+IAv2ESwx/NUiW1ohz0kta21nidfrGOTvXwCS67L1D2S6yVtqFvGIMI1Ywk7qUIbhHZItJnaHj3aIHE+4DPa5Hmq0AY7+IFwndq2VK/JAQCBEMDZ2dmAXF9fDylSGsRhO/qdkkPdLV4fsk1hmqNzebsZJ18UHrJFPoc+T9XBUs8O/cm5hn8IYfHxk+NjjS78a9ov3RZ/p2Rpf3rqL2eO8qDLPBlCaPorhsf5XWreP+53a98Zo1vzec5fYqqROfstn+M3ewokjl3GD99Z45Dc/rGZ2+Zw/ND/oS8hlI/lWl8O/cCvEMp9yWWCPvxDeLjPwA8khGV9wR+JHwKxNlt/UmtICGX1xhhEDsglXVL7zENIjBE/+B5CuS9JnR8otZqbDro4eWl+AEAwAAToyV71oIhALNjWbBkECP0VOapGxQQYP0xm8C82ooYiIALNCTBGQyjbKOQ4xzy8xJq6VDw5sUt3mwTiOja1V6HeEOq7ZZTYnxs/+BGCj7GML+wBWjKJ+aGvqX54Dr8pHT0TASsCNvU27Y2n2mdsrTk3mR4AxGCm8etpCQHYMjhK2pa2oT/6LW2vdvkE5iaDfItqIQIi0JIA8ySbim4uAwAAEABJREFUihZ9MP9iv4XtUzbpr1U8p/rU/X4IUDs56xj1Rp23IIBd7KfaRhf/U/Vz9HJ84eCk5SGAl/zk8JPuPggwBqtqfwaTl9rPmQ8ICS7Wc5PpAQAO4qjElkBuoVj2Tk6ti87Sv55skeee4lEsIrAXAmwqrGNlPmD+tbabYo94NO+nkJLOMQHq9vje3HfqvEW9YXeu7+Pn1P7xvdrvMMn1pdUhAL7kxoPvLfKT64f090GA2i+pU+hMScnBQqvax+6Ur2PPrOcmswOAFskaA6B7yxNQbtszh3HJhNDeM/UgAiKQQoAxnKKXqrP2fGAdT2rc0tsuAWqGzXtJBLQtaXeqTY29mrZj/pSOZVhavngTV6kv1i8fY5x0TwQiAeq0oPZj80ef1D7j6dGDhBu0TVBLVqmxV3KIccoxswMAknWqE90vJ8AAWJstgwY/yqNQSxEQARHom4DlPF2zQbCizLxvZUt29kGgZgxQb5b7jBpfatoeZ7p2LNe2P/an5rtlfmr8UNt9EMiv/dNcamrX09yEL6ejzHticgBgmaQ89/vXrilaSzrKsSXNx7YsNxyPreuOCIjAEgS8zNdWsfYWjxUX2WlDwGqfYWHHS+1bbvhr9xkWXNtUjqyKwDAMExBqx5FV7VvYsZqbTA4AJpjrUSUBq0RXuqHmDQkoxw3hyrQILEjAaizXbtStQrbYrFj5Iju+CfRWK57GsoUvFjZqX6J8V7C880Ygt95O+W9R+6dsr3HfKh4dAKyRvQ32afnfnWwwfLksAiIgArsjoHl/dynvImCrDXIXMBSECOyDwMkoLeYDT4cRFvEAy+QAwMoZHJKIwN4IaJO9t4wr3l4J9DaWe4un17rrJS6rTbbFbyNY1f6TJ0+q02Phi4WN8/Pz6lhkQARSCeSNnVSr0osETA4AojF99kvAYkHtl059ZJro6hnKggisTcBik712DIf99xbPYWy67peARd1a2IBw7d7J8qVb+wwyItkKgawxuJWgHPmpAwBHyfDqiuUC5DXGtf2q3SSs7b/6F4G9E+htnuwtnr3X597ir6nfmrbHnHmJqXnxttwb1NiCSU37Yy76LgJzBHLqbc6Wnj8moAOAx0x054iABuERkAZf2SSwwDYwLZMiIAKNCTB2e5oneWHpKZ7G6Zd5hwSoX+o417UWYxlfcv1AH1/4tJKafQZtrfyQHRGYI5BZ+3Pm9HyEgA4ARqDo1ksCV1dXL7/oqikBNgma9JoilnERMCfASwZj19zwigb19/qsCF9dmxHIHZetxjIvz7lrO/q5/qeAwya2U3SjDvrEEL/rUwRaEqDeqNP0PqRZQkAHACXUdtCGhZCXf036yyabSY/Jb9le1ZsIiEAJAebJnl6Wiefm5qYEhdqIgDsC7F+oZ+p6zjl0Wo7lnLWdPQD6cz6XPsc2faS0Zx+IfoqudESglgB1mV1vtZ3utL0OAHaa+KmwGYAshCyeU3p61oYAkx85QNr0IKsiIAI1BHhZYGPMPFljx0vb3uLxwlV++CDAOD21ni5Z+6ztHEjM+YJea3L0gR/IWF/cx1ftA8fo6J41gTgOqctc29IvI6ADgAJuLCZbKlIGFpP5lLCZRZjwtxRbQfqSmpDjKEkNjJXIAUI+pvJ2+MzCBWKm316EeCy4tLaBn8gcd3QsfJnrJ+W51f9ll0U8h+Og5TVzJEIevG+Mc+b9LcQzVSf4j6TUbYoOtqb6W+IZPqT46kUHf5fgUtoHnFhPGb/MEXwi+L30WB7zBd9KfKENgs1cNrRB6BsmCEz4zv1ce/gRJbetR/0YCyymBD0L/6f6SH22tXU51hsMC8ehBfpd2tABQGLaY3GGEIazs7Ph8vJyCCHcCQMz0cwqagwqfJwSdJBVHHTUKYxCuM8xeUZCCAP313KTvlPEwj/quifxtBiO5Ye8Mu6oM2SOvUU82JjrJ+X5WDxr3YPjEkKukLXizOk3hQexIDl2PenGdZmxg6TUbYoOtkJYft6P8YRwvwal+OpFh3nFU22c8oV6Z2zwiZzSW+I+/UdfcvuLtUKtItRBCGGINnPt4QdC+5K2IYS7vTG+ICEsP35y/T6lHzkQBwLbKbGofWxM9ZH67FRMS9/nABqOc1JSbw9j0bdSAjoASCBHATMJMEDH1BmYKuIxMtu5x2IaQrg72BnzmhyHEFY9CBjzS/e2SYB6Y86grk7NK9uMTF6LwDIEGD9T67KFF4zPEJaZ9+f2GRbxyEYfBKZqn/WEuqWeWkfLOhZC6GbfRDywhR8cW/OTfQMCMlFMQAcAM+jiZDCjNjBZhBAGJpA5XT33RYCFko1kilcsDOin6EpHBMYIMEdQb8wZY891TwREYJrA06dP79bcaS27p63nfeKhDzuPZalXAtRKytpBPaHbigP7INaxFPv4gn6K7lo6WpfXIl/Xr1qXE9ABwAQ7JqyUifbQBG0Ov+vaNwEmfRanHC/RV55ziEn3kEDqpumwja5FQATuCTD35q7L9y3r/mTeZ72os/K49VrxPPZEd7wT4IU+p/bRpY11XIwDxkOOXfSp9Zw2S+pqXV6StllfMlRBQAcAJ+AxUTFhnXh88jYTLm1PKuiBKwKlk35JbbgKXM6sQkBzwyrY1WknBBg/a8699G+JEntrxmMZi2y1JUCtsL/M7YU2vLDntpvSL7VHrZe2nfKn9hlsa22o/RoE1GcNAR0AnKDHRHXi0eztmrazxqVgRqB20q9tbxaIDG2GgOaGzaRKjjoksPb4afEy5RCzXHJIoKb2Lfcq2PLii1WaauKx8kF2CgioSRUBHQBU4Tvd2OMp52lv9aSEgHJcQm2/bdg47Td6RS4CdQS8zLeW41gvHnU1sZfWtTXn6eAKXzzlrZatp1j25ovirSOgA4ARfhYTgoWNEdd0y5BA7eaLhczLptQQi0w1IqBaaQRWZndBwMv4Yd63AK49wmOK/F+HPb6rOxYErMaPhR0LGxZMsOHJF/yRJBNIVmzx92Akd95A0SoekwMAK2cacJJJERABEagioPmtCl/zxnppaI5YHYiACGycgNWLrtUBmBecvcXjhWt7P5btocd9hg4ARmrIYsNvYWPENd0yJGAxoJVnw4R0bkobjTYJ7nEMam5qUysWVi1yY+FHjzZ6HMsWebJ6ebfwpTcbGs9tMtp8LLdx+6RVq3g8/eaXDgBG0m2RaAsbI67pliGB2oF4fn5u6I1MeSWgsew1M/36pbnJb241H/jNjTwTgVwCtXNtbn970W89T+ZwxJeeDnqsatbkAIBE9ASXeGpe7mhLwWFH4peAcuQ3N14801j2konTflgthqd7WP6J5qblmaf22GO9pcbeWk9sWxOW/WMCzLW9vb8cx7j0d3jCtWG/2aZr55ba9tFhuMAnfs/9ZE+a2+aUvtkBgBWcU44ufb8mHhK8tL/qr4xA6WCiXU2NlHmrVksT0Fhemnhef4zDvBbb0S6NjXaam9rkGbZtLMuq2KoG1iKg+dKWfPt9U76/+FT64m09N9XUW03bY2pmBwDAvbq6Ora/6e8l8VAosNh04DtynsGUOymgT7sdYdplqBrLvtNOfnoeh8RGjLlZoF1uG+nPEyAXYjvPqURDbEuoqY0VAfbs1KCVvT3bgWPzebIQcIlfLeIprTd8KQx9tJnZAQDWS4OirUfJjYfklBSYx9j35BN/wQ65S4mZl3/0U3Sls10C1IPGst/87SU/1CCxpmSCuank0DrF9t51YEsu9s6hRfzUt9i2ICubOQSoQWoxp410HxKAHxwf3rX/VmqRd7qcNbJlPHDCfmos+E2bVP0UPdMDADrEQRzNCYx2XoV4bm5uhql42BwQ88XFhdcw5NcMAXI3lWOa81wv/5DoVzSWfed2j/nJmZvY4PjO4Pa807zfJmd7HMttSMqqFYGUudaqr57sLDyWq9CxRnp5p6PeeHdkjTkVVGSL36d0Su+bHwDgCI4eBkYACM+2KofxxBiIieTxUkjM8b4+t0mAHMeJIQ7ImGPu83ybkcnrUwTIbxSN5VOU1rsfc8PnnvPD3MMcxLyEkJHIBC48556kjgBMo8AV5mJbxzS2jlz5hK32TZGMPj0RYLwz7plnEeoV8eTj2r7AI8ryY9km+sM8R4vEtHQ8vDviC/1Sb9EXrrnXcp5scgAQA4iBEQDCoDolBBrb1XyGEIYQ5gXgSE5fMZ4YAzFxL8dGbEO7EOb9vL6+zjE/qnt5eZnEJIR5f0KY14ErMurMBm7iO0KeY77WcDv2HcI88xDCGi6O9skkCrstCIyjMCZHA3J0k0XBC1fyXItmLp6YGz7Xyk/sO4RwN48yNyC1sZe0p1+EGoh+rcWlxP+121CzsDslMI0irnnZ2sJYzotI2nsmwDyLxPng1JzBfWrfCyvepfCppUQmfObOk7EN7UK4X1NDyPg8oUuukNw80Cayir7l2rDQh8ehL1xzz8L2KRtNDwBOderhPi/FSAhhIOlL+PT06dPh7Oxs4KUeWaLPNfqAK0IBr9H/1vukHp8e1MrW45H/IrBFAsxfIYQXc3aMgbkNCSEM6MT7+hQBERABERABERgncLivLX0HGrc8DKzJSAhal08xOr6/2wOAQxC8lLfcyPFCF0K4e/E/7Lf36zgYib/3WK3iow6pR+vJ0co/2RGBPRBgHDJ/zcWKDrpzenouAiIgAiIgAnskwDsAL/8G+9okfFqXkzANOgB4zomCoUiffzX94IXO1ODGjBF/K7YbQzHpLoyow0klPRQBEWhKgBf6nHGILm2aOiXjIiACIiACIrBBArwD2Lz8pwevdXmelQ4ADhhRpAdfTS61MbzHKA73HKb+bFF/U/3pmQiIwEMCzFNsHB7enf9GGw7w5jWlIQIiIAIiIAL7IMCaahZppiGty9PAdABwxMeyWLFFAR51scuvnP5pg3w69dTK6ad6IgIisASBmjlKY3iJDKkPERABERCBLRBgTbR8ByqJGR9K2u2hjQ4AjrJcswE8MqWvRwQ0EI+AHHxde5I8cEWXIrBLAsz9HFSWBl/TtrRPtRMBERABERCBHRAoClHr8mlsOgA4YkOxsBE8ul30VS91D7HB9uEdfRMBERABHwQs5n0LGz5oyAsREAEREAERKCdg+w5U7ofW5XF2OgAY56K7jQhoID4GKyaPmfR458mTJz2GpZgOCGgsH8DQpQiIgBsC/C3sbpyRIyKQS6BCX+vyODwdAIxwsSgWCxsjrm3+lhahzadQAaxIQONnRfjqelUCFrVvYcMKgidfrGKSnTYEVCttuMpqOwLW70DtPN2vZR0A7Df3i0d+fn6+eJ/qUAS8ELD4OzA8bQQt4rGwYZVfC7ae4rHi0pMdixxb8fDki0VMqn0LiuM2LGrFwsa4d7orAs0JqIMGBHQA0ACqTIqACIjAMYHaDZi3A7Qe46n5zzS85ee4/rb+nXqryQ/xY4NPL1Ibj5c4VPttM0Hd1tQK+cFGWy9lXQRaEZDdFgR0ANcqX8cAABAASURBVNCCqmyOEtBPCEax6OaOCLARKw3X4/jpLR6PjEvrpcd2NfmpqdVWLGviaeVTid1e4iiJfak2YrwUafXjjoAcakJABwBNsMroMYGrq6vjW/ouArsjwCau5Cc5Hl9eSF5v8fBTshLWtIEFTCTtCPSWn9J42hHOt0zt57dSi1wCpbVCfjQ35dKWvicC8qUNAR0AtOEqqwcEWIBYvA5u6VIEdkuAvxwn5xCA8eN5A9dbPLCGeWqBokubVH3p1RGANcxTrTDWaJOqv7QevuXEs7R/U/3hN/5P6eiZHQFYwzzVIrq0SdWXngg4JCCXGhHQAUAjsDI7DGy8+Mm/FiBVgwg8JMBLM5uzh3cff0NnC+Ont3hgDvvHGXl4Bx10H97Vt9YEYA77uX7QoTbn9NZ+nhrP2n4e9g9b/D68p+v2BGAO+7me0EF3Tk/PRcA3AXnXioAOAFqR3bHd+OLPxks/+d9xISj0SQJsztikIYeKjB/u3dzcDOgcPvN8ja/4jO+HfvYYDzHpcPMwy8tfT9XbFvNzKp7lyZ7uEa6Mb8Y5/p7W1JOWBGBPDsjFYT/kB9HcdEhF15smIOebEWh6AMALIMJL4JwwoTWLcsOGmeCZzLciLEox5znYaYNQJ9QCktPeUhc/6B9flhD6svDfokbYPFj40tIG+UGscgN/pKXPp2zTL8K4iUJs3DvVxvt9fI+x8NljPMRE/XnPxR78O6w35kByg2w1P8fxEJMHWXssk1PYkFcvgj8Ivq0x1uibvETBDwQ+Of7QBlu0m5Mcu6d0U/ua88XLc/idirW3+8Sawp0cW8RuYePy8nJI8dmLDuwQi9inbDQ7AADk2dnZgFxfXw8pMuXoXp/BcUuSm6c4mVAnCHVyeTtYkRDCoj8BPfSF/vFlKcnlNqZvUSdjdr3cO8xPrBWL/JBrJIRl680LV/khAr0QYA7sJRbiIB4vgj9ryOG8zzxtMedb2cAfhPWIDTuyBqPSPmEbQrjbpxNHCpfSvg7bpfSzNZ3D+Hq8prZDuK+V1NwYcDAzkeqzBz3GIhJC2z2p+QFAnFCAaJY5GeqSALXCwjlVK3EQoNsSApPbnC8t+5ftaQJL5SfWG/1Ne6SnIiACIiACLQkwD29lXWbtQPC5JRMr2xwswdbKnuz0SYC9N7VCbS8foXqEewhhIA/WNEwPAHBQE4p1ivq0xyKZUyvoUl8taOALg6yFbdmsJ7BGfqiHVvVWT0QWREAERKBvAmvM+xZEWTvw3cJWKxtPnz69+63cVvZltx8C7L2nfkjXNFIZf0GAPFjvSU0PAHDwhbe6EIEJAiySE49HH7VYVLFZ4suog7ppTmDN/DCfWU+45oBkUAREQAQ6I7DmvG+Bkj2F17UDtnqhs8hy/zY4KFozSvX9kABj9+Gdum9mBwDWjtWFpdaeCZTWCotWadtTPFioTz3T/fUJrJ0f63pbn6g8EAEREAHfBNae9y3oeFw78KkHthb5kY1pAtQKe+5praZPZfyIAPkgL0e3i7+aHQBoUinOwa4acipeUys1bY9BWw6kY9v6Xk/AQ36YcKnZ+mhkQQREQAREYI6Ah3l/zseU51o7UihJxysBy712WYxqNUbAMi8mBwC9TNhjsHXPloDFy5SFDaKysoMtiQiIgAiIgAiIQB2BntZlb3tjy5eHuiyrtQjMENDjkwSs5kiTA4CTXuqBCBwRsChcCxu4xQk9nxJbAlb/3ZhVnmuj87aJq41H7UVABETAKwGty20y42U9bROdrFoS8LDnsYynN1tW+dEBwEhlWL3AjJjWLRFwTcBT7XvZCHpi4rp45JwIiIAIiIAIiIAI1BFQ6wkCVntSkwOA3k4WreBO5E+PRMAlAdW+y7TIKREQAREQgY0R8LSeevJlY2mUu4sTUIdTBKzGsskBwJSjW3t2fn6+NZflrwiYEbCYWKx+PcksqEpDvcVTiUPNRUAEREAENkjgyZMnG/RaLu+OgAKeJGCxT6cDHQBAQSICIvCCQM0hWE3bFw44uugtHkdo5YoIiIAIdEuAtcPb4bE3f7pNvgKrIqDGpwkwr5x+mvdEBwAHvACrCfIAiC53SYAxUPKTAtrQtidovcXTU24UiwiIgAh4JWD1UzrL+PCJfa6lTdkSAWMCMneCgPUeWwcAz0Fbg31uVh8isEkCJS++JW08w7m6uvLsnnwTAREQARFwSICXbF62Hbo2sE6z3/Xom3wSgWEQg1MErP++PR0A3JJmMrQGe2tW/4rAZgmwebm5uRkYG3NBoMPLMm3mdLfwvLd4tsBcPoqACIhADwRYC3nJ9hwL+10OKTz7KN92SkBhPyIQ96SPHlTe2PUBQITKZFjJUc1FoEsCjI2pjQLP0Onl5b+3eLosSgX1gsCHPvjR4e3P3r2K0PcLR3QhAjsnEPeTW1kLOaRgvUN2njqF74iAXHlIgPHZao/d3QEAsOaEE1qkFCrtECbQKXmYxrJvKf1M+eDt2fX1dRkItVqNADXEbwMwZuLY4pp7PMt1jJqOQvtTkmt3TJ9NWfR56rMmnrF+dU8EliDwup/9leG//+++dhV57at/aYkQ1YcIrEIgd+1gTct9+adNXP/WCDL2zVo+tT4ePrPwM5XtYb9j1xa+jNld655FPIc1FfOb+4kNC18KOA6e21gwSa39Jfak3R0ApBQ6kzSSk0wGBG1CCMPZ2dmdXF5eDqfE6kX3lP2t3s9hLl1fBKj/OL64zvWOtiG8HD+Mo6k6zrU/po+f9Dsn6I211z0RWJrAu9/5/uGf/Y/fkiQ/f3sAsLR/sb83vPZXk3wkFmKK7fQpAlsgwJowt27wHL3ceGK7wzUwhHD33+fn2rLSx6cUsegvpZ85nRLuY77P9bPUc6t4pvZUqc8s3l940c1nd3E3Bi4uLlx+jtVP7r2LxNis6mHKv+4OAKaCLX1GwpioLQZFqQ9qJwJbJcD4CSHcHZZtNQb5LQJWBP7x058Z3vVbvzv82lveMSq/9AvPhtf89JuS5Pfe/8dWbmXboe9UP4npVLywgEm2A2ogAhsjEH+QxIvY2H6S+yGEu5efjYUmd0WgnoAsLEpABwAzuDmFYVKeUdNjERCBEQK8/Gv8jIDRrd0S+PCHPjb8X9/8fcPX/pNvHJVX/fBrumPzyh969WisMLj8pu8d9PcJdJdyBXREgLUw9QdJrJnoH5nQVxHomoCCW5aADgAmeDMBj53STjTRIxEQgecEGD9sZJ5/1YcI7IrAH/+XPxsuvvF7hn/9L779gfz7f/fK4U/++M+HT37yU6PymX/8bHecPvuZz43GCoM//cBfDt/97a96wAhm5//mu4c/+sP/2h0LBbQ/AvzkP3ctRJ81dH+0FPFOCSjshQnoAOAEcCZeJuATj3VbBERghoDGzwwgPe6GwJe//JWBF9n3vOv3hihvfctvDq+6/Wn+K37gPw+H8trX/PLwiU98qpvYawP5xCf+2wCTQ0Zcw+7XfvUdL3jC9U/++C8GWNf2qfYisCQBDgBK+tMaWkJNbbZJQF4vTUAHAEsTV38isAMCHKDtIEyFKAJ3BD732c8P/993/9jwdf/0m17I93/PTwyf/9wX7p7rj3wCX/j8FwcYHjKFMb9NkG9NLURgHQKshTUv8rRfx3P1KgILElBXixPQAcAJ5DUT9gmTui0CuyGg8bObVO8y0Hf8xvuGb7v8gRfynf/PKwbu/eVffHiI8vG/+bvhq1/96i75WAQNOxhGnnz+1i13WB+y/823/7ZFd7IhAi4JlP72gMtg5JQInCCg28sT0AHACHOduI5A0S0REAER2CEBfrr/F3/2oYFfP4/y5jdeDd/1/77yhfyH7/nxAZ1hCMMgGYZGDP7izz88fP/3/sQL7uSAXMS88EkeyNmgf0TAAYHaw3D+HiodAjhIpFxoSUC2VyCgA4AVoKtLEeiZgKfNCv8vHj2zVmztCfzpn/7l8K++4d8NX/tPvumFvP7n3tK+Y/WQRODnX/urL/JCjv7l1/+/w5/+yV8mtZWSCIhAHoEnT57kNZC2CMwSkMIaBLo6ALCamPTSsEYpqs8aAufn5zXNu22rsdxtapsGxk+aX/EDP3P30+af+E8/P7z33b8//N77//iFfOyjf9u0fxlPJ0AuDnNDrn7yR3/+Lnc//P3/eSCX6dakKQK2BCz2pb2tY73FY1sxfVjLyvFGQu5tLHd1AGBVcFZ2NlLTclMEuiRgMVl3CUZBjRLgL+zjZRJ51zt+Z/jWi+8f/u2//u7hR37oNcOn/tunR9vopj8C//CpfxxedZszckcO3/mb7xvIKUKO/XksjzwSuLi4MHGrdj/p7XC/lovWZZOy6srIVoLpbSx3dQBQOzEdFqEmqUMauvZOwLL2vcea6l/tZJ3aj/T6IPDO25d+foUc4b8z/9xnP9dHYDuO4vOf+/zdbwKQU4Qc7xiHQk8kYPnS3dvaXLuu1rZPTKHUViaQUfcre5refW+1280BgOWETTk8e/aMD4kIuCdgXfvuA05wkAO8i4uLBE2p7JHAP376M8Mv/+Lbhh//kde9EP67/t9423sH5L/8wX8dvvIV/Q3+W68NcvhHf/hndzklr6/72V95kW9y/0tvuh6oha3HKf9tCVivHaVrNO2sfbEghV8ldrQul1DbXpu8+thOfBwAlMZGO29juYsDgFZgr66utlOZ8nSXBFrV/tZheptot86zB//5v5X7/Oe+MHz2M58bPvLXHx+++9tfNXz9P//WF8J/N95DnIrhNIGf+rE3vMg3uacG/vrDf3NXE9QGNXK6tZ7sgQBrqnWcrEe8/ObapV1umyX08askHv1gbYnsrNsH44f6SPZiY4rEVlL7tPMW6uYPAEhEK7A1pz3eEi1/+iPQsva3TIuDO8bulmOQ7/YEPvyhjw2X3/J9w9f+D988fOP/+Z3Dn/3pB2870f9t39Do/7JvC3b//L9+6K4WqImLb/6+4UMf/Oigf/ZLoOXLCy+/2E+hy9rOOpaiu5ZOTjz46D0efJTUEaC+c9/H6npcp3VO7Xsey5s+AKDYSETLEqCYmbjoq2U/si0COQSox9a1n+OPB9040erl30M2fPnwh7//p8MbXvfW4RffcDW8+Y3Phqu3vnP45Cf/wZeT8mZxAtTAs197111NvPmNV8MbX/9rA7WyuCPqcFUCce1gv9fSEeyzdk/1gS+s7VtYx1Ljubm5GbYQz1Re9Ow0AWqW9yTq4bTW6JPN3iTWrY/lTR0AUGQIhcaEQgKWqB4mLvoi2Qg+LNGv+hCBSICaQ5au/di/10+YIHDZyqbJK8ue/eK//f7Wf/sf7n71v+c4FVs5Af6zEGrkda/55XIjarkZAqwbyNJrB3tJ9q/sJRGA4QfX0RfubUV6i2cr3Nf2k5pFYs3ynpTv07ZbbL323RwAUEhMilPCBh8pKbTYLoQwhBAGEofklB/6CLam/OQZgyLHdktdFhZ88iDkuTbWy8vLuxyGcJ/LEMrvdFieAAAQAElEQVQ+a/2wag+TudxQc0hJ7Vv4GfsOYZ712dmZRZfDHBOe4xeSyyW2oV0IoWg+MAlSRpoR+JmffNPwv/5P53fylje/bfjKl78y3BbVEG57lAziMAwPGFAb1MhbfuntdzVD7fznn/iFQf9sjwD7L9aHKWENQFgD1oiQvSSCj/jB9Rq+0Df9IiGEu5/U40suE9ogNfFEX0IIQwjTYrXPyI1zD/op7wzkCqFuiplUNIx9h3BfJ9QeUmGyuCn9Ipa1jz2k2KmEhm4OABJ8LVIBYAhhYLK4vr5+YePy9iUS4TmF9OKBLkRABF4QYGwwwR+PnxcKG7s4jifOCcwFSAj3hwEbC0vuPifA397Pr/cjb3jdrw4cAiD8TfDPVfQhApMEqBVqBnnj699695+LUE/8pwFs8CYb66EIbITAqbWQNXHptfDYl40glJuVBEqan6oVahYJIQzolNheow2+Pn369OQ7agjt9qRdHwA8vYVKQUwllee83HAQMKWnZyKwNwKMCcYGG4IeYk+NhzkB3R5i3lMM/A3ur/yPrx6+9p980/B1t/K2q3fvKXzF2oAANUQtIdTWV79606AXmRSBZQnw0pGyti+xFrLWpviyLCH1tgCB7C5Sa4V6Qje7g4Ub4CO+zu2xW43Dbg8AADsH9TDXAGZSPLynaxHYKwHGD2Oil/hz4yF22vQSf69xfO6znx9+9BWvHb7x//jO4Zv+z+8afvNtvz184u8/Nfz9rXzh81+6DTtIBjEYChlQQ9QS8o63v++2xr7zrtb+0w//3EDtDfpHBDZGgH0uLx2pbrMW8sO0VP0cPdZY7Oe0kW4vBPLiyK0V6opaz+tlOe2SeGhj6WGXBwBAIvm5oGiX20b6ItAjgZLx45lDSTy08byAeOa9hG9/+/FPDO9+5+8Nr/6pXxx++Pt/ZnjFD7z6+f+13xK9q4+9EeD/NvKVP/iau1qj5t71W+8fqMG9cVC82yZQss/lh2kl7eZIscbO6eh5pwQywqL2SmqFgy6Pe7jSeGBgGU+XBwBAyqitF6qtJrkXHehCBDZAgMlpA24mu1gTT03bZAelWETg2a+9c/j6/+Vbhz/4/T8paq9GIlBK4A//4E+Hb/jn//fd3w9QakPtRGBpAqxn7HNL+i3dV5/qC19OPdP9/gnkRFjz0ttbnVnG090BQC2cmkLLKWjpioBXAtYL/dpx1sTDZklzwtoZfNn/b/3G+4Z/960/dCevffUvDx/84EeGz33u80Phb3irnf7rgKIaoOaoPf4vA2M9UpuD/hEBxwRq17La9odoatblQzu63iSBZKepOfZhyQ2OFGvaHpky+Uo8NbVvGU93BwC1GQIuCaq1o/YisEUCtQdo3mK2iEfzwfpZ/eIXvjj81V9+ZHjzLzwbvuPbXnEnb33LO9Z3TB7smgA1GOvxF9/47K5GqdVdQ1Hwbgmwv61xzmI9pX8rO9iSbJFAus8W+y8LG+keT2ta+GI1fkwOACz+ghALG2CvOVmhvUQEREAEDglYTNiH9nSdT+DDH/rY8H998/cNP//at+Y3VgsRWIDAG1731uHym753+NAHP7ZAb+pCBPIIWKxjtQcIeR5Lu1sCGYFZ1K2FjQyXm6taxePmAMCK2JMnT6xMdWPH6nClGyAKRAREYDME+NXqH33V64bf+s3fGT76kY9vxm85ui8C1CY1+qOveu1Aze4rel/Ras/jKx/yZp6Ap5pt7cs8DWlMEbDKj8kBwJSjqc+sArL41QgrX1Jjb63XWzytee3ZvtXJYi3D8/PzWhNqv2ECn/70Z4aP/83f38nrf+5Xhx/43p+8u95wSHJ9BwT4fwX4we/7qYGajfVLLe8gdLMQa3+IU9veLBAZOknAyz7jpIMrPfBSu43fGbLoWrzTWdjIcnpC2YKthQ1cNDkAwJnawsUGDq0tvb149BbP2vWh/kVABNoT+MkffcPwtf/0W+7kLb/0G7cd6m+rG/Q3HQ7DRhhQs7F+f+I//fygf9IJ1G7Wvewl0yOWpgjcE6it/XsrdX+2f2fI8692PHuMx8v7sskBAOmsKVzLBFEsNXBr4oCDN+ktHm985Y89AeYD1a091y1Y5L/1/5mffNPwS2+6Ht7+7D13wr0t+C4fRSASoGZj/VLL1PSHPvjR+FifEwS0h5uAo0ddE6itfQs4zfdeBU6yJyxo5rZJDWNLFmYHABRuiWO0qYExluFnz54NJYcA+DJmb6v3eotnq3mQ33kELi4u8hpIuwsCX/zil4b3vfcPh3/1Dd8+vOPt7+siJgUhAr/1G79zW9PfcVfb1LiIzBMoXQO055lnKw3fBEpr3yKqJcZPiZ8wKX2no21Jny3b8L7sIR6zAwBgATqngABAG9paS65d/M5tY+2zpb3e4rFkI1t+CVxdXfl1Tp41I3BzczO86j++ZviB7/2p4Quf/2KzfmRYBNYg8IXPf2H4we/76eGVP/jq4atf/eoaLmyqTzbIuWuB9jybSrGcPUGA2qeWTzxudps+F3gHKvY/9we7vcXT4n3Z9ACAzFJAgOd6StAhoVM6Nc8YRGwq6WfODjr4Pae3lee9xbMV7vKznACTGxs+xm25FbXcEgF+GvrOd/zu8MbX/9qdvOkNV8N73/37w5e//JUthSFfRWCWADVNbVPjsd6pfcbAbOOdKrAWsCakhI9eT3u4lJil0y8BapmaXirC5d4Z6iLinRFf56ygA8M5vbWf58SDrrW/5gcAOAj4Uy/fcaOPDrqthX4oBvo97IvvCH6ic/hsq9fEw6TRSzxbzYP8TicQa5bJjQ1fektpbp3AZz/7ueH/+/c/PnzdP/2W4Z/9D/92eM+7fn/rIcl/EZgk8N53/8Hwv/yP53c1/33f9ePDZz7zuUn9vT9kTWCPdmoPx32eo7d3Voq/LwLUNLVNjbNPahEddhd9ZzAIgvcbmCDH5hTPMZHp700OAGKXJIoCpsAQrks2+rRBGBDYjPZTP2lDe/rHD4TvSKqNtfQocvydE2IjHhjl+Eob+NBuCbm+vs5xb1Q3lckcs1HjullNIE7Cc/xLa7bawUwD1Ozc2GAMIZmmd6v+tqv3DP/6679j+IP3/8nwpS9++U5uvnozBP1PBDomQI3Hev+D939g+Dff8B0DY2G3E0Fi4Myt7FVYM+K6wnfuJ5owVaNv1gT6R0yNOzdG3LXCmuolzLlYyC9CztfwOfZ9WPtxDNR8Yo+YiD8nrtgGv5Cctla69IsQQ2TAdfQtp5/YBntITlsrXfpFiKE2nhyfmh4AREcoMCR+T/2MiTk7OxsQJo3Ly8shhDAAC0m1FfXwA4nfvX/ia4rkxgHbEMIdV5jCdgnJ9fOUfgqTOZ1TtnW/nsAce57X97KchbmxwRhCQiifm5aLZr2ePv+5Lwy/89v/ZfilX7geXvvqXxk+8tcfX88Z9SwCKxL46Ef+9m4MvPmNz+7GBGNjRXc20zVrB7KGw+yb6PtwP3o476/h09J9zq2FKc+X9nmqvzl/yS9CzkO4X9+n7LV8Ru1ZSa6fBrWf22WSfuSRpHyg1Fs8B6ElXy5yAJDszYEiL/cMOAbnwe0XlwxIBL0XN3WRRIABA9skZSmJgAhkEWBeQjQ3Pcb2d3/3yeE7/u9XDD/zU296/FB3RGCHBF790784fPu3vmL427/9xA6j307Icd80tScNYd0XxO3Q3K6ne1zbbWrfT857i6eUrMsDADbODLKUoNBDP0VXOsPdb0+cWsAG/SMCImBGQHPTQ5TPfu1dw7ffvvz/3u9+YPjHT3/24UN9E4GdEmAs/P77PzB8x7e9cmCM7BSD67B5YUjdN2ned51KE+fIMTVhYsy5kRDCkFP7/GR9NCQnN8lbTjw9v1+6OwAANoMrp1bQ9150OfG00oVtK9uyKwIi8JgAc9Pex93nPvv54Y/+8L8O/Krzf/7xXxj+5mN/9xiU7ojAjgkwJhgbv/iGq7uxwpjZMQ5XoTN/p74wRMeZ97UnjTT6/KQmeJnsM7r7qKj9+6v0P/nt4rHaT7fQTpN4yFtODz2PZXcHAMDOSU7UJbHxWp+PCcCnlO1ja7ojAiKQSmDv4+5DH/zYcPlN/2F4w2vfmopMeiKwSwJvfN2v3Y2VD/7VR3cZv7ega/ZNtPUWj/yxJcDLpNeX3dpIqd/SvQttj/pf/Ss+9RSPBVBXBwAkqDSongdiKZPDdqWFf2hD1yIgAmUEet0kzNHgV5p/+Pt/Zvjd9/3R8IlPfGpOXc9FYNcEGCOMFcbM1VvfuWsWWw9ee9KtZzDN/4uLizTFjWnVvDM8rv2NBX/kbm/xxPBcHQDUFBwB9ToQiU0iAiKwXQJ7m5v4G83/6i/++u6n/j/2qtcNf/93n9xu8uS5CCxIgLHy4z/y+ruxwxhiLC3Yvbo6IKA96QEMXY4S4OVw9MHObz579uwlAQdXGsuPk+DmAMCiWHociBb/jdHFxcXjzOuOCIjAYgR6nJum4P3JB/5y+Fdf/53DW37pN2/VgmQQg0EMhiGDwa/+8juGf/m/f8fwgT/+i0H/LE/AYk+6vNfqcQ0CvdWKxTvDIZM1cnLYpydfDv1a+9rNAcDaIKz7t3hxt/LJky9WMcmOCIiATwJvu3rP8NM/9sbhPe/8veHjf/P3Pp2UVyLgnABjhzHEXw54/evvdu5tf+5ZvDTs7eC3vypIi8iiVtJ62qTW6k4rP+Mp0AHAOBeTu0+ePKmyU9u+qvMdNBbf/pOsw6/lcvzFL3xx+Lu//eTwmp9+8/CqH/q54R/+4R+X61w9iUCHBD796c/cjSXGFGPri1/4UodRKiQR2DYBi5+Yb5vAlPd9POvxME8HAI5r0+rlBTt62X2caE3aj5n0dofa7y0mr/G8/3c/MPxvX/etA78B4NVH+SUCWyTw9mfvvRtb7/+dP9qi+/JZBLolcH5+3m1sJoHJiFsCOgBomJraF8za9oehWdo6tLvla14OdTCy5Qym+a4FOo1TqdbNzc3wm2973/C617xlePbr7xo++pG/LTWldiIgAiMEGFPPfv3dw+t+9lfvxhpjbkRNt0RABETAFQE545eADgAa5oYXzNKXj9J2p8LBF73sPqajg5HHTHq7Q45V+22y+pWvfHX43Gc/P/zID//c8MoffM2gX1Fuw1lWReCLX/ji3Rh71Q/97PDZz3x+YOyJigiIwHoE2Kezv1jPA/c9y0HHBHQA0Dg5TA65Lx+tJhX9RRiPk83BCLwfP9GdnggwDnuKx0ss73rH+4d//j9dDr/9nj8chhAkYqAaaFwDjLX/9X++HBh7g/4RARFYhQD7eu0r5tDruWcCOgBYIDu8eKe+ZKLXclLhVweZuBYIezNdwBvum3FYjmYT4KDn6upqUO1noxtt8MUvfml492/93vCmN14Nb3rDs+GvP/w3o3q6KQIiYEvgI3/98bsx9wtv+PW7QwDGom0PsiYCIjBFgH3Es2fPplT0DAIS1wR0ALBQei4uLoapl0wmKLN+2AAAEABJREFUFF5Q0GvtEhPXlC+t+/doH+4wQTz6J5/qCXAIoNqv54iFz37288P3/fsfH370Fa/jq0QERGBhAj/2ytffjsGfGD7zmc8t3LO6E4F9Eoj7dPYR+ySQF7W0fRPo7gCAgbmU5KaWl0x+As+LPi+aCNcIPvOCkmuzVD/6gg9RmNxaS6m/h+1glSKHbVKuYYKQo1QmKXZTdFrEk9JvK52UeCx0Svw/zjG5nqv7kn56bfP26/cO3/gN3zn8/vv/ZPjyl748hNtAJYM4DIMYDMNiDBh7f/D+Dwzf9C++a3j7s/cM+scnAYt1zsqGF0Jz623qc4t4Uvpij1CzT7fKH3YsYl7IxoC/c7KULxb9zMVi+dzC3zkb3R0AnJ2dDUtJCGHgZQKZA334/OnTpwNtEK6RYaV/8CGKZfGessVkWxsq/3+cKTkOoSw/+JfKZOl4qBV8w0evkpqflBzO6YQQhhDu85zLA45RTtUr99HJtd2z/p/80V8MP/fqXxk++tcf7zlMxSYC7gnw/w7AWPzA7Zh07+xOHZxbw5Z6fnl56SYDrKmsrTWCDYuAUnygL/ZeOf1hlzaIZY5DCAM28SnHn6V1r6+vk97FQthGPPCzzOOcrRDK9rX4mSrdHQCkBm6lx6SKeB+MVvFuzQ65QXrJDy/XPcVjVU8wCaH9hGnlr+yIgAiIgAiIgAj0R4D9Ji947NcQ6wixGfc8HDRY2zexl2Gkt3gyQp9UjTmmniYVCx/qAKAQ3HEzEsWp3PF9ffdBgPyEEIYeJkuI9hYPMVkIXFpNlhb+bdnGJz/5D8MrfuA1w5vfeL3lMOS7CHRHgDH5w9//6uGTn/hUd7EpIBHYEgH2H+xDlvKZgwaP+9rS+IkHhqXte2xHPbVgogMAw2rhFOvp06eGFmXKmkCLQWTtY4693uLJif2UbqvJ8lR/e7j/Nx/7+7u/cfwnf/QNA38HwB5iVowisBUCv/G23x5+8kffOLzzHe8fGKtb8Vt+ikBPBNiPsf9YOiZemp0dAlQhgGFP8VTBeN4YJtTX868mHzoAMMH40giHANZJemldV7UEyE9PhzS9xVOb39ieyVILSKRR//lLv3A9fPO//J7hz//sw7fGgmQQg0EMhsERg7/48w8P3/Kvvnd48xufDfpHBERgWQIXFxcD+45le33Z28Vt/y+/rX1V339v8dQTGe7qy3JfqwMAi6wc2VhzEjhyRV9HCPDSbDmIRrpY9FZv8VjB0wJST/Ljf/P3w3/64dcOv/D6Xx8++JcfGb7w+S/WG5UFERABcwKMTcbom37+2d2YZeyadyKDIiACLgm42gcaEOotHgMkdyYs97U6ALhDav9HTy+Y9nRk0ZqA6u0xURaQx3d1J4cALxE/8kOvHd5+/ds5zaQrAiKwEoG3X793eNV//Dn9pwAr8Ve3+yTg4Qd/li+HNVm0attbPBZc2Nda7fd1AGCRkREbKtwRKI5u9ZYfqwnBUYpMXBEXE4wyIgIiIAIiIAIiMELAy36Sl8MR95a+ZdZfb/FYgbHa1+oAwCojsrMpAr1NLL3Fs6li6tTZd/7m7w6vffVbBv72/05DVFgi0CUBxixjlzHcZYAKSgREYJSA1cvhqPGkm7ZKFvH09Pd+QdeCCXbcHAD0lqDe4qFYepLz83OTcLyc/JoE06ERi4lyb2P5S1/68sD/ndjPv/bXhu//np8a+M8AOiyNBiHd3NqUDENrBreY9e8kgb/9+CeGH/jenxpe/3NvvRvLjOnJBnooAgsS6G1N9RTP6r4sWEd77coqx24OAEjkkydP+OhCrBLUBYyDIPTCfABDl5shUDs3WR04LQHsTz/wl8O/+Rf/fvjVX37HbXf62+6H0b/pfRj5R6yGUVbWXIaRf6z76MMeY/hff8N3DX/yx38xwky3RGB5ArVr6fIez/foZb/vYZ8xT2t5DfLTU91ZvUe5OgCwCmr58nrcIwX3+K7uwMXDQLSqNS/xqLLaEqitl9r2baN7af297/qD4XWv+dXh19/yzuFDf/XRlw90JQIisDkCH/7gx+7G8ut/9q3De975+5vzXw73R4A9U39RDYOHfa0Drm5d6KXuLA95XB0AkKAeBpFlgtyOpgrH1n4Zss7P2vFUpEJNEwnUzE3W9ZbocpHaz/zkLw7f910/Mfy3//bpovZ9Nzr81fa+I91edMrNqZx96lP/eDemGdundHRfBJYi0Ot+ae242Ges7cMwLFVF+f30wsYyDlcHAKTUMjjsLS0ahPPEeZmC07ymvQb9WtfYmvHYE5LFUwRK/j4BDjSt6+2Uf7rfikB8uWxlv2O7Bb9Jf3PbJhLnM58OrZD8lmohAiLQjsDV1VU74ytbXnMf6GafsXIO5rrfev3x/jIXY85zdwcADKKtJonkaLOfVn5wgleato1Wy0lyjXhsqMhKDoGcuallveX4nKL7Nx/7++FX3vwbw1/95UdS1HekoxfJ4mTfvshbtC3PQHnLYr8dN/zgX33sbowz1h27Kdc6JcDayf6+0/DuwlpjH+hpn3EHwfEf1N/S7x1WOPCb+rKyhx13BwA4RZJubm4GAub7FgRfLy4utuCqGx/hBbclHKKfkp/g5vi2ZDw5fknXjkDq3MSiTL2hb9d7O0vv/50/Hv73f/Ztw2++7X3tOtmcZYMXSF6C9yoZ+YZ0lBfNDrjd/VbA7fe7z1uFqMvn7deJf+c1Jhp39eg3rt87/G9f923D777vj7qKS8H4JsBauIeX/5iFJfeBsHW0z4gIXH+SH+qRdwLXjj53jhzjL34/v2X24fIAIEZHwCQJifc8fcbEcFiBr55824ovcIMfOUYs/V4jPy3jsWQjW3UEyDP1ikRL1BvCZM2iHO97/vzqV786/Pirfn545Q/87PAPn/rH4Stf/soif4/77buc835u8vy7DSiMya2VsFW5DSiEW++byDDcmr39YxiGcPvvKRkGHj+UI93h4J/bRw91b5+FITOXd22GETvbvvfVr3z1dox/+m6sM+a/+tWbQf+IQAsCrINIXAu3chBuxYL9Qct97SFbK5/r7WzHAvVIjti/IR49P8wx/rbwsekBAJtgHI8CcCQnEPQRBlOK5Ng+pUtBpPQV4ztlZ+w+bZDIJIQwhNCHEBO5QsZin7pHGySFe6pO5DzV79iz2C6EMMSYxvSm7hELkuIri+SUra09Y+JKiXtOxyLuy8vL2fEVc0y+cvpEH4lxUDcI9nLsrKl7c/sOwE/9r3/93cOXv/TlNV1x1PctlBxvwinlkw8eNUDTldw6c/vvMCePAkm+cW+ZPyebzCrctn6u8/zj9sbYv5k5HTPRwT0O+N529Z7hN65/e/jq7eHflkKKcyvzawhhCKGtsHZY8InrQ80na2qtL9io8SGnLblCyFWO37EN7UKYzu/Z2VmO6VV02R8gOezmdGGEwCgnqNiGdiFMsy2q/RxnnOiSG2SOeXxu4Tb7/Whv6jPmy6LPUzaaHABExxmg19fXQ5TL2804QgEC/ZRTvd4nZpggkUlPsRIT+UVCCAPxbik+/A0hDDE/+B5jCmF78eC/ZJ5AzPFW63Y+whSNcKskuYVw+28ih9s54fYt5ECf5fS5hNvP589DCLdqh/I1t98fynCn/zXDqc9w+3wtOeUT98d9CrdxpMrXDOF5bNh7JMMJO9w/lHD/c/6b23vIrQPDcHv9UIbbf27tPbq/x3u3KDby7/G6zHy9EdflZiKBsXeGxKZSmyGwFNsZN/TYIYGvsfaJyfrwBWrMPhM4m210x573di8OQGLuLbapeIiXw54pHS/P8BN/p/zhOXrkc0pPz/5/9t4DXI7rOhP8T72ASBKRBCPAABJgzkGiCICUSYnKEqlky/ZYwWN7xmFmPZ7Z8Q6I+T6PZ2dnxmOvveMcJFu2cqAkS7ZEAJKtSEoURTGDyCRBggCInF7X/v+tqu7qfv06Vr+urr6F+uuee+655577VzzV/RqDzYD28zBcmx7+/hNY9x9/H4/+8OnB3mH9iF45Y3lcVpiAJnllWaRglrRVSjODWXtgB67t9THrwh7t9wXHS2A2uX/SNlVpZqi0AWAVVTopEC0pMVJwm9KFrPp1agZ0zv/n3/wD/JDXgKmt+t+i+62ux/2PxEfQKwZ0r22WM/Rq7KL79dwWfQ93N79MXwDoYGvnYi1b9eluCvnvrTnqpUf+I80+Qs1bN/HsPWfnsZ39o/nIPrvRC+ipAFMahmvTU09sxh/9vx/DM09vK8Aey2IKLaSNSjKF8nCscC1XE0GJayJDBgR1ZirZwCJRw+moqCnNjE0VsILpAQBDeWEYECBdA1RsaBRMhk3ScQg9gdSCXSFnrqRNUlJ0epVCWq+6IJ1Kov7erK+l+VCtm57Z7s79Jx7fnNt567lB99vcBugD65oBPUvpXtu1I+9gEgOe20mUeEUNA7r11qg6r3ZyIqtPkT9R1Uk47DcxzV83886PrN711P7RMdjOCHmeTzvz6JVtUfzquCjytcntJyVMHoAxMWybB3bgCsLMYEa4JJe3VcqgbEEAJb4OFgCuHlCXhrl6wLY0or5pu4qctstWNoYYOJTHt2jcZJyynvG2KoO2cHxorhEiXYBKaSkODSQF6lMBAAPKdTNEdQB042SrkVWfhE72Nf1O8lMAHaeQx1X3Zd1n8xibjyk7BnSPzc6b95QwoPPHc5uw4cupGNBtc6q2tvQ64NrqkDLupm/KTe5EzcufhNFu0c08j8lUp/snr/OJ2O7rtlCD6xwu1IQ4maNHjuHTH/8HfOWL/8SaX1tmQAlg2ZgVrko6LdpAhTYGLkxOzSkMkJyC6oKZsQhimLNjhas1ROD6NbYx67Rd8UR9y+MEUd1s6pIBu/jNaEP7pJ6UZsb2IIZkY5Oxngbb1Zcwo55VGkU24CId1aiCKmzTmhKdjXQeDRn4yhe/4a4FuiY0NJzmxk7vy9Mcph+uCwaKeG/tgo5Mu/rzJ1M6C+tMt9hMJtfNAeeTqUx2Qe6d5O2C32083fbP/Q7rKMBidSriteno0WP4xN9+BV/43IZi7axeziadXCq7jOtmFLi6oSmbsUKYGcwCmKk0ICWbk9UmGMwSqJ4tAo41FYxtEZLxk5Ix8BN7S1C2oz4tx+2IS1PiLpTnQ3+sI0a5nfaIYWwTnA37IQH1Tk5KpweczslGGdGieiQBVCNZKPOz/qTmyzoMfPHzG/Hxj34ZR44crdPaH9V9993Xn4H9qNPKQDc5w7QGOmCD+fNnwHZYH8MNshjbH3D1WfQXuGpelExVa/pb6/YbCXmbT3/ZjEf3hWdg4BhokiYykaxMiRWuqptJiGAWwIwyYUxuzQzG5NXBUl+pp2xOT3vaJV+rD4IRBHFd/RO5XtmsvV6fWl21j8rYZTsLGH8Ud1nH+NL9rMZGbQnUx8m0Kctxf8SlkQdQFpwt6ypVR1k2ICDbrMMMZYCLq7PUKlllLdilVhXVm+zzyMhv+8BAt/flPoTshxQIDUQAABAASURBVGyTAZ8ztEmYN/cM9IAB3Vq7dpvFBTsLH11PxDsYKgaySOD9cVt9yGRZW7VqVZbuOvZVpIeVH//oGXz4zz+P7dte6JiPoeroEkhtYqiAwcxIQwSzqAQzVTPdUg2m0mEExiRXdWOS72AjCAhL6q4MaCfbBmAf9ROMcj2oLY16NtKlbQLGGcifi6MyvnSC7Muosanoq+OH7Eboi3Cy6gRYN/IBQTKBkQCuLp2DIaobzNgm6AVA0mYGCIhLJwNISlQvPtWv5qO2toPXgo/8xf3QtaG2rR/1LO7L/Yg772Pm6XeY/HNT744Wz23vuC2aZ95dizalfMzHn4T194PnpT4v3Wpzkix3O41c9s/Tg1OnBE1MlLB//yF87R++jd9a+4d4+smtdMUECh5oygG4kCeXYBrMjHXdOq0iU2dKVCFdAKNcwQhQUzcmw+nkOlCdCW5UjsCsAtk50Eb9IgQInH1cGkvCYgQsGyLuaywt9htwzARGuayP2422Af2aIJmQLsIIpzgVyIdsR6ISTPotlit92UY9aOdggeMMTPxNOle3SGepEpIBSAcuKgVQn0KYkuFlIMXB009tc9eEr37lW3jllYPQtQJ+yYSBrO7LRbgHpQkt2nzSc/OyZ2BQGOBdtvtQi/QJWfdseA+egfYYyOJmmIWP9qKuZ52trohzypah1r3tfmkv/p/f+jN84qNfbr1T4S1DzlBgUW9VDpno03KsM4uVLCxOUJWsmlHBpNXJcRkoibYoQQ5inUmXQG02CmMZCNQHMWSXyFEZQDZl2xr7yGYEDUv1SSMeS32M8QWCaZwASd1oIwQsBckRZDNCO0EyMULQhzlQ75J7luxb1lEGoTpoJyQvBsD+Dk5v9G0AXwYgIPkqjWUCJIJK6rWmRFXrQ/teqN86bFpdG3SN0LWin3PPKmnu5xySsbO6h2XhJwsfyby6LfMSy9q1a7udiu/vGRhYBnQ77Tp4nczdXrT9S4Sud4N3MMAMdHv+6Bzs+/QzDiAvcyrCtUm/8v39Bx/DU09uyXgvDZk7izNLV3DDuhlvo640mBnApNXMKAcUA1cadUEMY9IbEObqI7QZgbEunZCWA2cTsD2gXQwboRyh2jbSBfQ1lV5tdVH2qTEqfurZyncE2Qoj5ficfiRw8Rljr48RZ0+jSuleEARIdOonuQpmIJkEEJXpOgBW4w3c4uqUkpKiX6dm4OmntkLXiH7/IGARrrcJy1nNRffCIj0jZDGfhGNfegY8A50xwDtuZx1re3VzofNv4WrZ9PVhY6Db80c31H5zlvX4mlO3Dz3dxlSEa1OpVMIEEYb+0872jwdljwJgZjBwYQlJrJjxFsq6mcHMqA5YViNQIswE2+LE3FRPyWoXpFcpSI4wgoBjCBaXak/D6C9dT+Sy/RT9Erty6ezi8WKfzrfTB5Cdq7MtKmkreaTSJr25uQYwJvUJUJalF0bYHgDsKxs6Z5068gLC+aFvCGbklUjLrMLpATgZ0ZKWI020lT6S/LYBA7pG6E8AdM1oYNbTpjxc97OYYNb3jm6fEbKYU5Y+uplPFnFo//Q7hizm4X14BjplgHfgTrtW9+v0oq0HfH8SVnPpa8PHgM4f3ZA6mXlOzp9OQm/aZ8OGDU1temVQlGvT33/hG/i//t3v4tlndvSKqqHyq1zSjFsHwBXRhrIRAZIE1pjMKok1Jq9CwDKgTgl9QNkoCwFLQXIC1WWnupNpI9nBRhCkYCm5rHf2QSUWo1yDgPUE5uIJoLHkT/WAOkGymdrogzrJTlcljyDQmEr2VaotRhCX5vQjwEgAJf5GPTtRDqAyggGBwWLA2bBuBierdAAXi1EpAOkwafGvvyZRMkmxedNO/Kff+D186f6vT2qbTsV99903ncP1ZKys56BnBN2T2g1WzxVZx9JuDPXsO51PPV+d6DR+J/18H89AURjgXTe7qehhvZ0LlGzVJ7sIvCfPwOAyoJu0btbtzGD9+vXtmPfQtneu+zHHIl2bnnp8C/QDX3v3vNK7nTSQnusnipOm4szchk0qDbMXnoXFK28kbsDiFcL1OP2SG3DGJddjySXX4YyLieXX4gzizIuuxZnLr8GZFxEXXoOzHK7G2SzPufBqnOPKa3Au5XMvuBrnEUuF86/G0guuwbIY57O84PxrIFzIMsFFlJcTFy27BsuJi4lLiBUO12LF0muwMsalLC+rwaWyO/9qrFh2NS5heTHHXk5cRFxw4VU4/6KrsExYfhXOu+hKnLf8Spx78ZU4++IrcNYlV+KsFVdgCXHGystx+qWXY/HKy7DoUuFyLLjsMsy//FLMI04jTr3iUpxyZYQ5V67E7KsvJVZi5tXENSsxfu1KjF2/EqPECBHcsBLBTSsR3rwSpVsiTLzqUpx89aU4cWuE0rmLyvuFQrxqP8Viw6JVu4ZOCtOoa4SuFbpm9HNSSs7avRf2M97asXt1z9Lzsu5NteNNVZetniumau+3vt35ZBWvji0dY1n58348A4PIQKYvAESATmidXJIbQRcm2Tay8W2egWFjQDfrVs8fPWTk5ibWwx2lOWquumb0cJiya41TvGuTEh0PuE+HEx7AJZGnKPVJM/uYxe0qLWCCewMue+ev4PJ7iXuIt/8yrnj7v8KVb/slXPWWX8TVb/4FXPOmf4lr3/ghXPeGn8f1d3+I+CCuf/0HccPrP+Bw0+vej5vvej9uuevniPfjVXe+H7eyfivL237i/VjFcjVLYQ3L21/7AbyWuJO4K8br7/gAXn/7B3A38UbKwpsov3nNB/E24u2rP4h3rPkQ3rH6Q7iHuHfVh/Cu2z6E9xDvJd7D+jtlwz5vY/+3vPb9ePNrfw5vvPPn8Pq7/gXufN3P4rXEHXf/LNa84Wex+o0/i9e86Wfwqre8D7e89X248W3vw/XEtW//KVz5jvfi8nveg8vufS8uvfc9WPHOd2P5u96NC97zLix777uw9CffiXN+6l6c8757ceZP34vTf/ZeLPoX92DBzxHvvwfzPngPTv35ezD7F+7BjF+6B2P/mvjle2G/eg9K//YenPz1e3H8N+7Fsf/zXhz5zXfi8P9FrH0XXwRcBmi/gPtIpQAtrEvXEK3ateKrSDbipb9o9V7Y3yirR9e9Q/eq1atXVzdkWNO9qZVnBNnINsOhe+JKMSrWnjiv41T7R8dWnSav8gwMFQOZvwAQezq5dEILqqeRXCB10qf1XvYMeAYiBnT+6G8xm50/vXzIiCJpfdtrS81V14x6nGQ1tr82ZcVkQf2UE0sgCEYxMj4TI2PE+AzKMcZYJpBe8vg47SL9qOqEK0dnQKXD6LiTR6p0UfsY7ceoHxsbx1gsq4/TUT9O3ThL1culbGNdoldbYutktielbMYYg4Pzx7HY7sZjXeON0mcaI5yXq7McGR8jB5onofqMuKQcUA5mjMGVqtM2YGnUm0ohJYMyaG9JOXMccBhzZUg5nDmGqBxHODYSHXCmwm3gcn5wiauU/DqADDS6F+ZpOul7h+5VvY5NvOheKNSOlcQim9q2vNYVq+Yi9CJGcSLfeq6ajv3Tizl4n56BrBnoyQsABakTWtAJpxNPb90k6yHen4BiaPqQXPy0H7rB9EXc+Ug6vgQde83Q+SiVnq2OJbtKr9Ykxa9zRvtM548gPzk8f1qbUAZWCSfiRXyIm24gH4L8FY3bQ4eO4OGHnsD2bS9kwLx3ETHQYUZZp1vqfQJd1zGYUsuGOmt9D3UMp1PlgtKG0OomTSEdQ0013TRJrrENk7rzW2OdtNWofbU5A7pm/ODBx6FrSHPr3lsk131dq4VurvlZ9VUcCfpx7xAngu5dmpNikdyPWJIjQGMrJiHRtVqqj6A5aC6aU7eQHyGJq9VYsrTT2ILmpjJL38PgS5yJuzwgC75bnY/sshivkY+evQBID6odN8xJS5qLfsjiXvugG8hHP2JvdUydLIpxzZo1ENatW4dmaNV3I7tmYyTtisnMoH3QyF+9NvXR3IR67f3X9ScC8SFuuoF8CP2ZQW9H3b71efzn3/z/8PlPPeA+EFU+5IHmXJAknqpT28XtaGWhbV0zDVA1gqxkbNRGkKaTH64zdawD6RPUae6RiiOW56rHjbguHUVOluOWBcqtr0r+SxYiDELnJu0y8ehLRNwAbZX3f3q9u3Zs2/I88rToWi10c83Pqq/iSNBvjjQnxdKPOJJnLzOrevYyi553FFu7cWku6tct5Edod/ws7BNe9Own6FlQpVnESxZjDIMP8ZYXZMF3q3OZjmNFd+Qs5uR9eAb6xoBuEjpZNm7c2LcYWh143bp16NcNqdUY27bzHXLJwIkTJ7H7pb04ePBwLuMbxKCihFLbDqNnVzNzyRjc1oApSqPeMKgLIy/Ps8EcaMZpRgaSI4nbqgrrk1cLgQi05coaKotTVKpeaosBXTN07dA1pK2O3nioGFCS2+jZS887gp7RhokYPeM148XMIP6GiRc/1/YZ0PmzevXq9ju20MO/AGiBJG+SXwZ0YugEyW+EkyPTiwqz4jygTp6h1/Sbgeefewmbnt6OY8eO9zuUwozvzli36WZKiYOkbOarVbuKH+bFlUpfJcbe6nWOptCbAGfvKmhlCUJzLwGgvuBiMVgg0cEvnTCga8emp7dB15JO+vs+xWZASb2S3FZmqWc0Pau1YjvoNpqnnvFamYf48y8BWmFquG10PJnp5pYtD/4FQLZ8em/TyIBuQDoxpnHITIfSjSJTh/1x5kfNIQOf+cRX8dvr/tg/vOdo35glN/CkzDa4kO4EFgVZO+Wp034FoS2jabzw/G781//8J/gsryUZufRuCsKAklYl9e1MR89qemZrp8+g2Wp+mmc7ceslQDv23nZ4Gcg6Z/AvAIb3WBrometC2+4NKG8T1o1CN9K8xdVePN46jwzsfmkftm5+DsePnchjeDmJqdVEMbFTKSj8pJTcOmwAP5XO/0sFi3eASsIFzDLWNi5atWvspYitunboGvLSi3uLOD0/py4Y6PS5Rc9snfbtItxp6drNM2nWid20TNgPMu0MKGfQcZbVwP4FQFZMej+egQ4YGPi3vx3M2XfpHQPHjh7HcztexP5XDnIQJTcecEl3PR7ApZ6+Vkcz50OlYDh59BCO7n0RR/a9hCN7X8JRlkf37caRVyIc3f8yjh/eD4QhexoR9dNWCLk5cfwIDh/Yg0NEbXmQuggv4+CBl3Egxn6WabxyYDeEfXEpWdi3fzekS7CX7Qn2UK7GSynbl+H6Mv5XhFf28Fh62eHAKy/jIOsJDu3bg8Nl7CUHewiVwh4c27vX4fjefRBO7NkH4eSeVyBMsBw5eAIzj48Qo8QIZh0fxexjo5hzdAyzj45gZN8R4MVXYDGCXftQxguUn9+L4NBR8muYvEjXDOrVzGa42/fvP4Sd23dB1xax5THcDCgBUSLfKQvq32nfPPfrhhMldkV9MZLnfTaIsXVznNXON6hV+LpnYBAYyPJZ5osgAAAQAElEQVQk6Pd8B/nC32/u/PjVDDz5xBb8+3/zO/jql79V3eBrmTKw+4mH8Ngnfx+Pf+oP8Phn/jce++wf4rHP/zEeu/9P8eMv/Tke/dJfYPuDX8Po8RMYDYEghsVRsIrntz6G7z/wUTz0wN/gwfV/g+898Nf4zvqP4FsPfBjfJP6J+AbxdWLjA3+F9V/7Szzwtb/AV7/25/jHr/0ZvhLj77/2p/gS8QXi/q/9CT5PfPaBP8GnH/hjfGr9H+FTD/wRPsny48THiL/d+Ef4KPE3xEc3/CE+tv6P8cmv/gk+9Y9/is/+w5/gc//wp7j/K/T55T/DP/z9n+OrnMsDX/wLrP/CX2Ij8U/3/xW+9bm/xnc++zf4LvHQZz6Khz/9t/jRpz6Oxz79cTzxqU/gyU99Ck9/8pN49hOfxraPfwY7PvZZ7PzY5/DCx+/Hro/dj91/dz/2fvSLOOWfn8OKbQtx6dYFuHzLQlz57EJcu2kRrn9mMa57fB7mf/yHCP7gfoz97v2Y8T8/h5n//bOY/d8+g7m//Wmc8lufwtzf+iTG/vmJmFUWIeHXTBnQtUTXlKee2JKpX+9sOBlQslu0mftnuKLt0XzPJ6vjzb8AyPd+9tHVYeC+++6rox1c1QDPZ3BJL2jkBw8cwiM/eBL6+92CTjEX0zq+fw8ObH8K+7c/jf07iJ3PYL/w3Ca88tyzDkf27IKVwnLyr5utXgAkOHboFex9cSv27tqKPcKLW/Dyrgi7Kb/04ma8tIt4YTNeJHYRL7ywCS/sIlg+TzxH+TmWO194BhE2YQdlYfsLT2M75W27nsG2XU87bGUpbGGZYCvtthHO/vlnsOP5TdhJPMe5PO/wLF7Y+Sx2xXhxx2bsJl4m9mzfgj07tmDfjq14ZbuwjZxsw4FtxPbtOLhtOw5v3YEj22JQPrp1J45tfQ4ntjyHsZeO4LRD48QMzDs0A/OJBQdmYCGxYP84xrfvgz39HIKndmLkSeIJ4vGdGH18B0Yf246xH29H8NJ+gIm//keAXBwcBQtC1xJdU/bvP1iwmfnpdMJAFslHFj46ib1XfbKYj38O7NXeKZ7fLI43saJnEpUenoGBYcD/vVTvdlV73NaPIwsf9T17rWegzwww0SxH4GS3KatcJhpWdLrBGlunApvilX246k8G5COUj7guWUBYgsqQLxVcqXpJuskohRMosb3E9lYR0t5BfSgn/cPSBMeNx2Cbs2F7mMiKR2DMYVJSZidOhZNwMqAEXTwoWXeIv7gvXT2IO8SL+kp0dnQJ/fq/FE6WEEHtkeS3ngHPQC8YKOIn+L3gyfv0DOSdgfQ9Nu+x+vg8A4VkIE8Jc1uxFHJv+EkNPQNKKlsgocpMFUK5btJVyahusGWwPflTAJVqB3Vco1xZFXaWj5CbkEl2yZUh20suoZdOKMXJd0k2lMslk/WSkn/pBMkO6j9BHxFC6iKUyr7lsyR/aqOfUGA9FCTTX5iG9HUA2tApV86M8VOovAjgCwKjTgl9AnFRBXKQcJbYJGVMES3km8WUq9qFKQ18g2fAM+AZ8Ax4BgaOAf8NgIHbZT7grBhQkrpq1aqs3PXdT56++iVuWyVkKrs8zWeqGIuof+h7j2HjAw/i6NFjRZxeD+bkUvDmfsv/fR9N4y5MLcEPsFFeqHe6soICFVQjSWYDZq8VOWpnZhwLNGZ7yOSY6b7TqYygJJ3tcVsI1UtQsh4yAafEHJtbyQ5hTZ1tTMpLDaDEXv6qbDheue780o90KTlkQh/Sb0g9B+V0NHYUq+pOz9lwatpW4OzhKExzkpZd0g8udMdtZWXdQjEbQdtKYyLV1yatlbJVu0qPYZSOHj3uri26xgzj/P2cPQOeAc9A0RjQ/bZoc/LzGQIGipJkrl27Nnd7q8WY6sbdTd+6Dr2yZQb+7iNfwu/+97/Gvn0HASWtHk14AKbkCUwME/7ApUpWndBKMxX1YMx6059sm0tcEX0VXjJAC27iNc6JqWRjUmGpJJppNW25Zb1EUELIRDyUTJQkuxcDoXsxUJK1dDHU3irksySfTOxL6u98hdF4bgx6lz4B41efMuI6O1DiSl+cFIVoFWWCapM44dTLnNHAtasU2JbUWa1aE3/gfjMCWpJ9FpdmBkwCMFlXz264da+8chC/9z/+Bn/74S/BL54Bz4BnwDMw+Az4FwCDvw+Hcgb6pLoI3wLI44uM1mKqf9h107e+R6/1DPSRASadbnQlsYIq0gmJzARZayXJVaOASrLPqkteU2WUIFMB9WTp/LOksyiZThJtJt9KxvVpe5J0sx5Sdgk6y5B93af17uv7JZRK+qq/ygihsylxyAjqV4tQPomSfKTsnV/qk/aqUnbpNsbBwTkOY3ZyXGpajF9f/wdLTpHchGBazRJ1oRcBapetA7iERGp17an6lGJNvyntfINnwDPgGfAMeAaGgAH/AmAIdnJRp5jV38H0i5/169f3a+im4zaNrY4H/+l/HVK8asAZYObIVZOIC4qxpASXtWiNdeVMFS651Q22GmH5TwKi5DWVIIMLfYYC/bhSspLscskEngm0kveovQQl6KGzieSorSKrHiF0ts6eSbvKSaCfsi6WXcIfy65NsTCGUJDMNhAhZQ6ApKTAlbzQjgLfckjWHCvQS5FqflDFj9rdSwN2JSXsyFXjEJFeDdIRU600sanavN4z4BnwDHgGPANDyIDuvUM4bT/lojCgh81B/CaAEmx9iyGv+0GxNUroa+PWfPyn/7Ws+Hq+GVBaKDSLkhlkbMK8M5EqpZQp6JoUJbxgMmspACN0NUJb3XgNUU7sbJndhjFcnTZspUgt5RAlWiupD2lVIkLm2ixd4l2K5TC2L6VKyTGU9NNXKYbiDF3/pB9LJush20PpaR9OkmUT+UNsA/UhQHvQvlJysqoLamfVtatOKIFXgh/wVUnEC8iVYCyJ0Nw3AzhZliEBUhISKmvAquxUCMaNwILeta0HWQj12rzOM+AZ8Ax4BjwDxWUgKO7U/MyGhQF9E6CdZLWfvOhlhR6qlWD3M45WxlZCr1jrcFvurvko+R+E+ZSDLpjw4x89g//467+Lb3/zkYLNLJ/TYe4aJaEMT7JAkWuSnKokXEaqkk1clewq3XRQpwS003mWJMdMsSkqyVbfCGpX4g6+CJAcKvlmP+lC+qn0ifqFapc+DdqHri6bBOzpbFWnXLah7GzjMtHHSX7kh7E5G76cUCmb2kTf1SM7TgoRUE7mo5cAoUvSI15QvdBv0kels6GFShbRmtioFnIjsGA4zq9Ej2wY+PY3f8hrze/h0Ueeycah9+IZ8Ax4BjwDfWHAvwCoQ7sSyixQx3VfVFnMRT6yCF5+mqGTcdLJqhJWJaZ5gpJkQXPvZH797DOZ21XQXATNZ/Xq1f0Mb+jH3r7tBffjXE8/uXXoueg9AcouBY6kxFNZJsE0mcktdZS1VeX4kYN46flNOHpon0t400mr5Dlz5mHh6edhbGwGzelT/hLIj0vM6Vk6V4/kJPlWqaQ4TNvRNoyBlD50MhN1vkDgYAyR48knQa/xtgTZgbagjwjS0cLV2Z9lSERtib5SJno65DAcw9lGwynZl16l5rxo0VLMnTO/KkkXL3pRcoScvfjCMzh29KDjjh6ilS4rY7BC/+oTNWpLXaqQ6JEdA888tQ0f/fAXsX3b89k57ZOnDRs2YEOX6FPoPRu2FT6yGHy6xski1un00QovzWymM97pGCtPz/HTMd/pHKOnLwDuu+8+rF69GmZWhnTTOcFOxtq4cSPWrFnTFdatW9fJ0D3pk6f5iJdm3JqZO246OVbUR9iwYQM25AirV692c+rJDp4mp/fxfBY2bNjg5rKac5qmoXM5jI4vcWBWfX27jzxNd8DGAT2ATDlgLpn4Q7xU6mws60ImqSFrBFeXoDJX3vPSdnzna3+NXduedF/914/apXHO0stw3S1vw6mnLWbcriN9cHWiNpJZuoScDpU9M+F1/ssl9ZJTn8zD2YdIJ+qscKWOn8i7v91PlaDsID+E+iVgpyiRp410rHBVTHVAGzZyZUxxPPqfEJTwCwpfyb3K005djBtuejvOPe9ypDlJ5F07nsC3138Ye1/aRn8hjP6M/stgnJV9AfJHpHRJmy/JCxDxA2RWYgCX5HqdXLObPYe00m5mMDPomi8MIC1IeDGzlp55s5hjq8+BZhG3WYyZdx9ZPKfrmJWfvM+1nfh0XukYzQPaiXsQbHvyAkA7zMygk7z2YJTOzNwFcxAI8jH2hwEdN/5Y6Q/3zUYd9nbdiFavXu0elnScpvnQMSvoGpjW9142DuEBtMsBuLTQJwRc8goulBGqD6hjhSu0sGSKzYQ1qkycPI7DB/dh4sSxSVEp0Z0xNhOzZp2KIBiN+rC/S7hBgWtZjtzRRkoVHMWJLNnGvJfbRE8d26SrRdktrWmiajWoTPpEY8unwAb2kbHaqWGzxqGeCq5UUXY2LLlKdJAssOL4oyzmRjjn2Zy7OBAX0iXQQ8nE8WMxdyfIMTuzH7eVVfwnOpWCYzkxib3JzunjepUs23p6r0MVT7V8qFU6DMyi63GSHNVes7OYhK75gsbJwt90+Gh0H5uO8VsdQ7ya+ZyhVb68nWegVQZ0r23VtiU7XQB1wjYzlo1sm9n5ds+AP1ZydQwMdTB6aEoeJBsRoWPWzCD7RnbdtOkT2R3bdmH71hf4Aa7LgLpxN6R9lcgIzaYf26RppqzklwUT4jgHVoWZMtNjKuTTKarSKd10BSXEzmtkIuMIru5aIh+uTpGl9nli5MamTnXp3ZiqEGmZVbfGpk5miHQYiVNuNUDcKP9OpI6rE+XDyW5DlcpkEJUC1W6VTGhWbt5MzBNZXAiuTuNyKXuiHKjkBLTT+A6SE9BvIjYuk1EaW/nWyQyUSqG75ujaUz4uJpvlRrOaL2t1PZ6OgDSOxuvldT+LeejZu5X7WBZjZeVD3CrurPx5P56BYWdA993MONDJqZO0VYeyVZ9W7b3d8DLgj5W87PvhjUMPdXpoaoeBdu3b8a0H8T/7o0/jj37/Ezh+7EQ7Xb1t2wwo80x3Yl0Jr1Qqhfjv611SxGaXuEovyI6Ikl8KXKMUNOTLgZC1BK4X81qm8FKxRWvkItFFDW6cyJJbWamvbNju1kiWnetPXfWbCirUUAX6kToqaF6pyA/VGiRCuUKBPrhS4Mou3DqbZL4qIx0bZUgkn/xLr3ZBchm0YQBwtDLpdLLT0UIlCzdxuiyXiU6lR08YOHH8JP7oDz6BP/3DT2FiotSTMbJyqufLXnzi3yg+jadxG9n0s02x6XmqnzF0OrbiVvyd9vf9PAOegQoDmb0A0Empk7PiujVJffRg3Zq1txpmBvyxkoO9P8QhdJrM6xOhXtCmhOz5nS9h5/ZdKJXy/SDei/lPi08llzUDOZXbsEGJaFkGc9S4Qr32j7Bz24/x7JPfwcljR5jsw0HJrzBzbBYuvPhGnHXOSnYG5VgjLgAAEABJREFUEfenWL0meiX1bKF/bmnPbZXMOldacVu7Jj5q9el6bBMXapnsS5oIak+gFxqJXC5TfvR7ANKfzbletPxGzBifWf5tBPUVTh4/6rjaufVRzo1jaG6COsqXUJaTihQe08WArjW65ujao+N7usZtd5xOn0nbHaeefZ5fAug5ql7Mg6JT/D5nGJS95ePMMwOZvQDoZpK6UHfT3/cdHgb8sdLffT2so3dz3Olh0D+wDPCRE+eZSR6qmTA15YfOqS0bXTLEkm8BuLKTZFpte/aHeOrRb7gXALrhJhiho1njs3DJylfh3GVXsJas7OtElvTh/Lp6tEkSaWbIVNCGWw6orYOiigUWapdGqPSItFPV41aOTQdujXpTVBMLt0oWXCXeJHWW1Z/oU8FVSf55S6/AypWvxqzx2Ui4SMoJviR56rFvQJyROhegG1uxpKHGqno8vvSJ6MuhZkCJYj8J0Ph5u+53cx/rJ5e1YxdlHrXz8nXPwHQyoPtuJuPpYtepI/+A3Clzw9dPx8rwzTo3Mx7aQLp9kPMPLMU4dJRzlpNtJrSVWakSIQxLTEOZtso4AQ11s1VS7MB6srq6usaKSfVYr0IJtMpWIbdC2V6VRogNE5PyXKWnkmukkiBdGrHOxZ/SR/U4ctq4usrYRi1lnfSEBgkT7lIlWWUTDaSL+7vC1al3FW4kChT9OnwMdHu9Lipj3Tyn54kTPQf6fZynPeJjGUQG9EzSddxZPNz6k7nr3TA0Dvyx0q9dPbzj6oFjeGc/DDN3aWjrE02SS5VC3NPloZIlUK8i+hhbFbiv/2skpBbVFyw4030TYO7cBWyRBrRlaQQl1aoBLmpj4dYWZIbgTBttprSp+DcXT+LEIsH9+F4sU2O0MVdyo5V+T5m7ECtWvAoLFpzFVinhysROJbhEib8TSB07cuUbFcrSEVwdr9JTrqz0MElXaY0k2rhRo5rfFpOBvDwjZPFsXMw91P2s8rKPu5+J9+AZaI+BrP6sNJMXAO2FXt/an8z1efHayQz4Y2UyJ9OiGdJBsjjesn6BoB/iemXfARw/fpJ7JUlqfAmX3PWKB8SL/MciC+WcSkgFVvkJNbdSuqyVeSvlUmmC++oIShMn6kZ45pkX4aZb3uaSY/bmmhqDLwGMvYzayprUVApqUSkkskpBum4R+THG4STFRDiZOpNAGGXEesCAFObPPxM33/x2nMW5VrdEVuLm+DFxVCKHJI2ro9CVbhORKZF+VTjOJbDubFV6ANPAga49r/AapGsRcrZkcc3OYkpZX/e7iSkvnHQzB9/XM+AZyI6B3LwAyG5K3pNnwDPQCwaG1WdWb1uz5O/b33wEv/zz/xXf/95jWbr1vqZiwCWZcWMsK/kUmK1GiSkzUH167ZDIJSWzJezb8wK++Y2PYdvmR5D+urt+CHCEn56rlF4jKH8WwCTOHCgZuHCjBsHVWGfZ0hrHnLVtOQLGZKaaJRFzKHOwKk0IzTU9Z81bOnHzrW/8HV7Z+7zj0/EogvUnFSxVp0PXxo0TSXNUprftzDXdz8ttMfCDBx931yBdi9rqOETGa9euHaLZ+ql6BorNwKpVqwo1wUxeAPg3i4U6JvxkPAP1GBhqXbcX/qwfBF94bjce+IfvYNcLLw/1funb5MtJpgSBkTBJhaCslGWUsLKN8tFjB7FzxxPY/8pLTIdRBd2ER6gZoalBS7xl4XJqqdgOVgzxP8oU2WIE17igFKklECk1axmtaaeKw41o3BLlOiDRkCwG/Qv0soOS5mxsSkARB/a/5Dg6evQgqySDvIlDFqxzpSriVzIr5QbW/TrtDOjas/4fvwv9bwDTPrgfsG0G9CK72/tY24P2sIPm00P33rVnILcMZPWnRboP53aSPjDPgGcgLwwMdxxZXXCHm8VizD5kgi+ApWakPDRKVJmUSkeF6mpPSqkjxDbsaEyEHagKCL0ECJg1m5lrBdsFc6UkTFpkamaRXoXAWlSktpHIlhbWKttURaJAF8aYBIqU4AAuJnBjxg215gCoKjngCwD3ooPzVV2AW6jgmnDmeCOP6bo4lz6C68QNtbSTjhW/egZyxUDe7htFSZr1IqMoc8nVAeuDachAHs7nLD9M8i8AGu5u3+gZ8Aw4BoZ8o4cNPXR0QoMu2Hm4cXQS+/D1samnrARVSFuU65GgRFSoSlxdglqiqoSnn/4evv2tz+DQgb3uq/ABuyUjjo6O4+qrfgKXX3YbpBMgidmzqSTMKBHSUwKoA5dIBmsGcIt6i5rq6dO6lE1KpEdzkKkklXAaA1QyJrNIdnXpCLjFcPmlq3Dt1T+BsbFxp9FGX/0XDpOL73zrs3j6qe8iLJEQ8gXC8ciSxHGN9ero3qQ4oXpDk6maIkPFF0l+6xnoNQO67vd6jHb96z7U6X2s3bF6aa/7cS/9e9+egXoM6LgrwvmTzM2/AEiY8KVnwDMwJQO+AdDDUyc8dNqvk7F8n+lmoJJ1KmF1+Sqz0EiO2hJZ5cu7t2Pb1kdx4tiRcnqcRDwSjODsM5fjovOvxbKlV2DOnPnOxqWt3JgZzIzm5kozlajIMGihmkUkI9YhWRJ1Uk+XqbZITLaGyCdACWbcOrDuSgNAxDIlaFE5d848nM+5LL/gGje3Uc4RXNSW4PjxI46T3eRGHCVg1s/3AOTQkapP+qlxMh2QYzZK8PAM5I4BJQl5ve7nNa5Wd6JerAz6HFqdq7fLHwP6k3ed3/2ILOtj378A6Mde9GN6BgaLAR8tGdDb3/Xr11NqbdVNoh371rx6q9wwoNyUwaQTVqaozEuVrLKRSWq6jVrXxg17caWJPgFPQ98IOGvJhbjrjvdDpZnBLAYAA8Aq4SQA5v6BS1ofyVS6VTagXYSyYEBaTlejBm6plC9wUSlQZDc2cAvCzMAVhmgxM5gZuMGZbi4/x7lc5L7xkJ5rIsMtJMMl9yxreaNePIpbQbKD+rFNhYdnIC8M6LqvJCEv8dTGofuYEola/SDUFbdP/gdhTxU7xn4cg7049v0LgGIfp352noEMGPAuEgb08KTkQxfjRFevTB4CZV+vPRsdkyx4YLo5CCPOlarCLVEdioPKJCfVcSJUJa1sPHhwL7734BewecvD6lEGuCgpHrMRzBybCX0jAHGrIYBZCqAmroOyUVYJt1TiMZMspcoIhvr/QH0FlFxfA6r0BovHUumASGfUB4QpVlBHaA6ai+akuYGLpSAOvvfgF3GAnIirBGnOaB69MyG3oM8KZBV7i/dJpS3WV9l7XW/4gV9iBnRfyHPyH4fpvs02aC+nxW0/Eq+EM196BhIG9Fyne5WOyUTXy1Lj9OLYD3oZtPftGfAMFIABP4VJDOhirIuykDQq6Rf0YNWrh8CTJyfwxGOb8ewzO5JhfZk5A0mi2MCxS0bVbi7F5IfWzEbdZ/xSMmGlAVcKXKln4k+BZiGOHD2Ip595ELte2Bz1dT2ijbEQdGNeMG8JFi44C0EwCjMjAhhiGEvquIVJBttdG0vqwXoCM+pcHS0tzpp94PoYwNImjRG40aIfLVQUqrOUHfsGwYiLfSHnQC0iL6hapNu1azP0uwhHjxxw3DiOyJUeriRTyUJEkt6oIsH5Q7yVGg0XjSQ0NPKNHTKga5GuSSdOnOzQw2B30zVf0HVf94VBmU06iUnfx/IUf8KrrgeDxG2eOPSx9I4BHZM6d4SsR5mOYz/IOmjvL1sGdGDpxlIU6KDulqF169ZBN69hgy42Qrf8tdtf9kpoNXZROdfcNEfNtVWoj6CHE52f6i+Io1Z9tGt36OBh/MHv/B3+6k8/59IfpTUe6B8XTFaZocJlpdy6ZDTR1StL1S8D1CW9/1RPcNXlq3H91XdifHSc8zMCMDNESbfqRLru5AAGgKKzC1gxs1SdMuojoJ3AAmbG/iCMMmAAZfqm3swoG8wIECyjfpQBaTDGmK+76idw1eVrkF6MlQQUI9rIk84hkBvHJev1S9eDG74QoI0JrCX+fAlyP/348J99Hr//P/8Whw4eQZGWVp69dNzqmi+0e91P+qif7iNCP/jTuILmIuhe1m8oDiHhqF1ekn795raduPVs3G/esxxf50878x9UW507go5XoVsO5UNIjuFe8hL00rn33T0DuoAVCd0zEnnYuHEjhg3r+OJDMDP3Fb6Iid5uN2zY4F62rFmzBhq7qJxrbpqjLuS68LbLqs7Rdvt0Yl9ikvTy7n3Yt+8A+vK0b8DwjMvJcp1yvojyV9dOOVqZnLq3AGpjsi+ZiWpSU4mwRG0JO3Y+gQe//2XsP/Cyc6G//08PN2vGHJy95CK86oY34cwzzoeZlREl3AHrgjEhj0oKsICfxptswXaWgCu5gRY2ObG2VJsazCp9KCIZiwKb2RZ/ym+uTMaSPoJifdUNb8Y5Z14EzcHoOEEyR835wR98Gdt3Pu64ECfiRoypBDmTLLA71wqvrAB0KA20UFa9PtjItX4bO/s2dMuNrkW6JpVKJRRt0XW9ETqZr+4v8qn7TXI/1f1HMDPoHtSJ36z6KLZ+o9O5iDszQ165bTavfvOe9fjN5lvE9m45nE5OgukczI/lGfAMZMOAHhZ0s8vGW30velBZs2aNe9FS36J4WvGqh4dec1s85oZ0Rkwgy4koU9mEBSWugpJZlXqjH8aJf1J//oVN+MEjX8WO557EwUN7y3lY4oOuseDUxbjuytfijMXnwcwIECqZeAcsUwiY+JsZ83TqXXKuMgI7cTVwkwIAqsA+CcyoIMyMqgTxWNRpjKBqTNkEsS3d0eaMRefhesa84NTTYagskoVDh/Zxzk9x7l+DOAjLyT5fjIijuF7mLsWrdPLoOJczVTw8AwPCgO4rur8o8Z8qZN2DlERM1e719RkQZ+KufmukVbv2QVTzW8/AcDMQDPf0/ew9A4PLQC9vZrpJ6kEFg0tPV5H3ktuuAvOdc8qA0nqFplLpKaFEtg706bagxPfI0QP4zoNfwGNPfFOdq+A+Lacb/XieMZU2tporDSwIg1kMsCTcj/AluoC390RWCcCMdmUErAspHUBdVKcAow+zqO58g7IQ68ASxj7cmINkIo5bc0DN8mPO9TsP3o8jR/aTBhqSIwpcyR1l8ZKASvam3r0EUMmqk1V6eAYGhwHdU3VfaSVivSBQQtuKrbcBxJU4a4UL7QPZt2LrbTwDRWYgKPLk/Nw8A0VnQDczfVKf9TzlVz6HGeKgF9wOM6eDN3djyAKLeivz17Kacsgk2NXD6LNq5rNMV5W4EqwosS3FpeSJiZPY98qL2LTlETz0yD/ilVdegkv42V9+NLKS6AvOuRSXLb8ZM8Znw8zAz+RZBhEwEpX61B8GUykgJbOPSedK6lGDRF+2SXzTzulYV5+yXBkzYDRm5mK7lDFecO5l0X/5h2hJ5qO5PfTIV/Hslh+6OWvu4kBIc0KmIs7IAdeISLoKOT4bKMVrGJd1C6NWYOHXaWDAc92I5HaS/8SPElqfqCZsTHw6ouYAABAASURBVF2KW3E1tcXkFtmr3+QWr/EMDA8DwfBM1c/UM1BMBrK+kaX8FZOwNmaVTy70sO0BJYR5QGjMS+P9oaRUAJe4ZL7PD7KjipJdB/ZwiS4bVX9+17P41oNfwN59L9Sd0fKlV+Pay+/Aovlnu0TblIgr8RYkTwH3qb3a0nYwmNUAqgewlG25r3RlVNtFyX/gYlo4/yxcd/ntUKzG6ddCc9Mcn+NcNWeHGh7YzXFFWiSWk3+axXLMNTkHakfw9f5xAr80YEAvkxs0T9mkRNW/hJ6SHvd7CZ1y22m/qaPxLZ6BwWIgGKxwfbSeAc9ALQNZPyRUboy1Iw1fPWtuh4/BYZqxknyl9cxVJTJrVZLLjJYKrsxqXT3WS56EmK7kU3OaxhpgwWln4I5XvwsXLb0Kyn3NDOYSc4OS9cDVpYsgnVksx1/ll030d/wBgoD9HCQTNbZmbLcAZpEPs6ie+E1KqnHh0ivxWsamGJEs5KA8j0THCU2aM3khO6SJ3ElmP1a4OoGlWuUgqkvy8AwMCgPdvkTutv+g8NSPOP3LlX6w7sfMCwNBXgLxcXgGPAOdM5DVQ0KVn87D8T09A0PHgNLTZNJMZV3iqtTVyXHi6+pMcpUEw/3gnX74jhaU9ZX4Z7c+gq07HofFjpJS1RnjM3HWoqVYcf61uPSC6zF75hyYmUv+zYwyk/iAYNIeJeeB0xnrbIUZt5ITgO1CUnclbUA4me0s5cuBvo11s8qYsxjDSsay8vzrGNsyzBifhWSxWFC5jXPatPVHOHnyBELONXQclEhHMn+xJx4IcUWwkbZuG3uSXBa94BkYCAa6TTL1EnogJtqHILv9sMI/7/Rhp/khc8NAkJtIMgpE/5dmRq68G8/AUDPgJx8x4B8SIh6Ge6s0tgEDyl/Z7AomtxSZwiqZjSUmvUpfJye+SoCVCIc4ceIYfvDoevzwsa/j2PEjCEsT0Khl0Ll+D+CSpVfj1mvehIWnLcHY6BjMjAhg/DTfjCURfcpvcIk762bVslncJ24zq25P+gX0KV+JX2M9kg2jHFsx3HrNG6GYFJv7xB+AAQ6ag+byw8e/zrk94OYI8hOSjwicVFoWa6w7rpBsJSRcSiYarhq9oYFv9AxMGwNZJPDdvkSYtslO40BZcJLFvpnGKfuhPAOZMhBk6s078wx4BvrCQFY3stRNtS/zyOOg/oeY8rhXchgTc1lF5Qq3YY3JLnNaCkxmKYcOQNWP3lEX1fUyIMSOF57G/Q/8KXbu2lTuJx9JWqvytLnzcfuNb8NlF9wAM4uAwJWB6pAuQCWRpxwk7ZRNcoTExswq9myX3ljSE/Xcsp0WMItkjX37DW/DaXMXwBAtruTcNU9pNIcvcC47nn+GeT+TeCb30VwlR4jqiNvZWR1VkBeJmruqiexKv/EMeAY8A54Bz4BnoGMGgo575rSjf1jP6Y7xYQ0EA5VPuwci3KEKcsvm5/DFz30du3a9PFTzzs9kXXrbOJx0phrLLo+NNuUkVwlyyGQ4pD5CKX4pUMKBg3uxaesjeGLTg9j23FMoJd8EiP0pgBljM3HeGcuxYtk1uPi8qzBn1ikwMybqAcsIUQJPXSCMOL0+zXdgYu9KvhSQXSKb6sEIAvoyYz/aWYwAAcwMc2ae4sa8ZNnVOG/JcswYm4FkSb4BoJgV+xObHsIznMv+g3s49xKhpD8pa2VNkHCcxB5Z5auBqOLkSJx628I+mrqzb+mQgRd5Tfri574BXaM6dFHYbll8K9U/104+PMRJt9yuXbt2smOv8QwMCQNB0eapi0LR5uTn4xmYLgZ0/rib6nQNOADj5OWlyDe//jD+3a/8Dh5/9NkBYK2oIbaTYCrBjXhgTgsB/Dg7ZOIflWov0SBJiKMyaXvox+vxnR/+AyZOnoj+a0Ba6jfw1e5Ah8vPvQJ33fxOLDrtDCRJu5lBCb0ZU/ZyQk9ZdRuhXQBzeupYOjnVpr6BewlAO+llYwYz+iUWzjsDd3LMi8+9kmEkWXkIxWaAi3Vi4oSL/aEfP8B5h6ChK93cGTeguQpJm3gQH6Adzbk6M/JFscVVo7do6s0yZeDxH2/Gb/zq70DXqEwdF8BZt/cPn6ROfRDoeWXqVt/iGfAMNGIgaNQ4iG26IPgEZhD3nI85LwzogSUvsfQ7jvw9fCnJ8QDTzdwiLKfC0KIU15UUoqQ2SnJZdeltiQJTX5f4UkT0lXhqaLxr9zZ86esfwZadj9MFW7mqU8g2WlAHzJo5F7defTeuWv4qmBL8OHkPKKtuTOKNskvqXTI/ArWlEbXrhcAIjLamPs6PbANnb9RfufwWvIZjzZ45x42tGBSLYnLgZstzj+PvN34Eil1tgpsTezBsWoScIzlQXdCc4lLtFGmjrRBzSU4Bf9znnwP4pYaBbp9J/f24htBUtVtuuu2fCsWLnoGBYyAYuIhbCNif1C2Q5E08A1MwsHr1aviXaHAc+GvJFAfJUKuViDYhgEkt18iIWW1ZpkZyyBRXiTGbmPizJqGsUz36dHz/ob144tkH8eSWH2DnrmdxcuJ45MHZU2Sf8dExnH/WSvfnABeevRJzZ50KY7IeMNkPmMgHiezqI3B6ybVI27nkn4k/beRLPuV75dJr3Fjjo+McXDNRoTJkbCew88Vn8dTmh/E4Y1bs0RxL5TlyZkz+uWX8XCM95yAP9ORWJ6uRtUim0HRtYZ809eENPAO9YaDT+0j+XkD3hp9uvHbK0fr167sZ1vf1DAw8A8HAz6DOBPTG1Z/cdYjxKs9ASwwAGzZsaNGyuGb33XdfcSfnZ9Z7Bpi9co3GcQltXJMsKPHVnwNQVqJcohwSzIq5hg7ccA3xw6e+iW/84Is4cvQQPzqnH65s4BrZGX2cv+Ri3H3zu7FkwblM8o0IyhgJKBvBciQIMBJMhnsxQJuRIICTk9IMZyw4B6+/5d04/8xLoLFCjicwAMYDImRsB/GN738RDz/1z1QzwNgmsQs5t2iOSVv0tX8au/70wjVqo0B2uGWVW796BgaagdWrV6PdRFX2/h7UfLeLI3HV3LJiIXvtk4rGS56B4WOgkC8AtBt1cvuXAGLCwzPQJgOxecgHeN0o4+rQFPr2g64duoYMzaT9RNtkoMVPnJnAcnW+eTox141qOrcENYRMjNkgkUkvE3ptaRxJ0afnJ04ew66Xt2P9g5/Dszseg7OnTblkn5EgwOxZc3HditfgygtvglkqkU/LtKtK8Gvrso0hH1fQ1/UrbsMc+h4J9MjAOaTHpvzszsexgbHtenkHFGtIXai/82dckRxKcnNUzKHmzFooO4Ii1bShayeXNxKaocV90cyNb/cM9JCBdhJV3Xdl38NwCuVaXImzViale7vsW7H1Np6BIjOgu3lh56cHeD1gtHphKCwRfmKegTYYSJvqRjks50+S+OvbD7p2pHnwsmdgMgOtJ55xXutc6J4kQXmvZKa9Ljl2MpUhk2Onc7J6skb5wOFX8Ogz38ZTW3+IXXu24+TJ6M8B2Br153YkGMGFZ62Evqp/zqJl0C/2B0rmqR8ZGcHISIDR0ZG6UJv6B8EIgiBwfeXj0mVX48KzV2CE+vRYfAvhYti1Z4eL6UeM7eDhfVRXYg4Zt+ujOUkWGGek41amUJdYkEy0vlrrpt7SM9BnBnQ/1Tkx1T01uQfJrs+hDtzw4qwRt+Jc7f7ePnC71gfcIwaCHvntyK1O4GbQw3m7zuVTJ77e/OkiMF1oN85+2YtTcaSyXzG0M65uktO1D5uNo1jaiX0AbCeFqGND54/QjI+kfZKTPim0f5KYpip1XRB0/HfycKB+4khlr6epdMcDGEwOKkkuc2Aw7eVKHVd+/E25RLDCJBlMmB1oyDQ5sqVMAY9v+T42fv9+7D+8V1WCFuzDlV3Uv4SzF52LN9zyLpy7eBkT9yACXwCMjo5ibGwU4+NjmDEjguQx6sbYNsqXAyNBZH/O6cvwhpvfSV/nRXGVNI5EjhHHohg2fv/zeHzzQ4yjsupagSggdqidF/tzde3yIznuGv/k34DuXwx93OjxomusoOttI2zcuLHrSFoZRzHIrt3B1E/niO47ui+pVF2+OrkHtTt+ke2n4lb6duet/SGobyPIpl3f/bBXnILm0o/xOxkziVcxN0InvrPsoziFRjG205ZlbFP5ys0LAF2w161bh2ZYs2YNzAwicqpJTaXXhVX9pgMaa6o48qDXgaoYzQziVLyrNOuM2+mck+Kejn3YyhjTOe/pGavxKK1wov3T2Mv0tSqWZjHLRmgnqkE+f9qZp7dtxkDyKqKBXZzgusJtmBPLPCXHIhuUZAsycNUoT2ZVI7HAseNHsGvPTnzvsQ3Y/NwT5XZaszlkSh1iZGTU/RjgJeddiZsuXYUbL70VZy062yX9M2fNwOzZMzF7zqwIlGdSNz5jDGfSRrY3sc8K9p07+zSM0FfkVVEKHInF5ueeZAwbXSyKiYO7VXm/BJqocPEpuXECNdILFOnIrU5k4FrLciRMtRUbwlTtXl8kBnR9NoueVfScoueVRshi7tP5TKr5ZRGz91FhQJzq3q+yom1NSvrpWBMaHWtq07HSmuf+WNWbj1n0rK+2/kTV2qjitxWY9Wc+4s+s9WtTK3ORjZlBx678t8ZU+1ZB+13y0SMhqJfk5GOm2UchznRRm+qiJW514CnJyX507zHXDPjgmjLQyvljFt2Mmjpry0AJjwcwgByU/xs7lDNeJcECNdQxxWbmzK1LgqVX0qx61M4tlZo5OP/Dxw7hkWe+iye3PYI9B3bjxInj9AG3hKF+N6CEUjiBZUsuwjXLb8I1F9+E88++CAvnL8TcuXMw95TZOOWUOQ6SpVPb+Wdf6GyvWX4z1Fc+QvqDIO+MQX96sJdjPsWxH3nmOzjCWMCYjHDBI1kYPeeUqiFUXaCSrirmqlAH58MAlR7AQHKAzBY9g5gZpnpWyWygDBzpucnMoJgzcOdd9IEB7bvVq1e7DyIH4ZhDk6XZfHTMCnqmaeJqIJo1F2E65iNuzcwdK70iR8dgL+czsC8AEsJ7SU4yRpHK5OLWbE468PSSQAd5M1vfXhwG/EwaM6Abi645ja2iVtnJPqr5bbEZUNLaxgzjJJgZMRN3JsrsGiXHFFxaHOlUo4ErlCMLygmT0Z7d+QQ2PHS/ewmgHvIh6Nf2S6UJvgQ4CVgJFpSw/NxLcN2Km7Bo4UKcOu8UzJsf4VTKixYuYNuNtFnhbGHqSzgfepnAkV3MIfbs3+3G1A//IV4sCagcu6KJIpckqEmx0RMbuHX+6CApKba2lgdrzdxbDSQDunbqGWTQglfM/rlp0PYakBxvevYdvOgnR6xjUMdiK/PRs4pyg8leBlPT6/kkx8p0sdOr+Qz8CwDtAJGjg12yx9QM6KBt5WKQ9qA+6bqXC82An1wDBnQu6FrTwGRSk+z9tWkSLcOpUM6bnnmc+EbJMRvZJjmSWHEZM3Nlik7n8l5tCGbcZoajxw52kF9JAAAQAElEQVRj154dePTZh/DQU/+MH276Dl45uIfvFUrsXYKSfzD5D0aBU085BWcvORuXXng5rlh+Fa64OAZl6c5eco6zkS0CjsiXAKF+yZ+f/r9yaC99fxcPPflNN9auPTv5yf9hmJkDYHBLXDiZLqLoo23IiCK9JNfIhrhkg5PchhW/DjUDnVxr80SYEi9/3c/THmkei+7Vza0Gx0LHYDvRKjfQeddOnzzbaj69eKmh87ofx0ov5lOIFwA6CIt04Go+WUP8dHLQ9uKgy3pu3l9WDHg/jRjo5PyRP517Kj08A2IgneOmZbU5UKlPyqN8mRWnjDZmBq7gFmYBzAzHTxzHjzc/iG89+jV89/GNeP7l7e7FQEnJuz79HwkxMmYYmzGC+fPm4YqLrsA1K67D1ZdEuJblFRdd6dpkM0JbGykhZN8Sfeglw/O7t9H31/GtH3+NLwAexLETx9zY+h8GFAuM8TEWblMrY9eqFx0sUw1OTKvSsmv0m6FmoNNrbZ5I89f9PO2NxrEUbV91Oh+dd0pwG7M1OK3KX7KeT7svVrJkK+v5BFkG109fWRPTz7nkbWzPbd72SI/i8W6nZKDTG6oc+vNHLAwDlAU3mmclza2Vos/EtVX/uDV25wom1+aybLUbENdNLwGCAKbSRjDBT+sf2fIgHtv2MOSNaoyMGEbHRjA+cxQzZo0R45g5m5gzjlkqiRmzxqkfczayVR/1lQ/5+hFfMEyUTsKo1H8RKEgGGAthBNxiAGPDpEWe+IE/o9I2ao7mGW0jTaUtqdeW9F+r8vVCMdDNtTZPRPjrfp72RuNYlPg2this1m7mU5TzL9ljWc4nS19JfO2WWcYQtDt4nu2zJCbP8+wktm4uCJ2M5/sMHgM+4qkZ6PYtsr82Tc1tsVqaJKj6NDyecHXiGytdgpzILONk2nmlbEzAp0LAdvbAvoN7sGP3Fmx67jEcPLofwUiA0dEAY+MjGJsxirGZ4yzHMDZOzIgwPmMc4+Nso83oWOD6HDq2H5uef4y+tmIvfYKLmcEsgNUA6TpMlhEkUorWaMbRNq2JZKS4iTU1RZWzmjZf9QzkjwF/3c/fPqmNqGj7qNv56MVVLUeDXNd8un1+y9P8s5xPkKeJdRuLiOnWRxH7d3tBECdZ+JAfj9wy4ANrwEC315Zu+zcIzTcNGgNJotson3Vt2hjMJdfVZSCdPvkXnBy3Iyr3HnwZDz79z9hzaDdsxDDCFwDC6NgoHEZZEiOEq1M/RozKji8MjNhDH/pdgb0HdyPgOLDIt0ogYEFQb4JRJqiEYGau5MatmGqhmWtKOHEVvxlmBvyHFcO896d/7kVKDrNiz3NSn8m8XJuyyseC+tP02iIx0IsfwigSP34uYqCYyOLYz9XNMEmsfAklmvkDUD8moFqPaNF+lKTSgbdklmZG8wgUABthwbYgLplsGwHCAtohgBlR1W4I2VbiC4CJETiZjuAW49YM+gdtDQDroL1sS84eQJzcwwIEsW8zyUYVx6NMAZYqI5ntVgEow9kYnAwuRpkFVEgug8qyzMayPJU+beNllPnqAxfcRX71DAwSA0V7OZ/F80oWPvJ0DBRtPllxG2TlKA9+Vq1alYcwChlDFolUIYnJyaTWrl3bXSQF7Z3FcZuFD39tKugBNmlaTLom6aZSxLZM2MwkG3M3A5Qog7dmM1c3i0uXjFN2ZcC2GLQ19aEeKs0wZ9YpOHfJhZg9cy5KISJQKJVKCInSRAjJCSYmSpigfkI2sf2smfRxBn3Ql5kB8Tgaqz4MxvHNVEYAZbAfYj1gMDMWBLQkpeRmaMe2mS/f7hnoPQNFSy57z9j0j+DvzZM5z+KZZ7JXr8mKgaz2T5BVQHnwkxUpeZhLljGIl24vcvKRZUzeV74YKGI03R7zaU669eXPnzSbwyYzo06mrBxWgNskWlcqL5ag0sxgTJoRl0bZLNJFMm/dqiPWMfk3ZxPAWC487QzcdNkaLDx1CRN+YOJkCSdOTjicPFFifQInWXc4QZm646wfn5hgm14SgH3p4/LVWERfxiRefh04FjgGYFwNAWWjLiAskC6KAWZcJauEW6hyZfXGAK4OSJYUZ4nKl54Bz4BnIGMGsvo6dcZhdewui/n455WO6Z+WjlnsYwUaaFMUZEVKUfhIz6ObE1qfLnfTPx2Hl3vDQJfHfm+C6rPXLI/Zbvnttn+fqfTDt8SAklYhbVxbT7fVygYzAoRKB96iLYAZdWApSGaibU5PHeuAQcvIyBhWXnAtLll2NQIbRRgGYE6PkydCnDhWwrGjJ3DkyDEcOXwcx2IcPXIcR44ec20njpacrfqob4BRXExfKy+8DqOjY4AbxmAmaOyAOsowAAG3AdwLgVRsZub0ZkYbgUVLay13qgstdfZGngHPgGegKQN6Tuj2BX/TQabRoNv56Hl/GsP1Q7XJQJb7J2hz7NyaZ0lKbifZRWBKQIp0keuCisJ17f7YLxwl0LGuYz6rmemm2inPnfbLKnbvp98MKOkVquNQPiytmcHM2BiDyTMVEIyymcFYgjCTnCCAmWGESf/iBWfhnCUXEOdj2dmX4PQF5wBM3oEAYcn4aT/cC4CDB49g54vPY8cLO7DjeYLldkI6tZ04zhcAJ+H6qC8w4nzJ59lLLoCwmGNpTDPj+AGhMkG6HgCMOYIBiGAsI1BjqLNIKdRp8irPgGfAM5AxA1k+K2QcWkfuuplPN307CtZ3aouBLPcP79BtjZ1LYz1gZ0lKLieZQVCdcOS5zYD4HrrIZP/0ML5+ue7Fj77o/NGLhXbm5PdPO2wV0bZ+ImuJuiJAopmxFJJP0g3RV+tZd1+xD0ANwMQetBVmzpiNqy+7Fa+58Y245bq7sGjeEuhTeNgIM/kRJvMBJk4Yjh8PsXfvK/jhEz/Adx/9Nr7z6HccJD/8+Pdd24ljobMN3a8Asr+NOl8L552Bm6+7042hsWbOnA2NHYExGRHHB8kOxr5GkzQAKgjAlUBSYPJik1Ve4xnwDHgGMmagmxf8GYeSibtO57N+/fpMxvdOesOAniez9Bxk6awfvkSIHsz7MfagjamLQjsnuOc233s4q/2T71m2F50S9HaO8fa8A3qxoDFa6Sc7f21qhaki2DT7ajrby/lsWYgnrroxEa4GFVwDUOsAtw1YUGME62ctuQDXXrkKC+afgRkzZmHG2EwEI6MAk3G9BLD4JQBKAbY9twWPPvMIXty9G3v27iP24uW9e1nuw0svv+zattJGtggDGPvKByyAfMq3xliw4Axce8Uq920AA/+ZRTGBfeK6mcGMdVdKroDGAAzVS1x3BbmqbqypNWuvMfdVz4BnwDPQhAHdq/VM1cRsYJrbnY+em1avXj0w8xu2QLV/tE+znHeQpbPp9KWH614QMp1z6MdYOsHDMESjC53nth97pvUxM94/rQ+cc0vxogRdx3gvQ9UYjc4fja1rk+wkeww7A+mE1WW4jhAzyQazCGDCzApX1kGwbpaUASxVHx0dx3wm4kvPvRgXnX8FZs2eC9BWCF1Je74EOHj4AHbvexEv7X0RW57bjM07N2P//oM4cOAoyyMOTn7lIDbv2OxsZLub9upr9AEi8mlujFmz5roxzzv3EuhlwBhjMeN4ybhOjupOD4OZub5AojcABjNDZUnLac4qFl7yDHgGPAO9YuC+++5r+Gzcq3F75TeZT6PnFT03KSfo9XNTr+ZYdL/aP3qe7MX+CfJEnibaCkSGHq57QUie+OhlLLow6KTXhSHN+SBwq33fCL3krVe+0/ugkdzt/pnM2wZs2LAhc2TBUyMe0m3iRNjAeWQxbis+7uODQnL+pM8hxSH96tWrW3HTgY2SJA8gLxwgXmrjidUqlOQKLmbAjLZMkilFMgxmCXhLZpsx6TaVCVzd2IWAYe6c03Dd1WuwbNmlKEkFQCmzEvWQthihH5ZPbnsU//zw1/DNhx/Azl3bceLYBI4eOeF+BPDwoWMQ9IOAR4+ewInjE87mmw+vd32e3PooQB/yJZ/ON8fRqjGXLVuJa6++HXPmzKPKYBaDfZL4YQHXANywPSAiGyqcrDJqM0QLS4sRKeItdUgjVlfp0u1eRl+4gV9qGNB9qRFqzAtRbTTf6WrrlMip7u3pZ45audOxpqOf5iPo2aT2WUU67Y/piKOfY2iOWSCLOdQeO1PVta+S/dOr58kgiwll4UMktLqDekVGFvMYNB+6MKR5HwRu9X/rrlmzBlPBzGBm0Fw0v7zvk14e+9q34kEws8mcNeBxKn6b6detW5cJ5Yq9FWhuQiaDtulEx5eQxNnrOIzxeQADywHPwXLskpuCt2gl0ZyxWdTzrLMuxMpLb8b8hUswNj7TkRGySaCZq+/Zvxvff+ybeP7FbThwaD8OHD6AY8ePY+JkCScFJvtK+IWTlKVTm2wOHt4P4fmXttHHP+PlV3Y7n/KtMQTJGnsBY7j00ptw9tkXAlSambYAAlgqbjOD+6eyFrQ2QXqVHuQKAwn4ZRIDze6XZgYzg+4jwiQHA6DQ/U/3PsFsep4zWuXVLOJWMbZDpfaFoH7NoGStHd/9sNW+Sc9HdaEfsUz3mM1yhmbHUtKeRdzpfdDouJJdr/dPkMWEvA/PQB4Z0EmvZNQsugHkMcZexqQLiC5c4kGoN5bXDQ4DNjih+kgTBtI7jdchV+WGIh/6ZWSVEpSJgHBSbGRmAKGv/Z962kIsXbYCy5dfjRkz50Sf+gMoESFtVB48coCf5G/BI09+B3uZvOsbKWEIhGwsCSdDTEyUoITfgXKJOrXJxtlyo76PPPldPLdrC18IHHBjKI4QjIfjaZ0xczYuYiznLV0JxaYYwTjMZGMUCZheB8CMMgGoBJeojFXUSmXcxGtKjDW+yDkDfpd1voP0rCLovq3EoHNP09tT8eb9OUO8KkbFOr3s+NE8A/llIMhvaD4yz0B2DOgG0Ou3adlF270nzVVzbuLJN3sGPAMdMxC20FMpUQRtow6SIrjkl6mvSjODBQYQpq/RWwAzI0CYS7BvuOlOnH3uxShZNLa2Jb4GCI0JPsuTEyfw6BPfxhNPP4SQ2XxIXchkPmR2r7JE2UEvAkohSg5ApAvZJ0SJtqqHrm8JTzzzkPN54uQJaCyN7UqAFoDqZ5+7HDfcdBdOnbfQxcqwYck8OBc42eI2Y0+jzALGTQK4WrSt6NBwEQMNDXyjZ2CgGNB9e1CS1UF7zhC3inmQXrAM1MHrgx0oBoKBitYH6xnoggF9Cq6LfxcuBqKr5qi5Ng/WW3gGPAOdMdBC4qkcNnGeyGYwM4CrYGYwSwGRnBiwBlB35lkX4KJLrsXixedg5qzZLvF2CTpfBETJP/Dyvl348RP8xP6FzThwcF+UzDPhV+KvaF1Sz7rKCEze2SA5sgnhZKCqr3w9R5+PPfldNwa7MOmnjcZmJKorpkWLz8byi6+FYgVjTmJ3suYonUqjxpUSAKphJpkAl7igBKRlTLUogqnavN4zLFIXRAAAEABJREFUMJgMKFnNc6I6qM8Zejby3wQYzHPCR50tA/4FQLZ8em85Z6DoF3/d2DTHlnaDN/IMeAbaZCBJNptkpunmRGaSaxZVzAxmBm6gT8pVglWY27AwAhgZHcOsOadg2UVX4uIV10V/8494MSXhQIn/jh47jJ3PPYsf/Ojr2Oe+9l9iEi9ESb1L7Jn8u0S/rVI+Ss6nfO98bhM0VknfLuD4EOJw9JsAyxmjYlXMil3TMZMRoZIFLOBKwQxmEeTCzEAF3ELRldqkZdUnITFI9s0kA6/wDAwkA7qf5zFwxTXIzxmKXS8w8sitj8kzMF0MBNM1kB/HM5AXBvRmPS+xZB1HO3PLemzvr9cMKNHxAPrNAeKlNo5EndIrqWW8ZtQJMnGlwZQIE0AAU+lggNpjzF90Jm689U04/ezzMcEmfd2+nOZKIJSQ//BH38DTmx5G8vX9EpN8yclX/0N91d/pQkiuRUnthF4QOJm2of4UQKDM1wDO99ObfgiNpTH54T8cEBWKTTEq1htvfTMUe3oukRyw4ETiOZvmDNbLpcHM6JFISiQy1W5lXboynJKbWr2vo8zRdHIBv2TEgBLVPH4LoAjPGXnlNqNDx7vxDDRlIGhq4Q08AwVkII831W5p1lv5Nnx40wFj4MKLz8U973ktzjxr0YBFPizhMslySavmW5Gdym2oZ2lmMDNVQIErZdbNzMncQosS6fMuuhyLz1qGmXPmQgm2S8Tjr97LZu/eXdj0zCPYuXMT9u/fAyXwoT6dZ9IeEiXJLolnT8nUST8VZC+45D9tSx907sbYufMZPLPpEWhsxcBXClWxKdbFZy3FeRddwRcXF4CTguZkxi0BwiyWoTKAmdEO0UKZa1kG2AYuThnLrPo1PwzomqRrk65R+YmqGJHk7b6et3i62ctFmks3PPi+w8lAMJzT9rMedgbydOHP6qtoGzZsaGO3etNBY+DGWy7D2v/yIVyycumghV6AePlRe/Jx91SzSeemsRwV8ZYJrBllwvSJN0vnyqm4QYRgZASj4zNw4aXX48LLb4CNjYDpO9SslwATfAEwYSXoB/+2b38a3//+eryy/2X3CX0lsS/BJfJK4hl3qOSfSbwrqVNbGiF1Ydom7lNK9K4MoRcDetHwA465fftTjOE4FMsEY1JsLkb2VcwXXs74OYexsRkIRkYANRJmBq7QYibZAK2JDC0mlQRUBKBKRr2lhf1Ur5vXdcXAxSuW4j/91oega1RXjnznSQzok+pJyj4q/HNGH8n3Q3sGMmTAvwDIkEzvanAYyNtNNQvm2ppTFgN6H56BoWBASaW1PVPXg0mtOhozVzMDCDOVEg2mX8g33obNgMCkxOIl5+HWO+5heS7AxDok9CX7UEk4TfSjfwcP7ceDD30Vz27+EUrlxL6EMJxAiYm8EMZlul16IZSvFKQTQvYR1CeqR/6cjm3SCXoR8OzmRxnD13Dw0CtM+RmhYqNPSqyLsxCLzzgHr77jHZwLX1pxjhbPEcY5u7kb58jVVBrpIWBwC3Wx5Kqtb9RL47few1t6BvLMQJ6S7iI9ZxRpLnk+fn1s+WSAd+F8Buaj8gz0koG1a9dm4j6rT++zCGbVqlUtu/GGngHPQCsMdJZIKgUFE1iNYMaaAIv+SY5hRh0BIhgZwelnL8O5F12Gs86/BLPmnqLuLpnWp+sl6F+IvXt2YevmH2Pbtiewd+9LqJecK0kXym18SVCuS64DJfWyqST/HI9Jf9kHZbUn9X0cWzFs3fwYFFOJkZbiGN1LC4Obg+aiOWluwcgINFfBjAYxzAz6x0aulFiHFpamsiN0tu86Gsp38gx4BjwDngHPwAAx4F8ADNDO8qHmj4EsXgDcd9990z2x3I+X1Qua3E/UBzggDDRJJtNZqmQmrm5iKh0AM3OgxDIgjKKxZAFgdHQcK6+9FRdeeRNOjIQoGaBEWp/4lxBCX7MP+Qn71k2P4uHvPYCDB/XJe8m9AAiZnLMHZW4lM8F3Cb1K1QmX2Kfqrg/1SankXjblumwJ6dTm9Ci5bxgk8iHGoFi2PvtoNLZxfEIxK/ZSADeXC6+8kXN7DUbHxsFpgVRAGzNjQSOojEDRtYFt0KLSJMRIy7Gqumiyr6qNfS1nDPgX2TnbIQUOxz9nFHjn+qk1ZUB33qZG3sAzUDQGskq69QKgmweWLG9Arc8p/3tTvOY/Sh9hsRloMZFMJ6SUzbgRMSzNKGuNSyW1Fn8N3sxYNcB4GzaVhnBEANwn/hYy7QcXlSEOvLIbP/j2V7Bj6xOYKJ1AWJpwKIUqmZizXiKkLylxT5J7yqGT6YcvECK5hOoyaVPJtriPEn/5CulXvoWQbSWOWYp1E4xFMX3/W1/GfsZID3HMqXnwg3/NjRNGhICFOXADizmBqVmbpKQMwIwlVyRLWk50dcsW92Hdvl7ZDwaKdB/rB39+TM+AZ8Az0AoDQStG3sYzUCQGsky6xUteHliUNLf0MkJB5xjaP5pLjkP0oQ0NA8o0hSkmnG5ystuAGStXyQb3zyWwvN26khpXVuqzT5uP05ddiNE5czARMIVW8k9ELwKAV/a+iJ1bn8Lmpx/B3pd3IaxKwksoMRkPpRNcsi9dDNZL1Icq6yKES/TZ5mxo6+oqCadjm/PBeoljSXYlXwSE1CmmLc88gh1bnnSx6tsLil3fAhA0p7E5s7F46YWYzbnCzd8ACyiqTBDVDQYQZiwFaJGsMgarsVSnUKNQp8mrcs2Arv1FuI/lmmQfHPSckZdnN787PAP9YCDox6B+TM9AvxjQg0XWF309sOhm0u6c1CfrWDZs2ADNsVEseW+777778h5in+NTYuMBJoi9B+Kllu9YPSkG6Y1ao2AwE3SbDSinIb0gneH0pRfhmrvehlOXLEEYuK7Q1+hLQei++v/skw/j0Qc34uiRg0gn5FGiPoEoIS+hxITcyUrY6yCkLnTfAgjpJ0GJcoQS24TQ2ZXoLwaT/FLiW7JeAtAmGSukfPTIIfz4oa9j05M/cDErds0BBjenU5ac6eZ4+rKLYGZEQKgUJEcAotLMHBEGcyU3XBM5Kalya1JPSqfkJqn7EmUee8EFMl38PSBTOr2zOgz4Y6wOKV41VAwEQzVbP9mhZkCJsRLkXpCgm4kS+lZ9y1Z9WrVvx66J33ZcTbvt+vXrp31MP6BnoD4DSpTqtcRfK083J7KSVgf2k86Bm/JX3Cm7dt56+en3+Kw5WH79a7D08msxY9Zs2MgoSmYRaFKiOdN0nDhxDMePHUHJJd5Jwq+SUGKeQMk5k3HZKSkPWRdK0gmsu6R9ylL+mPTH7fJRcmPGumQcldI7sC2uK8YTJ45DMSt2/QZAKZ6PjYy4OS697Fo3Z80d5CACJ2oxylwBlZw1bgMXitxGa1mO90mkTW3LBimdF/POgF6q+3tB3vfS4Mbnj63B3Xc+8uwY4CNGds68J89AXhnoZfKfzFmJtxL7pD5VKRvZTtXerV4PTyE/ydM4k33lU6P9o5gVez4j9FF5BlIMpPPKRGYCyzUyomDGBoEJrZnBjHBy4ORZp56GReedj6VXXodFSy9A+dNyeigZ+BIAOHb8KPa8uBNHDh9ACCXahJJzJdwJlIRLrippJ12MkMl/yH6upC4qS+VP/sMqnV4CpFFKvXiI9clY7FcS6LukMRjjUcaqmI8d5wuLeB4uPaesOWqumvPi8y6AODAz8kFOHDeSDaBMJVcDN9BCMyQyqEaypOVE58uBZ0D3gnDA7mMDT3rBJ+CfMwq+g/302mIgaMvaG3sGBowBXfD1trdXn/zX0qHEvt5Di+IQ1Cab2n69qGscvQQQyv5zJoiT6dw/OZt+Z+Eo4fGASwJ7wgPTVUsA1B0HXDS27qAqiSRBNSavZlIAkmGSCepdYstS+rMuvhRX/8SbMXvRIpykn5M0KQFQkqxPzlXue+l5PPjA57Fr+yaUlGgzyS4hTsIlO11Un5CcJOYq46Rcibn71N/Zl+inCWr7yVfsu2oM6ZxPju9ikt8JxvoMY/4cFLvmkMxFc9McNVfN+aqfeBPOvvgyiIuEF1caiSCc3omGSGZpJCgBOYNkqlwpeRKS/aiShpPavW5q7trkhua9WAfhPtaLeXuf2THgnzOy49J7Kg4DuoUWZzbTMBMlknoz3Qy6aWURjvw0G2uQ2jdu3Ng1LUpolTQ2Q8hPD5L91fWgbTrQftP4CRSH0Kabrs0Vh5DE0Yyz6WxXTOJEx2/XE23TgcYVNHZWEM/y2WYobZnPmj0T97z7Dtz95lsze273ORFSXIYpOa1HvISuNJJmtDTWHKQoy5Fg5lpgZlACa8bSAldHEGB81izMmjcPwdgoYIAQ0iakLOx4+sfY/KPv4cDel3Ccn6aHTLZDJt3uk3wm5ZHM5JtyiQjTcHYT/IS/HkrU10MdW/lMfEkmSqyXx6McjSt/6l9irEddzM/+6EFoDppLBE6Mq+apOc/i3MfIgbgwM5hF3JhekLAuQsxMBVxBEYSZqYhB2RAv8b5hTarJCOM+8CWQGQd3v+nVvCa9FrNmz0CvFl1bhZD39Om6Rylp7NV88uZX961W74N5iV37p5VjQcdMMr+8xF4vDj0bt7oPBsFO52u9eQ67Trw023+yEXrNVdDrAYriXzvDzLBmzRroRG0FWcy9lXEGySYLTuSj2Qmkdtl5VDEA8ZIXVEc2fTXNX+exkOW5s27dOnd9MDPoetGLGc2cOY633rsGd959cy/ce58tMMDdSyullyzcGslmLAXqTOkVZTNKNRgZG8ec+QsxNncuok/HjT240k4/ABgG5r4FsHPT49j+1KOYOHkCzNi5hjFKCPkpvVByJRNvJuahoIRcSGSVgnTuBQL7upJ9nC4pE71K6tRHkE1SJrLqRMmNTXuVzmcUH5ikTZw8iR2Mfeczj7m5uDnpaYNz5EypMzf3cXIwh1yIEzODWTWoADXqQkgyllqTMpLZTYJHHxj4CV6L3vbONZg1q3cvANLT0vV7upAet4iy7lNm5u5brd4L88RDK8dBnuJtFkur+2BQ7JrNdxjbW9l3epYUzHr3LCnudUtW6TEFA8mbQ+2MKUy82jMwIAwMd5jJuawLcK+Z0PVCD1e9HUdJkAeYImYDcGnEJ5vLY6VkdjFzG0TNvK2ybhbALNajIs86bR4uXfM6nHnZlTgZhCiZAJZEQLALOwIImUvXogQl3iUm3GUwAXe6dKl21VUyIS+VwqifKyVPBflnm/qob+JDZS3UnoBtIeWQ/dLgJNyqFx1V4Jw19yWXXYFLb399+b8GNNPkSQJLMyMNkQxyCaMrM5gZwDXaOIFMqRTAReVUYLPrPFW716NtfuCXAWRAybPuUwMYug/ZMzA0DOgcNTPo+TXrSfPumrXL4vgT4cmnhMWZlZ/J0DIwxBPvx7msC3fvXwIM8U7NfOpK/po4LZtQ4BpZU+ANWrIpeTJKqscwM1hg4IatBn3aPWfx6ZhxyqnQV+OVGKX3KdIAABAASURBVIe8E0vWl9QP7HkJz3zvn3Hg5d16BwAtSVJdihNtl/xLJhLZlUzCZeOQkkPKEfjpvj7JnxIlvnQoxS8LWLKf85WMk9RZJt9A0LjyHZUh+4cK2cHN5cFvci4vIeTsQ2o1TzdnUiIO5ixajGB8DGZUBAHElRllB3aIS4OxwlX1ssx6ssbNSbV+2ZJR/a5e6xkoCAOrV69232QtyHT8NDwDhWdAuaieY7OcaJCls6L58g/vRdujwz2fYZ69Lp79mL9/CdAP1rMfU4lrknOiIlBkQskVXMwoEGYGMwM3kzA6cybG58xBOBq4T/xDGJQQC+Cn4ieOHsFL2zbjxxu+gn27ngfTaZdQh/pknUm4KylTyTVK0EMl402g5LwM+lFSn/ST7EAfiU3S1qiUrdoZSCrOEquMmjGGxL5dL7i5vLT1WWhumqN72cEnD81d/9uBuBifMxcj5AZ1eItUKT7BhVVnS1GrqipBIXSC33gGPAP1GNBz7XR8C67e2F7nGfAMdM5A1s+xvA13HkyRe/qLZJH37lDObWgnrXO5n5PXS4B+ju/HboUBpY1CK7YNbJiAQllolLXCjIoYKs68/Eosf+1dGF1wKo6PhjgxErq/hdcn4sdKJ7Dpe/+EbT/4LqKP/hkPk2gl0qFLsaWlFCfqIctJYHI/Sec+7VdiTqTalcALZftUW5juk4xT1U5fsb6k0rUptiRGxs6YVRO2ck7PcG7HJo6X56u5i4PRBaeRkztx1uVXcd4VvkgeIvAxReSpCfUWNkCotGn0Si0tqUVI67zsGRgOBnQv9Pej4djXfpbFZEDncFYz4501K1fF8uMvksXan342w8tAHs7lrL+6Nbx7c/pnXkkXrZJmGuOIYUYhgSxYZaskgHozY2GUA8xauBCnnHM2bHzcJcITQYgJNqk8iQm8snsXDux+EdHChNoJjICrEml+vB6l1fGLAdUFWbpEHiVWU1BiXmKrK1P6JGmXXnIC1R1CKLFPUOWbEYTx+OVScUqXtLnSKbXBwZdfwv6XXsBJxjdhITTnEueuFx82YwynnH02Zi1YABJVgfuzCZLDFVrIY1W79AnUXgNHWY3OVz0DngHPgGfAMzCoDGT5POtfANQ5CvzDeh1SvGqwGRjS6PNyLmf51la7cnRkxP3q9siIv4SLj14hnUQq1wS45Yp4MdVjWYUZNTHAMoEFAYKxMYTcX+5r7yZrgjb6EUCXEFOXjKdSUNLPvFrpNBP7sAz2jGVZEDSSfTkhV72MUmxb6V/fLtXORJ2duNJr2Q/bObDry5KNXNlO2eloRwVrXCW7qBkbq1plqblP8JDVnEPOPa3H6AhG9FsAQUDarAwKqAD1F0upTSOl6l7sCQO69uiX/3Ut6skA3mnmDGSZPGQenHfoGfAMtMRAVs+1QUujDZlRVuQOGW1+ujlmYFhDy8u5nPXfXN74qsvwu3/867j2hpXDumt7Pu9KGkmpblKZZJ3G/NTAzSSYRfrZixZj+RvegIUrVyBKfplM02dI6FPwkGaoXThspKLgEuqo5rblOv3EcpKEU8M8nFvquXVpeLlNujZAR1xjL0k/BUBZRQTGFwnRlm3SCFKodPPTHAnJehGguScQJwtWXOI4mr14MepxCfZFzKcrwcXVWU5aNWrl5cOkZq/omoFrb1iB//VH/wduevXlXfvyDnrPQF7uhb2fqR/BM1BsBrI6l/0LgGIfJ352ngEx4FEwBs46ezF+4vU3YclZCws2s35NR9llG2O7xJN9uELgxoyCAN5WLYARYN3MMDZnDuYvvwgzFi2Evu4/waFKCdjt8L492P3kkzh+8CC1VHDr1iiPpZjoWCa6pGQrc+5KtpvSsynWS9kGZOo6x5t0PZbjIvYf2UknRLV0k+HYoYN4iXM8tHeP+/MHvQQQ9O0HcSJu5i9f7rgSbwDnSu6QAEndtXDDOrTEZVxI0xgtGzZ2M+StS85chDt5DdK1aMip8NPvAwOrV6/uw6j1h8xTLPUj9NoiMeBfABRpb/q5tMWAv9i2RReA4bUv/rGiZMYDSg47BuKlmkdz/tRk3BBJIqqSGre6JD8ApKsLtQnGT/6Bk/zEX4j+Dj5EUr68+Vk88YX7cfCFFxAtHA/GT+8TRNrKVu2qqSRc1q2SkJrQSwEHyZ2APtP9wXgigIvGUWxK8lnKltpojdqQ2KsKcG678MQX74fmmsxbpT79PxmEjpsSZ6xvCEB//y84TiP+IK7l0+iQMGOpOn0jkZMSanMN3EhOgyq3pnVehuOsHR7gF8+AZ8Az4BkYUAZ4Zx3QyH3YQ8tA8ZO6jHftELvTsbJq1aohZsBPvVMGmNNGXZUTRVK8pYKJphnLWAMnG9w/yUJUowUTZANfANAjXwAowY2++s6meHVf0deP77k6jV1Zs2H3SJO0JyXghgOXioqVDNZW/aXt0nIqBIWv/25Qf1CQqMWFXgCoTf9FoP4cwk1GEyoDVBkBxBuWiBZjIbAAykJKTI8Gv3gGPAMFYSDr39Xphhb/nNENe75vvxjwLwD6xbwftyMG1q5d21G/Ye407HPP04PCsO+LgZt/KqecKnaz2EilRMKJ0QazTl+EOeecBYyNQl/7V7Krr74r8T05cQIHn3sOR3a/TPfsmE5iqale1Z5oKHNNamA/DQe3VDU4TfebqXxSzzXyXxZcVfN0AjdlmSaHd+/GAc5ZcxcH4iJ6EUDDsRHH1azTK78DYJwbNDkH2hgBblydpWSpHFR3AtLq8vjwi2fAMzDoDOTxOdA/Zwz6UTV88QfDN2U/40FlQBd9f5Fte+8NfQf/dn7oD4EOCUinjanEMuUt0ZoZuMJtJKSw6PprcOYdq2BzZ8F91V1fd49x5OhhbPv6N/Diw48AMFQvRk0FrETNxkJgASqNgFuMW4EFdWaJrHpnMPlxUH/TJkKVb+mFqEmsKaFXzcnsr1WydC/+8BFs/frXceTooUl82JxZOOv2VVh83TWAxhDKfwrAMVRPgHih2tnGVV94BjwDxWYgj8+B/jmj2MdcEWfnXwAUca8WcE76GnceL/r5p9pHKAay+tEU+coLgiDAve+5A+/56bswNj6al7AGLI4kLW0ctnJMZ5EISRJaLtVqqPpnYJ2YMQ7MHscJ7qKTTPz13+AJJ3n3nbASTh47jtLxE9DCLgB9GvQPYAFoQ51KaQ3RYtJHIszMSWZWlqUwi+pmLCGA20agjWxjVIxjPRVmBrewNItkbZ3IjZnJCtyAoiudYHDLxIkTOHH8GE5q7o6P0P0worgRR+IKM8mZswa0h0I5Un8Hbrg6n7GNK6RzQmpTT1duludyxQstMjDGa82733cn7n3vaxGMjLTYy5t5BrJhYP369dk46oEXPWfoWbUHrr1Lz0DmDPARJHOf3qFnIFMGdEHVhTVTp8PizM+zzID+zlrHUlkx4ELAT0bX/MT1eO3rbsTYKLPLAZ/P9IffRgKoRFIAN9EahavE1ElSEmoXpI8R8i6rZF8JrhJ//eq9vvaewEXBrjIHNxSdR8mAasZtBLj2AKpBMqFSdmYGt7A0k5zAaQFV3UbCFJAa8VKWKTh/1FOE8xFvqTejMoa5NoMWc7KkGLFNVDP35xAJB+JE/xOAOBJXodEqsVfJauj8qYEVyRLV5kCdq8cli9bWsDUzb1VmYJRJv645uvboGlRu8IJnoIcM6N6t5F+ftPdwmK5d61lVsXbtyDvwDPSYgaDH/r17z0DHDOgiqgu+LqgdOxnyjn761QzoWNKfklRri1BLZz9ehhLEDqGUUJjKh5lumymOlYAirkt27QE1BGUls/pbd/mLEt7QfaoNt7AfV9AaCIByGcnGupkBKh2oZ91oa6yDMI5RKzud9LJV6ewDmORGkF3SXpbl3TgU+zudwWgDghIA4xoAbIMZIrBelqmDwE/zEx0qi7gWP+JGZmU5oA8h6VNbyjhGGJeRV42VRqSt2KTbvIwyd+1wAb94BqaNAd2zde/Oe/KfEKJYFXNS96VnII8M8A6bn7D0Fe9G0EmVn2ibR6ILQLdQEtx8pMYW8tFtHNPdP0n8O7ng6zgRGh1LrbTJh9CY3d63KgahlZhrbJDXuubTe+bqjyBO9G0AHWOtHtf1PXltERkwJkTGiVUgiYpYLwlMRs0ivYH/KJvFZVwfP30hFr72VRg/bwmU3EaJbfR194mghIPbtuPlf34QJ/cdVA8CBH0AMFNJqKwFKvpAbXE9iBNyM7ZT59pi2Yw6gXpKk7dqawYAZuxdF1EbDUALmJkUrjSTrKrBEC3H9+/HS99+EPvJwUT8ZwAJPyXWZ5Kzxbe/CjPIIQKDcxFtKBvAFaxzhRZXpWDQP3BbH/DLQDOg+4au38JAT2SAg2/1npmFne7RulcP4v5WzIpdc8iCi1Z96Hk/L4dXqzEPk12e9k9uXgBs3LgR69ata4g1a9bAjDd4QidXXg7yenFoJyvGblHPd7s6JdHdxjHd/RVzO/PUg4H6mBl0nAjNjqdm7fIhmJlLpNuJp1vbbObT+HxqNv9etie8mk0/t8m+0fHSynEtu6RPHss5c2bhggvPwqmnzoYxQA90xQPcQha5wnmKtq4KOE1Z5vEruQIDVYRhfPECzL/9JoyfuwQTFlbhBJPcg9t2Ys+3v4+Trxxw9mbqGwOo6AAEMJgRklU6UKuk38lsS0pZS5YtUnoDqK4PoKIHQFOYGdw/lVXQuGyhDoSZISC4sio9AOMqhQQAZk4hweHE/gPY/Z3v48D2HRAXtfyIs4VrbnEcmiV9XVdULWyic5QBLVKqnBqy8ADa5UDXGF1r5s6djelcdJ3WdVj3jeS+ZNa/e8d0zj1vY2lfTBe0z/M2/3bj0Rymiy+N0258vbLPKgfSnIqEXvHdid+gk0556KObgJlBiVIe4vEx9I8BXRz0YKCXSL2KIjneNFavxkj8aoxM5pM4zHmZcOvP5c521BVXX4T//ge/glffdlVnDnyvGgZC1gUWtasypjhtMpamdt6HUAvq9dX/6G/b4X7kboJJfwVAiXdfSxJ4GMwIGHsaLNYDAYwy4jZLZNajpNtgJtAOBukEM+oC6mivbwZI50rq9OORaRh1DrQ1oVynD9URwPWXXn5TkN7MAMKcbSJHJWK9SmhhHWyCK81x4H4XIQA5EviiJMWTOFS3xL66VAudcZXkIDmBU/hNlgzoGvM//r9fha45WfqdypfuCWbmPhiqd39P7h26Z07lw+s9A54Bz4BnYDIDvO1OVg6SRomSbhKDFLOPNTsGdOPXQ0B2Hht70lgas7FV563yrTE691DpOWiSP5c722OnnjYHl115IRYsOq0zB75XZwy4RNOYkxKIAJbgoprEKLlVUqvkNo0Qk5JbdlA/M4s9GMzqIaC+AiX2Zomd9MaEPSrN0vpanYGOuFo1oLpsBcqBOTvQl2BmMPcyIKCeKMvGutGEOrNYVgkuKgWJKgU4DqKXImluKLNZenEUOl/qR3sWYFtp94lXAAAQAElEQVQEClylcvVqARUd/JIRAwsWnuquNbrmZORySje6F+qeMKVBqkH3TNmnVF70DHgGPAOegQYM8E7doHVAmnST8C8BBmRnZRimbvi68WfosiVXGlNjt2TchpF8yncbXRqZDmSbP5cHcrcVJui6n/sryUygmaZl1cswl3OaGUCEMPe1/5OsnrQQUYlyqd8FMDNa0ZxbJ7k6JZUJ2BZIjhNtJ7MOwiyydTrXrnrAprgs61QXkjbJ9aB2Id2mukAd/SFgqXFVCpITqJ0yA+BqnFgCgIpJEAfVvBj5IVf6FgC7hgSIkD7FJ1jCLVSyDAm/Fo8BPc+1ey+UvfoVjw0/I8+AZ8AzkD0DQfYu++NRyVN/Rvaj9osB3fCLNHa28+kXM92P68/l7jn0HpoxUJ06qibU6xWlmtEWSJeSYygxjcXEJmS9+hsAIfSpdoKQfYz+DIHbmqkGmLEUynq2u6/XR1/FN8mEPvkXXJ2Jd0VWf9lGcO20r1eqTxpGPw6yr5Vjnezr+Yr6cWy9FGBfcA6CWayzaG7SgTKo159BJHxUSrgXJ6qHskP1ErIf0vq0XG0a1Zq1Y6o9H3X32+lnQC+COxm1036djOX7eAY8A56BQWYgGOTg07Hr78P82980I8WW85AkZhlDlr7cnh/gjT+XO9t5N9x8KW6/83rMmj2jMwdD3Ks6R2SNq+hQrgm3cTVEcqpRbWlAbcatOVslsRFKVcm/dCFNAN6Ck/6UjUk2CJVmBivLAYxJtdkIjIiScMrBCNzf81On9kQOnF7tQdTOvkEZ6jMZ5vrUs0/pLGAcI4RKwtUDgL5hhqhkXTJhfBkA1yadYI4XZ8t2cSAuqmDxixKW+oZAYhuVgCthCNkfDgDoFrUyUovaUlUvtsfArNkz3bXlel5j2uvZvnW390L/HNg+576HZ8AzMHwM8I5cnEl3e+MoDhPFn0kePi3P8kEj6/kM+hHgz+X29+A73n07fv6X34FTT5uLKBliVqTEx6MlPszEFwAWbuPqrsIqS9XBhaUZ6xKJymowiwALoM+V079ur//eLo3Q4Oy55WqRzH5msczE2Vydt2mVqhNK5NPJumRz+hEELomPSqfji4G0birZ1G8k6le2SfrGetlECBCVqRcBHN/qgIZubjAD9DJAZQr1vwGgFwBwL0zEUaUf4PwYEAYAWDpo43wCcKUagLLsdACkdjIFX5KP1nk45dQ5+NC/fjvuec8dyPvi7x1530M+Ps+AZyAPDOg2moc4MolBnxxm4sg7yTUDWSbe3UxUx1sWsWTho2YevuoZ8Az0gAGmTC6PlGvJYM1SUB3xouS1/AKAd9qybExwCffpdqqvWeIpqGilc5COsBSUcLMeMFG3WLaULH1AfaDk3iHVl/0sgbMJELBeBnXmMAKjPpLZ3+lqSrULanOxch41JVgHjCsBLVEpDmp5cf9zAvmRXl1k7Ur5cHAaOJ3bRL70wiUB/DKwDHT7Mlz35YGdvA/cM+AZ8AxMEwNBFuOsXr06Czfeh2egJQZ8wtyMpsFv9w9xg78PizaDKM1Mz2qyJt2qZPRkEMKBCe0JymmUqEvszSWygJkkAxBEsupMrgOWgpk5vUvUaePKwOBK2TEJd7LKGhhfDgQ1OldP+qXarEZXrksfw4yxsI+ZSoJ6UJ4EqM0AtYFLuQTEQZqTalntcN+kYC+3ilMn0B3ADVcVTkZqkT5V9eJwMeCfEYZrf/vZegY8A+0zELTfZXKPvLwAWLVq1eTgvMYz0EMG8nLsV03RVzJlIIt97K9Nme6SHjpT5phGe0NFPY05qUHfAFDyf2IkxImREqGyAn393eheYOH6SDYzmBEIWAqUmVzbJEgvBCgn/bRxclym+7hk330TYARBuWRfJvHqYywTBJSdzgIY4WTqXDvrxpcOZhqbkD6RTfbUlesGUOYmLlhHtCiZ16f9Jxw/FV5OBOSKL0vEnb4hAHaRraCeUUmlKoTqguxY9atnwDPgGfAMeAY8A00YCJq0t9ScxQNySwM1McpLHE3C9M0FYWDt2rW5nIkPKnsGuk3gp+vadNHF5+A//dYHsPqOa7MnYcg8VlLMNifuslHw023gJJNbJbIqq37ojgmuPv2Gs7Uod41ljWZGncAWSpWtdOUkO4BJRk3pEvJIp8S9FchPYifZ5EOQf5WCZI2fyEkpHdvgSgNimQIA1QVwYcmtW2NRHNTyMkHOpBNnYepbEq5feePIiugr6ypC1Mp6PA6lqrXcXqX1lXoMrH7tdVj7Xz4AXVvqtXudZ8Az4BnwDAweA0FWIXf7gJxFHP7HX7Jg0fsYcAZ8+D1goNtrS7f9W53S4tPn401vfw1WXLas1S7erikD6SwykmfOW4R5F6zEvPOJZSswb+kKzF96Ceaddwnmn3cx5p+7HPPnn4N5h2dj/sGZWHBgFqFyJhYeiLBodDEWn3lhFU5n/fSzLsIZLJeceREcWD9TOHs5zj4rwjmUzzn7Ypx71sU4j+V5Z13iyqWUl1JedvYlOJ9lggsoCxeyvKgKK3DBWStwvuyJZedcAmHpORfj3HMvxjnnLcc5nMtZ512Es869CGcuvQhLiNOXXghh8bILsWjZBVhw/vkO81jOO38ZTotxygVLMfeC8zCHmO1wLmZdeC5mEjMuPAdj808F830EzMiTXF+f+usFwMQoEJ63GKVLz8XE5cSV5+IkceKq83D86qU4fg3La5dhYslpiBaLCrc16BsYTvSbrhi4ZOVSd005/YwFXfnxnT0DngHPgGcgPwwEWYUyXQ+4U8XrP42dihmv7wUDOt76fczXn5fX9oIBfYLf6UtOHSu9iKmxTyVDHkA9DsClnj7Rsdmt6bpkp+TGsODiq3HJ2z6IS976flzy5p/DJW/6Wax4w89g5d3vw8rX/xQuveu9uOySn8AVO5bgqmcX4+pNi4jFuPaZxbiOuP6Z03HdnOtw7ap7cJ1w2724ftU7cf1t78RNr7kXN7O8hbpXUfdq4tZV78Jtt70Lq1a9B2sc3os7Vr0Xr131k7iTuIt43aqfwuuJu4k33PZTeNOq9+HNt/003nLb+/CW17wPbyPeTtxz6/twL/HOGO+g7VtX/xTetPon8YY178Xdt78Xryfueu17cMed78bquzgucdvr3oVb73onbnndPbjxDffgujfeg2vf+HZc/aa344o3vQ0r3/IWrHjLm3HJW96Ei4kL3/pGLHvbG3DO2+/G2e+4G2e+43U4457X4/R7XoeF996F+e+6E6defCHmHB/BrBMjmDERYJTZvzFz54qJ8RGU7roGE//yThz7V3fi6C+/Dod/7fU49G/vxoFfvxuv/MYbsf/fvxHHblkOuP2MeEn2lcpWoa6t2g6bnbjx8Ax4BjwDnoEiMZDZC4DVq1ejPw+6cOP6ZKxIh2X+55Lb4y3/1A1shPphqXZfAsi+H8fKa193Az70r96KxWfMH1i+exe4ErhWvPNj6SqzSr+RsXGMzTkF47NPceWYyhjjs+ZibPZcjI/PwvjJEYyfCFw5g+UMJrrjxAzK4zYD4zPnYEYtZs3BTOpmzpzLMgX6nUVdPcymXkjaZtNW9QinYM7MasytqUd2c+FK9p1VxhzMYjyzOJ+Zs+cgwQzqZsyezfnPgeRxymNsH1M5Zw7nPxtjcyKMshyZMwujc2dDZYKAOhsbhRJ+A1gSJbjFMW/Uzh4HTp2NkCidOgvhabNQcpiN0rwI4cxR9nE9WLIPt+2vnfZrf6RB6bHo9HnuGvLa1904KCH7OD0DngHPgGegRQYyewGg8fSgO90vAfr1gK35egwfAzre1q9fn9uJ+8B6y0A7LwF0rMi+txHV937jLZfhbfeuxrx5c+sbeG2fGEgSVQ2fllUX6umkzzEa5c6tTkd2CSChtfnqmwJTWrbuZkoXw9wwb94peOs9q3DTqy4bZhr83D0DngHPQCEZyPQFgBjSSwAlSNPxIkBj9OsBW3P1GC4GkoRO33bJ6cx9WNPAgK45uvY0Gkrtsmtk49vyyEBGWaPcCHWnmG6QLMgwKSULqguSBxBhb2NX8q8fEVTp2Kk3XD0djRu9s2CzXz0DngHPgGfAM1BoBjJ/ASC2lCDpRYAeggUlTtJ3C/kR9IIh5MOFxujWp+/vGZiKAR1rgo43If8J3VQz8fqsGdC1R9eg5Pqm40TQcSK92rMes11/py+Zj5/+wN149W1Xttt16O3LCWKSQKoUxAzvPSq6Q+IM8efdlXp3fvvQu2HobBRfabgZU69ykj6JX+2JDPcX/uV9gmgxmpRBldrLUBt19VbZ1NN7XYWBV73mCvzMB+/G6Uv8D/9VWPGSZ8Az4BkoDgNBL6eih2BBiZMeiruF/Ah6wdBu3Ek/M4NZY6xbt65d97m213zMGs/ZzKB9JeR6MhkG1+x41DEj6HgT2hk66WfWnPc1a9a043pq24K1mDXnzsz6etzqfNG+TtDucdLLXbb49Pn4mQ+8AXqYNw7kAUzFAeIlaY+rkX05maSQNGRShkyB5bNSRq8DIl0yhGJK5Eal7BI0skvaZJvIlbK+ttJeR2raJZ6Pkn3OOJmjZu3kRC+zsvumTp1lwI//9RLAuZXG+ZIQQV5qoZZana8jOtYBV77qNVe6a8fp/jdE4JfpY0D3Ud1DzQxm+YLu9cL0sTHYI23cuLGlfaj97Xntz77u6QuA/kypelQdWGYGJVk6IKtbfS3NwDq++BDMoqQq3ebl1hhIbmD9ON5ai7B4VjpmBZ3r4r94M/Qzmj4GbIqhqrLTujblhDbd2rxb2nqSPFU0kwyp0FAJWO1wlYcOuybd5EJQXWWC2rr00tVFw8Y6PWifJP8U6xh4lWfAM5BTBnTfViKY5+cmPWMI/jkj24NIeZl4NfN5R7bMNvdW6BcAuqDowGpOg7eoZUC86UJXq/f1qRkQX328gU0d2JC06JgV/9oPQzLlFqfZThrZosuCmVUzVF2rmqqSS6FKWVupY1BHVdurXr22m+qCbNNlIkufNeRbmOQ3USblJIN2FA04d240iOAqkzeuKe0jLdPctbP0q2fAM5ArBnS/1n1biWCuApsiGP+cMQUxGajFrZlBL4QycOddNGGgsC8AdFEZlAtKk33Ut2adjOKxbwEM0MDiSXz1L2Q/csKA9oO/gSRsALNmz8T8BadidGwMgBIjj3o8WJkbcLHJSCWRE8eP4cSh/ThOnDh0gHKE45SrcPgAbQ7iOMtjbDvG0smHD+JYjKMqj7AeQ/WjlBMciWWVR44cwJGjB3BYJXGYclrn9NQdZh+1OdDuEHVpHGRdSHTO7uhB+k2BcR0mjhw+hCOuPMjyEI6yfuzQIaRxnPUTBw+Rh0Oc7yFXujp1J4mJg4dx8sAhqJw4cNiVJZa1CGkT7j8MECoF7D8Ee+UwcQS27zCCfUcIlcTew7CjJ6J95faP9hurbpVMhER533oZDbjQNULXCl0z4BfPQI8ZGOTnJv+c0buDQ8dF77x7FEM6FQAAEABJREFUzwkDhXwBoINHJ2cySV92zoB49MlUY/5ycbw1DnHoWrVPhm7SU0z4rjfchP/0X96P8y84cwoLr04YUHqYyNHflSurJLg6vb5mTux54mE88ck/wROfjvGZP8Xjn/0zPPa5P8ej9/+Fw4++8Jd45At/hYe/+Jf4wZf+Cj/4+w/j+3//ETz05QgPfuUj+O4/RPgOy28T3/rHj+CbxD8R3/jqR/D1GBtYCuu/9hF8jfLXWH71gY/gH4kvr/8I/l7Y8BF8ifgi5fs3fBifW0+w/OzGD+MzxKeJTxIf//qHIXyMpSDdZ9f/NT73wF/jfuKLX/tr/P1X/wZf+ceP4mtf/lus//JHsfFLf4uvf+nv8E/EN7/wMXzn/o/he5//OB767Mfx/c9+Aj/89Cfx6Kc+icc++Sk88Qnh03jqE5/Bpo9/Blv/9nPY9tHPYsdHP4fn/vpzeP6vP48XP/x5vPyX92PvX3wB+/7ifuz/s/tx8E/vx+E/vh/H//f9OPEHX8DE79+P8Pe+gOB3voDx//FFzPh/voBZ/+0LmPNf78cpv30/TvutzzvM+KenAe6TaP9wG6Kc4qJqqdq7VS2+EjGw7PwlvFZ8AK97482Rwm89Az1kQM+XPXTfc9f65kLPBxnCAfTh7erVq4dw5tM75UK+ABj0i8r0HgLNR7vvvvuaG3mLvjLgB69mQDcQf9xGnJy79Axcf9NKnHLqnEjhty0zwFyyru3Rfbux79nHsHcToXLzY9iz+fEyXt7yOCI8gd1bn8BLWwiV257Ai1ufxIssd217EgleoJzg+e1PQniOpbCT5c4dT2IHSwfK22NsYylsZbmFcOXOJ7GF2Ew8u/MJJNj03BMQnmH5dAqbZMe+m4ktO57Clu0RtjGmHduewo6tT2NnjOe2PI3ntzyFF1i+uPlpODz7DHYTezZtgrCX5d5nNmHf05vwytPP4oDw1GYcfPJZHCIOP/EsDj++GUcf34Kjj23G8ce2EJtx4sebcfLHWzDx6BaEP4qAH26G/XALgoe3YOThrRj9wVaMfX8rxh9KQP0L+/gCINlNqT2WEpNWXzZmQNeI625cAV0zGlv6Vs9AdwwU5f5clHl0tzez761nuA0bNmTv2HssM1C4FwD33XdfeXJeyIYBfyJOzaMuUDl44TR1gEPcon0zxNOvmrqZYWxsBKOjI1X64a1Yy1OvzSNV1/8gknzqLFlAWIJKgQLCkupCiNC1lVAqTSB0KMWl6pJLqbYJJ8tWiOwnEIYTKAmuP2WWap8SsuW4pQSMpzQJsR9nG8v0GzooJiLuH7q+sikhkqPS2U4kcnWJsn7C9VE/AfSlfiodaKcyaZOMEpnWJ/tESNAB0jr3DQ2auFJ7UzYqBelVtoTWj4WW3A2oka4NukbwUjGgM/BhDxIDRXlu8s8ZvTvqfD7XO27luXAvADQpj+wZ8CdifU7zcfGvH9uwa/2Lq8oRsHDxafg3/+G9eMd7bq8ovTQFA6mEUImkoCxTpYM2QJSUVuSozgSYiagSWdVDJs+SEZeSQyXbcYKtesnJTJClp12JcP3iUvWSS5jpWyX1JWc7wXy4grCOrp5dta5EH4T8EhqnDI4jn2ESnytLCKWnbUiUCFdPdEzknU56hwmEExOAk9mXZSRTT1k+hEhXiu30woS86gUAERJw4O4itwwA2h1RSTuuTmaz9Km9J80kNGuf1GFIFG9/9xp3jVh0+rwhmbGfZr8YKNLzpH/O6N1RJG575917LtwLgKK8VfSHpmegZQa84ZQM+Bc0ETWzZ8/Ezbdejte/6RbccdcN8A/54qV+Khhpo62s6kJJpxpUKimlrEJQshpScGDiGrrkmEmtEl4nR4mwEmUhpL5EvWTB1aVLQT7UNhXq9ZnKtpG+7GeKeNJxyDYN+VW98ql/NE/pQr4YAOcjqK4yjUhHMslXpI/k0NUlJwSrFKjjSqmy1tbLLdqXAtxvA6BqifRVqiGr6Fqga8Ldb34VbnnNFdC1Ysgo8NP1DHgGcsqAf4br3Y4p3AuAVatW9Y6tNjwX7QcsijafNnZl7k19gJ6BVhm47fZr8F9/95ew8rJl7KLkZ5hBClxKOJkDq9GHri57wbSBPm0OKTHXdzJFfhDNRJ8KrlDyGkpgEhsy+ZUcUi4RTmaSHSZQu/QsSzFClgmcjrZ6URD14TjOPipLlBOElFsG4wsJ+U0QcpwwHrvKp+wa+q5O+CMfUXyh+k1QdqAdSxBhDLBdkJ3KKiQky4YxiPcK4n3h9o9kIiSSelpOdFWl9lrKvqptOPQrLl2G3/5fvwhdG8SGR/4Y8M9f+dsn6Yh8kppmI1vZH/vZ8pn2VrgXAEX6alF6R3k5nwzk4OKUT2JyEpW/HlTviJGRAOPjYxgZ8b8FUM1MdU05J1wyiGihgqvLO90mqSghpUWoMobkkEk0WFcZgckvdWU5TrCjOhPiKlvVpwD7lYhQKPurtk0S+ZZK+nH+3PiKMUGJOXiJU0iBtpV4a/RqY4IeJpA/p6NdTUnHSOwkC+U6XwioXgb9OFmlOKd/JLIrqeRqAveDShbRSl0kRFuLCr+tYWCkfE0o3ONgzUwHs5qXD7WyZM8nzFmyWe2rSM88RTz2q/dWf2v+it8j/ot0Eoqios1Hc8oCegHQ34tUFrMopo+1a9cWc2Jdzko/9HXp5edj+SXndulpyLrXJJTl2SsRVUWloDcELJUsw5VKqqO/b3fJbJIQK4Gn7BJwlmENpE/DtasPUU7u2Sdt05bc0A9jruPbxUB9vRLUC27eTo58SJeG+qbrkUxyXR/xJDkFcgiqxaWojcB2cU6Uk/6KCs6GbX5tzICuAZdecb77gdDGlr61XwzoGaNfY/txB4+BIh0vRZpLHo+kwr0A0AHT74SsaIlH0eaT9YnY15cjWU+mQP78fqm/M2fNnol/+Stvw0/93OvqG3it++y/7ifGTDKZ1pIhCsoy40LJachENYHqQlJvXvKTcibkYQMo6a9qZ8JcVW/Qt65d0/6caWpOoWR+Ah8mUL0GJdVdO+dD/6AsuD5qI8RLGmpDYlunvWJL2rXKxpVA3eQf6aXuXkwbDLX8k//iLvzCr7wds+fMGmoe8jx5fx/L897JZ2xr167NZ2BtRuWP/TYJa9O8cC8ANH99vahfLwF04hXpoBWPRZqPjo+s0c+XTlnPpSj+dB4WZS5ZzyMIDKfNm4tTTp2NcqarPGnowAlzbZsDQKk/oj8v5xsAl4WypD5amThDoJ1LVtWmeg3Y5pLqFkvU2rkxany2q6v12Uo9GaOOrWIUauclXRrp9khP5ugvksmXZI7jdg+r5uSQCT9BU1GuNorRqooQ1VC7T91/baf2SaCCa639sNR1DdC1QNcE+CV3DPj7WO52yUAEpGd2PbsPRLBTBLl+/fopWrw6KwYK+QJA5OgEUDmd0AnXj3F7NUfNRy9TeuW/SH7Fk/ia5jn54eowoIemIp2HdaaYiWr+glNw+VUXuJcBmTgcSCfK/hoF3qy9Ud/QNbpc1knaSDcZSuP5uoAGSRvFmjVpaVTWdKlTrd9b49dDdUxxX07IJfBMyuu1y0+dgcum7B7L9Fep1O3ihkhaaJ6IrZXRvou29XpM3VLPukg6Jf0693UNKNK8ijQXfx8r0t6c/rkM8jOpjn19sDb9rA3XiIV9AaCDRw8pOpCmY5dqHJ1w0zHWdIyhZLZI85kOzsSXjoPpGCsaw29rGRD/PvmvZaV+/cZbLsXv/tG/wTXXX1zfYGi0zRLBKdqZkCp/dXBcUaGMNS4kJp9o617UCLKrbi9R1T5KYQmNEbJ9MqrHDjl2Y9AAdAR9fb8KjgwSUFOm/aPcRtJoGvGUyFSoPf7TgSpbmpRtJafBbq6trJtin7XcXjYspKBz/n/94a/hplddVsj5Dfqk9Omnv48N+l7sf/yD9kyqvMMf+9N33BT2BUBCoS6iSgqERJdlWbQDNpmPLhxZ8jQsvnp9vFXx6CuOAR2zOr+VZIh/p/SbpgzMPWU2zr/wLJzCEsPynee68wSXJGFMl0ZrY5tWlQ0QGnNVtrOsTkTVl5iUoFKXWtWcqjYROQ4jQxngIh2Lsk51QbreoG7MUqaQiC1FkBiLw6p5qDfnUqtXPUGVPW3VhTojnOhKo5iA4iRd0lb8cu7c6NzXNUBMePSfgfR9TB9g9T8iH0ERGNAzkZ6PhLzOJzn2lXf4Y3/69lLPXwAkO1QHoTB9U6uMpHEFJQh6u5QV5C+ZX2W0/Ek68VuZ86DMJyuGdaFpBB0zgvZxO2OqjyA+W+G9U5u89tPx1g5fU9m2Oj/tH/E9lZ9e6jW2oPGFXo7VK9+LTp+H08+YjyDo+e2gV1Po0q8SPrmoLaUD00SrgjQRMGlRDjtJmVbIwMHgXhQ4mQYs9cF3c+hFA7tW2Se6yT5rx2hUbz529biNfKmNIbJDNDfVW0O9OcQ6uiqvznm5Fgu0455CDNXglorkqm5TT+caCr0xM3eu65w3Ky4HuhY3ure30qbrehYHwyDcx7KY53T7UNLYKreN7LKIe926dWjlmOrWRse10O6xqT5Cq8+k4rZbXuSjEe/pNs1H8bU7pvqJU/UV2u0/7PY9e+LTzjAzrFmzBhs3bsQ6niCCmUFt/SJeB0tW6NccOhm3lTl34neQ++i4bAQdr4KOYbPOjttWeO/QZlpuOJ3GlsVx0erYWYzVro/kxqNjQ9BxIphFx0k/r3HtzCUIDP/iQ2/EB3/pzZgxPhqnThjC0jhnofu5Q4sS1CngfsCO2XZUAu2VIe2nBui3Gmg5CW8aB13ZFKB60trUXwjOJQWA+2AKNLW1cl891AgGlHUV2agT6rUVXzdzxhg+8Itv5jn/Br7wMxR1aXRfb6ctC37yfB/LYn799NEqt43ssoq/neOqU1s9Ywh65tAzhtBu/I24SLe167eefdpfI7le36l0ybOXmeUuv5wq5rzqdZ/MNLZk5+ggncqx2swMsp3Kxus9A3ljQMdtJxfc3szDe+0XAzoGdAPWTbxeDDpOBNnVa8+Tzsyw9PwluO32a/AzH7wbl6w8L0/h5TKW4qZNuaQ7eoHRMLTKHqlIDTsMZaPObZ3jq+64BssuOBNmnq2hPBD8pAvBgJ4xhEF4zsiKcOWMjZ69NI44Wb16tUSPJgxk+gKglZ2Tjkc7Un3SOi97BvLMQG4uLnkmqcCx6WarY6CVKcpO9q3Y9ttmxaVL8R/W/Qyuu3FFv0Pp8/hKihJMHUpkEW0Bc/9QXqws1RP4YXb52/D12nOrSweekvWlg/KEUvrMdJMIEb8VVKRJhrGiuUVsWOji2hsucee4zvVCT9RPzjMwRAwM0nNGN7tFz1LKGVvxoQ9nzPyHzM24yvQFgHZQswFr21vdobX9fN0z0C8GdHHp5FjPMl7va/oZ0D7XzbadkWWvfu308baDw0CSWipic68BtEVZUi0B/NIiA0a7RmAz18SCol89A54Bz8DQMjAMzwxwHJwAABAASURBVBmaY7s72D97NWYssxcAIlqJUePh6reqb/0Wr/UM5JMBXYz6+O2VfJJS8Ki0zzuZYqf9Ohmr2z76lFBfEZ41a0a3rnz/JgwogW1i4punYMBzNwUxddQ6l3VO+2/31CHHqzwDBWFgkJ4z2qW80xxROal/Tp+a7cxeAHRz8HXTd+qp+RbPQG8Z6PSi1H1U3sN0M9Dtvh6Um9A9770dv/hr78DCxacV+kfCWjt+sk0zreZ7AWC9CKidV7N68znDLcbtVGBTi6s8tGhaQDP9yOeCRafiF3/1HdC5XcAp+il5BjwDMQOD8pwRh9ty0U2O2O2zW8tBDqBhJi8AsiC4qAfuAB4TPuS8M+Djm3YGurkBKdgsrpHyMx1YfvG5WPd/fxB33HUDh1MC5YGCJOt5mIeRy1aQh1gHPYbb77we//m/fQjLLzkXfvEMeAaKzcAgPWe0uie6nZP/FsDUTGfyAmBq9623+BcArXPlLfPBQL8uLPmYvY+iHQZ0rLRj309bfWJ4x13X43VvvBmvuu0KzJk7q5/h9Hls4/i1oMqvOWSgdj+pnsMwpyEknbO3vOZyvP5Nt/BF3vXQOT0Nw/ohPAMtMeB/pb0lmto2GqTnjLYn10UHn1/WJ8+/AKjPi9d6BvLKgI/LMzAtDLzlntvw67/5k1hy5oJpGW9wBlFiWYvBib4Ykdbyr3oxZpbFLM5YssCduzqHs/DnfXTGwKpVqzrr6Hs1ZcC/RGhKUccGeeLWJ+8d78amHTN5AeB3UFOevUFBGZj+C2VBicz5tLp9kOu2fz/oGR0bwYwZYwiCTG4TKPaiBNQDmC4O4JcGDASB8dwdh87hBma+qccM5On5IItY1q5dmwljWcSSSSAFdJKXfMzv4/wfXEH+Q/QRegbyyUBWN8O2ZueNB5KBQb0Zzp4zE1ddtxznLj19IHn3QXsGho0Bnas6Z/VnAMM2dz/fxgzk5UV0FvfDbv82vDFTw92q/dPtsSIfw81i/mfvXwDkfx/5CHPKQD9uQDmlovBhdbuvu+3fL4LPOXcx/s/7fhpvfOur+xWCH9cz4Blog4E3vOXV+I/rfgY6d9vo5k0zZkAfEOTtut9tPN32T1MsftL1duRu+rYzzjDbdrOvtX/8C4D8Hz3+BUD+95GPMIcM6ALXh7D8kH1iQDezTvd5p/36NNWqYUfHRt0PiN35hpvwS//mHTj73Cy/CaCvi1cN10ElCx8dDNvzLlnMKwsfPZ9oBwNkMa8sfHQQeg+76NzUf+F51xtvcues//p/D8luwbXuGS2YTauJYur0ftRpv6kmqASz00+Z1Xcqv16fDQM6VjrdP+qbTRTeSy8ZCHrp3Pv2DBSRAd0I+3MDKiKbgzMn7fN2b4hFOVauuf5i/PQHXg/9svhZZy/mTlMC1S3opuu/Gc/CR7fz6EX/LOaVhY9ezK1bn1nMKwsf3c4ju/46J2++9XJ3jupc1ew8+seArvt5TYLydB9TLO3upfXr17fbxdt3yIB+T6CTZ568Hvsd0lDYbv4FQGF3rZ9YLxjQjb2Tm1YmsXgnfWdAN0QdA60EIrsiHSsLF56GX/1378Q73rO6lel7G8+AZ2CaGHj7u1fh137jnVi06LRpGtEPMxUDg3Ddz8t9TImiEvpWk0zZqs9U3Ht99gzoWGln/xTpmSd7NvPl0b8AyNf+8NHklAFdAHXz6efFLafUDF1YOgb0kKdjot7kpS/isaKvFJ9z3ulYtHhevWl7nWfAM9AnBnRO6tzUOdqnEIZ+2EG77if3sal23HTNRwm9kkzdU6eKRW1hGEK2U9l4fe8YaLZ/kmPF75/e7YNeeM7VCwAdZM3QCxL64bPZPJP2LGJLfDUrsxirWx/NYlR7t2Mk/XXRagbdeJTMadxOLm7qJyRjdlF23VVxTBe6DnaaHCR8tDucHp7UV8eGjhEdR5IF6Ts5VtqNoV/2p5w6G0o2Zs2a0a8Q/LieAc8AGdA5qHNR5ySrfs2QAV3Tm0HXfl3zhU6v++qXYdhtudJ9TIm14tdcNF/JguLq5D6mfm0FERsnsSgOIYlF8aktNvNFnxjQPtC+0LFRu3+0zzs5Vvo0lZ4NKx6aoWeDd+A4Ny8ANm7ciDVr1jSFmbm3gDoYO5hv37sobp0orcxVNuKl26DlQ76awcyg+IRux2ynv04YcWJmTfe/5rBu3bp23E9pq3GbQVwotimd1GmQT/Uxq8zHLOK2jnmLqs7M6sUiDnuJrPZPZzNu3qseJ2bR/tH+bu6hYqH9rD6JT9UrrcWUXrPmKvz27/w8Vl62tOu/4M/ur6DhYwE8B8BQcbDi0vPwX/7nz+O226+GX7JlQNdyXdcbQdd+2QntjC6f6mMWPSOYGcyie1A7frKyVSyaSxKX6u34TvqZdT8fxSEkPtuJw9v2ngEdG37/VHhOjlOz6Nhv9mytfKzSu79Sbl4AtEODCFSSoQNR5LfTt1+2ilPxKm7F3684mo2r+ASd4M1ss2gXJzph8sxJO/MUb1PNR7yadXiTbycI2ibH21Sx0GQo12b7R/tINkNJTouTXnz6PFx/80q84z1r8Jo1PvGAXzwDfWDg1tVXuXPw+ptXQOdkH0LwQ7bJQLP7su4/ZuY+iGnTdV/MizafvpDoBx1IBpod+4MwqYF8AZAQq6RRCY52RKLLY6mEQnEq3jzGVy8m3YiUnNdry0on/4PESbN5az7irZmdbHRMNLNLt7cj63wYtOOtnfl1aivOxX2z/rLRvmxmN8zt+urxT/6LO/Gu992B+QtOwdj46DDT4efuGZg2BnSu6ZzTufdTP3cXZs+eOW1j+4E6Z6Cd+7LuQbpfdT5a73sWbT69Z8yPUBQG2jn28zzngX4BkBCrZEc7JKnnqVRcupjnKaZWY1Fy3qtESH7lv9VY8m6nm3U789ExoT4tzqstM50PbXUYAmNxLc5bnar2pY7RVu2H1U6fPv7PP/xlXHfjCoCfXHmY58EfBz09Bq694RL8j//9y7jhlpXwy+Aw0O59WfcrPT/mdYadzEf34bzOx8flGWiVgXaP/Vb9TrddIV4AiLS8XlgG/UBRIpQ1t/Inv9pvRYDmo5t1u3NRn9Zu8K17ViytWw+HpTgR1+3OVsdo1vun3Rjybn/GkgW47fZrcPdbbsEtt16OkdGRvIfs4/MMDCQDozy3dI7d/dZXYdUd10Dn3kBOZAiD1j2ok2nn9fmx0/l0ch/uhDffxzPQKwY6PfZ7FU83fgvzAiCPD+tFOVCyvmhn7a+bEyCLvt3Mp6VjpMUglax2E0uLwwyVWV4fwPK0E4LA8L73vw4f+MU3Yc6cmVA9T/H5WDwDg86AzqlZs2fg/b/wRvw0zzXVB31OwxK/7vHd3JfVP29cFW0+eePXx5NPBnQudnPs521WhXkBIGK1c1TmBUrI8hJLt3FkNZe87aN+89LKi6tWY8xqH7U63qDYdXvB9ry2tqcvu+oC/N+/94t41WuuaK2Dt/IMeAZaYkCf/Ovc0jnWUgdvVBgG8nb/6fYZLm/zKcyB4ifiGWiTgUK9AGhz7j03V3LX80GmaYBuL/rTFOa0D5PFzayJj5bnlJWflgccAMMsjtssfAwAVV2HeMaS+XjdG2/CXcT1N63AjBljXfv0DjwDw8yAziGdS3e98Wa8/k03Y8mZC4aZjoGce7cvoPUcmad7e7ex5G0+A3lQ+aD7wkC353Jfgm4waCYvAPLyY1m6sDSY67Q2dXuRnNZgp3Ewz8tkshtzMtl+Kk2ejv+pYvT64jPwzp+8Hf/6/7gH8+afUvzJ+hl6BnrIwGnz5uJf/dt34F0/dXsPR/GuPQOtM+CfM1rnylt6BvLMQKFeAOSZ6EGPLS8vefLGYxa8NPSRtwn7eDwDTRgY5yf/Ky5bin9/3/tw2+1X09o84DmA5wBog4PXrLka/2HdT2Pl5cugcwpDsqxatapQM81iPv4ZoVCHhJ/MgDKQxbmcp6ln8gIgTxPysXgGBo2BRl8xH7S5+Hg9A2Lg9DPm4633vgZ3veEmXHH1hZg9e4bUHp4Bz0ATBmbNGseVPGfuesON7hzSudSki2/uAQNZ3Ze7Td6LlnT0YFd5lwVmIIvzMAsfRaQ4kxcAusD5i1QRD4/KnPwJVOEiLXV77K9duzbtrlb2dc/AQDPw5nfcil//zffgDP+3ywO9H33w08fAGWcuxL/9j++Gzp3pGzU/I+XhWSPL+7KeEbpht9v+3Yzt+3oG+s2Ajv9u8sssz+U8XJuy3B+ZvABQQEUjRnPyiBjI8gSKPBZr282x37hvsXjysxk+BuaeMguXXrEMv/Crb8OqO/TnAMPHgZ+xZ6BVBvQnM7/4a2/DZVeej1NOnd1qt0LZdfvAnwUZWd6XNZ9On6GU+GQZSxbceB+egelmoJtzoJu+tfPs5lyu9ZWHemYvAIpGTB52Th5i0I0ryxMoD3PKOoZOj31x2zAW3+gZKAADCxedhnvfuwavf/MtWH7JOf7PAQqwT/0U/n/23vxLl+ao76wUIARiEasRq1jMKrCR0AaG2w1akBASYsfIYyMM2BjMjG3sOcdj+vacY/CcmUHMDzOD55/p9/5lPf3pfvPep5+nllwiq6Kyvu954z5PVUVEfuMbkZFZ2XexZYA/IvNDP/xdw2c+99HHucKcsR1hX974i3F5+d0CdYt1mT1USTzwsAUHGlMMeGLA0x67dC574jNiMTsAwCHEtGie+JaszwC5JKfrj7y/EeEJvlKRo4tNqr70xMDeGfjkpz80/NVf/8Hwvh98795DEf6jM2Ac//f9wHc8zo1PfubDxp73646X35KX5pqIW67LufHc3d3VhCJbMdAVA+yXmZ+pQaGLTap+jl7uXM7xvaau6QEAwCEc4vku2S8D5JBc7jeC9ZHDF7zNjcyGhoUd3Tk9PRMDvTHwTd/y9Y9/IeAX/+BTb//rAL1FqHiOwoBlnD9//Y8G5gR/WSZzxNL33n2x0V5aUy1iXGtdTokHLPf39wM/9bSITT7EQC8MsG9e6gfMnzX22Clz2Tvv5gcABEySaGAkCuGexD8DceKQO3LoH7E/hPAGf9Q9EhFGbmkaWtgjK/o8GgPf+J53D7/3zz8+fP43/8nwXd/zbcO73vXOo1GgePfPgEkE1D5zgLnwT//FJ4b3fNPXmfjtzcnpmso6ahkf/nhZWHNdHosHHEjEYhmjfImBnhg4nT9b77FPsTB/98ZzkwOASALkILwQLQmNL9p5/YyLBC9wIYQhhGm5vr42CQNelrizeh7jMwF+cCfUPRJzsxduLeoNHxbpD2F6foWQ9uz29rYayqtXr2bneghPWMg3Uj3gARzwU8+//ts/fvw3zh/YGyRiYD8M2CD98fe/b/iv/+cfD8yFA0z56hDprayjcU21+MQf+7kccNiABTuE70iOD3SxwRdx8Ingj2epEm2wQ/CJpNr3qAcnCHwgITzM1xnpkYNWMZ3yCrfUGtJqvDm/jIswf5CIbc6YNLXVAAAQAElEQVSm1TNwMD44lsTTQUHTA4BWZK/tl8RS7LzU8zKArI1B44kBMeCbgduHwwYkhDCwIPhGuy26b/v29wwf+tiPDb/xOy+G/+Ff/vLwz/7wU8P7fkB/N8Cg//wzUIGQGv/ilz71WPNf+O1fGD78sz82fPs/+KYKjzJdk4G4D6TPsw9E+I6EsF7fH9uTnmJh/UFnTW48jBXzo726bTaopcgtdRaFukdCWK/2bSM7tjcdACzkn0Yam8mCqh6LATEgBh4ZYFFkwXy80C+jDHzN13z18Ptf+uTw8n/70nDz3770+DL0te9+1xBCGNXXTTHggYESDCGEgdr+0Md+9KHW/+Cx5r/4cOjFHCjxJ5t1GeAFKIQw8OIzNzJ9nz3jnE7tM/wv7UnBgQ66tePtwZ78sN4u5WcPsXjDCLfU0hK31NxR6s1bjkrx6ABghjmKmaKeUdEjMSAGxMAoAyyYbEpGH+rmMwYe9taPPxX9o3/zq8NXf/VXPXumCzHgiIEiKNT0v/zTzw7//I8+PbzjHTrgKiJxI6P4ApQ6PHtG9o6p+jl6+MV/qg262KTq71Uv5QV1r7FtidtT7W/JQ69j6wBgJrM0z5nHeiQGxIAYmGWAQ4AjbMBmSUh4GEIYfvwn3zd8/NM/M/zab//8wG+VTjCTihhYmYH84ajlz//Wzw8f/8yHHms8BB0A5LO4nUVJ/2bvyMuTNWr85vrEpgWWXByt9Evy0wpLb345WMmNqfd6y+XDs/47PIPbEpuaypbsa2wx0A8DWhDTc/kTP/X9w19/+U+Gn3vx/seflPLT0hD0wpTOoDSbMpDoPITwun5/9hfeP/zN3/3J8P6H2h70364YYB/IIW4JaGxL7KZsavzV2E7h8XCfuFhfPWDpDQPclsZUY1s6puzyGdABwARnaioTxOi2GBAD2QxoQcyj7Le/+IvD3/1/fzF8+b//2+EXP/XBB2MOASTDIA625CB17OtPfuCxdqlfannQf7tkoOYn5xwc1NifE1azJwXLuT9di4E5BmrrzbL253DqWTkDOgAY4U6b9RFSdEsMiAExsBIDP/mPf3D47Bd+dvjVX/+54VOf/fDwkZ/78eHdX/c1K42uYcTAKAOLN6lRavWXP/uRx9qlfn/qp39w0U4KPhmofXG22kta+OnxhazmJdVnxflAZVErFjXrg41+UegAoN/cKrIZBjz9W5wzMPWoEwZqN5Kd0FAUxuceDgH+8r/83vDe7/zmInsZiQEbBpa9fMd7v3n4y//l94bP/cbPLStLwzUDvb3A9BaPxUuq6wLcEJy43ZD8hKGt/nJpHQAkkC0VMSAGxIAY2IaBd371Vw3f/4PvHf7iP/3W8IlP/8w2IDSqGFhggNr8H//n3xp+4Ie+c6BmF9T12DkDVptsL2FaxaMfnnjJaDscFrVi4aNdhNt59sSLmwMASKltLDc3N9tlVSPvigHqbVeAdwQWbmvn8o7CTYKq3pRE06TSN33z1w+/8msfGz79+Y8OH/7ZH3uU7/uB75jU1wMxYM3AmD9qMNbjL3/uI481+p5v/roxVd3bGQOsY7WQLXyAwcKPhQ+wWIgFFnxon2GRjUsfcHt5V3csGLDg1sIHsbg5AACMVVD4koiBOQZ6++1wc7Fu8UxzeQvW+x+Tn7L+3X//8wH5zd97MejvxBsGcTAMK3AwOsZv/O6Lx1qkHj/5mQ8P+q8vBmpfMK32GayntVjwYZGd2pgsD8OtYrLgpTcftfVWWye98RnjsahZCx/gcXUAUFMwNJUae8iQHIMBauUYkW4Xpebic+7Fx3M+Sq/4S9a+4zu/ZUBefPynh7/4j7/5+FuuS/3JTgykMfBc6/GPpDzU3tUnfvqxFqnHd3/du54r6Wr3DNT0bet9hhcsvHzUvBzWxHFeUJa+zn0f/bqGW+va7y0Xd3d3xSFZcuvqAABGSoOjKWEvEQNLDNQ0tiXfev6GgdK5/MZDH99qmn0fDLSJgn9X/Q//9WcH/p31H3v/9w0/+hPfO3zDN767zWDyemwGHqKntqgxao2a+9K/+pWBGnx4pP87ZYB9Zek6Zr3PAEvJizf4rbGU+gOLdam08GmNcY/+qLcSbqnR0vrYI08lmOEWnnJtyYclt+4OAAiOIHOIQR9Cc2yke0wG9DK2Xt5L5vJ66NYZSb2pLc9f87VfPfzJn39++PL/++eP8oEP/fDDgEGy1e+J73Tc4SEuautv/5+nOqPmvvbd7xr0X/8MlKxjrfYZ/O3sOS8O6ILfOkvst3NjZC1sgQWf+LaOUf6GoYRbbMTdMgMe5rK7AwBoo4BSJjTNjSaEPnYSMTDFQKwVFq4pHd23Z4C5mTKX7Ufe3qN6U/scfMVXvGP4ru/51uGHf+x7HuXXf+fF8Kf/0xceRT+dbc9/7yP8xE++j1p6lF//3RePNUatfff3fttA7fUev+J7YiB1HVtjn8GLQ8qaig66TxHY/8peijUuxTNY4DBFt0QH34xRYiubeQZSuaX27+/vB+pi3qOeRgaYnyl1iw660c7q0+UBAMFRdBQTgXN9KhQa9yFExXbKjL6fM0CtsEipVs6ZWe96bi6vh2Kdkag3ehO9S71pHc7jKCGE4bNf+NjwH/7z7zzKL/zSP3o4HPi2R/m6r/+aqKZPMTDLALXyXd/zVDe/8Ev/ePgP//mpnj77ax8b3vEOfnfJrLkedsrA3DpG319znwEW1hnknO6IBZ3zZ9bXrHGsdWM4GGtNLMQ7hwU8kjIG5riNOWaPXeb92FZwy/xBzpmI3KJz/sziuvkBAEUBeITvuaCxi5MagmKT5X6uL8bHbknQy/XdSh8sS3j39PzVq1fVVDEpqIUpoUaiwB+LVO6g2EVec233rH8ad4x/7BO93Djxw1yOuZnKX7yf67+lfsQ09hnj4RNeiLMlFvlOY+C3f/96+Lu//7NH+finPjjw6iYZxMMwzHJArcS6+Z0vXg/DoP/EwBsG6O+sY3EtiH2/ZJ/xxmv+N3AgEQs4+M4alIsFGwR/SC4abBgbgZdaLPhDwFSKBQwIePYiubGurU9OTnMMv+Qot97AjR3+EK73LjXxwAFyyi3f8VnCbSqXzQ4AAB5CGK6vr4fb29tH4XsI4fHPlaQCjHqQg5SQgU0Iz7FETGOfFi+pEXft5xi+Pd+r5QN78kktTAnPo6CfKtQsdiE8r5UQnmqW8VJ97VUvtbZq5jIcI/A5J1445MBpDiexRPGCWTiG4Xvf9w+GD37kRx7l0/HfaP8m/Rvtqo1xBt7zUBu/8vBT/k9/7qOPNUPtUEPj2rp7dAbimkDv35oLsJTgiHse1nMkrv8hPO15SuKywBJxgCmEMizwgYBnDwLWEr63sIFP8CI548d6CyE8ezcM4SnH+M3xt7Vui3jgIJfXUh7MDwAiIUzcKVBMbgJEd0rH4j7+QwiDpxd6i7jkw54BJh01O1Ur1CyCnv3o+/UIJ2vM5f0yJOQeGPjEZz40/Nm///Xh+3/ovcM3fOPXDvw276/4yq/wAE0YNmSAGqAWqAn+ab9/8+++MHziMz9zikjfxUCXDLCXWdrzhPD0YtaaAPYQS1jQYU/fGov8t2Egpd7YT6LXBoGtV3Au1az3eMwPAOYIOaWfFy10W03omJzTMfVdDIwxQK0wUceend9DD/3z+0e+bj2Xj8ytYrdj4Du/+1uH/3Tz+8OX//7Ph7/6638x8MI3zP5m8DAMej4MHXPw/T/w3uG//Nd//lgT/+nl7z/+fRHDs/90IQb6Y4A9DHuZlMjQQz9Ft0QnhLQf0mmfUcKuDxvqhzpKQYMe+im6W+mAD5wp46OHforu2jqmBwCc0OUG0IIYDhUgPReL9I/HAPWXWyvoY3c8tuYjFifz/Ojptgzwk94PffRHh6tP/PRw/cmfHn7l8x8bPv+b/+S1fODD/BOC22LU6G0ZIMenOee3/P/ipz7wWBPUBjXyDIEuxEBnDLBOs4fJCQt99tU5Nim6Xt4ZUrBKp4yB0nrDrmzEtlbgYj7kjII+djk2a+iaHQAQHCd0uaCxwTbXbk6/RaOaG0/P9ssAE7MEPXaqs+fMtZjLz0fQlRiwYeCbv+Ubhn/7H39j+Nu//zev5Ytf+uQQQngtNiPJy9YMhPAmp7//B594nW9yTw1QC1MYdV8M9MYAe5eSmKz36fhjz5CLBRtsc+2kvw0DpfVWatc6ylJc2Hl7Z3iHFVkEV+qrxvZ8TAi29HfuX9f9MFC7iNTa98Pkm0g0995woW/7YuCDH/7h1y+H//JPf2V417veua8AhPaCga/+6q8a/vBff+Z1XsnxhdL0DT0RA10xULNn4cWb/bUVITV7hRpbK/zys8xATb3hvdYeH5ZSi6fW3jIWfJkcAFg0BQsfBGTlB18SMSAG8hnQHMznTBbbM/Dd3/ttw+d+4+ce5dOf/+jwS7/8geEXP/mBgd82rsOA7fOTioCXfnJG7n7plz84kMuY1+/5vm9PdTMMg1TFQF8M1L44W73AWOwRLHz0lV1/0dTmqNbeHyO+EOkAwFc+hGZFBmoXQ+sT8RVDbzqUmnZTeuV8BQbe/1PfP/z1l//48SfHf/7vf334xm/6uhVG1RAWDPDP+f3Zv/vCY+7+5u/+eCCXRX5lJAY6YsDTumyBxcJHR+l9HUrJ36vw2tjwC/lhj1zjsta+Zuwx297eGUwOAMaIyr1HseTaSF8MiIF+GXjx4oWL4LwsqC7IOAiIr/jKdzz+U4Ff/w1fO/zo+79v+Mv/8rvD//q/f+m1fPzTP3MQJvyH+YmHXJzm5i//6veGH/vJ9w3kjr/U7yu/quyfe/QfuRCKgXUZ8PRC1ts7g/YZ69ayRhsGkwOA3iaiCkMMiAExIAbEAAx8+z94z/CF3/75gb9ALsqnP/eR4Wc++iOv5ad/5h8O3/ied6MuacgAHMP1Kfef+tUPP8sNuSJnlTBkLga6YsDiBfPm5saEE70zjNNY+0OPWvtxVGV3qTdPeMqieG5lEQ+8PPe63ZXJAcB28C9HtvozSpeedUcMiIEUBqzmoJWfFMxzOl5wzGHUs3UZ+Pgvf3D48t//2Wv56y//0fBj73/fA4ggGdpx8KM/8X3Df/3bP3rNOzngdwA8kG78v9yJgf4YsHiB6Y+VfiLy9HIJq7V7J6sDJ7BYSG/xdHcAwARQk7ModfkQA/kMWDZsD3PZMp58NmXhlQF+a/l3fve3DlHe94Pvffwp9H/8q98bovz67/7C8M53fqXXENzjeuc7v2qAw8gnn/xTje/7we94zTv8kwvzYORQDHTIQO0LTK19h5SahlTLb629aTAPztjDPXwU/694iqlLMuzuAICovRUNmCRi4AgMWM89a3+5Odh6/Fy80t+GgXc+vOh/5vMfGf7k3/7qa/mt378afuKn3jf8yI9/zzN53w98x8DfVL8NUn+jwgWcnPMEd7/5T1+85hNu4Rj91lHIvxjokQFeyEp/QKbD8PYVQX5KeS61ax1VWW2GvgAAEABJREFUKa5SO8WTzkCXBwA1kyidOmmKATFwykCLhr3lXG4Rzylf+t43Az/xk+8b/tv/9SfPfrs6v2Wdn2S/97u+pe/gM6L7ju/85se/ZBFuTuVv/u6Ptvob/DPQS1UM7IsB/vx97iEAa6EOw9fJMzz3lB/ioX5y2EMfuxybtXTBBb6c8cgndjk2a+h2eQAAcZCdmyTsJGJADOQzcHd3NzDn8i2XLfC79lxuGc9yxNLogYF3f927hh/6ke969tN/fsr9gQ//w+GLX/rE8K/+4nOj8kuf+kAP4T+LgZim4v1nf/jJ4QMf/uELnv7hj373AIfPHK1yoUHEQN8McAiQuqaixxrcNyO+oustP9QPdZTCMnrop+hupQM+cKaMz8s/+UzRXVun2wMAiIxJSk0UNhIxIAbSGaC58bLMT+rTrfI115rLa8WTz4AsemHg2779PcMf/KtPP/7Um39e8Fz4owP82fYU+YZv/NrNaGHsFIzo8Fv5z+OM13Dh6m/t34xRDSwG1mMgrqlTI8a1EL0pHd1vxwC8z7277C0/R43H68s/ldv1AQABUnQILylMJoSJsxchhlrxFGttLN7smdxL4g3zHJ7UWmE+IcTe+uU/4mUeI4zLPEZS8S7p4RNZM54Ylz7FwCkD/DT8b//+T4cU+ewXPjaEEDaRX/m1jyVhJI4PfuRHTkN0/V3gfDNAj7YQL1ESy1ZYWE/v7+8H1lKEdZJPrYVbZeT5uC9fvhzID/kgL1b5oeZq5TnStKsjxEOOyBf8rrU3TmP/Uqv7A4AYMomg+BASsxehmGIMpZ/E7iVei3hKeWhhd3t7O1xfX89KCE8bdGqvBQZLn2BMqRVqCskZG7/YhPDERwjh8Y8NMGaOH3xgg+DTQvCJ5OCQrhhowcC3fOs3DB/66I8myfUnPzD82m//k03kFz/500kYiYWYWnDVwKdcOmSAHk9/DiHMrrVLa/Hp8xCe1iHWkbVDPo8nhDAQ3xZYiJ1xEXDxCRbuS+oYiFyG8FRrITzteXK9kg98leYHO3yE8ITjdB6Ufg/hyRe4toonxlQaw6ldCG/iyY0JHNjAM8J1Lidb6B/mAGALcjWmGDhlgMOCEMoWgFM/e/seGyLN9tWrV8/g3z4coCA0z2cPdCEGxMAiA7yE/x//978etpBf7PDvKhiGRcqlsCIDc2uHFQzWnxDWW5d5ORhbC1kbIxbitopPftZngP1MCGEgn+T1FAH3QgiPP/w4vd/qO1jG6s1qvC3jOefWIibiQeDNwp9nHzoA8JwdYeuSgaM0F5JHE01ZfOAkhDBo4wNrEjEgBjZhQIO6YYC1IGXtsALMGsR6ZeXv3A/xhBCGlJcW4m6J5Rybru0YIG/U0pJHdK6urpbUqp7jn3GqnCQaMw7jJaoXqeGfcYqMM40Yh/GYt5mmu1HXAcBuUiWgPTFAc2Gh6Cmm81honMR5fn/uundO5mLXMzEgBrZlQKP7YYCX4LXRsF61WoNy4wELa+jaHGi8cgaoHfKW6oHDIF4yU/Vz9MCC/xybWl3G6y0eeKzlxau9DgC8Zka4umeAhaLnBT53w0PCWy4g+JeIATEgBiYY0G0nDGy56W6xLpfGU2rnJI2Hg0Ht5AbNnsd6H0jdlGDJxT6mTzyMP/as9B7+eoqnlAdrOx0AWDMqf2IggwEaW4b6blRr4mIBsV4Qd0OcgIoBMbARAxrWAwOsHVtt9mP8YIjfaz9Zy0rjYS20xFIbi+ynGajJU43tGKLSehvzVXLPenxrf7kxMT7zONfOu74OALxnSPi6ZoAFvsfGUhuT9YLYdREpODEgBuoZkAcx8DYDluty7VpYa/92SPpozAAviaVDWNabl72TVd16iac0t57tdADgOTvCJgZ2ygAL2k6hC7YYEAMHZEAh+2Cg5kXKRwTPUdTGw1pq9TL1HJmurBiweEm18GEVj4UfxWPBYlsfJgcAFn/pg4WPtlTJuxhow0Bvi7tFPGx62rAtr2JADIiBCwZ0Qww8Y8BiHXvmUBevGbDY71v4eA2ooy+91a2XeHrck7o5AOho/imUnTDw4sULF0itGpxFPFpUXZSEQIgBMbAqAxpMDIiBtRjobZ9hEY+Fj7Xyd8Rxbm5uugvb5ADAghUVvwWL/n1Y/LYgCx/+mcpHWDuHLA4Q8lHLQgyIATGwMQMaXgyIgV0xULvfsQzWE5be9se9xWNZd7W+TA4AKP6alwdOVvBRG4zs/TNAnmtrxSrK3hoL3NZwU2tfM7ZsxYAYEANbMaBxxYAYWI8B9hq1+0B8rId4eaSaePButR+Fl1os4PEiXuKxyo8XXsFhcgCAox7JIS6JPQM1tVJjex6Jl8Zyjqv0mng4TCu1t+S2FIPsxIAYEAMrM6DhxIAYWJmB3vYbNfHU7NvG0laDZczf1ve2jsc6P1vzGcc3OwAoffmA2K2TG8nQ5zoM1NSKNUL+/H1Pp6XMpZJ47u7urKmVPzEgBsTADhgQRDEgBtZmoGYfyD5nbbxL43mKBywl+8ClGLd6Tjy8K24xPuN6rDcLLswOAAADSZDF9xRBF5sUXen0xQB5J/+pUaGLTap+jh5+e2qWuYcavPzTYHM4k64YEANioAsGFIQYEAObMMDei71d6uDoYpOqv7Ye2MCYOi77TmxS9XP02AfmYMnxvYUuPK0dT8v8bMHh+ZimBwA4T00SiUQXG8kxGSD/1MFc9ExAXlDRndOrecbLb2/NMiWeyC3x1/AnWzEgBsTAXhkQbjEgBrZjgL3d0j4QdOigy3fPAkawLmFEh33akl7N81QsNWOsabtmPGvkZ03uxsYyPwBgEJJ0f38/QCAvGdxD+M7LHM9evnzJLcnBGaAOqIepWqFBrvWCChbqEyw9pIV4Iren8cR5uCa3p+PruxgQA2LACQOCIQbEwMYMnO5V2J9EOHxnT8Y+Bp143/snWMHMXhKJeLeI5xQL40cse/1sGQ/8INQc4+yVo1TcTQ4A4uAQyEsGZCJ8L3mZi3bYWgi4kIiz98/b29shhTc4gest+IhjUycIOMC8NhbGBAvNOwp4poRmUYvx1atXyfkBW+542BBLjKGEW2zwAz9Lgl4uxr3qw8sSH7nP985fC05yORzTh1dki1qDEyTiAgeyBRZPY55yErlZ9/NqtPeSG2QLruAEubq6GsV2VXCfWJAt4tnrmLeJ+6alfOw1/lzcpzVLrSG5PrDBT81ehTHxEfOCT4T7awvjIrXxWOAGB7ywF0QiprFPi32tBeY5HznxjMV4eg8+EPhBqJ25sc+fRRvsrCTGdz6W5XXTA4AINBISr1M/ISCEMFxfXw+8JFkJjR0JIQyMkYpnz3op3MEJXMMJskW8pbXSEmvENPZpNW5qfshRCGV1G/HnYI6Njbpg7BSc6OSMsUdd5kcIwbw3wR08h1CW4y25PK0V4vAm8IqEsC631ArzB4mcgAMJYV0sW9bH6dhuauXVq9G9xe3Dyx8Swnr5OeXktFZizdR8EgsSwnrxnOZ7r99rOI+2e409Ffdp3caYqTUkhLJ6K9mrgJdeG8LzdRkcSAhlWPBbK6Xx1I47Zx8xTX3O2Xp8NhVHyv3SeMZqP86B2k9qlnWAmi7Ft2S3ygHAEoix5yQNAsaeWd5jjBDCQCIt/e7ZF5wgLQtvz/x4wL5GfpgTNCAamYeYvWC4uroa4H9o/B9jhLCP3kSv2FOtwC15bJlC5g9jMNbcODyHvzmdnp4Rq5daSeF1jfxQK2txskY8KbxKZ/8MpMxl6o0+SI23jJgxGGtuDJ6DeU5Hz8RACgPU0Ro9m5oNoc3hlcsDACby2i8dJLJ1g0opKk86FB5F7gmTsLxhoGV+yDtz4s1o+gYD6k2w8FyoFWrx+V3/V6wx5LMVUuYPY6T4hz94TNHdsw4xEquTGJJhgLlVrbDvoFaSwRgotozHAJ5c7ICBnLlMH2xZ48xNxkihTbWfwpJ05hjIqf05PznPqFvWihybJV13BwAQmzqRl4LLfc7YuTa967cout45WzO+VvnB75px7GEs+oN60/NMwcmea4V8snl8HlX9VYlPeLRe4OsjsfPgr1byYqNWiCHPalm75YvR3Oit4pkbU8/6YIB5QL/KjaakLy6NARZqeUnv9Dn62J3e03cxkMIAdVNS+ym+l3RYKyz3CK4OALYkFuJpCpbk4rMHIS89xNFrDNb5sfbXA+/0ha2aPvypN8FCG7HmlvmDzxK02JbY7cFmy/kzyk/BTesYts438dDbCqiQyYEZoG5KwqcvWtYb86cUS6ldSdyy6YeBreuGmrdi09UBgFVQNX4sya3B4cnWuml7iq0HLNb52brBecyJ5aalND5vvQlOeqkVS27hpTTH1nO5FIe1nSW/VthK/dTk93xMD/Onp9yc86trewZq66XW3jIiy7lsiUu+fDLgoXbZI1ix4+oAwMNiCLlqCpfl5aHwL1HpTmTAKj9WfiKuXj7Vmy4z2VOfpO9fRlh2p9aX5mAZ75lWxepW+elp/hSTKcPDMVDbH08Jq12XrebyKSZ975cBLz3bCoebAwCrgPotPUUmBsSAGPDDQG892yIebSjH69OC23HPpXfL7axeYLxwQjxesJRnRZZrMVD70g1Oi3qz8EHtg0ciBlIY8FIvFrVPvG4OAADjRazI9RKPBY4Wf3mLBa6tfXjhxUtj2jofLcb31A88YWnB9ZY+LeayhY8tOTjM2Ar0GQOq22d06GKGgRcvXsw81aMeGLDoBxY+euCyRQxW+0A3BwAUi5fG4umnOJ6wtCjkvfukbvcewyl+q8Zy6lPf+2Sgp95ktfZY9AMLH31WnF1UNZ5ubm5qzN3ZWtW+u8AEyC0DFj0OH7W129tctko43Fr56slPbb1548LNAQDEeCg6NQQycSk9bfYvoyu/46Fmy9HLUgyIARiwnMe1mwRLLMTmQZytHx4ocYOhx3pzQ26HQGrnsuUeW7XbrsBq17HaOmkXWbnn3mJydQDggVwPGE7LkwZXOxFP/ZV8t2zYJeN7txE/3jMkfC0YoDf1UvuWfb/GF3zCa4t8bemTmLZex97EX/etJr91I7ex7i2eNizJa2Sgdi5b1lutr1r7yEmPnzXcsI71yElt7XvjxNUBAORsWThbjk3sU7L1b8uuaQRTMfV0H3562dz2lBfF0p6BHmrfuu+zSSj1iW37rG0zArWyzchno1Zc3t3dVVj7My2tU3+RCNGaDJTO5Rb1Vuqzt7lsnX/WolJuS+vDOoYW/nqKzd0BAOSWFl1NshmTsWt8tLTdqlltNW5LLlv49lw7LeKVTzEQGdhz7bfq+3CC78hRyif6bLpSdPeoQ2we1pNS7nrLD/FQp6V8yO64DJTM5Vb1Rg3jOycb6BNDjs0RdeE294dbe+7xKTmmbqifFF3vOu4OACCMoluTYMZiTMb2KhQdEyt3MpbGwziMx7ilPo5kB0/39/cDvB0pbsUqBvZa+637PmsKY6RUCL0W/RTdPetQKxHAkOMAABAASURBVMS6YQxFQ4O5p/xQlz3FU5RUGVUxkDOXW9cbtcwYKQH1NpdTYq7R4Xcgp3DL3hduqYua8fZgm1NvnuNxeQAAYRDMC1VK4aFfIrFgGavEfm0bJlbqZCzFBidwzjiMV+rnqHbwBn9HjV9xH5eBvdQ+PY6Nyhp9nzHoB8hYZXCfde5IvZZYiZnYxzhpey/POxjBCuY8S5/aa9a+TwaEypIB5gXzg3ky5nfNeqPXzmEBI8/BPIZV96YZgFv4Q861yDH3Wf+PxC2cUE/Efs7JXq7dHgBEAiPJbNgg2kLwReL2WrCtOIEXOMF/5D/1M9rxmWrTSg8MxGAh+MrFybjUF5Jar7ljjOkzbq28evVqzLXuOWGAekzJMXpbQAYbdU8vSal9Ng8WOFPGAhPY4CZ3o4INQny5eLFBGBsMUbjmfq6/XvSJHQ7gIyV/Jjo3N8OSH/AgYANjLt/UCYLtnKCT63tMPycexlyz9sfwrnGPvrLEy1rPLeIlb3O1FJ9ZjFXig/GZL8wbeOWTa3CvXW+nWMCBgIX7ubGBHymxzR1rDX1iQUriwQaBy5hjuC31t0a8a4wROYELeFkSetMauFLGcH8AEIOgiUC0heAr+t3zJ3FY8IEPfCE5fDDxsQkhDNfX18Pt7e3jZwhhwGeOr1rdMSzgqRXiCqE8HnhYEjisjR/72lixx4/ELwMc0JCnJamt21oGqOmluuc5erVjYY+vJSkZK/YV+ETgPYQw4IvxGDtHsIuSY9ezLnzA5RqSMgZ4kFzO8R1CeFwDY61QL1PCXM4d41yfzSTjzgmxIOe2S9f4xI5YEOII4Wkt5NmS/ZbPwedFLHiA+xQJIQwhPOXIYtxcH9QLvPOZazvVa0MoiwcMUXKxEEMIz+dyCE84eJbrb2t9MMMF8xihlkIojyf6w+fWsXkZHy7gZUm84AXHbg4AACvxwwBFTiOZ2sScNpjWqJewWIy/ZjwWeOVDDMAAdcvCxOaKa0kaA/AFb1M9jr4Ht/SeNI/ScsBAEwixVqiHJgOs7PQ0Hur8fHjiRFT758z4ud5bfuZ6LawSDzp8bynUfgjh8YdZY+OAA9lL7RMPvIFZc3kso8e+pwOAY+e/KHqaHw0lxRg99FN0S3TwzRgltiU2jMWYJbayEQNbMMDCz4ssm4Etxt/jmPAFb0vY6QdssJb09NwDA/YYmFOptWI/ur3HnHhU+/b8W3okPyEES5dNfNE/U3otOiGEgRptAYR9HXM5xTfcXl1dpahupgNPxANvSyD2EM9SDHqez4AOAPI5O7QFTZJmkUMC+tjl2KTo4hPfKbqWOozJ2JY+5UsMtGZANZvGcO7Gjg1Wrk0aEmmZMtDAGRvsBm43c5kbD7WvvrJZupIG9tybqB1qKCmQt5Wwefur6Qf7uhyH4G6FJQfHlK7m8hQzuh8Z0AFAZEKfSQzkNsnotNQu2p9/0nitfZ6PMXe95dhzuPRMDEwxwIbF82ZwCvea9+kr8JQ7Jjb8xCXXTvrrMWA9ErVi7XNLf6XxsBaq9rfM3PzYXnsT9UbtzKO/fEo82F4+Kb9T6g/8Hmu/t3jKMyvLOQZ0ADDHjp49Y6C0qUQnHhtlxFbyWctHyZiyEQM1DLB56m0e1vBxbsuG7vxe6rX6QSpTm+iZD1pTK+ZgDBzWxKPaN0hAQxce81NTbzW25zSzHtb4641bj/Gc50zXNgzoAMCGx0N4oVHWBGrZWGoadk0Mp7a1fJz60ncxIAa2ZaC2P+lwZdv8zY9u+7S2VmzR1HurjUe1X5+Dlh685cdi72ThA85r/cAtfryI5rKXTPjHoQMA/zlyg7C20dXaRyJqG3b0U/tJPF6w1MYi++MwULtBOA5T+ZGqH+RztoqF8SAeDqCNQ5K7zhnw1JsssFj4IOUWfix8gEUiBlIYsPqjnDoASGFbOmYMWDRKCx9mAcmRGBADxQxYLGT8W+jFAE4M1VdOyOjsq8KZZ8Ci9i18zKPU0xoGestPb/HU5PbU1oIXCx+nmPTdJwM6APCZF3eo1BDGU2LxAmPhYxyd7low0Ft+FI9FVcjHjhgwh2p16FQLzNNc9oSllldLey+1YhlTrS9P+0l+J2dP8dTGgr3mMiy0EU+/A1MHAG1yLK8HYODm5sYsSm0SzKhs4qin/Hha3MHSE7dNik9OKxmwN/eyiWP+WERnEY8VFot4PPmw4NZTPMLimwGLetNc7j/HRKgDAFiQiIGNGbBo2huH0PXwveSHQytvi3stt7X2XReughuGBhwwh7Y+uLKcy7XxgKUBzV24hNsuAlEQu2CAeqvpTZrLbdPsKT86AGiba3nvlAGapOWLR21T6JRmN2GRH3LuBlBHQOC2dMOinHRUCI1CaeXWsv+3wpjjtyaeGtscjHvVVZ/aa+b2ibt0PrIOl9ruk6ltUNdwXGN7Hq0OAM4Z0bUYWGCgVZP09OfiFig45GMaL7nfa/BsQonBI/4SXJ7j8cjxQTE1C5uDK2qw2QAzjhm3ZM7MuBxK47m7u5tzq2cPDJArcvbwVf+LgeYMlM5l6rQ5OA1Q3Gute4gOAFSMYiCDAV4AW76o39/fD4yRAUmqKzJA7q2b8Brwwex5cWfDkvMi4T2eNXKqMVIYaKvDnKIW247y3DvjMe7zuzZX+MV/qjfmLHM3Vf/IerncHpkrxV7PQG69aS7Xc57joSQ/2OSMsaSrA4AlhvRcDLzNABsjXgDfvmz2wRiM1WwAOa5igCa8l/xwmMTCDuaqoFcw5kWCA7A5bvcUzwqUaYglBlZ4ztyiZqnNlsPhf425HOMhpql4wMJcZc5O6ej+JQOR28snuiMG7BmI9aa5bM+thUfyQ09fyg86LXrt4Q4AeLmySJwnH8S0hniK2QILm5gUYfKx2WGy5o4b85Jrx1iMSWNAUnDmjiH9YdhbflLqIOpQt8R3dXWVnWrsso2MDKZqvyYeoBHTnKBTK3P+LZ/V4vRoX8vPWExr3aNmwU+NpvbrOE9TPvGL/7XmMvEgjHsaD9cIWNbitmQc8M1JiU8rG3jdam33yokVt737IX+5MVJvCPPWai6DA8nF0kIfHEgL32v4pKcv5QedFlgOcQBAcUAgcn19PYQQBghHWpDa2udpPCGEgZhay+3tbeuwVvcPjylC3eSCwy92MS98L6k3bBD8LUkuxiPrwyU52Vt+wAz2FEE3J8f4xCaEp54SwrZ9krpHwIWArSQe7EJ4iinme+zT4t+DxseYb+t7IQStYw9r+SmvITxxQr6pm2EYcsrFRDeOTb1aCn5zADI2NiE81X0IZXMZH3CJP4RrJAfLFrrsV05r4/x7CNvXCrwi8LokHBLV8rjUm0J44iSEp1qpHU/2NgxQG8y5ELafyxFLnE/gooZtIs3zwriM7wFLHvJxbWIhJjhGuEbGtW3udn8AAKEUCM0PibSxQCAhhAGy433vn1PxeMd9FHzkJ4SnRn1ab3yP9YbOUfjwFifch6D8nOfl6urq8SCROj19Rs0i8HZ63/v3q5N4zmPyjj0HH7lBiFfr2BNz5BtOQjjmiwy1EPc8T4w8/QonyN7m8hP6Nr8evVamWKVOQjjm/JniZO379HMvc3kKyxbzh/4VQhioUcaPeeE790IIAzrxvj6nGej6AIDJQ0FMh//0hMVyDwWTGs9TVPp1bQaooZR6QwfdtfEdfTw4h/slHtBBd0mvh+cs7CGEgcVzLh44CSEM6M/pbf0MfFdXV4vxbI3Tenzyp3XsjNWHS+pWc/mBiJP/4SQE/3P5BPIqX+HlKLWSSiic0E9T9aVnwwDrGP2cvj7nkfyE0HYuMydSsaA7h7f2GbVIzEt+0GmNZQnDHp53ewBA8pcmz2mCKBgm3ek9T99z4/GE/QhYyA81lBorutik6kuvjgG4hvNUL+hik6q/Vz0W9hzs6Hvuk+DL6fs5se9Bl7r1nB82cGvlJ+YLTjSXIxtvPpkrb670DQaOUivEmirMV+Ztqr706hnInZu5+qkI6ZvMiVR9dFvVClioxRws2KTqH1GvywMAkk4h5ia01STKxXGuXxrPuR9dt2GgND/UqOfNehu2tvEK17kjY9NzfqjbXE7QL7XDtqV4xdUy5jHfXnkAV84Gbiy2jHvPVDWXn9Hx+qLVZv31ADv80nutlKSEecv8LbGVTR4DpTy3mMvMhTz0w+PvviuNYWos/JVgwabnPdwUX6n3uzwAIOmpBJzrUWjn97a+rolna+xHGL+mwXist95yVsNxja1nHomrtK+wGayp+Ra81MTTAs+WPj3mBz5K6w3bfLm0oEYu7+7/DnGVcuu1VrbOCpxujcHb+NSYt77vjaNaPNQdPJf4sZ7LYCnBgU1pDNiOSY2/mjjGsPR0r7sDgNpke2twtfH0VKweY6FeaLyl2LDFR6m97JYZqFk8lJ9xftWXxnnxctdbflbHM5IIzeURUh5uecjNAwxX/1MrrgA5AaO9ipNETMCwnMs1+ybgWdVKrR/NZbIxLt0dAIyHmX6XYqktuPTRpLl3BixqxcLH3nlshd9iQbTKj8U/5WTFU+3iTp+0wmLhpzYeCwyefJAfq7q1iGttLFOYveCYwldyv7b2qZWScXu36bFWanMmTmoZnLf3Mpct8myx94ItCywWPsDSm3R3AFA7gbwlWIXrLSP2eJRje04tPSo/lmzK1xEZWPklc5Li3uayVTxWfiaJ3+EDcXKZNC/z+BKZ7kQGLOrWwkfEU/tpgcXCR20cHu27OwDw9FM2jwkXJn8MXF1d+QPVCSILbi18WNFpgcVqMbTyY8GN+r4Fi734OE4cFv0Atqz84Etiz4DyY89prx5VK71m1j6u7g4ALH7biSaQfaH16tGiVixqtjd+b25u3IRkkWOCscizFRbwSMRAlwwcLKjawy9PvZbU1caDDwux6NcWOPChvg8L/Utt7XubyxYZs5iHFj4sYvHmo7sDgNpG2eME8lZ0PeGh3mqatuptvBqsGnZtfkCHDz5rpdaPamU6A1b1Mj2CnuyFgaPh7K32PcTjrdeydtTsM442J/Yar4fa98Zdbe17m8ue+O3uAAByaxKuCQiDkhwGVDM5bC3r1szfMe81+bHGUuOvJo4xXnq6V7tJ6ImLg8dyuPBrap9+5K2v1MTTc/K95alnrreKrab2Pc5lKx5rah9OrXD05qfLAwCKpeS0lAnUW4IVT3sGaDAltYMNtdoe4b5GsObEU36ITb2pTT16+jsJ2kQor8sMHFODvlISealdyVg5NlvOZa/rcuk6lsO7dLdnoHROltptH/EyAmq/dN+E7fIIx9To8gCAVLKA5BSM16ZPLBL/DNB8qaFUpOhik6p/FL27u7smocI1nKc6p3dgk6qfo6felMNWnm6r+slDIe3NGDjowGxyc2s/V39tarfAxxrRqu9b8Ac2MFr4kg+fDPQ4ly2YZt+UU/voMl8sxu7VR7cHACQspWDY6LPQqFBgTFLDADVE01nygQ66S3pHes48vL92jKeTAAAQAElEQVS/H1j8WsUN53C/5B8deseSXs1z/DPOkg90wL2kp+dPDFA/1BG8Pd3Rr0di4MixUvvsZeilczzwHD305/S2fga+NecyPWMPvRaMYN06Pxq/HQPUPnOUuTo3Cs/RQ39Or5dnqbXP/EC3l7hbxdH1AQCkUQQUA8J1lDhx2IgfZfLE2PXZjgHqbWzTQr1RgzxDpx2CfXmGFxYw5uEayOGeHJALxo5j8h0BCzrxfstPxolYTseJOHiGzukzfU9jAN7IMZJmIa0OGDh8COxl6KXUPXJKSOwrPEfv9Jnn7y3nMpzA0956LZyAGeyecyds5QwwR5mr5Bg59UTdslfhOXqnz3r/PlX7cAJPzAt0eufBIr7uDwAgiWJAKIwoJRMHG4QJt5a8evWKEKqESUGzqBF8VIF425g81HJHDt525/aDOGOt8Qlm7uUCxi6Vr1zfY/rkuaZOcmwjL8Q3hqXlPXIBt2BA+I7kYok22EWfubixA0OU6DPXT7QDy5wwXq7vMX38zI1j+YyxiG8Mx9Q9bJDI61JtsoGY8pV632r+pI43p0fsljmo8TWH0+7ZsifW05o4trAlj7W1zxzAB/iXWXqjgQ2CnZVYxLM0l1OeR07A8ybitG8tOCnBgQ1xIEsx05vSopvXsqgD5uH8KMtP8WGBZXmkbTXIMUKOo8T6y0GGDZLCGXo5vrfQHeOEe7lYiDVygj3XuT4s9BkXAQs4EAu/cz4OcQAwR0DqM5JyfX09IDSetSQV35Ie+GtlaYyU51a8pYy1Zx0mfwghq94s4q2tkRx7C7xb+YiN+rQf3N7ePuYrhDCQv7WwMVYI69eK1VxO8RO5JVakhNul2izxOWazNE7K8zG/ufdSeF1LJxd7kX6i0VoxW41zWvv0ncQwq9QYhzqlvyFWseDHIh6w1UoJQfSeEPJ6LTEvCZwgIZSvHSl8lMR8brMUS8rzc5+l1yljLemUjr0Xu9K5vJf4SnGOzWXmIP2OZ0ip7xy7sfyAAwmhvB+kYNABwAJLMTk0kQVVPRYDJgywkDP5TZzJiTkD5IdFYq4nkL/WC0jsTYxlHqRTh8SKtObWafiCNcNA74+oe/pO69rHP+PM9TcLrteKxwLrmr0WXsiBBW75ODYD1NEac3lPLKfMZeYgAn8tYwPLUn7AEUIY0LXGogOAGUYhfCk5M+Z6JAayGbi6uhpab7yyQcngNQM5+aFxt1pAjt6bWnL7Otn6sicGDoO1Ze3Tr/C/JpmMx7hrjpk71tr7QDhhrcnFKX0xEBlgTlFH8VqfTwzkzGX4g8cnS9tf8QuWVK/osu9L1U/R0wHADEsQPvNYj8SAKQM0BL38m1Jq6qwkP60WELCYBrdDZ3BrvSDukAZBfmTgWL+0qH3mEn63YJJxGX+LsZfG3KrXshfYauwlTvTcNwPMJeaUb5Troys5VINH+LRGi99cn9bvpDoAmMiAGu8EMbrdhAHqraQhNAEjp6MMlOan1G4UxMNNaoXN4cPXw/8PF4cnQQQMwwE5sK79FpvcnLRYx5Mz9pQumKz799RYY/cZe+u8jOHSPd8MqGYu88NcLt03YXvpsfxOjb8a23PEOgA4Z+Ttaxrv21/1IQbEwMEZqG26lguyetObYmRBt+T2jWd92xMDR8RqWfvMoa37imU8VvUAL1a+Sv3Urj2l48punwxQs1vPZY/MwUspLuveVJOfGtvz+HUAcM7Iw3VNoTyY638xkM2A5aTOHlwGiwzU5sdqE6fedJkqK24vPevOThgQzEoGvPQVb3OZjX8ltdXmHjBUByEHqzHgZS6vFnDiQLXzyKo3WfixyrEOAEaKx4rcEde7vVXyZ2d2G+zKwFVvKxO+wXC1i0+ErFqJTLz5tOL2jUd92xcDx0VrsZmEPfUVWHguVtw+91p2pfyU8XZEK9XKZdY9zeVLdPl3rHKsA4AR7vWyO0KKbokBMbA5A+pNm6dAALwxcGA86gftki9u23Erz2JgTQY8zWWLl3cLH/CvAwBY6FysTr9evHjROVPbhOepOW3DgP9Ra2v/5ubGf5A7RWjFrUWf1Fxev4g0Yj8MePrdPJrL/dTVkSKxWMd648tiLlv48MarDgBGMkKiazf8I243uWW1OQa8GgsstJFe6q0NO9t7pSdsj2IYwKFaeZ4JOHl+p+zKwo+FjzL0h7U6dOBak9umX722Lb/yLgbWYqB2Lve4tusAYKL6tLBeEtPjBLiMcps7qrdteE8dtTY/tfanOC19nfrd43cOOC37Ev5KeaixLR1TdsdlQPXWPvfqte051gi2DLAe1r7s2iLy4a1mLtNr4dVHJHYodAAwwSXJ3vskomhrin6Mmru7u7HbulfJAPVGvirdyLwhA6X5KbWbCoVa2Xtvmoot9751f8NfCbfYYJuLX/qVDBzYXPXWPvn0Wuv+3R61Rjg6A+oNlxVQM5exvfS4/zs6AJjJIX/RAhu7GRW3j8DdogkwEbQgtkk7+SJvbbzLay0D5Ce39tHHrnbsc/s996bzWEqv4bbUds6uJF/kY86nnrVh4KhedRC/XubpB1qX1+NbI9UzwD5dPeKSx5K5zD4DPi+97f+ODgAWcsjGjgJYUHP1mMUK3K1AMYn2xkkrLqz9kjdxa82qnb+c2ieP6NuN/tzTkWuFzU0rblns8U8ffc745RU69/f3lw90Zw0GDjcG9UZtUqOHC37DgI/cazekXUNXMECPoFdUuOjSNGcuw1+rfYYHcnUAkJAFCoDNfILqpipxc0CBtwYCJ2x898BLay6s/cMtvCLWvuWvnoGl/MR5iF79aPMeGONIdUKs9B02N/PM1D3FP32U8cY8xRyjM/Zc99Zg4FhjUIvUG7V5rMh9RBt7LXnwgUgoxMA8A/QK1kvV7HOe4lxmHX/+5OkKvuAN/p7u9PnrKgcALFoQvjWF4EBKsGBDQXAiRHGkiEW8FOjSWGBCiK2kYLEjvhK82MHLEkbL53BSgvXcBuxLAjfndmtcR1w53K6Bq7cxyC9c58aFDXKaH+Yg1/jMnYfYIPgswcK4jJ86z3LHGNNnHqaOV6tHbMRYws8Y9tR7jMe4jE8MfCLkKjfHjIkdgt85QbdWrPJTiwN7uDOXm5thK5/EVCup+aHeqEHqpXZM2T8xEOfg01X6r+QAIR+ptZfuXZq5DKTmYE4vd8yt9GPN8pmLIdYsvWSOi/iM3pQ7xpg+464hpZxgdzqX4YdrMI/FM3cPXwi2c+LpnzptdgAAEWyQQgjD9fX1cHt7O4QQhkjMHJHWzyIWcCCnWHLHIqYYw9wnerm+x/TnxojPGAsZs5+6FzkJ4Xl+8IPfKbup+9isJWCcwpFznzpYEuolhKe6zfFtqZvKq+WYPftqVfsldRmxUGcI9RhCWb0xfkqtoGeR35SxrHSsMJfGzfjEwieS4yfmOISnXhvzTK6nJMf/lC54ayU31pZYzmPZ8noqzpz7cJsSA3o5fqU7zsD5PGTuhfDUa8nDuNX0XWxSZNqDntQwwEtqCv9LOjUY1rAFfwhPawc1y/oRwlPd5o5PL8HfkqCX6/tcnxdd8K4hp5wQ2zmWpWtskJK4ox0YkKV4l7Cs+bzJAQCEQAQFcB5MJAed82fW17Hhz2EJoWwiWWNd0x/cT3FCzshRyURYM4a1x4KTEI5XK2vz3Hq8lNpHpzUO9abWDPvwTy1N9VofCHeLQsDFQDID7Gem5iFrO8JcTXYoRTHQmAH2CCGExx+ejg1FzYYQHn+oOvb8iPfgBFljLp/mh/emPfJtfgBAoyUBS2Sgg+6SXulzkjPV8M99gmWNgjkfd4tr4iTepbEp6BDCAI9Lukd6DndweKSYe4n16upqcjEdTv4jxyGEkzu2X5lT6k22nHr0Rp+gljxi2z8mRSAG0hig77OfWdJmrqK7pKfnYqA1A6wd7BFSxqFu0U/RPYoOnLScy/Cdmh/PnJseAEBKSqONhKDbKkm5yaFgwB+x9fhJfMSZExs2OfpH0IVD8bKvTJMv+k0OavWmHLake8oA9UafOL2n74YMyJUYSGCAHp7T99Fl7ia4looYaMIA9Ze7dqDPDxaaANqp01ZzGZ7he6e0PINtdgBQUrQgIUkQyncrAUuJL5JqjaUERwsbOCG+XN/kB9tcu971S7jsnROv8VG/JflqUftgKeEJ/L32phI+vNuQL+8Y94xP2MXAEgP0Wnr4kt75c+aueu05K7peiwHqr2Qs6r3ErmcbuLSey9b+tuTf7AAAoksDyf1p/dI4NVg0iS7Zhc+eiv4ywrI7qpUy3ta2on5Lx6yxHRuzxp/qbYxRf/eUp+Y50QBiYJEB9dpFiqTgjIGatYPDLu3TLxNaw+m5N3zV9JVzf1tfmxwAWBSdhQ/IJEF8lgqTqNTWs11PReuFZ6ua9RKPcIwzYJVn9aZxfnu7q17bOqPyLwbmGbDotVZ9fx6pnoqBNwzU1lxt3b9B0s833ulqee2HjeeRdHcAYJFoCx/Pad72yqIpWPjYlgX70dVY7Dm19mhRtxY+iMuir1j4AIukDQPKTxten3nVhRgQA2KgQwbYU9aEVWtfM/YRbL0c7vN3m1jwbXIAYAFEGycLFsd9WBXLuHfdFQN9M2A1fywWZ4s+aRWPlZ++q0fRWTMgf2JgiQGLPmnhYwmnnm/PwIsXL6pBWKyFnurNIp5qUg0deOLWMKxqVyYHAJ7I9bLJrs6MMwe9NQQrej3x4mUhs+LWwo/yM86iRa2Mez72XU9roafaN6wKuRIDYqCAAfWDAtISTTxx62kNSqRPahsxYHIAsBF2DZvIgKfmlAh5F2o3NzeucNb+VvUeXwotat/CB4VSmx98WGHBV414q/2aWHq07XEuP+VJv7ZgwKI3tcAln7YMqC9c8qnav+TEyz7jElnZnd5ybBWPDgDK6ml3VrUbdquC2x1xOwJc27Rr7b1SVbPpYd5Y8YKfWixWHNfO51p7qzjkZ5wBam38yc7vCn4TBqiXmt7UBJScmjOgvn1JaW3ts0e49Lr/O73E1UscsaIs49EBQGS188+axm9ZcL3QDCc1nLbiAVwlvrHzGE9JLOc2nn5LXA3HNbbnnLDpIefn91OuS+1SfEunngHyY1kr9YjsPMhTOwZUM+249eKZvq+DnstslNY+XJbaXqLwdaeXuHqJI1aHZTw6AIisHuDz7u4uO0ptJscps5yE4yOU3QUXi1KuNXa5NnvS91L7bMCYU7ncleBfGoOc59YK+tgt+dbz7RjoOD/bkXqAkUt70wGo6SpETwfiXogtrf3ee22LfceaOS/Za62JL3cs63h0AJCbgR3r5zY5iq33BpebTl6AvDdFFnhylxLbHuJJiWNJx1PtM6dS80Nc1Bv4+W4t1Ao1kOIXPfRTdKWzPgPkh1pZf+S1RtQ4rRnI7U2t8ch/GwbUJy55za19OGy1Ll+i2+YO8eXsVbZBOT4q+SGn40/3d5c8WMejA4D91UEVYgqIiUExTTmKG0l0p3SO+jJN4wAAEABJREFUeB9eeAGiKXqPn9zN5Rj8e4oHvLUCJ15qHywp+QFv63qjppew8By92hzIvg0Dh5jLbaiT1zMGUnrTmYkud8YAa8r9/f1AX98Z9KZwX758ucgJvRbu4LApGCfO4YR491Ir5GeNfdNa6YnxkAfrMXUAYM3oDvzRuCgmJgmTmgKLwj02+ujsIJSmEE85ibw0HdDYOTmOjZs8456YiAUhz9w7klDX8EL8cAIfUbgHJ+iswQk4xvIDHi9YwAFGsK7BicZIY4AaQcgPQt2mWe5XS8jXY4D5zrynRyLU2nqja6S1GDjNs3L8xPopJ9Q+d+GG70futfBC/PAAH/DiRcCDgI+1cK09XKv4iQVpHY+bA4BXr14NIYRqsUjI7e1tNY7r62sLKAN+QljmhcmJ5AzKJMGGCROFezk+9qzLBmdOTjnJ5QVbbEJYzl0IaTr4I1+5nGODEGvEha8cP9EuhCes+ENyfFjpWmAhfvDjKwr3rDDm+AEHEvMDnlws0SaEp/xgj88cHOhig0Qs+OF+jpxjwR+S48OT7nk8ITxxHMLlJ2uHBXb4nxMwIeQHyRkz2oVwiT+E5/dYf3J8N9Rt6jpyApchPOcghMtrCzDUSgiXvkN4fo+5g1iMmeuDcRH4matHnvFikOt/TD+E5/GHkH/NfnLM917vMQ9DWOaBXCG5cWKTkmPybCG83ORiXFsfThDihRu+0x9ycGCHTQjLuSPHOb6ndPETwvJ4xINM+Rm7TyzYEBe8zAkvr2M+cu/hZ24cnoEHAV+u/7X1PcXj5gBg7ST0Nh6bCSROzt7i20s8sQnRhK03IfgjxyGEgTyvwclUPOBAQlgPCzGHEB4PxeAixg8OhOfgjfeP8Em8LHrn9QY/cBKCn/yEEAbw7iUvYL26urqot73gP8e573jOo7G7vjrJMfPGzrONJ+YxEsJ6c9kGubyszQB1goSgWlmb+9Px9tBrqROE/gfeU/z6fgwGdADQWZ6Z0LwM8DLUWWjuw4FzuF9jE0meGa8lKfhPiWcNLCxSjDMXL8/BC+45vV6eESfxLtUbvKDbMm78M87SGOBFd0lv6+dgBOsSt1vjTB1/9/GkBpqhx6Y3hDDsKcfMMXKZEaZUD8qAamWbxDM/97R20P/AC+5tGNOoWzGgA4CtmG88Ls2fDU7jYeT+bQZonnD+9uUqH4zHi3GLwXLjAQs2rbCwSKX6BkvvtQ/XxJnDCTap+jl6+M3F4jk/ufHkcLWFbg/xtOCNTW8Lv619MtfIaetx5H//DKhW1s0h8xLO1x3VZjRwe16XbaKUl1MGdABwykZn3/e6wdlbGrZs+rwYM74lZywCLAa5PrHBNtduTp/Y8DunM/YMu7H7vdwr4QQbL/mhN1ljscgtdQNPFr48+OgkHnMq4cXc6YoOqVGP82dFCjRUIgOqlUSiDNTg2sDNZi5YlzcbXAOvzoAOAFanfN0B977RWZetfY5mvejUbCyt6600thYHI16qo4bjGtux+Evzgy9rLPiU9MiAbUzUXU3d2qIp90Yc5dayPBIDqpX22e6F417iaJ/x/Y+gA4D953A2gh42OrMBbvyQl2UPHIPDioqaeHjxtsJSuxBZ4bDi1cpPL/mhVqw4sfBDvdRwa4HB2kcX8ViT0ok/5g8120k4CqMhA6qVhuS+7bqXXttLHG+nRR8zDOgAYIacXh5pk9Auk164rX1ZjgxZ+Yn+tvzscdNjUW+ecmwRj1WNecJiEZOnPNfEY23b0wZXObauDvkTA/kM9DYPe1sL8zN6DAuTA4BWfxHZMVKgKHMZsKi3Pfw7tLm8WOhbNH4LH8RisVG3wgIeD+IpHgssFj485EUYmjFg6lj1ZkqnnO2IAdX+jpLVAVSLfXoHNLgOQQcArtNjA06N34bHMS+9ceupaeuQ5rLiLPJj4eMSme5YMdBb3dfFY8Xqkx/V/hMP+nU9BrzUf297lfUyuDyS+soyR6Ua4raUuWU7kwOA5WGkIQbsGLBoCBY+7CKq92QVj4UfCx8wYvHb6ix8gMWLWHHrJR5POLxwa4XDyk9tjqpw1A4+Yu/lhWwEmm6JATEgBjZnwKpn1/baWvvNiXQOwOQAgGJRopxnujN4tfXW24uhVTwWcxkfHsrt5ubGAwxzDKp9c0ofHVK3tdw+Oqr8xdNcrgyl2ryFAyt+W2CTz/4YUL31l9PziLysHee4Sq4t9021tQ+vJTHIJo0BkwMAhqpNND4kYiCVgZp6s2xwqXhb6lnH44Vbmn/NC1lNHC3zVeu7Ji7rWqmNxZt9DbcWsVjnx0M8FRgsKL3wUdtXLhzqhhiYYUD1NkNOR4+89blSai3jqK19SyylfPRsZ3YAQKKtNy89E6/Y6hgorTdeKHtrKtbxlHLL/LfGwp9bJGe51QKWXJu96JfmBx6t87MXzlJxwi08pepb61nnh3i2nAt18Viz+8afV1xvEOpbTwyo3nrK5ngsW/facVR5d1usFaW1f3d3lwde2tkMmB0AMDKJblFA+JaIgXMGcuuNjT025372fN2qScJTzlxuyS1YcnIE7lybHP8edImPOFOxkB8OU1L1j6wHT/C1Ngde5rJV3NXxWAEZ8dPDZn0kLN1yygD15nk+OKVtd7By12VPAbKfAL81ppLaBwt21ljk7zkDpgcAuKaASB7fJWKgNQOp9caGno19L02FeO7v74eW8aRyy3yH21a5JkZiZZylMdAB95JeD8+Jk3iXYqFWWuZnafw9PoevFG4tYiM/1Dd1buFvzEdqrYzZ5t4jHl52auPJHTdXf01OcrFJvz8GmA/MC+ZHf9EposjAHvsKax24YwzWn7H2l/wyN5gjLbEsYTjSc/MDAMgjeWxoKCquJWKgJQNz9RYbChv6lhjW8r12PCncorNG/IxDT0FOx4MT7tFz0Dl91vt34iVu4j+PFV5YTHup/fP4Wl/DLfyNcWsx9tr5IZ6pWrGOhw1fpc9VzE85IR+rDKpBDssA84J+TE9RvfVbBqd9xWuU1B/CGgfe1jip/bj+MO7peFwzJ5gb6J0+0/d2DDQ5AIhwKSoSToEtCcmPdlt/gmUJ79JzfGwdRxz/9vb28SfFTKwpIVdItNnjJ/ipN4T88LmHhkLzA++SlMYDBwj8IHzPzS92jB8x8h0/1FOOL2zwFSXHFt1ox/gRS/TJ8xyJdtFnjq2lLjgQuCzFgt0pJ3yPPi2xWvvy3ptiTuAz1pvFJ/5K8oMNQr4RvufmBDvGt4gj+sAfWOArF8+4ft7dODaxIXnWw4ANPogjxjT3meu/lf6rV6+S13bia4VDfvMYyK039gh5I1xq59TKpbW/Oynx0I9qhVwhJfMHu9SeYvXOgJ+53hWfEQ8CPznZxYa4ouTYoosdPk554Zr7PM8R7MCPLZJjK91haHoAEAkmQSkS9T18puBd0vEQR8RAs5yT24dDAiSE8LgZinZ7/SQ3e8IO3iXJjSc2x+vr6wEhvwjfQyjLc8RYgwUMUUJ4wlHSvEuxMFYI4Rkn4AnhCUtubKX65/lhfoIDCaEMSyknpTFY2BH3nMAHEkIZJxYY8RG5tfjEX46c1wp8IBZzeYt4FmNPVDidy9QQnCAhlNdKCh+J8FZRI+45gQ+EWoEvZBVgGiSJgTXrba5OeEadICE8zR/vtQLm1gIfCPMnhCdekhJ7opSSY3ROTIq/4idFcgegFkKw3TdFnDlY4loYwhMW8k9+kBDK8pMzfk+6qxwA9ETYEWLRRNp/lmnWLFg0x6loyDN6U8+t7jPGHBZwIOhZjTnmJy4cjDX2nHs8C6H9IkKsc5xELCyQfJc8MbBWfp5G8/Fraq2g5wNxPYolDzlzGd0lf0d5zvxBjlQrR8mtdZzUCaJaec4snBxtXSZe4n7OxJsrnoXQft9EL0/dN6H7BqG+jTGgA4AxVnTvkQEmtZr/IxW7+oWckbsU0OjR3FN0S3TwzRgptuiBPUW3RGdp4Tj1CZZWCwgx4v90vKnvHODA4dTzo96HP3jsPX5iJNaUONHrpFZmw2Ve5sxldLGZdXqwh9QKtXWwsBVuAQOqlUvSjrQuhxAG4r1k4fJOy1qhX9HLL0e9vANedNX3L7k5vaMDgFM29P2CASa0JtEFLW5v0CTJWQ5AmiV2OTYpuvjEd4pu1AF7i3oreTFqsYAQGzHGeFM+4bAEf4rvPevAI3zuOYY57MwfYpzTOX9GrWB3fn9f1/NoS+JrMZfnUfp/Sm2VcOk/MiG0ZoBa6bnXlvBFr+19XS6Jr1Wt4Dc3T+pv84zpAGCeHz19YECT6IGEnfxf0iQJDTvrBR6f+M4V63rDH4t1Lg70seXTSko5Bn+prRV2j36s8+MpxtL5g92ua2UmCeSbuTCjMvkI28mHB31ArRw0dIWdyYDmzyVh9CL12kterGul1F/P+blkPf+ODgDyOTuchSbRPlJe2iRjdLX20Q+fNb6s661mk2uJhY1CDZYaTslJj2KZH0/81Oa61n5LLubGrpk/vdbKHF8pz3qtlZTYpZPOgObPOFe9zh9PvbYGC7/7azxzuqsDANVAEgO8vCQpSmm3DLDAW4GvadhgsFpUPdVtLRbyU+sDbnsTq1rpiRdqZafxTMJW7U9SU/VAvFbRdyhj9drLdPfYay+jzL9j1Vcsas4KSz4Lvi10AOA7P27QaQK5ScUkkNqXbhxb5NnCh9WiaoHFYgGy4hY/kucMWNXKc6/bXnmZy+uzMD2ip7n84sWLaaA7e9Lj/NlZCgR35wxY9CYrCkr+3P752BZ7Hk+ceMJyzvWW1zoAaMS+xSRsBE1uxYAYyGDA01zWQpaROKnujwEh3oQBi77iqU9uQmLDQb1wq8Oidkn2kmMi9ITFojcRk+SSAR0AXHJidqennxJ4aghmCZKjJgxY1MrNzY0JNgssJkAenGjz9EBCg/+taqUBtGKXFmuHp9pPJUJ6YsALA57mjycsXvLjCYfVS2pt36+1t+TUqmYtfjeCFRYLfq2wWORKBwAWLB7Ah6eiPQDduw/RolFakGBRtxYLkEUs8jHOgEWOxz1vd7e25nZ6KLId4Zkj1+Ync7hdqDMPvfR9C8KIx8KPhQ9PWCzikY9xBmrzXGsfUeGndi7jI/rb+tMKS23f97Yu6wCgYWVanQo2hJjkmqK1mkBJA0pp9wzUNspa+1MCqd/T65zvNbY540i3jAHy02NvIqaaDZjl/CnLTInVfmxq87OfSPOQ9lJ39JW8yNtre8TUPupjjVA7f2rtT9mu8UWt0iNP/ZV+x0/NWgiW0rHP7Wqx1HB6jsXiWgcAFizO+LAsvplhmj7yVrRNg5VzEwZolKW1X2o3BZz6LV1AsJ3yq/vbM0CdbY+iDYLS2rOeP22iG/G6s1ul+dlZmFlwmY+lvTZroIbK4PeYWzCBrWHocu2AgdL+XWo3FXLNXMZ2ym/JfWq/xI75Umo7NV6pP+v8TOHLua8DgBy2CnQpFo+JTw1lz9hTY5ReGwaofRpwjta6iuwAABAASURBVHfqDbscmxTdEp93d3cprqWzEQPUivVGY6NQRoclNmIcfThxE/2SWp9wt+rtvQ1Wkp+9xViCl9/5mNv3S8ZpZQP+Vr5r/Wpu1zLo354c08dzkKKPXY5Nii5zIXcug4XemOI/VQd/Jfsx8KeOkaoHFmJM1UcP/Rb5wXeN6ACghr1EWxJPASSqu1FjwoHdDSAB2R0DNODU2kevVb3RtO/v74fUxYzax2Z3hB8EMPlpVSueKCRG5kUKJvTQT9F1qLNLSPAN77sE3xA0fT+11zaEkeUavPSVLKOVlVmTvGNcmZIuh8vpK/Qf9FsRkTOXqc1WWHJqv/VcJkZ4T+EcPfRTdNfW0QHASoxTABQCstKQxcPEycOEK3YiQzHwNgOx9t++vPiI9YbexUPjGyxmc3OQZxwUqPaNiTdyF2vlSPlhXrCxojbHaIycoDf2fB/39osS3ukZU/nZb2R1yJd6bZ13W2tyB9499BUwqt5s8+/RG32FukTG8K3Z95kbUzjAFrFQm1y3Evwv1T44wYtuKxz49ZQf8JSIDgBKWCu0oWCQuJmjUJk4c1I41DOzOf/xGVjAxeRaY/I8A3hywdjIya3NvoJjSTYDt7OBqXtqixqj1qg7viNwXNKssUNyqYhYwIFELODjWa4/MKRIrt8x/ZRx0Bmz9XgP7peEHFEn5IfYcmsFG8Rj/KmYiJnahAP4QOANXoiN56m+XOp1AOo8PzFH5GlMOgh5MYTICXUKH8gYF6f3Fp0mKJz6m/oOFnAxp8CZ4PaZCvPOSp45TrwAM9iJI8pUrPF+outZNYuYZwfQw9cMkGOEOiXH5JHvCHko6fvYIa8HSfwCDuqNsU+xcA9/JVgSh75Qi1jAgURewMKzC4NGNxgLYdxTHHBUygl2SCPIz9zqAOAZHetcMFEoGoREzwmFXYuK8ebG4BlY0Ksdq8Se8Rk7hDBcX18/SghhAFOJvxqbMSwR09jnq1evaoY7nC15Jq+RZ65zSIh2IdTXCjiQ6DMHB7rYgn+sLsbuYVMr1NuY7/N7ITzNHzDWjtnSHv7gf06IAb1cHPjELnITQhhCeOIl15cnffhAYnyesJVi6cmO3EQhR1PChrGnuOdiYR6mcAJXc35SnzEWvuYEHXCl+ox60S72FYvPEMp7E3iiLMUbY6j5tIiXdawGw9FsqVNyTH75juRwEO1CqN83MfYplhwc1rrgQGJ81v5z/J3igKMc24g/hPr85IyrA4ActqRrzgAThQVlbEG4vb1dbcMeJ+AUFvPA5TCbAU+1EkIYqM+xus0OrJEB+BAWpkZDuHS7NJfhJISwyQGjS8K2ByUEYsA9A/TREELTvq/e5L4MdgfQy75pd8StBJi+MvXe0bof6ABgpSRrmEsGaEwpL1BMAibJpQebO7wwTE1AmxHkpYYB8hNCGDzUCnVIrdTEs7Yt84e5tva4W4wX8+OhVraIf59jCrUY8M0AfYU+uhZKxmLMtcbTOH0ywLqvtdBvbskPc30JITot+oEOAJaY1/MmDFD4KY0pDt5qAvByubcXusjJUT5z89OqVmjA+N4j78w15twesadiZi7n5gd97FLHkF4DBuRSDDhmYKu+r97kuCh2AI31nnU/FSr1Rq2n6kuvjgG43jo/OgCoy6GsCxjILfw4BA3KerNu7S9i1acNA9RKiacWtYLPEixebFhsSvn0EsMcjtK53DMnc3x5eSYcYsAzA1v2/dzDb888Ctt6DLCmsd7njkitl66juWMdWZ/8wHUuB9hY5kcHALkZkH41AxRxqRMmTqntuR2+arCc+9O1PQM1+SG/VogsfVlhKvFTw2fJeGvZkJ/S2NgoWS6qa8XcyTgKQwy4ZYC+sjU4Dxi25kDj5zFQuhYyiuoNFtqKl/zoAKBtnuX9jIHa5qLN+hmhHV9a1IoVPT29IPYUi1V+a2vNCsfx/ChiMeCXgZqNulVU6tdWTB7DT+1axh77GExtE2XtfCY/tT5i5DoAiEzo83AMeFjcIZ0/q8Wn5DkDFk3OwgeoaLp89iC1GwSPHNTO5Z7y6zE/k5j0QAw4ZcBLn6Q3Wa1jTqkWLGcMqN7aJcQTtzoAaJdneR5hwKL4LXyMQNMtZwyw8fEASfXmIQvtMSjP7Tk+H2Htax22jjMuXsZ50V0xkMKAp/ljsY5Z+EjhTTplDFjlx80BgKcJVJYSWYmBbRl48eJFNYDe5qFVo6wmVg6aMqDab0pvK+dZfnvrTVnBS3l1BjzVmycsqydCA4qBjhiw2JNa+IBSNwcAgLHYxOFH4pcBi99WZ+HDE0NW8dT60fzzVBXCsiYDNzc3aw6nsR4ZyPvF4iXIwkceav/aqv3xHFErHtZEDxjGGdLdyAC1Er/rUwzshQFXBwC1LzB7If3IOGmUNQtab5sVy3jgtqa2au1rxpatGKhhQGtHDXsb2RYMW7t2qMcVkH5gEw/14gHDgUtgMXTLPdziYFIQA4YMuDoAoNHVLPCGvMhVQwZqNus1tg1DKnZtHU/pYsS8s8ZSTIoMxUAmA6wdpbWPnWo/k3AD9RIXylMJa9M2qv1pbnhCvbE28n0LYWwwbDG2xkxjQPlJ40la/hhwdQAAPZpMsNC3lG7W2az0xEyLeJg/bBpyecIu10b6YsATA9Swat9TRmaxFD2sWTuoj6JBOzViroiT5eRuyZHVn/VdjlIaJQzc3d2VmMlGDLhgwN0BAAu8JpWL2mgKgkU15wUYXWyaglrRect42DTgPzUc5hvzLlVfemLAKwPUPi82KfjQo/ZTdKVjzUC5P9aBnP6GLjblI/ZnSe2Lk7S8sjZSQ2nadlrqTXZctvBEfqiNFr7lUwyswYC7AwCCZlLd398PWzRdxpesw8DLly8Xc8xGhUaL7jqo2o6yVjzwtTR/IhbmW9uo5V0MrMcAhwAptY+ean+9vDwbqfIip7+hWzlcV+b0fdV+XkqpIfYhS30lz+u4Nvlh/6veNM7P1nfJD7Wg/GydCY1fy4DLA4AY1GnTZdLF+/rshwFyzGLHwooQGblGaLK9bFS2iOeUW8bvlVvikoiBUwZSav9UX9/XZcBitNMcx7UDv/S6ntYOYqoVOIGjyEutvyPa88JHzcEjYskB+UGUH0tW7XyRGyTmh1qw8y5PYmAbBpoeAMSXNyYLQvNEckKNdvjiRXFJcnwfRff29nYIIcxK5Dk3P1YcMi5Cfsk1AiYr/638sCCAeUlK4sEGTuAhhDDwHcmNBRt8gZFPBJ85fqINdiHM11IINs9z8O1BF/5rxXrjuQfeajBa1H7N+NF2i/kTwvI8ZD7DERKxrvD5eohTXiKW1w8Tv4AdiXMr+kw0f1TDBgFDCOW99tHZir/wUhLjnvskNjgivhx42GETBR9Ijo8tdK+vr2f3OyGEgZiIBcnBiD4yx3fuM3hGwJSDJdpgF8L8fIeTHN8tdVP3TXM84sMC49wY8Rk8I/CcM2a0wQ6hbpAcH9Jtx8DR89PkACCSSsN59erVEOX24UUUCSE8vsy0S6s85zJAjsgNEoLyk8uftT6LBfOHfJAb/PMdCWG9/IzNZbBIxIAYSGMgzmXmMZJmtY4WeOgpSAhr9ZVhYBMcQhjocWCIsjYOWI75iVi4Bw4khPU4YVwvMtb3yRGcIOQPHS94S3DsOR64j3VLHEgJB7Jpw8BYfsgRcwcJ4Zh9pQ3b+V6VnyfOzA8AWBhOF9KnYS5/ZRKge/lEdzwwoPxskwUaUwjh8dBsDsEa+WF+pszlOZx6JgaOykDqXPbEzyp95eXLgXHm4uZ5CGGAwzm9mmf4vrq6Suq16NWMtSfblw/5Wer75AcddPcU2xTWPcUD53DPC+VUPLq/HQOp+aHm0N0O6TFHpu+nzJ8j5Mf0AIBihrTUskIXm1R96a3LgPKzLt+MRmPiM0XIT6uNKfMS/yk4pCMGxMBzBuIm4/ndfVwx75n/LdDiF/+pvumHcJmqn6OH79SXKPRa9doczK11c/NDLlvlp3WsY/69x5Obn7EYda8dA7n5od6waYdInk8ZoFfR90/vzX3vPT+mBwCQNUfm2DNsSMrYM93bngHlZ70clGww2Zi2WEDI+3qRayQx0BcDLebkmgwx/63XZTi5vb3NDgO7bKMFgxKfrXrtAtTVHsMJec8dMGdDnet7C33isa59qzhK8mM1tvwsM1CSH2y81ttyxPvSYG7nIu45P2YHACweucRG/Rrb6EOf7RhQftpxGz3DMRvMeJ3zSYPK0V/SBcuSjp6LATEwzgDzp3Quj3vc5i5xWI781KfyPcKl5QaZuEqxYGeJJZ+NdhbEVuodTkttPdp5jMcjJo+52wpTTX5qbLeKd2/j1nBcY+uZJ7MDgJrFw3qB90z4HrEpP+2zVruprLU/jbBmLp/60XcxcEQGLOfilvxZ9v3XG6jCgGrtC4cdNfOEZRRgwc3amu1tzaD2C2hsatIbx03J2sB5TX6ot9o5uEHIuxpS+blMl8kBQI8L4iVVx76jHLfNPwtAzQhW+bHyUxOLbMXAnhmonct7jn0Je+lzOLXaINdsBEvxe7ez4NbChyeePMWjddlTZVxisciPp3q7jFB3LHLsjUWTAwCLoHok14IX+eifATX+djku+XsV2qGR594Z6G0ds4rn7R63efotcHAYsXkgxgAseLHwYRxWlbve4qkiQ8bNGVC9taPYYh3z1Pet9rVuDgDapV6eLRiwKjgLLPJxyYCn5nSJTnfEwDEY6K1PWsXz1J+2rwGreCwiscBi4cMiFvkQA2sz4Kn2LbBY+Fg7B3sZz4LbFy9emIRrgcUEyIMTkwMAnVw9MNnof4uTq0bQ5LZDBnqby56abW/lYtGbLHx44rW3ejONpzJRVr2pdiN3c3NTGYk/c4t5aOEDZmrzg4/exNM8tODWKp7aWtFcHs+m1Vwe977+XYt6s/BB5BZ+LHyAxeQAAEeSvhnorSH0nS1FBwM9Lu7E5UVqF6Fe81O7KfWSX3DU5hgfUbx8eokJHLW1YrUug6UmP5Zz2Sqmmni82ZKf2lrxEpNlrcCLh7jAUZsfL3VvmR8PuYkYvOTHolbwEeOq+dQBQA17K9iS6K0n5Nbjr0CzhuiQAS8LaofUvg5JveE1Fa+/9FJ3xrl9zc/WX2ryAyc19uex1/gCy7m/mmtrf6VY2PPUbtZLx/ZsV1MrnuKyjKPGF/VeY3/OaY0vsJz7K71m/lj6K8Xhzc5LfuDFCxYdAJAN50KxbLUgMi7jO6dI8MTAMwa0AD6jo9kFvYEekTsA+cE2124P+j1swOzz4ytzd3d3RYDIbZHhhBH+4Hri8eRt5pz1/MEfficHnXgAfmwnHhfdtvZXBMKZEbVSkh9PYVAr1ng0ly8ZZf6U1Ar5wfbS4/7vMH+IryQSa07A4iE/OgAoqYYNbKwLMDWErcZNxSc9MXDOAE1edXvOSrvrXK6PkB84Ic52rLfzzMYE/KYjOHPGBiw3P+hjZx0KXOM71S/5sfr7EM7vqJZVAAAQAElEQVTHBMv5vblrcOfazPmLz+AZ3/Fan08MkHfy/3S1r1/Jp5daAQs1Zs0g8eE71S+5JKep+jl6YMnRB3euTY5/D7rER5w5WEoPmJbGIO/kf0kvPkcX/PHa4lMHABYsruCDZnV/fz9QBCsM9zgO4zHuGuNpDDFgwQDN3bpJWuDq2Qc9gl4B90txonOU/BAn8S5x4uk5eNmYWGPy6C8nP2wC0W8VB77hfsk/63/L/Hiay3AC70ucHO05+U+pFU+8gJd8tsKEb8ZY8s/8oabQX9ItfY7vVCzksnScJbs4l4l5SRe84F7S6+E5cRLvUizwRq3A45Ju6XPyn4IFHXRLx5my0wHAFDNO71MEFAPF2QIifil6xmnhXz7FQAsGYt3S3Fv4l89lBuB+qjcdNT9wkno4ssxwO43G+WkHvNLzXH7ghHomfy03gTGEJSxrrstgIXY4iPjiJ/fAgk681+oT3uEfLK3G2KNfuIcTxDP+NWsFTqZqBRxwxb6WmmrN2RIW5g9YWuPAP+MQOxxwfSrcAwt4T+/3/p1452oFTuBtrVohP8g5763z4+oAgKTUyjmBJdckvhZHjn0uRnyDkQKmUCmcGsEHgj/8rlH0uTGn6oMfgaMlSfU5p5c61hpY5nCu/aymHlNtqVmktG5zcrc2f63HW6rH+DwXB3bwSk7IY01+csf2rA8vcAIfCNxsLeBAwEXOcvs+NgixzctLk9SkjoVe7oDgh4eYE3jBD/dzfdXqM+YpFr6DpTY/ubjAwbiMDy9wwnfubYGFsRFwgGdO2Djnxrs3ffKDpHICXxYx4mdOyA8CrpJaqcUYOYkYwQIO7uf6jnbY8j3XHjt4iFj4jp/c+ZM77rk+OBiX8cECJ3zn3tpYzrHVXIOf2BC+5/rCDh7gBIEX/JRwgh3+kBIc2EUs4OA7PkuwpI7v5gDg1atXw+3tbbWkBj6nZ4UlNZ4QwkDy5zBNPaM4sK0RfCBTY+zhfpwo19fXA5LCvUVcKeMs6VBvFli8+GDzVVOPqbbULJIb92mtLOWG573lh3iIK0VCeOpN5CSXZ2xK8pM7zp704QOBm60FHEguf6fzJ6nXPqzruWOM6afWLZhCeKrbMT9z92JOSniZ81vyLGLJtZ3KTwhPnOA31yc2JZwsYcnFgT44wDMn6B1JUjhBx4KTOd55xjiIxVg1PsCC5GKJNRtCeLaXtOgrNfFY2ZZwYjW2lR9iCME+P1a1EsL6vbaEWzcHACXge7JhMx7CU9H0FNcasTBpac5sENcYT2PslwHVSn7u6E0Ii26+tSx6YoAayO21W8VPzYYQBjb0W2FYe9yl/MAJgl5rbFdXV48vUFPrMjhC0J6ndR7kP50BesVSf6Nu15g/6aiPo0l+rh76CjmYippn6Ew9t7pPDczVCjgQ9KzGtPajAwBrRiv9eS+YyvDMzZnoUxsM88HkcNcMhBAG1Up5CtWbyrnrwZKNDDWQGcvm6mzS2DhuDqQxgJz8kEf0W0HKWZfBcoT8tOJafm0YYD7QK1K8UbPUeIqudGwYoEeQn5Q9HDohBJuBR7xQK9TAyKOLW+ihf/HAwQ0dADhIwjkEzwVzjnXLayYVE31LDBp7HwxosbbJk3qTDY9780KvJff5uH1YgN8HkjYoiC83P+hjZ40In7nrMht7NvjWWORPDKQwQO0xH1J0ow41Tq3Ha322ZYAekTtCi30fOc+tFfSxy8XfWl8HAK0ZLvRPwRSaHsKMySSODpHq6iCpFRbrakdy8MiA5t0jDYf6pTjnTlhi/tMHnMAxh1Gan1K7qQDguNQntlN+dV8MtGSAA4AS/9R6qW3JeEe1Ke0N9H3r/JDzkjxgZ42lBMepjQ4ATtlw9t1bsTijR3DEQBIDNN4kRSklM6DelEzV7hVLN18E7kl67QO1+fEyl1ts1j3Vn7D4ZID6r+kNtfPPJyu+UHnJT22ua+2ts6IDAGtGDf15KxbD0Kpd1TSE6sHlYDcMsLjvBuyOgKo37ShZlVArem3lyPbmPfaD2pgs53JtrdTGYl8x8tg7A7U1x8FV7xxtGV9tfyI/tTneMv6WY+sAoCW7lb5VuOMEajKP86K7lwyoVi45sbhDb7LwIx++GaibP/5iq91M+otoqP6LTZnLFnm28FF7gOAxP8LkmwGLmrOofd8sCR0M1NaKVa8Fi4WYHABcXV1ZYJEPMZDEgJrtJU0vXry4vFlwx2IuW/gogH4IE0/cah4eouTKg3Ro6Wn+eKJHvHjKhrCsyYDF3klrYbuMWXBr4aNdhNt51gHAdtwvjkxj0sK8SJMUHhiwqhMrPw+Q9L8YEAMHZkChr8MA+4SakWrta8Y+t725uTm/VXRt8Ts9elsLLeKxyk9RUh0bWdSb4/A2hWbBrUXtb0pCo8F1ANCIWAu3KloLFuUjhwGLmrNo2DmYj6RLfjxt2I/EvWLNYsClsnrTZVroKZd38+/gp7Y34SN/5DYWnrBYRVibHyscnvzU9gRx6imb41h6nMvjkebdNTkAYEidDMKCrdQ2Jls08uaZActaqZnLNbae+fWEzTLXnuISlp4Y8BdLr72pth/U2p9musYX+bHaqOOn5sUMLKdx9fK9Jj9wUGuPD29SWyvYe4upJzzwq7ncJqNmBwA0hpoktQlvv157XYD2mxG/yK1rhblcGm2NbemYR7OrXRCPxpfi3YABh0P22pvoB6VrQKndVHrBUroPxHbKb8n90nyDv9S2BOeaNnBcmvNSuzXjKx2rNN9wUmpbivWIdqUc9zyXLerA7AAAMKVJwlbyhgE1lTdc6Ns8A61q5e7ubn7gkaclNiNudCuBAfXaBJKkshkD3gamT3rDZImHfsBmN8cnnGCXY5OiW/IXboGFl9MU/6k6+CtZk1pwkop5DT3i81Ira8SbMga1Qg2m6J7qwOXptb63YYD8aC7bc2t6AFCaJPuw9uuRJqSmst/8rYm8Za3kzmWaMzZrxn/kseAaznM3ckfmTLGvxoCrgZgnR1hTefFmTUghH72WnNzf3w+pvaklFvok/lM4AS+1gk2K/p51PNWKFx6ZDzm1Qo17wX4EHMzLnPwcZS7X5N70AAAgJImJkZoobCTD42JJwdKExIcYmGMgblRa10rKXI5Y0J3DrGf2DMB5zkbOHoE8ioExBnzcO2JvYk2Y23tFTtBrnaWl3rQWFmJd2pPCGXjpqa158eIfXoh7Cs9a+Zkaf4v7cMI+fI4XnlErW+A7+pjkR3PZrgrMDwAitNNEMWFoJpIXjy/6pzzADQ2HhrLl4sP4FhLzf5TP01y2/k6dIOSppFawK8nL2FwGB4LPEiwlOPZuA1dLUhLjWH6WarFknHObpVh4fm6z52viOaJk56yRwVJNx+f0JYRclfQm7LxICZWxH8AB+wt44ZNr4irlpAYL4yNgAQfiBQsvFHBWEh8xlNhZ25TiIG7iJzcI+eFzi/xYc4K/El6YH/ACB3CBwAvXcMUzfOcKWCRvDW+99dYzyeUR/ZcvXw7kgtwga+WHsWvlrbfeehb/WyPXtWOk2jc7AIgAXj4kChkLUvfeGuDm6uoq0rXqZxw7hDBcX1+bSAhhIB58rxrMRoMR51p1DK9ITqhgwyaE8JjfEEJxfogViT7xm4Pl6LopcywEm/yQoykhhxa5uL29faypubhCCEMIYbAa0wJ3jg84pM6RuTh7fUaOc/hCt5WQA/KxJOghOTjwiU0IYbGm18x1COXzh3iYd8TGJ9c1nIQQNls7iAH8IYTH/IQQzLDkcIJu5DKE8BoL9xCeryWRE3ihJkMorxWwI/jkE585cWCHTQhvOOEaXzl+LHTHsIADyfEf8WMXfebYo4stfkJ44oU8SZ6/a4QQ3MzlpdyQ01phTV0aJ4TyuZyDr/kBQA4Y6a7DAE0phDBQiK9evTIfFJ+3Dy8HIYSBxmk+gBwmMXB1dfW4QSEfpwZcx/xQC6fP9H17BnrMzx7rjbnBQk0+kO0rYxcIdgWS9elqok96CmTt+XNa+6c8MA/WxDKXn1Ms6J3ibPGdMUIY3zfBCQJvLcY+98k4U70JHCGEAZ1zuxbXU/PnND9rYCE/U1jgBFkDBxwzTgih2R6bMXqS01ohj61jY4wQ/OeHmg0hNJvLOgBoXWnO/NOYKKq1YLFIMdnWGk/jDAN8hxAGmuoSH9QCNbGkp+fbMNBbfvYSz9XV1ePmbdB/mQzsR52+x/qU0ie9RMX8oTZb4sE/4yyNgQ4cLumVPmcdS80Pei2x4JsxlmKBE/gD+5Ju6XP8M86SPTrgXtIrfU6MYEmZP62xECf5WcICjhDCAPbSuJfswMI4S3p6Ps4AeYTD8af1d/HNGPWe1vNAPYHbekQdAFgz6tgfBUQhrQ2Ryday4a4dj/fx4DsHIzWh/OQwtq4u+WHurjtqu9G8xwPXSxvJduzs3PNO4NPvqMOdwH0Gk9q8ejigenbT6CK39uEQG6Phn7nxso4RH3E+AzdzQX6wmVEpfoRf/Kc6ADc2qfo5evjNxcK8yxkjRRefxJmiG3VyayvaLX3CSS6WJZ9HfA6H5NU69j3nB07Ab8mJDgAs2XTuiwLaCqJ14W4Vh/dxS3lutSB652sv+Ji7LRbEreL3Gg/zB2xb8bL3cfeCf+/9jhcvatWSb/yV1D421r0JLCWxldrNjUV8c8/HnpEf60MaYivBgk2L/BDjWOxz91rMu1Kf1vmBY7iei1/P0hmg3tO10zT3nh/wU2dp0S5r6QBgmaMuNFpMphxiWCwsCzdn7CPp0iBK4926RkpxH8Wut/x4jKdm/hylDmfi3MUjj3VXQpx1rdb4s+QUX6VYrPcZYCnJDTbWWEo5AUtNHNifixcsNXFZ50f72/Mqqbu2zk9NrdRFYmttGYcOAGxz49ZbTcO2CsqycK0w9eSnll8tYL6rgQXRN8I8dN7iUf3n5e9Sex93esqzVSy1a4enuVwby2kVe9g3gac2z+Sn1gc4kFp+rXCApdZXbSxgiOKlViKeHj6Vn8ssWs5lHQBc8tvdndomaUUIhWvlS34uGajNM/mp9XGJSncsGegtP57i8YTFsmZW87WTgehzO4G6CNNyg7w42IKC1fypfZGyyq9FPFb5scCykL7kx7VYyE+tjwgWX/H7lp9Wed4yBo9jW+XXqt48clSDSQcANeztxFbFv5NEVcK0apaVMGQuBpIZ8NSbPGFJJtCR4h6gKMfjWbLgxcLHOLr8u56w5KNvY2HFiZd9hkU8XmJpk/E+vFrk2cKHJzat4tEBgKesNsJi/ZedNIK5S7fi1nfalB/f+fGETrVSlY1dGCvH/tP04sWLapAWebbYZFu9YFpgsfBRnRg5EANioJoBq7msA4DqVPh3YLEYWkR5c3Nj4caND4uNiptgOgXipfat6O0tHiteLPyI2xoW92Orvr2fXJUg7W2fUcKBbMSAGBADSwzoAGCJoU6ea9Njn0i9MNhz2sJjL7WvjW2L6njjk/ncS628iWqlblkVggAAEABJREFUbzsaRn9e13eylB/f+RE6MSAG+mBABwB95HExiq0XVV5etsawSFKGAi8KPcWTEfruVHvJUy9xeC4gcVyWnT1Z6aDHd7Zq8tPbPsN3poRODIiBPTOgA4A9Zy8DO4sqi2OGialqbxvr3uIxTbYzZ1vXvgUdW85dC/x78dFDrWzA9e6GVP/2nTL+jCuH7LkolddcxqQvBsTAURnQAcCBMs/iuMWLxN3dXVcsEw8vCl0F1XkwW9W+Ba3MWfBb+JKPZQbgGs6XNaXxxMD+fqV/08f3h/w4iJmHOdEqnzlsSVcMiIGjM6ADgINVAIvqWptbTvDv7+8HNls90Ew8bDJ6iaeHnOTEsGbt5+Ca0o31Bu4pHd1vwwCcr9Un20SwotedDkUfZ31Snn0mMDU/sU+i7zMSoRIDYkAM+GNABwD+ctIcEZvbuPGx3vywGCO8KPPb+JoHs8IAp/Fok7EC4Q2HaFn7VrBVb1ZM1vk5rRVyUuetX+u9R0aeWQeRvcfSI/6x/DAfkbjP0LrcY+YVkxgQAy0Z0AFAS3ad+2ZhRTgMsBJe+pHcBTnaYIeEEIYQxuX29taE2dSYIzaTQeXEBQPUPZJSA2wyLUCnjIVOSb1hgzB3kBDG504IYbi+vrYIx8QHczmEaazEgpArxGTQTCeMC7fkZkmsXiKXxnH0fEjBkkn5qHpOrZCvUScTN8kxkhILOhNuDn07Jz9wnUMW+gjcI+QXoTfk+Dmy7qtXryb3VCFM9+AQnj+z4JA1KITnfkPIu8aHBZYQ8sYN4VL/1mBPyoEWtd2LWO2byHMIl5yHkH7PIj/UmkVuyDO+PIgOADxk4cAY4iLOJGeBinJgShS6GEhm4HT+nM6hZAfOFWM/YAFHQggDLwLOYR8Inp9QT2uFuUCdMD/8IDw2ktP8aC4fuxYUvRgQA9szoAOA7XNwWARs0NiosTE4LAkKXAwUMsDLzRHnDy8P9I5C2mRmyYBjX9QJ80O14jdJ5Ej58ZsfIRMDYqBfBnQA0G9uXUfGos/i7xqkwIkBpwzEl3+n8JrDonfQQ5oPpAFmGdjDQ9WK7ywpP77zI3RiQAz0yYAOAPrMq+uo2Liz6LsGKXBiwDED/GTTMbxVoNFDOAhZZTANMsbAbu6pVnynSvnxnR+hEwNioD8GdADQX04VkRgQAx0zwAFax+FlhSYusugyVt6XO9WK73wpP77zI3RiQAz0xYAOAPrKp/to+Ikdp/3ugQqgGHDKgObPm8Tw94fQU97c0bfVGNjZQKoV3wlTfnznR+jEgBjoiwEdAPSVT/fRaLPuPkUC6JgBzZ/L5Ognh5ecrHFHY4gBawY0l60ZlT8xIAbEwDgDOgAY50V3GzHg5QXG07/F2Yhque2QAS/zp0NqFVIeA7vU1gum77TxuwC8ILy6uvICRTjEgBgQA+YM6ADAnFI5FAPbMKBDjW14X3NUbUrXZFtjTTOgJx4YUD/wkIVpDFZrsvI8zbGeiAExUMaADgDKeJPVzhnQgjqeQPEyzovu+mXA008N/bJkjEzuumLAy++MuLm5ccOrxVpo4QNCrPzgSyIGxIAYgAEdAMCC5HAMeNnwWBJfG5OnzZclLz35YiNo9VOlnnhRLOsyoNF8MFDb831E8QaFt3hqey39+k105d+s/JQjkKUYEAO9MaADgN4yqngWGej1RZdNQs2GxdvmazGRB1VQng6aeD9hC4kDBizXsdq1w4IOy3gs8OCjptcSD7zix0LwZ+FHPsSAGBADMKADAFiQHIqBmkXdO1GlsWlz4T2zb/CxqVS+3vChb2szoPG2ZoCD3tJeP4Wdv2AUv1PPW9+3jscCb02vtY4Hf1vmx4JP+RADYsAPAzoA8JMLIVmBgbu7uxVG2W4INiy5MfIyyeZiO9QaOZcB8qXNYC5r0jdhQE42Z4D53wJEK79LWHPXrCV/ls/hhDUyx2eufqpvDmlSdaUnBsSAGJhjQAcAc+zoWTcM8LLEJoMX5G6CmgiEGIl14vGz22xU2OA8u6mLXTDAZpD87QKsQHbDgALZjoHW6xhrx/39/cA4a0TJOKxVjLvGeKVjsEam9NoYD/qlYy3ZkZ8ULEt+9FwMiIFjM6ADgGPnv/voWZBZLHlZ8r7JsEwGsc5tFOCFjVfLjYplPPI1zgD5o76RcQ3dFQOmDMjZBgzEfr3WOsY4LXsK8eCfcVirNqA0e0h6LWsmuM+N144HLOBg3HMsuhYDYkAMpDBgcgBAE6chSV4OL1++7FZSCmoNHRY9Fr85YaFGYm3m4op2Lx/ymWtrrR+x8JnrG/wcBMBFFK7xlbvxwgbBJ5+5WKTfhgHygZBXcjw3LyyfMQ/bRJTvlfhTJN9znxbMXwTO8iKUthUDzJ+l+ch8RshVbr8GJ3bkmE+ucwQ7egqyhDP1ObEg4MF/Dh4rXcZGSsYnB9jBCXFEKfVXExM4GBcsqfzXjOfRNjXuOT2PcbXCRL0g1E6rMaz9pvTJufzyDB/WuHrwZ3IAQDHd3t4Okn45oGl4Kfi4CFN3U4IOkoOZGLEJIQzX19ev6zmE8Hiok+OrVncMC5hCKMNCXFFysUUsjI8wz/kMoQxL7vjST2eAHE/NCev76ajaa1KTKRLCsWt2bC6HEIYQEnlpn8rDjJAyV9FBckiJOQ7hzTpW26+tegexIDnxWOlGXuACoV+EUF77xBHFCmOpn5T8gLXUv0c7XupS4l7S8RibNSY4COGpH5zWPvcR6/Es/YGvVnqrfSt+TQ4ArMDIjxjYigE2BzTGV69ejUK4fTjgCmGdTTLNzgsWGucSFnRGSdNNMeCQgTXnsqfwmae1c9lTPMJyyYCnteMS3TZ3WNtTah/utkGoUcVAGwZi7bPmjY3AfUS1P8ZO//d0ANB/jhXhAgM0PzbGC2qPj1s3S7AwxuNgC7+gR4NfUCt+zKZp6kDk1Ck6IYShJZbT8fRdDFgwwPxhvln48u4jhDAwT5dwohNCmFLTfccMUMvUdApE9NBP0d2zDmsSazt1vRQHnFxdXS2p6bkY2AUDqv1dpGlTkDoA2JR+Db41AzRJFv4cHOi32DzhE985WNjcEEOOTYouG6GUTdOpL/CfXuu7GPDOAPOt97plLufmYdwm14v012KAGqaWc8ZDv8XakYOhtS685IzBmqfaz2FMul4ZYG+Yg43az50vOf6l648BHQD4y4kQrchAbpOM0Ng8xe9Wn6U+rZs2/lgMcuPCBttcO+mLgS0ZKJ13W2JOHZv5yLxM1Y962GAbrx8/9YtbBkpruOccExt1nJs0bHo/GMnlRPr7YoDaL0FMH1HtlzC3TxsdAOwzb0JtwEBpk4xD19pHP3zW+LLesLAIgKlEamxLxpONGLBgoGb+WYzfykfNfDy3bYVRfusYqKld67WjLhJb65r6reHUNgp5EwP5DKj28zk7ooUOAI6YdcVswoDlSWlNwyYYqw2LRUwWPohJIgbWYqDHmrWI6cTHWqnQOJkM1ObIau3IhN1UvTamng9GmhIv55szoNrfPAW7AaADgN2kSkCtGah96bbaJNRu4Cx5scBi4cMyJvkSA0sMMJeXdPb23GIevtlM7i36tnj5J8jajpDuvbZ2a+3TkUpTDIgBMbA+A/p7PcY51wHAOC+6KwZ2xYDVJs7ipWFXxAmsGOiUAYu5/Hrj1AlHnuKxwGKRY1Jr5QdfHsQiHgsfHrjoFYPF/OmRG4u6tfDRG7eeDn2tuNUBgBWT8iMGChmwWMhubm4KR39upp/4PedDV2JgrwxYzuW9cuAZt0Xfx4fFxhQ/nrkStnoGlON6Do/iQbVymekeOdEBwGWedUcMrM6AxSbOArRFk9OLh0Um5GNNBqwO0NbEvDSW4VxeGmo3z616k5UfD8T1WPseePWIwcs+w4KbnuagBR/RhwUvFmtHxOPhk3h6qn0rTnUAYMWk/IiBCgZqm3at/Sn0mkapzeQpk/q+FwbYIOwFaw5Om7mcM6JfXcveRL144ba299fa+824kJ0z0EuuLefyOUd7v/bUmzxxWVv7tfaeuIhYdAAQmdCnGNiQgZqmbb0Y1jS6GtsN6dfQB2aA+cP865GCmvn42rYTYqzjKfXHwUGp7VgqqF1qeOzZ0r1SuyW/eu6TAWqF+vOJLh2V5fxJH3U/mqX8UBultt7Zqan9XvukDgC8V63wHYYB/uIVGnBOwDQm64ZNo7y7u8uB8agLlscv+kUM7IQB5pv1/PEUusVc9hRPKZYWvQluS/zS50vjmLKjhqnlqedj98GO3dgz3euXAeovt1Y8sUHdesLjEUtpb+q9H1D7ufmi3nrlRQcAudUgfTHQkAEaVOri3LIx5S4gLbE0pFuuD8wA84z51jsFuXOZw7+TDc/u6WnZm+AJ/ykkUW9wm6JbokMt52ABe8k4stk/A9QK9bi3SKhv1W1a1uAJvlK0qQV6E2tFiv6edYiTeFNigD94TNHdo44OAPaYNWHumgEWZxrPVJA0L5pY68aE//v7+8EDlikudF8MlDBATTPPSmz3aPPy5cshdS4/3wTuMdonzGv2SeoJeRr58lewUG+tuSXPczhAxtoBFr5LjssANbBUK17YYf5Qt9S3F0x7wAFf5BiZwgu31ELr3jQ1/tr3iZN4lzg5Qr25OgCgECUvBmsO1p5grcdj8lpIa5w1/mncccNOo4o1QVMidppYrn/scm3QBwvjnuPgHj5LsOC3Vhi71kdv9nCC9BbXUjxxfix9UrPMK2p6yefYc7idkzEbT/eIGw6S57Ij8Eu5jc+JjRjJU0lvwi43bHhFGJfxIxaukRKf2CAlWKhxcCCnWLhfwkkuhjF9YkHGnh353pacULPUBHWCxFqZ+7TI1Zz/02dgivOntG7hd04s4vHsgxwj8AifkV+uEbjxjL8VNjgZq/3IyRHqzc0BAEVJIUreGt566y1TYdK3mkRb+H316tVwfX1dLVtgzx3z5cNP7pC33nrrsSaurq6yXLz1YIcNAmchhOHl2z5zHGGPHf4QrpEcHxa6p2PXxGOBxZOPyAucICE85dkTxpZYiD9FSmqWuscuhLDYc25vb1uGaeKbWIgp8sU1Mubc0z0wRsxzn8SGbg52/GETwlOOQ3iaP/jK8YMPbPCHcI3k+Ih2zGMEe3zm+EAXGwR/CH64v7bEsYkFCeGJ27VxeBovckJOTjkhX1vgZFwEXEtigS91LPTgKGdM8GMTQhhCeJrPcDwlOb73rAsn8Ak/CNfInmOywA4nCJwguZxEG+xCWK433l8scFv4cHMAYBGMfIgBMfCGARoSix4NB4lPeElBQggDzSve9/5Jk+4pHgu+yd/V1dXji+lpjvEdcwxvXEvyGIC3EMIAj+fc5nnarXb3wJfmD7mnDtYgYgoLtQeOEMKwFhaLeKfiwfce4wG3hVxdXb3u1+Q2+oQT5OrhOdzF+/pMYwDO4C7uEdKspCUGyhk4rbfTuVzucV1LHQCsy7dGEwOrMEBjSmlILJZ72AsEYKAAABAASURBVFQSD5ujJfL2Es9SHCnPyRvxLuUZ3tBN8SmdJwbgC96ero76a99x88KQOn9CaHtYSr2lYkHXe2bAmBoPvd17PBb4qDdiXerXPIc7OLQY9wg+4BbO4O4I8SrGbRmg3lLm8rYol0fXAcAyR9IQA7tiILcx8aJDQ/MaZG/xWPDM5pC8pfpCFx5T9Y+sl8ttt1x1HBj9jheGnBCpixz9VF38Mj9T9dHFJlV/bT2wgTF1XF7ajtCb4IVYU3mBQ+o0Vf+oenCUO5ePypXitmEgdy7bjGrvRQcA9pzKoxjYjIHSxoTdZqBnBgZXzqYpuup9Q8DmMMaa+gmPbJZS9Y+oR72VcNsjVz3HRJ5z42P+tHhRLak3bLzOZbCVcFuSk9xxttInNuond3zscm2Opt/7Wn+0fHqPlzlZMpc9xqUDAI9ZESYxUMhAyeaLoWhoNDa+e5LSeIjBYzzgqpWauGpsa3Hvwb6m3vYQXwbGblWZA/S7kgCxs3zxBksJDmxqbLFvITWYep57pbFZ11uLnG/ps6betsStsffLQOlc9hixDgA8ZkWYxEABA7WLoeXGtgD+hUlv8VwEWHijZgHShnKadG/1P410jSf9jlGb59q+dMpsb3O5Jh54qc0NPrxJbb3U2nvjwxJPj/ViyY982TLQ21zUAYBtfcibGNiMgdrFsLeXw97iobAsFiALH2DpTWrnT1d8dBwMfcFDeBbz0MKHFRcW88dTPF548VKvVnxY+hE3lmzK1xIDtQecS/7Xfq4DgLUZ13hioBEDvS2GFs3WYlPaKF1yKwbcMtArMIt+0Fuf9ZTrHrm1iMmibj3l2QKLOLFgUT6OzIAOAI6cfcVezUCLvxSqFNSLFy9KTV/bKZ7XVLz+4okTCywWPl6T09EXbShfJ1NfxMAmDFisYQD31OMsYvIUD/x6EHHiIQvHwmAxlz0xpgMAT9k4AJaefouft2ZQuyB6i8eiVmo5iVOylpubm5voqurTKp4qEDLunAGFJwbyGbDoTRY+QG7hx2L9AUut1K49teN7thc3nrMjbN4Z0AGA9wx1ho+FuZemTSye0lOLp9beExdgsXrpxpeXzSBYauePp1iIR+KMAcERA4UMeOlNrGU1WDytHcRSmI7uzbSWdZ9iVwH2Vm86AHBVXscA08sk8hYHG4WaTY/HeGo2Ypbx1HBLDJZYanyB5RhdRlGWMiA7MVDKgKfeVIOlNP4xu5q1A39e4gCLN6nl1ls8wuObgd7qTQcAvuutS3Q9TKK7uzuXueHPMZccAnh9MWTz4yUesJQkvdRuaizmT0m+sLHGMoVR93fLgICLgWIGPPUmT1hK12Wv+4ziAmlgqDWtAalyOclA6VyedLjhAx0AbEj+kYdmEvFCskcOwM3mwiv23AWReHJt1oydWsk5BGgVDznP3ZDl6qfySr6IM1Uf/rBJ1ZfeURlQ3GKgjgH6jJfelIsF3NjUMTBunesXLKw54950NzIAR3AVr/UpBlozkDuXW+Mp9a8DgFLmZFfNAJNoT42blyhe6MBdHXxDByyI9/f3wxK3e4kHqjgE8BAP3FIDYJqTyC36c3o1z16+fLmYY/zDG/zxXSIGZhnQQzFgwICn3pSDBV2D8EddsBb0ti6PBrrBTfKWsi5vAE1DdshA6lz2HroOALxnqHN8NO6URXFLGuLLHC9RTPwtseSMDbe8/CGndornlI3879RArNmtuSXHEQt5jdHwHWFThE68r08xMMeAnokBKwboO1560ymW0/jokfRwcKJz+qzVd8ZhTOR0DLDQr/e2zziNYcvvc+vylrg0dr8MTM3lvUSsA4CFTNGMERKN0GROhXtR0Ftwp8cTDMAhizDCIjgnLJQTbrJuz40Rn4GHvJLzHOfYINgRG5Jjb6XLuAhxRIm4rMbI8RPHjrxwnWNPLEiMhU984C/Hj4UuOBAwUC98lmDBBj/EwCeSiw8b/IAB4TuCz1xf0t+eAfK2gQytxtye0T4RvHr1qlnOzmuBHoPkMokNvYi+hPAdwX+Or2iDHT6RHHt0sQFDFHxyj2c5gh04EOy5zrHHBok4+MQH/nL8YINgt5bk4NtCF14ROEVYm1uLxZ50zbm8Rq2QA4v842cJLzqIxXi5PhgXodaQpVqzqJVcjFP6OgAYYea0oV5fXw/I7e3tgDBJT4V7UdALIQwUAzLiWrcSGFia7DxPcLOogp8lWXRyphBrh1pAqJVYHyE81caZySEumQ8hhMe5BCcIvMBRCPvnhTrKTeRprcBF5ITvIeyfk1w+pP+GAWphfXk1tBrzTWT6Zs1Aq5yd+6UvISGs25tO+2TEBA4khHWxzK1jPEOs8zvm75QT1tDIyxqfY3g832NtXkMsOFgjf2uOsRYn9AIkhHX7wVh8S7U2ZrPVPR0AnDBP8w7h+UvKyePkrxQiEsL2xZgMWorVDLAox8V4ylmsC3SndHq7T0Mk7rm4eM78m9Pp6RmxptQK3B2pVnrK8e5iEWAxkMgA/TqEMLTuTal9Er1E6EVqxHl1dfX4Q6Bh4j84QdbAsrR2TEDUbTHQPQPMwRDa96YeiNQBwEMWU5r7g1rR/7EYWy8KReBkZMYA+WVRTnWILnWXqr9XPTZNnDin4GeuwGOK7p51iJFYU2KAu6PUSgof0mnHgDyLgVwGWvamnD5JP2WtycWfqk+c9OIUfbCAPUU3Vwe/YMm1k74YOBoDzJMj7LFr8nroAwCKg0WDQklt7qVksyiEoN8RUMqfdzvym4uRusu12ZM+m5XceQWP2O0pzhysxEaMOTboYsenRAw0YkBuxUARAy16Ez5z+yRrDXZFQcwYlfgEO/vLGbdFj/BbZCgjMXBABkrm7pFoOuwBAIXBCxiLxpoJp4Ez9ppjaqy2DNTks8a2bVR13omLWi/xUmpXMtZebOhTLTaUe4lfOFszIP9ioIwBehP9vsx63Kp0DcDOsk8SFz7HUc7fxXZeI++ptb+80aUtBvbHQIvetD8WphEf8gCARlra1KepTH/C2PzOg3QLaXpmgHyW4quxLR1zD3aWmzgv8RJTTb7pW15iEY7OGFA4YqCCAXpbhfkz09o+V2t/CqYmLl4+auxPcfC9Zu3AXiIGjsiA5s101g93AMCLt4eCYHEIQX9RxXRp7uOJxWbDcpPghbXaOWbBqxcuIo7aPNMzan1ELPoUA6cM6LsYqGHAsjd56nHEVcOL1Tpm5acmFtmKgb0y4KmneOLwUAcAvPzXNnTr5PHHEFSc1qzuy19v+beIx9s8tagoC14scMiHGDhjQJdiwA0Dtb2/1j4SoZfuyIQ+xcC+Geht78W7rEVGDnMAQDO3WhgsiD/1AbbTa33fDwMWjcXCx34YE9IaBlQrNezJdpwB3RUD9Qz01pusNtn1zA5Db9xacOLJx9XVlSc4wuKYAU+1cogDAF6wa39Lcst64mDCU1G0jFW++2eAWn7x4kVVoDc3N1X2Ho2Z5x5xCdMTA6wTT98O9qvCFQMGDFjNn9q1o9Y+UsE6Fr+Xflr4KB3bs5148ZwdYWvJgEXtW/ggxu4PAFiUPL/8kwSElwOw8l0iBsSAGBAD6zJgtaiui7p+NHkQA7UMWL10g6N2H2Q5j2vjssQCNz1Ij4f75Lm2VnrIrWJYZoBaWdaa17DwwQjdHwDs4eWfRCBg1W/1ggnJ3hmo3cTV2u+dP+HfhoEeN6cLTOqxGKhmwGpDChB81bxMWa4dNb7oJcRCTJI3DNRw+saLv2+9xuWP6f0jojeURlFjez5m1wcAe5yQe8R8XlS6FgNsfEobVamdWBcDtQzQf2tePmrHX99eI4qBOgbo18ybOi/PrUv9geW5p7qrmnUM27rR+7O2zo8nhsi31g5PGfGLhf5WUivYYGsVWdcHAPxE3YqotfzwRwH0uwDWYlvjtGSARpW74KOPXUtc8i0G5hg4VP3NEaFnYmCBAesNaRyOlynWgnid8ol+i7mLT+JMwRB1wEIM8VqfwwAncNkzF+zdc2ulZz4U2zQDJXOB+pr2mP+k2wOAEnLz6WtjsWfsbRiR170yQC2z8KfgRw/9FF3piIFWDLBxv7u7G46wkWvFofz2zwDz46233moW6MuXLx9fGlMGaL12ECdjpGChd4A9RfcoOnB3FE5yauUo+Veclwywz7i/v0/aZ9Br0b30Unen2wOAPf70P6ZSvwsgMqHPHhhg4WcDgIzFQ3PTpmmMGd3bigEW5wNs5LaiV+PumIHYr5kfrcNg7WDj62HtAAs4kLG4uQ9WesfY8yPei7UCd0eKn3iphyPFrFjLGKCPTtVKnD/olHmft+ryAIDJNx+2/6c9xOCdZTiuFQ5rLOKsxZFq36qRLHEQ8bFBotkhvPRzDabcTRM2UZbG1vM8BiKvMWdTn1a1n4duXHsK4+l94hq3nr6LPTVKrVKzS8KCPe1t3Sdgmcd78/gT1iWddVFPj0b+yEetTI+wzydL+bN6zhxAyENuv4ZZ7Mgd33MFO+ZhjAUcXOMzFws2CD5LcGDH2OdYuJ/rb239iLn1J/lB4Dk3P1acMDZCXmoFP7m4GJM6gYdUvnPHaKWvtePl8PLlyyKxqBVqBsFXy/nT5QFAq0khv30xwO8SqRULRniRqsWRan99fT2EEB4bmwX2Eh8v326sJY0tNkTiiBLCtvGUcODRhryEEIbI61JNeYphCSvPiSuEslqhVuFnSdDzwssS1pdvz8M5PU/xWPRJfHjJjwUONupz+bN8Ri0gObhjvw7hqa8wD0MIxWtQjCcXB5gjFvoAErFEn+jkSLQrwZIzjpWu91qxiDPmOISneot5Jtc1gp8QjrN2UNOxvks/8WGRUwsf9P2a/OfYWtQK3CEWsc/56PIAgGTNBb2HZxQszWwPWIVxfwwwR0IoW9C2iJa5QEOkuTI3zjHsLZ5z/Ftew20IYYDDLXGsNTZxhhA2PQRbK9a5cfRMDLRkgBeHqX7NuMxDejrfWwvjTGEBBwLe1jjkvx0D5G8qx1ajUichaO2w4rNnP3uole4OANjM9lxUik0MWDJAk2LhtPRp7Ys5nbqw7yEea35q/JF7uK3xsVfbg9fKXtMm3DtggL7C/FqCymFuCGGgxy/plj6/uroaGGfJHrzoLunpuT8GUuvNCjm1wphW/uSnXwY814oOABzXnRqM4+R0BM1zg4Lm3BdU7/EQkwehv8CVByxbYSB+eNhq/O3G1chioA0DzCfmVY53bHL0U3V5oU95+Y/+0G2FJY6hT1sGyFduvVkgYEzGtvAlH30z4LVWujsA6LuMFJ0YaMMADarlT2FKUZcusF7jKeWhhR0ctfC7N5+H5GFvSRLeXTBAvy6ZT7x487JuGSRY8JvrE/we18LcOI6iT762ipWxVStbsb+vcakVb4i7OwDoaTKWLF7eCkx49sMAGyZvaGuapsd4vPArbp5n4mh8PI9eV2JgewbY71ju37R2bJ/T1gg89G0PGFrzLP82DHirle4OAGzSJC8T80TkAAAQAElEQVRiQAxszUBts2RDuXUMXse33Gh7jTEH18H4yKFGumIgmYGal+7kQRIULdYO9YQEojdW8ZAj7TM2LoIdDe+hXk/p0gHAKRv6LgYOzAALmacGZYHFwkePJUGue4yrNKZj8VHKkuzEwDQDFr229sV9Gp2eWP8RCw+MeunbFrXvgU9haMsA9eqpVro7AIDgtimU960Z6HEh25rTXsf31Gx75biXuA5TK70kTHG4YsDT/LHAYuHDKkHa81wy6Sk/l+h0RzXrvwa6OwB48eKFf9aFUAyIgVUY0E+ULmnWxumSE+4cZcNCrKkiTi6Z0h7jkhOrO/oBzjiTmofjvHi529uaalVv6pVeKnQcR3cHAONh6m5PDNCc1Fh6yuh4LLUv76qRcV5195KBm5uby5t93smOSvPoOWWsP8/v6EoM+Gegdj31H6EQWjGgHmfFpG8/OgBwnB9tvKaTo8VsmptenrAI1cwB7HvhQnGIARsG8r2o1z7nTHw850NX7RlgLatZC3XA2T5HvYxgWSvqlb6rorsDABqlb8qFzoIB8lyzIFpgkI/2DJQuINRGqW37qDSCJwbY8BymVgqIV699Qxq18uZK38TAegzU9Kga2/Ui1EgeGLCsFdYO9UwPWR3HoAOAcV5c3GXyuADiFIRlo3Ia4uFhMQdKFhDVxuFLJ4mAox0UJZEyotTbn3EdCXHxFn1IfWWRJik0YqB0LaRuG0GS284YuLu7M4+Insk6a+5YDqsZ0AFANYVysBUDLIgtGtZW8WjccQZYQHI2MdQEtTHuTXfFwBMDbEqoraerQ/xaFSTzCs6qnOzUmLhVKztNXkewqcGctRBdbDqiQKE0YoD+3mrfxAEytdgIutwWMtDdAQA8sFjzuXdR417OIA3r/v5+UHNZ5mrPGi9fvlzMMfOeWqAm9hyrsLdngH7BpuRYtVLHK1zBGdzVedqXNfES975QC22vDLAW8rJGXU7FyFqIDrpTOrovBmAg1gr9netWQi3O1WyrceV3moEuDwAotOmQ9/FEEyUvT+Sclz94o6EheR6k7Z2B0xyTZ/CSZ76z2dEmHUYkYwxQJwh1glBLY3pd3zMKDu567rXUCUKdECfxGlEnN2LAhAFe1qhL1j4Ep9QsQt2yFqLDfYkYOGWAGkGom7VrhZqlpzI2Ao5TbPq+LgNdHgCsS6FGs2AgLlghhCGEMNAokFzf2OALodG0FosGhg8LnLlcjelfX18/8h/CUx5CaPfJBoV8jeGYu4cNAmfkme/4mrM5f4YdNiG0iy+E577PMejajgFqYU7IN0LOkZyRo10Iz/MZwuX17e1tjutVda0HY97BDTLHvdUzNoy1MaT0WuJBcuukFluJ/atXr5L7NfkqGUM29gzE+qLGQnjqI+QHyRkNfYQ5hk8Enzk+og12IYSBT3zm+JCuHwZ4qacepoR8I+SYXOcgxw6bEJ5qlu/4yfGBLjYI/qZwxvv0bGxqhLUj+qv5rMHg0bbLAwCK0qJotkwYk2PL8dcamzhDCAMvnmxm4ri3DxtpJITweBgQ7+uzHwbI99o5ZsGhP5zXWz+sKhIrBqZ6k5X/lf1ouIMzsHavPTjdk+HTV+L6wxoYFckPwvN4r+Xn+VoYsfAJjhC092rJ/558n9dKxK5aiUzs87PLAwBSsVYTZSxr4bTK2qdHf+SIhWYJGzroLunp+X4ZIMe8mLeMgBqKG6+W48j3/hmgVqjJ/UcSI9CnGHhigLoOIQxs6p/u6Ne1GLi6uhrgf5j5j+chtM0PuU9ZC8EC5hm4etQ5A6yFqbWCbud0dBVetwcANK29/i6AI0wiYmRxSZ1N6GKTqi+9/THAaTLztgVyaocaauFbPvtioMta6StFisaAAercwI1cJDLA2sYal6j++LsieVFP1U/VwycvdKn6YAZ7qr70+mGAHpGzb0IXm34Y6DuSbg8ASNseC/EIP/0nLzQKcpQj2LB45dhId18MsNmgPqxRUzvWPuWvPwaovR5rpb9MKaJaBui1erGrZTHNnr4C32nab7Swe3Nl8y3n5T+OCPYWWKJ/ffpkoGQtxEb7dJ/5PEfV9QEAi9uefhcAWI/QZGkQ54WYen0EflK56FWP+rBcQFQzvVaK4kpkQGpiYJQBXuwse+3oILq5+Nv+pyiyzk/NWmi9Lk/FrPs+GKiplRpbH9EfA0XXBwCkkMWNF2u+e5cjTBryUZMHFsQae9nug4HaOjmNko3L6bW+i4ExBqi5PmtlLFrdEwNPDBxh3/EU6Ta/1vJba38aNT3u9FrfxcAUAzVrIft01doUs37ud38AANWWDRR/LYTf+s/vWGjh25NPi6Zg4cMTJ0fIey7fVjnew9zP5Ub6bRiwqrk26Cq8ylQMzDDAZn3msR5VMlDbVyzzU+tL62llMezEvLZmCVO1Agu+5RAHALxg8W9jek0FL/9HmSwWjcXCh9daEK4nBmo3Kk9e9OsRGNjL7/DaKhcaVwyswQD7rNpxepzLFmuZxZ7HwodFLLU1Ivv2DFjUSnuUGqGWgUMcAEASixMv2nz3JGA6ysu/J96tsFBXVr5q/fS4earlxFN+amPBvrd4iKlWrDjpdNNTS68be4s8W/hwQ4ghEC+1r/wYJrWBK+0xGpDq0KXFPLTw4Y0ai/r3xMthDgAoJF60eeHmuwcBC5g8YBGGMgYsJrNq4JJ75sblXd2xqDexeCQGFKsYWIcBT73JYk218LEO82mjkJ/aFxh8pI0mrT0z4CnPFvPQwodFPmvnnwWGUx+HOgAgcArBwx8HAANYwCTZLwM0yppJbfmiq3q6rKPa/Fx63O6OZa1sF4X9yKr7GU47emQxl1UrbQuiZi0EmVV+amul114LL/BcKlb5KR1fdusx4Gku10RtOZdr6792/tXwMGZ7uAMASCAJ9/f3g2Vh4DdFmFS8/IMhRV86/hl4+fKlC5DUFPXlAkwFCOalJaeWvirCqjbtJY5qIk4cUCsnl/p6xkBvlzVzQLXSvho85acGS3umthmhhhPNn21yttWonmqFd6ateDgdt3aPXcPpKQ6r74c8AIjkkYw1mxpj8WftKKKIQZ/7Z4B8lrx4Uw/UoCUD1FcJFksMtb6sOSE/cF2La0v7veNvwR11bl0rLXBu6LO7oUvnMvNHtdK+HErz02IugwW/uVH3XiulL1OaP7mVtG995g9zITcK5px1rYAFv7lYwG+NpdQfWHLxt9Y/9AEA5JLM1r8bgMQzBmMxpqQ/BnJfvGlmreqhld81sla6OVnCBifMwyU9j8/BDX6P2LbCxPxhzm01/j7G7RMlc4E5kRodtYJNqr706hiA69z8tJrL+CX/qRGBG/yp+nvU42WKOHOwt1qXczBId30GmAs5tcJcY861QIpf/Kf6Bjf4U/VT9Zg/ufOhFZZUzFN6hz8AiMRQKLykk6icIov255/4oEjwie/z57rujwEaFPWzFBk66C7plT6nQVF3jFPqY227OF/A3mps5uGeOIEH8IKb75InBqiVlvPnaZQOfu04BOYEc2MpRHRUK0ss2T9Pzc8ac5n8UwdLUaID7iW9Hp4TJ/EuxUJ+2Me2XJeXMOj5tgzk1ApzrSVa/KfULTrgboWF+cC8YH7MjcFz9FpimRt/6ZkOAM4YIlEUWXyBopDOVCYvY7JJOD4okkllPeiSAeon1s55gLE+0Dl/1uKacahfxm3h38In2NacL3AylR+LeCx8wAl5Ayd4LXz24ANeYq30EE/rGHr3z9xgjjBXzmONtYLO+TNdr8MA3C/lh33SGmjAQu84rxXqBOEZOmtg8TIG8cb8wMEpLq7hhPxoH3vKzDG/n9bKOQOntXL+rMU1WJjHyKl/cCDULTqnz1p8Z14wP8DBuKdjcM19nqN3+szTdx0AzGSDIkJoklEorlOJ9/mMyfac8Jlwd/Po9vZ2gOM5IW/IVkExNjURa4XvsT5yMGGDryg5tuhihw/Gj1jmPmlc2NUIPubGiM/ABDbymDMeNgixRcmxRxc7xo9Y5j5p5NjUytwYp89ibLXj7cEebk9jn/pOruAlt1b2wEEjjM3dkg/mETmpFfwg+MwFjh31EWuH7/gBU66vWn3GRRh7SdCrHW8P9jE/5IUc8Uns8JODHxsEfwjfc+wZDzvGBweCD4RnOb6wwRd2S5Ljdwtd4iCeyAufXBPXFnj2OGbKnhQ+54Q8WMSOn6Vx0EFyx8OG+kCYP3yW1Ao2CP4QvudgwQZhfHAg+ECIPcdXrS44GPccC/dzfeMHuyi59rn6OgDIZIziOpVMc6kbMfDq1athTm4fDgmQEMLAZDIaNttNrJVcQxoBttfX1wNxRAnhKZ6SmPC3JLk4p/SXxuH5lO3U/VNOpniZsp26D44UmbLPuZ8yDjo5PnvQJeYl6SHOdWNoN9rpPKQvzfXh1Gf4QZjXITz1uNwIYg3l2lnon3JCDKlxW4y9Jx/kKBfvObfUCQLPIaxbK6dYwJCS59x4t9Qvyc+WeD2NnVILSzoW8SyNQd1GCaFs/oCzpFZO5w/zN+LgewhlWMCBgGlrAQeSiwObEMIAD5ETPkMo4yR1fB0ApDIlvd0ysMZEsiSHZkAjoJGP+SUepOQQYMzfHu4R6xwnxHA0TohZIgZGGWh0c6k3WQ27p7mc0puseDmanxRu16qVtWr/aDlWvNsywPyhtluj8DSXW8ea6p8DkRDC4w8zp2zITwhhQHdKp/S+DgBKmZPd7hhgItGEPAO/urqabQan2PcQzyne0u/kjFhT7NGDwxRd6YiBXhloERfzaupQssV4e5jLOb2pBUc9+8zhtnWtrF37PedVsfljgL4eQmgGzNNcbhZkpmNe6PmhVqoZutik6qfo6QAghSXpdMMAGwXrSWRFDk2SRpzjz3M8OXFM6cIJMU49H7sPh2zYxp7pnhg4AAPmITIPmVfmjhccMqbXucw6ktubFsLV47cZoN5yuaVWsHvbhdkHPvFt5lCOxIBTBlr0WuaPl7nsiXZe6HPxwGWuzZy+DgDm2NGzLhmwnkQWJIEpt0nGcbGN33v7ZJNdEhMbtlLbkvFkIwb8MGCLhHlU2psskHidy/BiEZ98XDJQWm/YWeaFtRWflwh1Rwz0x0CLXls6f7CznMueskVfKcFDfkptx8bTAcAYK7rXNQNMop4aS2/xxOKj0RFbvM79xD7XRvpiYPcMGAfgoVd6m8twwgbVmGq5e2CgNte19g8Q9L8YOCwDlvOn1letvdck1qwdNbbnfOgA4JwRXR+CAW+NpXZSe4vHQxHVHB54wC8MYqCEAWub2t5kgcfbXOYAwCIu+bhkwBO3Hmr/kiHdEQPtGKDXWs1BKz/tol3fs8Ve3YpXHQCsn3+NKAaeMWA1mZ853fDC6s+RWfBi4WNDKjW0GMhlwFTf0/wRFtPUPnNm1bOfOS284AWk0PTRrNb+0cnDL57q7QGO/hcDu2KA+VM7F2vtd0VYBliLQwSG0wEALEjEgBh4ZMDTRvAR3W5KkwAAEABJREFUUOUvLEKVLobeOKnlQ/aeGegXm8Vc7pcdRWbNgOrNmlH52wsDqn3fmbLak+oAwHeeha4RA55OFi0ms4UPqLbygy8PYnVS+uLFi6pwau2rBnds3Fu9bU71CYDeuLWayycUFX/1tH4UB/G2obfe5A3P2zTpwxkD9DfVSpukWPRa5Wc8N/Ay/iT9roUPRtMBACxIxMDGDHhZyCwai8XiQTpq/dzc3ODGhVjw6iIQYxDixZbQ6M1T7UdMNZ+9xVPDhbWttznYU9+3zpX8iYE9MaC5fJkti35r4QNkOgCABYkY2JiB2kZZa38afs1mu8b2FAPfaXJeDkZq+a21h4/exLJWeuOmMJ7XZqq311ToywID3mqFvr8Aefaxt3hmwephFQPKdRV9o8aW67Lm8ijFQw3HNbbnaHQAcM6IrsXABgzQKEsndqndVJgsqqUv3thO+S25X+oPTkptx3B6ys8Yvr3do74s87O3+NvgffJK7T996+NX4lGttMkl3LbxXOe1FFepXR1aWW/FQM26vBVmz+Myf6x7LT5LYi61KxlrbRs4Zg+UOy422ObaTenrAGCKGd0XAyszwMRmgucMS5PELscmRbfE593dXYrrLJ2SBR4OS/AvAcMnfC/pnT5HH7vTe/o+DPpLhhpUwYPL3uqt1Vx+oOrw/3uuFXom+HKShD52OTbS3T8D5Jw+sf9Ito0ADuHSGgU+mZs5ftHHLsdmb7ol8ZXYzPGiA4A5dvRMDKzMAC9GNL+UYdGzbghx3Kurq4EXehaFeG/qEx10sZnSqblPjMSa4gMscJiiW6KTgwXM6JeM06sN+bm/v+81vE3j6q3eqJWWc3nTZG08+B5qhd4JzhSq0EM/RVc6/TFAn6AG+otsnYha91rmZmp+0EN/nci3G4X9MvvmFATkB11sUvRTdXQAkMqU9MTASgzQ/GiCU8PFZoDelI7FfZrN0sIKTnTQtRhzygex8uLIeGM6kROwjD23vAcWcCBjfiMW9MaeH/UeC9ga+Tkav2/X29BLvcV4VCv2lRy53UutgJM+i4yxsbd4xmLQPRsGYq1QEzYe+/cCV2utyzE/mstv6op989y+Fk34Yi1El2tLcXUAQJCSt4a33nrLVCwLRr7WYeDly5cDjYHmTAOIjZrrt956a7i6usoGgh2Sa/jybSzgQCIW8PEs1x8YkFw79BmPcSOOiAV/a3NyjoXcIGtjgZctBO6XhDzBCTkryc8WcdWMucSH1fPIK9w+1Vt+P6iJM9d2KW7iQbaOBy5TJDf+Mf0lTqyeR15ruE3hJFVnjIu5e/RZhB5CLPDCZ+t45jD1+Czmz0NspVioE2ypDWoEoV7mxEO8lhjmYo3P4AWO4GrNdZn8IJZz2ZK7rXydckJuyBP5gSeetcLl5gCAf1f3+vp6kNhzcHt726p+5LcxAzRnGkBs1FznDBntQgiv51YIYcBnjh90sUGiT+7lCLbgj3M8hPB4kMH9HD/oYgMOBJ/cS5VoE0K44AS/qX6iHjbRpyWW6N/rZ4yb2KcEnVxOvMabgotYp7iwvB95ZbxHXM5/WYqdeJCt4oljx9609GlBN7Eu8WLxPMbGeDm4GRubEN70ySVeUp6HEKr7foypZTxH2TdFLmPuQijPT04+znXH6i2Ep70KGM/1566pW2wQ/M7JnJ89PkuJGR042jI+MJAXPrfGsiUPp2PDBQIva3Di5gDglAR9FwNioI6B2EBY1DlcO/fG5iaEp8X1/Jn1NVhCCANjnmPhmvs0O/Ssxz73R3Od4wQs6Jzbtbgm5jksIYSig5oWWOXTNwNCV8YAPSeEMNqbyjz2YTXXmywijH3fQ6+1iGePPuA+hPHaj/mhDpgjreMDy9xauOa63DpW+RcDXhjQAYCXTAiHGDBigAV7ajE9H6L1whoX9vNxz6/ZcIAZ7OfPrK7ZzBDvkj900F3SK31OjPgn5iUfYIHDJT09PzQDCr6AAeYVPafAtGuT1N5kQQL9LYQw0BMt/I35uLq6GlJ67Zhtr/eofbhfig/emCP/P3t3Aj/F+Adw/FsK6XT755YQkitSInKUIkchKkKH7ki6D5VKl0iS5OimVCpdOqWihEq5cl+5Krl1/H/fzbK/X7s7z+zM7MzufLxMuzvznef5Pu+Z3f3NszPPeL19THLRGN2WVjmzHAEEzAToADBzIgqBjBHQL2w7yeoXq/5BYGcdk1gtU8s2iY3GaO5e/LGhuegfM9F6rB411qs/Nuzmooa6jlXOLEcAATMBfT/p+8osOjxR+pmnn33pbrFuDy/q1HL9aI8XbXGrTDWxue9HLpVzq/7YcjQXO9tHY3UfjS2D5wggkJoAHQCpubEWAoEU0C/UVBKz+weBSR2plplqGxLlpOWlkov+saHrJio3lflanpZrd13N34uOEbt5EI9ANgjo+ykb2uFmG1L9bHIjB/1M1PrdKCtahpbHdo5q/Pdo32TPum4feKe6fXRf4btwzzbhXwScCNAB4ESPdREIkIB+Kab65a7N0C9kfXRjclJWkL7gnXjGc3RSnhPTeLkwD4EwCvA+ir/VnXw2xS/R3lytX7/D7K2VOFrLS7w0nEtS2vf/oXL7e9nJ9nHSjn+awwMCoRegAyD0uwAA2SLg9I8np+vHOjr5ctdy3PyCd5qLWy5O26R/gKkNEwIIpC7g1vs59QyCt6bTz6agtSjb2uOWbyrfhbF1u+Xq9D2o34VOy4htF88RCKMAHQBh3Oq0OSsFnH4hZuOXqht/sLhRhu5wTrePW2VoOUwIhFVAP+fC2vagt9utz9qgt9OP/FL8/vEkVTdycaMMTxrnc6FuX6rhc3Oo3kMBOgA8xKXo4ApcfPHFwU0uxcyC8oetG1/MQWlLipsi7mpBaZNbfyC4VU5cLGYi4IGAG59NHqTle5FBcXHrMzIo7fF9wzpOIHcB2bh9svFvwdxbjVcIxBegAyC+C3OzXCAbD17c+CJzw8WNMtxoi+7CbuTiRhmai1tt0rKcTkHKxWlb3FqfXx/3lnRj3w/SvuZGe/ZWSm1OkHJJrQXur9W9e3dXCs02Wzfak1IZebaGW+9lN3LJkxovEUDApgAdADbBCHcmwB/ZzvySre3U1q0vd83RaVlu/YHgRjlulKEmTrePluFWLlqWk8mtP9Sd5BDEdd3YxkFrV1Dey265OG2PW3kE5b2s7cm2/TZIturrZHJzf7VbVt683XJ1Y38LUi55nfx6zfeyX/KZWS8dAJm53TI2a/3Qdvol5Ebj3fgCciMPN8tQWyflOV0/tm6nvk7Xj83Fyf6mX6huuWg5TnOJbZeT5276OskjSOsGafsEycXpvuJ0fbctgpCPfq643S4n5Tnd953UHbuuW9smKO2JbVuqz7Utqa6bdz2bvnlXF6frxxbo9LvQLRe3yoltm1/P3dw+frWBetMnQAdA+qyp6R8Bvz+kgvbH1z8srjyk2jb9MnZzu+iXqpaZSqNSbUOiutxsV6I6TOc7ycXJunnzc7p93Mwlb25+vnbSLifr+tlmq7qd7itW5ad7uZP2uJVrEPcVv3PK5s/9VPcbNXFzu9jb93NnrbnknuPslZvtcpaJyKJFi5wW4fv6bm8f3xtEAp4L0AHgOTEV5BXQLyG/Pqy03iB98eS1cfpa25bKgbeu57TuvOunUqbmnsp6eeuOfZ3q/ubFvpJqLl78gaIDZal3rJXVc413e/tY1ZnO5aluH91X0plnuutKZZurSSrrpaNtuu+no554dXjxXo5Xj915qe77duuJF+/FvuJne+K1MZV5Xrx/jMuMSThI2ydIucQQ+fo027+XfcXN4srpAMjijRvkpumXkH6QpzNHrU/rTWedftSlf9xqW03r1j9I9Y8l03jTOC1TyzaN1y8xzd003k6cbnc7Jhqr69ipwzRWy9XyTePVUC1N4+3Eqbe6m6yjcZq7SWwmx2gb7WwfjdV1MrnNVrnr/qf7oVVcdHkm7Ct22hNtl9NHrVMtnZbj1fq6H+v+7FX58crV+rTeeMucztNytXyn5fixvu4rXtSr+59J2dG6vXwv290+ui11nWhubj5quVq+m2Wmoywvt0868qcO/wToAPDPPvQ1p/MDVz/Ytb6woGtbtc3J2qtfHLt37xb9gyBZnJNlWrbWYZWLLteDUSd1Wa2rJvqHj7Y7Uawu0xiNTRTjxnwtX9ucrKxoLmqYLM7pMnU3yUXjvM7FaVvcWt/O9tFYt+oNcjm67YPyXnbDybQ9btSVrveyG7nq/mz1eeBGPVqG1qP16XOvJi1f6/GqfLfL1X1F32e6f7pddrQ8LVvrSOISCdXl+rkfeeHRPybbR02C8r3sEUNKxUa3j27PlApgpVAL0AEQ6s3vf+P1wz/6RaQfZm5mFP3S0PK1HjfLzoSytM3adnVVC81ZH3XSL1Ovv9i1vuiUKBfNQ3PU5dFYLx/1i1LbrSY6ReuKNdGY6HwvH7XN2nbNQyetS/PQSV00Tz9y0fqjuWhe0Vx0XpimIG2fILmri+4Tum/E7is6T/dnXR6kfK1y0Xw179j2WK1jslxtdFKXdL6XTXKziok1URereDvLoyZqrvXYWTfVWK1H69O26JRqOV6tpyY6RfcVr+rJW666aJ1qovXrcn1ctGiRqFePHj10lueT1qP1aR46aYWah06aXzrfP/Fy0XyCMqmJGqmL5hqUvMgj8wRc6QDQN6e+eZl2Rz40s9FBt7GXu7d+kOnkpp3mnK4DKC9tnJatrmqhtvqok18ueXPxMw/NRU108tskmovmoZOfLlp/1ETz8isXp/u9W+urgU5RE/UJu4m2X03UIuqi89wy96Oc2PZom5xOaqNTJruoiU5OLWLX99NE26JTbD5BeK4mOvmxr2idaqL1q4U+VqlSxY+3oGgeOkXzCEoumk9QJjVRI91uvmwkKs0aAVc6ALJGg4YggAACCCCAAAIIIBBSAZqNAALZL0AHQPZvY1qIAAIIIIAAAggggICVAMsRQCAEAnQAhGAj00QEEEAAAQQQQAABBJILsBQBBMIgQAdAGLYybUQAAQQQQAABBBBAIJkAyxBAIBQCdACEYjPTSAQQQAABBBBAAAEEEguwBAEEwiFAB0A4tjOtRAABBBBAAAEEEEAgkQDzEUAgJAJ0AIRkQ9NMBBBAAAEEEEAAAQTiCzAXAQTCIkAHQFi2NO1EAAEEEEAAAQQQQCCeAPMQQCA0AnQAhGZT01AEEEAAAQQQQAABBPYWYA4CCIRHgA6A8GxrWooAAggggAACCCCAQF4BXiOAQIgE6AAI0camqQgggAACCCCAAAII5BbgFQIIhEmADoAwbW3aigACCCCAAAIIIIBArADPEUAgVAJ0AIRqc9NYBBBAAAEEEEAAAQT+E+AZAgiES4AOgHBtb1qLAAIIIIAAAggggEBUgEcEEAiZAB0AIdvgNBcBBBBAAAEEEEAAgT0C/IsAAmEToAMgbFuc9iKAAAIIIIAAAgggoAJMCKPZrDYAABAASURBVCAQOgE6AEK3yWkwAggggAACCCCAAAIiGCCAQPgE6AAI3zanxQgggAACCCCAAAIIIIAAAiEUoAMghBudJiOAAAIIIIAAAgiEXYD2I4BAGAXoAAjjVqfNCCCAAAIIIIAAAuEWoPUIIBBKAToAQrnZaTQCCCCAAAIIIIBAmAVoOwIIhFOADoBwbndajQACCCCAAAIIIBBeAVqOAAIhFaADIKQbnmYjgAACCCCAAAIIhFWAdiOAQFgF6AAI65an3QgggAACCCCAAALhFKDVCCAQWgE6AEK76Wk4AggggAACCCCAQBgFaDMCCIRXgA6A8G57Wo4AAggggAACCCAQPgFajAACIRagAyDEG5+mI4AAAggggAACCIRNgPYigECYBegACPPWp+0IIIAAAggggAAC4RKgtQggEGoBOgBCvflpPAIIIIAAAggggECYBGgrAgiEW4AOgHBvf1qPAAIIIIAAAgggEB4BWooAAiEXoAMg5DsAzUcAAQQQQAABBBAIiwDtRACBsAvQARD2PYD2I4AAAggggAACCIRDgFYigEDoBegACP0uAAACCCCAAAIIIIBAGARoIwIIIEAHAPsAAggggAACCCCAAALZL0ALEUAAAaEDgJ0AAQQQQAABBBBAAIGsF6CBCCCAgNABwE6AAAIIIIAAAggggEDWC9BABBBAIEeAMwByEPgfAQQQQAABBBBAAIFsFqBtCCCAgArQAaAKTAgggAACCCCAAAIIZK8ALUMAAQQiAnQARBj4BwEEEEAAAQQQQACBbBWgXQgggMAeAToA9jjwLwIIIIAAAggggAAC2SlAqxBAAIF/BOgA+AeCBwQQQAABBBBAAAEEslGANiGAAAJRAToAohI8IoAAAggggAACCCCQfQK0CAEEEPhXgA6Afyl4ggACCCCAAAIIIIBAtgnQHgQQQOA/AToA/rPgGQIIIIAAAggggAAC2SVAaxBAAIEYAToAYjB4igACCCCAAAIIIIBANgnQFgQQQCBWgA6AWA2eI4AAAggggAACCCCQPQK0BAEEEMglQAdALg5eIIAAAggggAACCCCQLQK0AwEEEMgtQAdAbg9eIYAAAggggAACCCCQHQK0AgEEEMgjQAdAHhBeIoAAAggggAACCCCQDQK0AQEEEMgrQAdAXhFeI4AAAggggAACCCCQ+QK0AAEEENhLgA6AvUiYgQACCCCAAAIIIIBApguQPwIIILC3AB0Ae5swBwEEEEAAAQQQQACBzBYgewQQQCCOAB0AcVCYhQACCCCAAAIIIIBAJguQOwIIIBBPgA6AeCrMQwABBBBAAAEEEEAgcwXIHAEEEIgrQAdAXBZmIoAAAggggAACCCCQqQLkjQACCMQXoAMgvgtzEUAAAQQQQAABBBDITAGyRgABBBII0AGQAIbZCCCAAAIIIIAAAghkogA5I4AAAokE6ABIJMN8BBBAAAEEEEAAAQQyT4CMEUAAgYQCdAAkpGEBAggggAACCCCAAAKZJkC+CCCAQGIBOgAS27AEAQQQQAABBBBAAIHMEiBbBBBAIIkAHQBJcFiEAAIIIIAAAggggEAmCZArAgggkEyADoBkOixDAAEEEEAAAQQQQCBzBMgUAQQQSCpAB0BSHhYigAACCCCAAAIIIJApAuSJAAIIJBegAyC5D0sRQAABBBBAAAEEEMgMAbJEAAEELAToALAAYjECCCCAAAIIIIAAApkgQI4IIICAlQAdAFZCLEcAAQQQQAABBBBAIPgCZIgAAghYCtABYElEAAIIIIAAAggggAACQRcgPwQQQMBagA4AayMiEEAAAQQQQAABBBAItgDZIYAAAgYCdAAYIBGCAAIIIIAAAggggECQBcgNAQQQMBGgA8BEiRgEEEAAAQQQQAABBIIrQGYIIICAkQAdAEZMBCGAAAIIIIAAAgggEFQB8kIAAQTMBOgAMHMiCgEEEEAAAQQQQACBYAqQFQIIIGAoQAeAIRRhCCCAAAIIIIAAAggEUYCcEEAAAVMBOgBMpYhDAAEEEEAAAQQQQCB4AmSEAAIIGAvQAWBMRSACCCCAAAIIIIAAAkETIB8EEEDAXIAOAHMrIhFAAAEEEEAAAQQQCJYA2SCAAAI2BOgAsIFFKAIIIOC2wGcffysVTrzLcho9bKbbVVMeAggggEAWCNAEBBBAwI4AHQB2tIhFAIGsFti29Rf5+MOvZdVrG+Tlqctl+qSlsnjeGnl71YfyyUdfy08//JzV7adxCCCAAAIZJ0DCCCCAgC0BOgBscRGMAALZJPDXn3/LquUbZWifSVKzYju58tw2ckv1btLytsHywH2jpW/n56RDs+HStG5/qVutm1xV4R6peHJj6dzqCXl1wdvy9187somDtiCAgAcC9Wr2sDzDp8YF98rff3vzebJiyTrL+k3OQorG6Ofk7df2kvZNh8lD3cbKqEdeknkz3pCft/7qmt6IQVONcn5y6HRHde7evVu6thlpVFe0/Z1bjpBdu3Y7qtfdlSkNAQQQsCdAB4A9L6IRQCALBLb8uD1y0H/RaXdLywaDZMLT8+WH77YatWzXzl2y4OVVcl+TYVL9/LYyuNcE2fT+l0brEoQAAuES+GDjF/LRe9afDz9+v01W53RGZoKOnin13vrPZOkrb8uL4xdHOgC6tR0p1XI+D7VTYM70laIxmdCWF55bKPNnvmGcaukyR0uX/g0lf/58xut4HkgFCCCAgE0BOgBsghGOAAKZK6C/+D//7AKpc1mnyEG/05b8sv130fLqX91Tnnp0hme/4DnNk/URQMAfATsHl7OnrfAnSZdq1c5R7RToce8oqVHhXhn75BzZsWOnS6W7X8zaNZvk4T4TjQsuVrywDBjRQgodsJ/xOukIpA4EEEDArgAdAHbFiEcAgYwU+HTTN6IH6vqLvR64u9kIPR1UT0VtVKdvZKwAN8umLAQQyEwBPaV/2sQlxsm/MmuVbP1pu3F8kAP1wH9Y/8nS+Ma+8vknmwOX6g/fbZOOzYcbn8qvv/gPeKKFHHHkwUFrC/kggAACtgXoALBNxgoIIJBpAm+ufE8aXtdbdMR9L3PX02Jvv7a3fLDhcy+roWwEEMgAgddf3SDbt/1mnKl2JC6au8Y4PhMCN6z9NNLxGqTPxJ07d0mX1iNEL7swNWzbta6UO7e0aXga46gKAQQQsC9AB4B9M9ZAAIEMEpjxwjJpXm+g/P7bn2nJ+s8//pLWDYfI11/+kJb6qAQBBIIpkMop/VPGLQpmYxxkpZ+JLRsMli8/+85BKe6tOnLItMidXUxLrFargtSpf6lpeHrjqA0BBBBIQYAOgBTQWAUBBDJDYP3bH0ufjs+kPVkdZLD17UOy5nTetANSIQIZLqCn8i+as9p2K3TAwA83fmF7vaCvoIMCtrptsK1f3b1o07KF78izI142LvrUM46TDr0bGMenO5D6EEAAgVQE6ABIRY11EEAg8AJ6S6pOLR63neep5Y6X6+peLI1a15JWHW+UW++6Uq66vqLo6M92Cvvi082ROwX88ftfdlYjFgEEskBg4Zw3ja8vz9vc+bPMR6XPu26QX+tZUW3vHCq//vK7L2nqZ3LX1iON6z7w4KLS//Hmsn+hfY3XSXMg1SGAAAIpCdABkBIbKyGAQNAFHuo+Vr77dotxmnXvuEImzu0lo6d0lvt71Zc7W14tt9x5hbTsUEe6PXSHjJnRXSYveFBa3F/buMx1b22SuS+tNI4nEAEEskNg2gTzwf/ytvil55f5ckeRsmeXkpUfjbKcFr4zTKYu7icjJ3WQ25peJSUOKpq3CQlf61gAc6e/nnC5Vwu0I/b+ux+T3383uxQs/z75ZeDIlnLo4Qd6lZIL5VIEAgggkJoAHQCpubEWAggEWOCd1R+KjqhtkmLxEkXk0efuldadbpTjSv0v6SpHHXuY1GtUTSbN6218RsCYkXOSlslCBBDILgE9hf8DB6fx6+UDr7+6IbAoBxTeX/531CFyxjknyt3trpepS/pFzpIyTXjcqLkpnx1hWkfeuAE9xsnHH36dd3bC1x1yOoFPK3dCwuWBWEASCCCAQIoCdACkCMdqCCAQXAHTgbSKFC0kj41tJ+UrlrHVmGNPOEJ6P9xEChTYx3I9Hfhq6StvW8YRgAAC2SHgxin8qQwg6JdeoUL7Rc6SuubGykYpfPXF96J3ZjEKdiFo2sSlMmvKa8YlXVOnspi2xbhQDwIpEgEEEEhVgA6AVOVYDwEEAinw7Vc/yrwZbxjl1uvhxnLiKUcZxeYNOrbUEXJXq2vyzo77eszI2XHnMxMBBLJL4O+/d4jeecRpqxa8vEp0MFGn5aRz/cZtasm++xU0qnLq+MVGcU6DNq77VPRyMNNy9KyG+3reahruZxx1I4AAAikL0AGQMh0rIoBAEAVmTF5mlFa5c0vLBReXNYpNFGT6K9G6NZtEOyYSleN0vp5uvGLJOpkzfaW8OG6xLJi9Wt5a9YFs/uYnp0WnvP7ff+0QvRRDc5k8dpE8/+yCyIGRnhGRaqF6He/aHMuVS9dHLvHQX/amTlgi82e+IcsXrxNd5tcAY4na9N76zyTvtlGXH7/flmgV1+cH1W37tt9Ex8lYtnCtvDx1ubyYc1C4eN4a2fDOJ5H3ix5Mu47hcYGrl2+0PHA/8uhD5aLLzrTMZNGcNy1jghRwyGEl5IZbqhilpIMkGgU6CNKBYPW6/107dxmVovn3e6yZFNy3gFG8v0HUjgACCKQuQAdA6nasiQACARTQgwiTtOrecblJWNKYgw4pJpUuOSNpTHShnetPo+ske/x+8xZ5bsRsqV21kzS4uqfo6No97h0V+bWrc8sRcnfdh6RW5fZS44J7I/N0BOxk5cVb9slHX0uFE++ynHbG/IH9159/ywtjFkbyanJzf9FcBvYYJ4N7TYjcknGmjVNxNSf94/2tN96PtKH6+W2l8Y19pc0dD0uX1k9Ivy7PSf+uY6Rrm5Fyz11DI8uqlW8rD9w3OnLQ7fQAckD3cZZtH/vk3mM8fLbpWxk+cErE/vZre+21bdRFt4tuu1GPvCRbt/yiTXV18tMtWUN0n3r6sZnS+KZ+cvk5raRRnb7SrvEjkW32ULex0qHZcLnjhj5y7cX3S+UyTaVRzvZ+ZvgsWfP6+6IdGcnKDsIyk1P3r65zoVxS7RzLdF+ckJ5fyS0TsRFQ6dJyxtFe7PfRynX/79FulPFAsHo51+BRrUQ/06NlBPqR5BBAAAEHAnQAOMBjVQQQCJbA559stvz1TTPWP/YqVD5dnzqezr3gFKMyPtj4uVGcSZD+on51pfsiB5lWv6jrL816VkCdyzrL0AefNynedsyv2/fc1ktPWW5ef6AM6jk+4dkHam9agV4n3KDWA3L3LQMiZzb8/pv1CN560K+/Jre9c2ikE0J/ady9e7dplbbjtsUcvP/26x+RbXLTlV0inTNqn6xA3XbaAVCtfJvIr9/JYu0sC6Lbqwvejhz0163khppvAAAQAElEQVTWTZ4YMk3WvvmRUZP07JkRg6dKs1sHRDpUdN/XbWy0cpqDdPA+k8FHtdOwYpWykj9/vqQZfvTel6Kj5icNCtjCk8ocbZyRehkH2wx8OqfTSM8KMl2tS/+GctKpx5iG+x5HAggggIATAToAnOixLgIIBEpg49pPjPKpWqO87F9oX6NYqyC9M4BVjC7XU8H10cmkB8BN6/YX/UU9lXImjJ4nbRoOET1QTWX9ROvoafd6iYP+2q0HbInidH6BgtYDJ+rZDZ1bPSHN6w0UPQjS9VKZNn/9k3Rq8XikHP3lOZUyrNbZtuXXSIie4VG3erfIgX9khs1/9NdvPavB5mq5woPopvuF/sJ/X5Nhxgf9uRoV80L3M93369fsGTkjIGZRIJ4umrvGcnR7Pf1fxx3Ru49UzOkEsErcdDwTq3LStbxYicJSuEgho+q2/PizUZzdoNeXvStPDp1uvJreArZarQrG8QEIJAUEEEDAkQAdAI74WBkBBIIkoNcTm+RzxtmlTMKMYsqUPV7u6VrXcrrwknJxy8uXL/mvgNGVduzYETnV/e1VH0ZnpfS48tV3ZdADE4zWzZfPLLevv/whcgq+yZgD++yTvANAr/+uf/UDooOgGSVpEKSnj99Wq5fYPZgyaf5POQcx2knR5OZ+oh0OBukkDNFfj/XSgYQBSRYEyS2a5rc5HTB31ekreo1/dJ4bj59u+kZa1B8oi3MOuN0oz60yTO4+ctX1FSVfvj3vq6pXlbesevrzSyWoZzwkSv6Qw4onWpRr/t9/7cz12o0Xus/Z6UgrX+nUyC1g3ag7fWVQEwIIIOBMgA4AZ36sjQACARJYsWS9UTZHHnOYUZxJkP6xe+NtVcVqqlm7UtziTE9PHz1sZs6B1Dtxy7A7U2+JZXLwZJpbnw7PiP4CbpJHwSRnAMyetiJy/bcXpwbr2ATd2o6UYf0nm6QZiTG5ckBHGdezMnRAu8hKDv/RcR3Wv/2xrVKC5qbJb9v6izS/dYD88N1Wfen6tGvXbunQfLjoIJOuF55CgdoJpJPVqpWr/tcRqGcAWF0GoPuVDnppVW5Qlutnhul4IwcfWszVtHfs2Cm92o8WNTMp+PCSB4neCcYkNlAxJIMAAgg4FKADwCEgqyOAQDAEdICwr7743iiZkkcdYhSXzUFD+kwU/YPZjTbqGQCm5eTPH/9rR68J79nuKdNiUo7TQfv0jgQpF5BnRb3O/5d/xkDIsyjll9MmLjFeN6huA3uMF9P3o3Fj4wR2bTNS9FffOIvSOkvP3rCqUE//Lx1zjXzxEkVEOwGs1ps9dYVVSGCWf/7xZsvLIKLJHnr4gdGnrjyOHTlHdPwLk8L0doWDR7WWEgcWMQkPVAzJIIAAAk4F4v8l5rRU1kcAAQTSLGDnuvYDDyqa5uyCV52erm5yFoDbmccbBPDnrb9KxxaPu11VwvIefnCSuDEmQ8IKHC6YOfk1ozsDBNVNL7nQWzOaMJQ9u5Q0al1L+jzaVEZO6hD5RbbpPddJhcqnmawuOtr7+KfmGsV6FaSn6E8Zv8iy+OrXXfDv6f/R4Eurnxt9mvBRb43oxVkxCSt0sGDVio1GaxcqtJ/oeAHi0n961owOFmlaXO+hTaTUSUeahgcpjlwQQAABxwJ0ADgmpAAEEAiCgJ1fYd0aANCvdl9Tp7Lor1dTFvaVVzeMkDlvDJGnpnSSO1teLcWKFzZO65WXVxnHuhW4T4G9v3ZGPfqS6C/pJnUUKVpImt57nUyY84C88tajsmjdYzJpbm+5t/stcvChZtce60HjoAfGm1RnK+bAg4vKXa2ukZHPd5RZKwbJyo9GiW6jB4fdLTryu53C1r+1yTI8qG56FwbL5HMC9ED/yRwr3W+r5hwIn3HOiXJ5zfPk9mY15OGn20rX/g1zoqz/1zM6dLBB60hvIlYv32h02nns6f/RTHS/yG9xNwC93GH+rPS/V6M5mj7qZTYvTVpqFK4DIRoFGgRt//m3yO1GDUIjIQ2b15SLLjsz8jzz/iFjBBBAwLlAfudFUAICCCDgv4BpB0D+ffJLwX0LSCb+p6cMPz6hvXTqe1vk1OEjjzk00pYSBxWV08qdEPklddK83qK/qpq0b3XOgYtJXKoxekCut0mscsXZcvHlZ4n+0V+gYG57HThQb+1mUof+KvzCKw/K7XfXkONPLCnaGaC/JB5b6gipU/9SmbzgQTEdzVvvVrDqtQ0m1RrFnFm+tDz3UrdIB4AOMqlt1xV1G11a7RwZ9GQr6Tm4kc4ymt5/9/OkcUF2WzL/raS568La9S6JHOjr80RTjRsqRcbWSLQ8dv4by93blrHlmjyfPc36FH09/T/ebeb0PX3BxWUtq5lueGBtWZCHAY8PmiofbPzCqIbKVd05ANcxB/p3HSP6fjCpWD8bm7S91iQ0mDFkhQACCLggQAeAC4gUgQAC/gvoLcJMsihewvwXcpPy0hnz0Ijmclb5k5JWqb9Cd+ln9supdproiOpJC7S5UM9OeHpqF1m09rHIr+DDxrSTfsObSf/Hm8vYmT2kxvUVc5U4cfT8yGncuWbGeXH2+SfLgJEtRdsXZ3FkVqED9pPuA+807gQYaeNWYZEKEvxzQumSMuCJlmJ1TfOV15wvzdrdkKCU3LP1lObcc3K/CqqbXpawfdtvuZON80oP7uPM3mtW9Wsv2GtevBl6SUu8+V7P01PzTa7/r3Zthb1O/4/mZnIZgA4wqANORtcJ0qOOv9Lj3lGitxk1yatgTifgNTdeaBJqGfPS88vExD9akHb8uf2ZFy07HY/UgQACCLghkN+NQigDAQQQ8Ftg165dfqfgaf11GlSVcueWNqrj2BOOED2l2iTYrQHUDjviQBkx4f7I2Qllyh4nejBuVf/WLb/IhKfnW4VFlvd5pKnogUPkRZJ/8uXLJx37NJCSBgM96sHAepsj7serulPf26VosQPiLdprXvXrKuw1L96Mzz/+Nt7syLwgu+ltESNJWvxjOg6H7ssWRUUWf/Plj5HHdP+zeN5bRoPeXXjpf6P/583xwkvPyDsr7mvTcRXiruziTB1v5ZsvfxAdgPKxhybLtRffL3OmrzSuoXb9S0XPWjJeIUlgKneZ0LuW6GVASYoN6iLyQgABBFwRoAPAFUYKQQABBLwVMD1gimZx3oWnRp8mffzlZ+tfa5MWkLNwv/33Fb1m+8zyZh0UOatE/l9vcJ27Buo1/8l++deY2EnzaWx4mu9qw0HLYsvP+1xP7847L9FrPUvgkMNKJFr873y9rvnfF3meBNmtSFGzjpBF89bkaVX8lwcU3j8yloKOp5Bs6jbgjvgFeDx38tiFljXo9j7l9GMTxhUvUcRojIgZk5fJn3/8lbAcpwu0Q6zCiXeJ1XRpuRZyXZUO0vimfjJm5BzRsyBM69aOwZtuq2oa7kncupzPnSnjrAdt9KRyR4WyMgIIIOCOAB0A7jhSCgIIIBAogYMOKWaUj14GYBSYJOiGW6uIngafJCTuordXfRh3ft6ZlaqY/UIau15Fg+uqNX7Vaxv1Ia3TIYdZD1b487ZfE+YUZDeTtmnDhvaZJCbXzmtsUKdN738pemq+VX56unu+fPmShplcBrB922+y8tV3k5YT5IU6/sqQp9rIEUce7Huaj/R9IS23qXS1oRSGAAIIuCRAB4BLkBSDAAL+CpicHq4Z7tq5Wx+yftIB8kwaqafzmsQlizH91TdvGW8ssz6YKVr8ACld5ui8q1q+LlaisJx13smWcW+ufE/0GmbLQBcDTC8XSFRl0N2uuPq8RKnnmt+z3VPSssEgWbZwreit9HItzIAXpiPzmwx4Z3oZwOyp1gMOBpWu15BGYvcsIa/aovtbv87PeVW8J+VSKAIIIOCWAB0AbklSDgII+CqgpwqbJODGAa9JPZkS49fYCTt27DQaMfzUssenTHnyaccYrfvV598ZxaU7SA9S8taZCW71GlfPm3bC16uWb5R2jR+RauXbSre2I2X0sJmidxHYtvWXhOsEYcHOnbtkxgvLLFOxOv0/WoBeBlCxStnoy4SPi+etke83b0m4PKgL7m53vVS9qnyg0tN9b9rEpYHKKUkyLEIAAQRcE6ADwDVKCkIAAT8FTH/x1oMqPYjyM1fqFjG99OD40iVT5jrm+MON1jXNxagwj4NMc/XT7aQyR0duh2iHQu/iMW/GGzLy4Wly/92PyZXntpG7aj8Y6RBYu2aTnaLSErvqtQ3y4/fbLOuqWbtSwtH/865sOnDnojlm4yfkLd+P1/876hAZ8EQLua3pVX5Ub1nnkN4TjW8haFmYpwEUjgACCLgnQAeAe5aUhAACPgoULlLIuPY/PRxIyziJkAduT3KNeyxN8RKFY1/ael78wCJG8T8b5mJUmMdBmeLWoEl149sxJiJb//bHkQ6Bxjf2lcvOail9Oz8n76w2GzciUZluzZ9tOOr9RVXPNK7ywqrljGJfGLNQdu8O9qVMBQrsI3e2vFrGz+4plW0YGAFYBNVteLloJ5RFWGSxfhf07fRs5Hmg/yE5BBBAwEUBOgBcxKQoBBDwT6Bwkf2NK9+2NfEAa8aFEOhIwPSXbNNLO+IlU7iw2T7x8zbnd0KIV78X8zLFbd/9CkqPQXdJ6843ucKg7Z4+aak0ubm/dG45Qj5LcptEVypMUsj2nP3F5JZ8kdP/yx6XpKTci4qXKCIXGAxe+cWnm2Xjus9yrxyAVzrI30WXnSndB94pM5cPlEata0mhQvulNbNrb75IWna8UTo+eJtxvTqw4qwprxnH+xFInQgggICbAnQAuKlJWQgg4JuAHnDo6aYmCXz71Y8mYcR4KJAvX/JR0T2seu+iA/5ramzC+fJllpv+GjtpXm8594JTYpvh6PmC2avlpiu6iMlBuKOKEqy8aO6bsmvnrgRL/5v9w3dbpeJJjSxvqxd7270VS9b9V0CSZ/NmvJ5kaWqL9DKqKlecLVbT5TXPk1o3XSS6be9oUVOat68tPXM6e+a8PkQeGtFCql97gZQ4qGhqSThYS/Nq37Oe5M+fT8rkdLzUa1TNuLTBvSbKD99tM45PcyDVIYAAAq4K0AHgKieFIYCAnwKmBxlfujjomw4quHHdpzm/yCWf9JZhftoErW492DDJ6fff/jQJixvzm+G6xRxcZhC3Yg9nZqLbsSccIcPGtJPRUzpLjRsquabTtc1I0dPhXSvQsKBpk5YaRnoXpmdD6Onrbtag40b0G95MrKZeDzeWjn0aRM7uaNzmWqnfuJpcWauC+Pk+qnTJGdJtwB2iZyFETfQShMOOODD6MumjjkHRr0tQ7wqQNHUWIoAAArYF6ACwTcYKCCAQVIEyp5udbrtm5fuuNWHN6x9Iw+t6W04jH57uWp3ZUJDe3s+kHT/9+LNJWNyYLYbrFi1WOO76QZyZyW6nljteuvZvKEvWD5dHn71HGjStLiWPOsQR86Ce42XN6+69n62S2fTBV7LhnU+swjxfQzCm4gAAEABJREFUrh1jK5as97yeTKhAb/fZ55GmUrBggVzpFjpgP+nU9/Zc85K9WLbwHd/OKkmWl7AQAQQQcFmADgCXQSkOAQT8EzixzNFGlS+Z95bo3QCMgi2Cvvhss0XEnsWlDXPbE539/5oedH/52XcpY3z1+fdG65oeVBsV5nFQNrjtt/++Ur7SqdKs3Q3y4uJ+8sIrfaTfY80i14ybXAOfl3j4gCl5Z3n2+pVZqzwr227BM7luXbRT6aERzWX/QvvG5atQ+TRbZ50M6D5Ofvoh9U7HuEk4nMnqCCCAgNsCdAC4LUp5CCDgm0DpU44yqvv33/+UN1e8ZxRrFbTS8Fe4UicdaVVUqJbrdbonGXSKfPTelym7fPLRN0brljza2a/QRpW4FJSNbkcfd7hUufLsyKjxQ55qLTOXD5KWHeqI6eUO69/+WD7c+IVLwomL2blzl7z0/KuJA9K8RH+x/n7zljTXGqzqLrjodCla7ICkSbVoX1uKFTc7y+fnbb+KnlWStMD0LqQ2BBBAwHUBOgBcJ6VABBDwS0BP+by02jlG1U+dsMQoLlmQDib4+rJ3k4X8u+zYUv/79zlP9gicn/Pr3J5nif/97tst8ukmswP52FJ01PhVr22InRX3uY4bke6RyuMmYmNmtrsdclhxufWuK2Xq4v5y8eVnGcmYdvYYFZYgaNXyjfLj98EaKG7By6sTZMvsqMCBBxeVe7vfEn1p+aiDTC6et8YyLj0B1IIAAgi4L0AHgPumlIgAAj4K1K5/qVHtS+a/JU5OL9dKpk1cqg+Wkw6CdkLpkpZxYQsod25poybrL51GgTFBK5eulx07dsbMif/03Ipl4i8I8Nyguun76flnF0iyaeZk89ut6aUZeitBk19vP9z4uedbbO70lZ7XYbeCKeMWy+4MuouF3fa5FX/F1ecZ3WIxWl//rmPk5yDcLjaaEI8IIICAiwJ0ALiISVEIIOC/wJnlT5LjDH9t73bPk/LXn3+nlPRbqz6QZx6fZbSu/pppFBiyoLJnlzJq8YTR821vp/Gj5xmVffb57t2ezqhCF4KC6qYD0w3uNUGSTb07PG1r/A09q+fCquUs1T7Y4O0lANu3/SZzPbj1nmXDLAK++HSzvBuAQQkt0vR9cb58+eT+B+rtNVBgosS2/LhdHu4zKdHitM2nIgQQQMALAToAvFClTAQQ8E1Ar5Gu16iaUf06mnf/bmNFbwFltMI/QXraf4e7h//zKvlD4SKFpOpV5yYPCunS4iWKSB2DMzb0tOvHB001VtLLO3TbWq1QpuxxUvasE6zCArc8qG6mYymsffMjW6a7d+22jC+47z6WMU4CFs17U3bt3GVZxCGHlZDlHzwpKz8a5XiqcNHplvVpwLwAdkxoXkGbjjjy4MjYEqZ5vTx1uby2aK1puBdxlIkAAgh4IkAHgCesFIoAAn4KXFnrfNGDO5McZk15TW64tJO8OG6xbP1pe9JVNqz9VHSU6Na3D5FtW39JGhtdeONtVUU7AaKvecwtUKdB1dwzEryakPOL/qhHXkqw9L/Zeoq5nr7735zEzxo0qS758uVLHBDgJUF00/3cZBT/Ib0nGp9eradhm1yPXfLoQz3dWqaX+1SrVUG0E9KNZC67qrxRMTNeWCZ//vGXUWzYg2rXu8T4u0Gt+nZ+znYHsa7nzkQpCCCAgDcCdAB440qpCCDgo0DBggVErx02TUEP/B/qPlaqnddW2jQcIgN7jJNnhs+ScaPmytA+k6T7vaPkmgvvkzuu7y1Txi0yLVb09OVrb77IOD6Mgcccf7hcXvM8o6ZrB0CTm/tHRmL/+MOvRU/L/uP3v+Szj7+VhXPelPZNh4meYm5S2OElD5JLDAeMNCkv3TFBdbspp8PLykLv7NCiwSDZ9H7yOzxs3fKL9Gg3SvTSAqsyy3s4loPuayZnlGiOF112pj64Ml1wsdkZAOqzjF+qjczz75NfOve93ShWg374bqs89lD6bjOpdf478QQBBBDwSIAOAI9gKRYBBPwV0IH3uvRraDuJla++K5PHLpIRg6fKo/1ekAlPzxcd/EtHo7dTmP6hOXhUKzn8fwfZWS2Usc3aXW98m653Vn8oD3Z6Vm6p3k0uP6eVVCnbTG66oot0avG4LH3lbWM/Ox1ExoWmOTCIbnra+lHHHmYp8cGGz+XWGj2ka5uRsiin82bjuk8lOulo+9oJV618G1m+eJ1lWQcfWlwqVz3TMi7VgFdmvWG0ql6acfpZpYxiTYK0XRUM7pShZb384nJ9YDIQOPGUo6Rh85oGkXtCXhy/WHTMlz2v0vcvNSGAAAJeCdAB4JUs5SKAgO8CNWtXklvuvMKXPPRXprPOO9mXujOt0v8ddYj0H9E8bWm36nijnFX+pLTV51VFQXVrZ+OWa/NnviEdczpvGl7XW6JTywaDIp1wpm739bzVNNR23M6du2T6pFeN1quZ83nj1un/0QqrGl4GoNeqf795S3Q1Hi0Ebmt6lZTM+dyxCPt38QP3jTY6E+XfFZw/oQQEEEDAMwE6ADyjpWAEEAiCgB7stexQJ62p6Kj/Na6vmNY6M70yPSDvNuAOz5uhYzL41SnkReOC6KZnAXR68DYvmrtXmbotq1xx9l7z3ZqxesVG0UEoTcpz8/T/aH0Vq5SNPrV8nD9zlWUMAXsE9i+0r3Tpb36G2Ddf/iB6VtietdPxL3UggAAC3gnQAeCdLSUjgEBABPSAvOegu1wbnCtRs/R0/z6PNpUW99dOFML8JAJXXVdRHn66rRQqtF+SqNQXtczpCLqna93UCwjomkF0u+bGyqK/snpJpnW0uN/bzr250183aoKe/l/27BONYu0E6WUA5194mtEqeveL3bt3G8USJHL2+SeLnTFaJj3zirz7zsfpoaMWBBBAwEMBOgA8xKVoBBAIjsCVtSrImBndpezZ7l2jG22dXu9/e7MaMnFuL6la/dyMHVk+2h4/H/Wa53Gze0b+OHcrD70mfeTzHUU7gtwqM2jlBNHt7nbXS99hd4veGs9tryZtrxU9y8DtU+5j89y+7TeZ89LK2FkJn191fUXPOhgvq1E+Yb2xC774dLOse4sD1FgTq+fN2t0gBx5c1Crs3+U92z0lOvDovzM8ekKxCCCAgJcCdAB4qUvZCCAQKIFSJx8lT+YcCPYe2iTnoKS449xKlzlamrevLc/P6y1N77kuMuq/40IpIHJt7rAx7SIHeHonBSck9ZtUl7Eze8gZHnT8OMnLi3X1muaguemdFibN6yXaQVa0+AGOm13jhkoydXE/W4O4pVrp4nlrZNfOXUarX3S5d4MQVrRxGcA8ww4Lo0aFIKhYicLSrsetxi39/JPN8tSwGcbxKQayGgIIIOCpAB0AnvJSOAIIBFFAf1GbuqS/DB93n9S94wrjzgA9wNLrfHXQsSkL+0bOKKjfuJroL8xBbGcm56S/7Oop3i+80kfaP1BPLrz0DOPmlD2rlDS/7wYZP/uByKNe7ysh+S+IboWLFIp0kM1/8xF5fEJ7W+857QDSU+Db96wns18fIl37NxQd/DAdm3PqxCVG1URO/8/Z54yCUwiycxnArBeXy59//JVCLeFdRc/auuBi87EWxjwxW/QuFt6JUTICCCDgrQAdAN76UjoCCARUoGDBApHTzFt3ulFmLh8k417uKY+NbScDnmghPQc3kvt71Y8cbDw+/j6ZvOBBeXXDCHkx55fHh0a0kBtuvUSOPOZQV1qmtytc+dEosZruaFHTVn16BwKrMnV5vUbVEpZ7/IklLfPSMuzmlrDCOAv09PHrb6kiA0e2kkVrH5NRkztFxgno80iTyBkC2jnwwJDGMujJVvLExPtl1opB8uQLHUV/+T+hdMk4JZrPuq/nrUbtt3MKsdb+6HP3GpWr+6jGpzL56ZYsXx20MPqem7d6qEya2zuy3fSsnPY5B/k6VsfgUa3lqSmdZMZrAyLbfOgzbeX6W6vYOlU7WQ6my0ZP6Wy0neauflgKFNjHtNiU4tRA32tWk75H9tt/31x16MGt1Xq6/MnnO+Zaz88XTe+9zsi+UetarqQ55KnWRvWpk04nnXqMK/XGLYSZCCCAgMcCdAB4DEzxCCCQGQKlTjpSzqlwilSueqZcec35cl3di0VPN9YDaf2Fv+C+BTKjIVmcpf4afPqZJ4he7663R9MzBLRz4Iqrz5NKl5wh5c4tLfpraRYTpNS0oLoVK1FYji11RGS76Vk5epCvY3VUrFJWTit3ghx6+IEptZeVEMhkAXJHAAEEvBbI73UFlI8AAggggAACCCCAAAKWAgQggAACngvQAeA5MRUggAACCCCAAAIIIGAlwHIEEEDAewE6ALw3pgYEEEAAAQQQQAABBJILsBQBBBBIgwAdAGlApgoEEEAAAQQQQAABBJIJsAwBBBBIhwAdAOlQpg4EEEAAAQQQQAABBBILsAQBBBBIiwAdAGlhphIEEEAAAQQQQAABBBIJMB8BBBBIjwAdAOlxphYEEEAAAQQQQAABBOILMBcBBBBIkwAdAGmCphoEEEAAAQQQQAABBOIJMA8BBBBIlwAdAOmSph4EEEAAAQQQQAABBPYWYA4CCCCQNgE6ANJGTUUIIIAAAggggAACCOQV4DUCCCCQPgE6ANJnTU0IIIAAAggggAACCOQW4BUCCCCQRgE6ANKITVUIIIAAAggggAACCMQK8BwBBBBIpwAdAOnUpi4EEEAAAQQQQAABBP4T4BkCCCCQVgE6ANLKTWUIIIAAAggggAACCEQFeEQAAQTSK0AHQHq9qQ0BBBBAAAEEEEAAgT0C/IsAAgikWYAOgDSDUx0CCCCAAAIIIIAAAirAhAACCKRbgA6AdItTHwIIIIAAAggggAACIhgggAACaRegAyDt5FSIAAIIIIAAAggggAACCCCAQPoF6ABIvzk1IoAAAggggAACCIRdgPYjgAACPgjQAeADOlUigAACCCCAAAIIhFuA1iOAAAJ+CNAB4Ic6dSKAAAIIIIAAAgiEWYC2I4AAAr4I0AHgCzuVIoAAAggggAACCIRXgJYjgAAC/gjQAeCPO7UigAACCCCAAAIIhFWAdiOAAAI+CdAB4BM81SKAAAIIIIAAAgiEU4BWI4AAAn4J0AHglzz1IoAAAggggAACCIRRgDYjgAACvgnQAeAbPRUjgAACCCCAAAIIhE+AFiOAAAL+CdAB4J89NSOAAAIIIIAAAgiETYD2IoAAAj4K0AHgIz5VI4AAAggggAACCIRLgNYigAACfgrQAeCnPnUjgAACCCCAAAIIhEmAtiKAAAK+CtAB4Cs/lSOAAAIIIIAAAgiER4CWIoAAAv4K0AHgrz+1I4AAAggggAACCIRFgHYigAACPgvQAeDzBqB6BBBAAAEEEEAAgXAI0EoEEEDAbwE6APzeAtSPAAIIIIAAAgggEAYB2ogAAgj4LkAHgO+bgAQQQAABBBBAAAEEsl+AFiKAAAL+C9AB4P82IHJq5lMAAALYSURBVAMEEEAAAQQQQACBbBegfQgggEAABOgACMBGIAUEEEAAAQQQQACB7BagdQgggEAQBOgACMJWIAcEEEAAAQQQQACBbBagbQgggEAgBOgACMRmIAkEEEAAAQQQQACB7BWgZQgggEAwBOgACMZ2IAsEEEAAAQQQQACBbBWgXQgggEBABOgACMiGIA0EEEAAAQQQQACB7BSgVQgggEBQBOgACMqWIA8EEEAAAQQQQACBbBSgTQgggEBgBOgACMymIBEEEEAAAQQQQACB7BOgRQgggEBwBOgACM62IBMEEEAAAQQQQACBbBOgPQgggECABOgACNDGIBUEEEAAAQQQQACB7BKgNQgggECQBOgACNLWIBcEEEAAAQQQQACBbBKgLQgggECgBOgACNTmIBkEEEAAAQQQQACB7BGgJQgggECwBOgACNb2IBsEEEAAAQQQQACBbBGgHQgggEDABOgACNgGIR0EEEAAAQQQQACB7BCgFQgggEDQBOgACNoWIR8EEEAAAQQQQACBbBCgDQgggEDgBOgACNwmISEEEEAAAQQQQACBzBegBQgggEDwBOgACN42ISMEEEAAAQQQQACBTBcgfwQQQCCAAnQABHCjkBICCCCAAAIIIIBAZguQPQIIIBBEAToAgrhVyAkBBBBAAAEEEEAgkwXIHQEEEAikAB0AgdwsJIUAAggggAACCCCQuQJkjgACCARTgA6AYG4XskIAAQQQQAABBBDIVAHyRgABBAIqQAdAQDcMaSGAAAIIIIAAAghkpgBZI4AAAkEVoAMgqFuGvBBAAAEEEEAAAQQyUYCcEUAAgcAK0AEQ2E1DYggggAACCCCAAAKZJ0DGCCCAQHAF6AAI7rYhMwQQQAABBBBAAIFMEyBfBBBAIMACdAAEeOOQGgIIIIAAAggggEBmCZAtAgggEGQBOgCCvHXIDQEEEEAAAQQQQCCTBMgVAQQQCLTA/wEAAP//g34MCgAAAAZJREFUAwBb8bgoB8F2YAAAAABJRU5ErkJggg==',
  pwaQrDataUri: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABAAAAAVuCAYAAADrlE4dAAAQAElEQVR4Aey9CYBtx1nfWdVPDkxgEgOZmAlh2GPwxmKThWSifpMwScgwWbGzQAZwjCFAIAkEQpbXj5CwJCQQMF7wvseyFkvebfn18yrJsqzFiyTvtmRbtiVbXrW+nvqd26f79O27nHtv7fV/6q9PnTpVX33f76uqU1X3vqetPf0RAREQAREQAREQAREQAREQAREQARGoncDeltEfERABERABERABERABERABERABERCBygkYowOA6kMsB0VABERABERABERABERABERABJon4ADoAMBB0I8IiIAIiIAIiIAIiIAIiIAIiIAI1EwA33QAAAWJCIiACIiACIiACIiACIiACIiACNRLoPNMBwAdBv0SAREQAREQAREQAREQAREQAREQgVoJTPzSAcCEg36LgAiIgAiIgAiIgAiIgAiIgAiIQJ0E9r3SAcA+CF1EQAREQAREQAREQAREQAREQAREoEYCvU86AOhJ6CoCIiACIiACIiACIiACIiACIiAC9RE48EgHAAcolBABERABERABERABERABERABERCB2ggc+qMDgEMWSomACIiACIiACIiACIiACIiACIhAXQQG3ugAYABDSREQAREQAREQAREQAREQAREQARGoicDQFx0ADGkoLQIiIAIiIAIiIAIiIAIiIAIiIAL1EDjiiQ4AjuDQjQiIgAiIgAiIgAiIgAiIgAiIgAjUQuCoHzoAOMpDdyIgAiIgAiIgAiIgAiIgAiIgAiJQB4EpL3QAMAVEtyIgAiIgAiIgAiIgAiIgAiIgAiJQA4FpH3QAME1E9yIgAiIgAiIgAiIgAiIgAiIgAiJQPoFjHugA4BgSZYiACIiACIiACIiACIiACIiACIhA6QSO268DgONMlCMCIiACIiACIiACIiACIiACIiACZROYYb0OAGZAUZYIiIAIiIAIiIAIiIAIiIAIiIAIlExglu06AJhFRXkiIAIiIAIiIAIiIAIiIAIiIAIiUC6BmZbrAGAmFmWKgAiIgAiIgAiIgAiIgAiIgAiIQKkEZtutA4DZXJQrAiIgAiIgAiIgAiIgAiIgAiIgAmUSmGO1DgDmgFG2CIiACIiACIiACIiACIiACIiACJRIYJ7NOgCYR0b5IiACIiACIiACIiACIiACIiACIlAegbkW6wBgLho9EAEREAEREAEREAEREAEREAEREIHSCMy3VwcA89noiQiIgAiIgAiIgAiIgAiIgAiIgAiURWCBtToAWABHj0RABERABERABERABERABERABESgJAKLbNUBwCI6eiYCIiACIiACIiACIiACIiACIiAC5RBYaKkOABbiqePh7u6u2d2XnZ0dszMl29vbZntKpsv0972eOsjICxEYT4C+zziYHiv9Pc8Qyo3Xml9J7Efwpfcthyv2IPkRW80i2CL4Mosr+b2splmlIbCILbx7tpSjfMmCD/iDX7OEZ0jJPmL7WD8pR/mSBR+I2ax4ksczpGQfZbtfAvSZXugbQ6HPTMvw+XS61+PXQmlLQ2BxqzoAWMynmKf9oGUw94PdWmustebkyZMHcvr0aTMtZ8+eNdNyekY58npd1k50923RLoIdxUCToSIwggD92trJOGIMTI+V/p5nCGPEWmuoN0J9NkUYu4xn7Efwpfcthyv2INZO5p5a+eJjL9aW149SdWj6g7XtjFNrx/tq7aQfwShVfNZpF3utHe8n85a1E1/XaS9VnX7utXa8r9ZO/IRRKrvVbhwC9I9eiDfvacTaybuQft9L/+7or7Pe3f2zWddej7UT3bRDm71gRxyv1crGBJYo0AHAEkA5PmYAIgxMxNrJS4OBy4DuB3wM2/u2aBfBBmuPThzYGsMWtSECPgnwwrPWdgdm6+hlPFhrizgIYB5h7DKe1/E1RZ2eb+7zC/Ztwrf3k/6YgnPubcLFWqtxuiRQ9CMEXkuKJn+MjdYqpssCQTwReC0rq+flEOCdQUx5b1h7uL7nHU28eU8jMTyiHdrsBRusnazxsRHB3hi2qI3VCCwrrQOAZYQyeM7gYpBNTwYMTCQDE2eagG1MGv2Egf34gcysoEwRyIQAfZS+68Mc9KDPhy7fOphbrLXdN4B8646lj/klV77YhX3MhZvyoB8xh26qp6b68IWLD5/Qgz4funzr8DlO8dNaa9Dp204f+ogBNvrQhR70+dDlWwf8t7e3vcy9+GmtNbn66ptdTfroBwh9AbF2suEnpj7eGyFZYSPCO85aa7CfPog/IduV7lEElhbSAcBSRPELMHgQBpO1tvv6PoMs98lgGSnsxw/E2sMTRHxdVlfPRSAWAV5g9FGf7aEPvT51bqqLcceLe1M9OdTPkS/xxi6ffJhDeS/41FmqrhB8iRd6c2ISapwy9tGdk6+wJwY+bUJfbmMG7vBnPPv2Fd0+dUqXfwLEiD6J0A8Q+gLiv7V4GrGf8YY/1tqDA4F4FqilQwLLUzoAWM4oSgkmBGR6QojSeMJGhpMFL38YJDRHTTdOgD5InwyBAb3oD6F7HZ28pNepl2sd+OYyfxBn7AnBikUW74kQukvRGZIvcUN/LixCjtOQulflB3PYr1pvTHnGDPrHlI1RJqQtxDSXeTAGy1LaICbM2wgxok8ipdi/jp34x5i2VocB6/DbqM6IyjoAGAEpZJF+UmBCQBgwIdvLWTcTBQysnXyVDTY52yvb6iLAoow+GNIr9OfQr/E1pJ+pdOfiF3EOyYD3RC6+hvRznu7QfNHfyjhlQzKPc8x8mIdsD/25xJTxG9LXlueGkFxX1U1/Y3whrG2JO7KqnhrK4zdj0NrJ+l59NGxUx2jXAcAYSp7L9JOCtbb7ej8Dw3MTxatjomDCtHYyWRTvkBwQgX0CqV98tM/42jenqgtzKf6ldCpW+7XGcFnsYvGN1c4if2PEmDHDmmSRHaGfxWIdq51FvFqJ6SIGtT9jPGnTPz/KjAHE2sn6PodxOd/aIp+MMloHAKMw+Sk0PSn40Vq/luFEUb+38jAFAcYm/SxG2zksuGP4maqNWHGc51/M9um38+yoMR9/Y/FNPU5jLopjtjWrXyqms6hslpc6pptZX15t5iY2/dbqg71VosfYR6ydHAasUldl5xEYl68DgHGcNirFRGytJoWNILrKw0mCydZl6UcEvBBoqT8xjrxAy1hJqnjGbpd3S8Zh8G5aS3xjjlMOO7wHa6TC2H04dntDDK3EdOhz7WnmJDb+fGM15TiqgTPjw1odBGwcy5EKdAAwEtSqxfpJwVpr6NSr1lf5+QTgyWTLixyZX1JPRGAcAcbruJJ+SqXqt6na9UNtvJZUfsbuR60tOGPzHd/j/JZM4WeKNqGWql3ajikp/EzRZkymKduCrTb+YSLAGt9aq/+t5Zp4x1bTAcBYUiPLaVIYCcpDMSYJxFpNFB5wNq0i9kYqdntNBzei88z/EZvrmkrRZtdwgl+xx03s9nqkKWKaok38jc04dnv4iKTgm6JNfK1ZYKqNf5wID9f3qQ7143jqtZXRynQAMBrV8oKaFJYzClWCiQL+miRCEZZeERABERABERCBUgiwWS3F1tzthCVrTL59muoQKXdGoexjfY9ofT+G8PgyOgAYz2puSTqltdZoUpiLKMoD+GuSiIK6qkZ4sVfl0AJnWvJ1AYZgj5iDgimX4iQEWhkzrfhJJ2rJV/yVrE+AvqKN//r8fNZkfW+tvvG7kOkKD3UAsAKs6aL9xECnnH6m+3QEiIe1miTSRUAti4AIiIAIiIAIiEC5BPhwT5/45xc/rfHnx2SVJzoAWIXWftl+46+JYR9IphdNEpkGRmaJgAiIgAiIgAiIQIYE+jU+a8gMzZNJ+wSID4c0+7e6GLMSAx0ArITLGDqbNv4rQktcvJ8kmNQTm6LmRUAEREAEREAEREAEMiPAGlFf988sKEvMYX1vrb7xO8G02m8dAIzk1U8MdLaRVVQsIwLEjYMbDnAyMkumZECAF34GZsiECgicf/75FXghF0RABESgLQKsDVkj6t9xKTPurPGtbfwgYMXQ6QBgBDBNDCMgFVKESYJ4FmKuzBQBERABERABERABEQhEgA8BWBsGUi+1EQkQx1bX+Kti1gHAEmKaGJYAKvAxE4S1OiksMHTBTI79ye2pU6eC+SLF6Qjwvojdeoo2Y/uo9kRABETANwG+2Wut/g9evrmm1scav8FDgJWx6wBgDjJNDHPAVJStSaKiYG7oijZRGwJU9Y5A7H6kg6QOu36JgAiIwEoE2CDylf+VKqlwMQRY31vb0gd9q4dGBwAzmGlimAGl0iwmidiL9kpRFu1W7D7AHFM0MBk/kwD9KPa3SWYaokwREAEREIFjBPhwj3matd+xh8qojgBxbmK9tUbkdAAwgKaJYQCjoST/6Iu1OilsKOTHXGVBEGvjpk9tj+GvKiPmYiNmW1UFSc6IgAg0R4A1Pp/6s+ZrzvmGHeYQgDUe8a8Vwzp+6QBgnxodQxPDPoxGL0wSWlA3GnzndqzYx2rHuaSfBARYaMQ4TNJBUoLgqkkREIEiCfDeZY1fpPEyemMCHPoQf/rBxsryU7CWRToAcNjoEHQMl9RP4wR0CNBuB2DjFnpTFVp/u9HLy3PeKSEtoh+FbiOk/dItAiIgArEIMFeytovVntrJlwD9gP6Qr4XrWLZeneYPAOgIdIj18KlWjQToD/SLGn2TT4sJEHc2V4tLrfcUvehfr7ZqlUSAw6QzZ84EMVn9KAhWKRUBEaiQAHMxa7oKXZNLaxKgP1S1FluTQ9MHAHQAOsKa7FStYgL0C14cFbso1+YQYF5gkzXn8VrZ6EPvWpVVqUgCzB++DwHUj4rsCjJaBEQgAQHmYL76naBpNZk5Adb4tazJ1kXd7AEAgacDrAtO9eonwIuDFwj/PkT93srDIQHmBzZbm/5dbuqzCUTfUL/SbRBg/tjb2zP0pU08Vj/ahJ7qioAItESANRtzL2u4lvyWr6sRYA+4s7OzWqX8Sq9tUZMHAEwMBH5taqrYDAFeIPz7ELxQmnFajnYEeDEQdzZvbMC6zJG/KM/Gn/rMNyOrqVilBOhL9Af60iouqh+tQktlRUAEWifAO5c1G2u31lnI/+UE2AuWvUZb7uO8Es0dABDo1icGFpXTwsJ0KNPP53WgVvJ5obCIb8Vf+XlIgLizqOCT3H4TNxwrfZpnCOUoz1xzqGX9FLoQ7NhUWp/71o/C5jXpD8SP/kE/6fvNrCvPKUfcqbd56+k04AOC75tKCi982b6K77SZwtdVbPRVNoWfarNOAowb1mp1ejfOq+m1e38//Z7p8/vrOO11lmJdVOx7doOQNHUAQIAJ9Aa8iqnaD2oGPYtJhAUlwiQ5LdMv8+nn1OsFXehFaKcYKBsaykkhXDZUo+oFE2AOmR4r/T3PEB/u0c/QhbCgQeh/m4oP26RjcwLEte83s64837yVdBr6/mutNfRdZNO+S/0UHtFubEmxTqHN2H7SXoqYqs36CDCPMs/U5+84hQAAEABJREFU59lxj1h3I6zBWY/3whqduXeWwGco02Woi/S60I3QznEL6sth/ivxvbtJJJo5ACCwBHgTWLnWZYAi/cBlEPeDmwGP74gv+9GFXoR2aA9hskCwxVdbuenhBYPPudkle+ohwPiinzFfIfV4Jk9qJ8DcOOy/tfsr/0RABNITYN6p+TCJNTXSr/HxF2ENznzbi49I9LrQjdAO63vaZn2P+GgnRx2st/A/R9vm2LRRdhMHAASUwG5EKrPKsyYD/ERSmcpkgfQTBhMFksqeUO2yOcPHUPqlt00C9CnGb21zVZvRbM9r5n7mRvXf9mIvj0UgFQHem8w7qdoP1W6/xmfzjY8I6wMkVJuL9NIuczyCTQjre2RRvdKe8f7C1zLs3szK6g8A6KwEdDNMedSenhDopEge1h23AvZIjRMFfh33WDkisB4B+hOLmFrmqvUoqFapBOi/NX8CV2pcZLcI1E6A92YtPs5a4+fsG/M+Utsan3UYfuXMvrNtw19VHwAQwNIXJaVNCPP6I7FAapkomCByPnyZFwfl50mg9HkqT6qyKgYB5nX13xik1YYIiMCQQA1rMK3xhxHNJ807jXdbPhYdt2TTnGoPAAgcAdwUUKr6/aTQf+0nlR0h2iU2SH8YEKKNGDp1CBCDcv1t1LCIqT9K8nAWAebxkt+zs3xSngiIQP4EeG+yBsvf0tkW8tV5/l59zWt8fERmE8g/l3cb77hMLd3YrCoPAAgYgduYTgIFNW/8Z+EkViUfBPACwodZvilPBJYRoO/Qh5aV03MRyJEAi9cc7ZJNIiAC9RIo9b3Zr+9Z8+IDhxj1RskYfETwt9SDAPaS+JBfnDa3qLoDAAJFwDZHE1cDg4NBwoKq9klhFlnihv9wmPU85zz6G/bnbKNsy5MAfSdPy2SVCCwmwJynw6vFjPRUBETALwHmndLem/3Gv9X1PT2AuJW8xid2+JGNeDCkqgMAAlTixMCgYHB4iGfxKuAAj9IOAuh32F58AORANALMV9EaU0MiIAIiIAIiUDAB1listUpygbUs7/oWP9ibFSdiWOIan39skjjO8ilFno82qzoAoGP5gBJDx/BEMEZ7pbVBLEubJHgx1TZBlNZvSrJXfaWkaMnWaQLMd9N5uhcBERCBEAR4X5Y057DGZw3LWjYEj9J1woV/A4EDklJ8weZMbPViRjUHAASmlK8j0umZzHQiuLwPE1d4lTJJYO9yr1RCBIxhDhAHESiRgPpuiVGTzSJQLoFS1lZs/Fmzao5c3te2t7cNcS1lfc8eE3tN8j9+DKjiAICAlHAySCfnRJBO7yd8bWiBFzGGX+4e1zZB5M5b9omACIiACIiACNRLgPUfa6vcPew3/qxZc7c1J/uIL3ujEtb47DWTH+54Cl4VBwAExBOPYGqYGOjkwRpoQDH8Spgk6I+1TBANdKtkLpawoEkGRw2LgAiIgAg0T4B1H2uqnEH0n/pr479ZlIh1CYcA/HsAm3m6WW1ftYs/AKDD+IIRQg8TA5tWTQz+6BLz3CcJJggdAviLuTSJgAiIgAiIgAi0RSD3zT9rUdZ6WuP76Zes79kzwdWPxjBaEsbbm0NFHwDQUXKeHOjATAzeoiVFBwSIPXwPMjJMYGOGZskkERABERABERABEciaQO6bLH2zN1z3Yf2c8xqfb3BiYzgC8zT7yy/2AADwuW7++dRfE4O/TjpPE30g55PCGiaIeeyVLwIiIAIiIAIiIAIhCLC+Yw0VQvemOlnjs/bM/YBiUz9T16cPsJdKbce89tmDRv+Qd54xa+QXewAA+DX8DV6FiYEOoYkhOOqDBpgkcj0ppJ/SHw6MVUIEREAEREAERCAZAa3PkqEf1TBrOtZOowpHLsRaU2u6eNAZqxy2sLeK1+r4luir40tvXtKnhiIPAHIFTgfVxOCze47XRZ9gYh5fI15JbIvXmloSAREQAREQAREQgTIJ5Lz513ouTZ9ib5XjGp9vqUTsE17hF3kAkOPkQMekg3qNjpStRIBBSBxWqhShcMkTRAQ8akIEvBPgUwPvSqVQBERABEQgKAHWcUEbWFM5a8tcbVvTpeKqwZ845GY4e9I4+z+/nhd3AEAH8Itgc210yBzt2tyz8jQQB+KRm+VMELnZJHtEoFYCOgCoNbLySwQ2I5Dj+mAzj+qqneNaib+HztqyLtJlekMcchzD2BWcqOcGijoAAHBukwMdEbs8x0XqNiBAPJiwN1ARpKo2JUGwSqkIHCOgsXYMiTJEQAREIGsCrN1yM5C1pN4neUWFfsLeKyer+KZv6G8B+Pa3qAMAbf59h79efUzYTNw5eVjiBJETP9kiAmMI5LYwGGOzyoiACIQnwNzA5iF8S2phVQLEJbc1PmtI1pKr+qLy4QnQXxjP4Vsa3wI2jS+9cknvFYo5AMgNLB0vN5u8947CFTJxM4Hn5Ib6TE7RkC01EtAYqzGq8kkEREAE4hFg7cgaMl6LamlVArzr2YutWi9UeT7kw6Yw+v1rLeYAIKeTQTpcSUH2323K0cgETrxysZgJorSvCeXCTnaIwDICOY31ZbbquQiIQDwCzA1at8XjvUpLxCW3NT5rx1V8UNk0BOg7jO00rR9vNVg/Pt7UxjlFHAAQ4I099aSAjpaTPZ7cqloN8SJuuTh58uTJXEyRHSJQDQHGOGO9GofkiAiIgBcCmhu8YAymJKdNk/pKsDAHU8x7n/8Ne7AGVlQc4vBoRRNGFc/+AIDA5jI50MGwZxRZFcqKAHFjYs/FKOzJxRbZIQKlE2Bsa0yVHkXZLwL+CWjd5p+pT405zdt6j/iMbFxdfLOWsR631dmtBfim7+yGNszN/gBgQ/+8VqeDeVUoZVEJ8KJhgo/a6JzGcjnUmmOeskWgCAK88Pm7moztIgyWkSIgAtEI8L7Xui0a7rUaymUtRF/Re2StEGZTibHOmiAHg/z2pTAeZX8AkMvkwCIzTAikNSYBBqUmiJjE1ZYIhCHAnMwLv5Sv24WhIK0iIALTBHjHMz/wvp9+pvt8COQSH/pLLrbkE50yLckljl6/BRAoFFkfAOQSSE4GYy0yWdC2KoH6+DG1ufQr4nzMuIIz8GdaCnZnoenTfq5zv7CBih6yuPIlzMUs7Pf29ozvOXmdGLZcJ0UX9dWPVtHTip8wKdnX4dzAuPQ5P6BvU0nBNvc2c/mAL9aacNM+VHr9GP2Rcc9cEKOtZW346lfL2ln3edYHADlMDnSkkEFkQNNhrbXGWmv4B+JaFWsnDOABc9is27EX1UM/cV1UJsazEk4IF3EgPrBErJ3dd62NE9NFdvp41vtq7cQfH2PUh10l6KB/wM+HMC+gz4ff2IMua/3F1Ee/KEFHqnczMYstKTbG9MvYfjK2fIyrVXX48hP74bZq+7PKYxO6EGtnv9tWHaepxsws/3LII1452MFakDiHsCVEP1q13+VU3trJu5bYIyGYoxPdKeZt2h4Ka/zh/ZrpYNWyPQAggMG8XkFxKDvQa+3kxZJ7J1kBl5ei8OBlycQFJy9Kp5SgN4cJAjumTMv+tn+pER9ihSwzmjLDmKJjWZ0cnhMfazVOc4iFLxsUU18kpUcE6iLAe4nN4CrvtroIxPOG9UC81ma3xOaf98Hsp+vnqh8tZkfsEWutCcGf1okB19SyuX/hPMj2AIDOEc7tcZqZHMaVHF+KTskLJgf/xludriScrA0zSRCL1IcAbIyxIx3h1VpmMusXR6vVPCxNTNGBrsPcvFLEROM0r5hsao1iuilB1ReBegnwPuK9xDu5Xi/z8AzWOVgSwg50qh+Njy7rQWut4f08vta4kvx1wXElw5XCv420B6yc5QEAAyigz6NUs/n3bQf6NDGMwn+sEIMIfscebJgRQueqJuVgwxibt7e3DXEwnv6gK0ffeRFpnHoKciZqFNNMAiEzRCBDAr7fbRm6KJOmCLDGn8ra+Jb1DOuajRU1qIA1F/x8us64DhHnVW1k/bFqnb58yGuWBwA5DCDfHZEOkINfITtTaN3w8x0XJgh9C2B55OAe4pOREDFd7s38EoxTXkTzS+hJiQQU0xKjJptFIDyBUO+28JaX2QLvWN77Ka1nU0jcfdqAvtR++fQnhS740T98tk1cUq/xsWFNn4JWy+4AIAdQTA6+qWsB6odoiAnC94Szjqc59Pt5dmMb3Oc93zQf3TnEAD/wlaukHgIc8tXjjTwRARHwRYD5nvePL33Ss5xADu964r7c0vEl0Kd+NJ7XopKwXPR8nWchdK5iBx+erdfvV2ll9bLZHQCs7oLfGmz+fXcW3/r8elyethA8iXtKEkwQKdtf1HaMF1uImC7yadYzbMg5DrNsVt5iAorpYj56KgItE4jxbmuZ7yzfUzMPsdZL7dMszqXmsQbjve3Tfj4EKPJbAD4hzNCV3QFA6oFER5nBaaOs1D5tZHyGlZkgfJ+mMeGkniB8++QjdHDxoWeZjhAxXdbm9HON02ki5d8rpuXHUB6IQAgCsd5tIWwvVWcOzH3b4FtfqbH1aXeI93bqOLHGXZVR6PJZHQCkDhAng74PAFL7FLoDpdIfgmsInavwSd3+LFtDTMSz2iEvpf8p28Z3iX8Ciql/ptIoArUQiPluq4VZ6X6wxvftQ44f3Pj2MYU+31zZ2xX2IV9w7FkdAAT3dkkDIRaMvjvxEheaeRziNC31BBHCp006ROy+m5v/m7BTXREQAREQgTwJhFjr5elpXlalPHRh8x8i7lq3hOljIWIVe007TWY1n6Zr+7/P6gAg9eTgH68xmhxCUJ3oDDGYUw/QED5NaK3+O4UtKdqETMq5h/Yl/gkopv6ZSqMIiIAIrEMg9doqRPup1ivr8C+tTqi9EwdBqVjg0+g+E8HIbA4AQgzOVfilbn8VW1V2QiDEQNre3jYpvybUej8MEdNJb9FvERABERABETBG75m2ekGoTZ/6UXn9qJQ1dgyy2RwApBxImhxidLVy2kg5QeR2QlhO1Na3NOXcs77VqikCIiACIiACZRDQN7LKiFNOVoZamxXwIV+UMGRzAMDGJ4rHMxpJueGbYY6yEhPYTvwtgMTuHzQfavI9aEAJEQhEQH03EFipFQEREIEVCaRcY7PZS9n+iqhUPAKBlP2Bve7y9UkECK6JLA4AUgYj1Kf/jq1+CiaQsk+mbLvgkMl0ERABERABERCBzAik3PDwgU5mOGROYgL0CQ6GEpsxv/lIT7I4AEg5OUTirGYKI5BygsjphLCwsMlcERABERABERCBjAiwpklljj5QSUU+73ZT9otlbccil8UBQKrJgU//cwlErICrnfEE1DfGs1JJERABERABERABERgSSLmOYo0/tEVpEegJpP6Qr7djxjVaVvIDAH36Hy3WamhFAkwQK1bxVjzlS7N3IqX/vQ26ioAIiIAIiIAIiMCqBHJYR61qs8rHI5Cyf8zf+8bzv+kDgJTBjxditbQJgZb/npAOADbpOaorAiIgAiIgAm0TSL2lft0AABAASURBVLXR0af/bfe7Md6nXOPOHRdjDPdUptkDAE0OnnpQ5WpSHRKl+msxqcOZindqv2tuXzGtObryTQTKI6A5KV7MWl3LxCOsljYhkOpDvnkHAJv4smrd5AcAmhxWDZnKxyTQ8gkhvsecHGO2FbMPtdyWYtpy9OW7CORJgHdbnpbVZVXKTY4OeerqS6G8SdVP5ux9Q7k5U2/SAwBNDjNjoszMCKTaxKQcH30IYk6OWpT11Ou5Kqb1xFKeiEBNBFK912tiuMyXVGsYfcN3WWT0vCeQco1yfHz0VsW5NnkAoMkhTueqpZWYm+Ahs9STA7YwOcZYKDEmU3HGT0kYAoppGK7SKgIisBmBHN6vm3mQf20xzj9GstCYGGvcUZwjF0p6ABDZVzUnAmsRYBO8VsUNK+XwFSFciLGJS8UY/yRhCJw5cyaMYmkVAREQAQ8EOHj2oEYq5hBItYaJsWaZ47KyCySQqr9MtxsbXdIDgNOnT8f2t2svNfTOCP0qikCqE8IcTtDZnIdcKKGbNorqEDJ2IQHFdCEePRQBEciAAGtB5qoMTKnOhFRrl1RrteoCKIdiE4jeXtIDgOjeqkEREIG1CIRaKLH4QvdaRqlSlgQU0yzDIqNEQARmEOD9w5w145GyNiCQ6gBAHyZsELRGq9JnUhwcHf2GTHz4yQ4AUk0Omujjd7IaWmSRkMKPVONklq8w8Dl++Io4Ome1pbwyCSimZcZNVotAywR4D/l8t7XMUr6LgAiMJ3Cwxh9fxVvJ5g4AvJGToqYIcEKYwuGUk8Msf1ko7e3tmU0WS9RFRyqms/xS3mYEFNPN+Km2CIhAWgI7OzuG9xJzWVpL6mg91dqFONZBUF7EJJC638T0tW8r2QFAb0DsqzYdsYnX016KrwjlSo/Jsl8sLVswwQ3h02GEurn6JbvGESCeCPFEFNNx3FRKBEQgbwLMZcxpvNeY4/K2VtaJgAiUTGD/oCyJCzoASIJdjYrAOAKp/47QMitZLCEcBswTJjiEwzdkmc5lz4e60GetNdauLydPnlzWZJDn83iVkE8MEPgjmwIa6kKftevH01prWoppS5sUazfrF9auXj/FHMw/kGzt6rZau36dVGPG2vVttnZSlzkD4V3EXLLpfDTU5Ws+5kBhU7tKqp9i3LTGuKT+kLutjPkUNk7mqxQtG5PsACCF0y0tlNJ0p7pbZXFRt4d5e8ecwSTNQpXFRS95Wy3rFhFQTBfR0TMREIExBPp3AQcnvB94VyNj6qqMCIiACEAg2R6RxhNIsgMAJuzY/rJ5iN2m2hOBTQmwSdpUR8n18Z+xy8IuxbxRMrtcbVdMc42M7BKB8glwEIDoECBNLJnfU7TMOiFFu2pTBNYlwJp23bqb1kt2ALCp4aovAiJQPwEWEtr41xVnxbSueMobEciVAIcA2hTGjw5zfPxWjVGsU1Cvp81E/ScZwCQHAJocksVbDW9AINXkkGq8bIDKS1X8ZvPvRZmUZEFAMc0iDDJCBJohwCdsqd7dzUCWoyJQAYE084QxrItS4EtyAJDCUbUpAj4IpPg7QqkmBx+8NtGhzf8m9PKsq6/k5hkXWSUCNRPQIUDN0Z34lmJtNmlZv0VgAwIJqyY5AEi1odne3k6IWk2LgAiMJaCN4lhS5ZQjpizEy7FYloqACNRCgLkn1dqzFoZj/RDnsaRULicCKfaIKf1PcgCQ0mG1LQIikD8B/u5m/lbKwlUIKKar0FJZERAB3wQ4hPStU/ryINDa5i0P6rJiQwJd9VQHZs0cAOjrQV0/068NCeglsyHAEdW1SBsBqbAiimlhAZO5IlAhAX0LoMKgyiUR8Egg7l7Ro+FrqGrmAGANNqoiAiKQgIA+KU4APXCTimlgwFIvAiIwioAOI0dhUiEREIHQBBLr1wFA4gCo+bII6BsAZcVL1oqACIiACIiACMQjwDct4rWmlkSgTAKprdYBQOoIqH0RWEKgpZdpqr8LtSQEerwBAcV0A3iqKgIi4JVAS+9Tr+AyV6YPZzIPkMybJpD8vpkDAE0OyfuaDBCBpQS0WVyKqLgCimlxIZPBIlA1Ac1JVYdXzolAAQQOTUw1HyU5AEjl7CFupURABERABERABERABERABERABETAmGgfFmcAO8kBQAZ+ywQREAEREAEREAEREAEREAEREAERiEYgh4Z0AJBDFGSDCIiACIiACIiACIiACIiACIhAzQSy8E0HAFmEQUaIgAiIgAiIgAiIgAiIgAiIgAjUSyAPz5o5ANC/O5BHh5MVIiACIiAC/gi09HcW/VGTppYJaMy0HH35LgLzCUTZK041n2o+SnIAkMrZKea6FYGVCaSYHFY2UhVEQASaIaD3aTOhlqMiIAIiIAKFE8jF/CQHALk4LztEoAQC559/fglmysYVCJw6dWqF0ipaAgHFtIQoycbWCWichu8BKdYs+nAmfFzVghcC2SjRAUA2oZAhIiACIiACIrAaAb4BkGLBvZqVKi0CIiACIiACrRPIx38dAOQTC1kiAiLQCIGdnZ1GPG3HzZQx5RCgHdLyVATWJ5BynK5vtWqKgAhUQSAjJ5IcAKRYrJw9ezYj7DJFBESgVQL6Cmp9kU8dU21q6utT8sg/gdTj1L9H0tgT0F8B6EnougmB0HvFTWzzXTfJAYBvJ8bq0wQxlpTKzSOgPjSPjPLHEOCr2tqsjSFVVpkcYqrNTVl9RtbGJ5DDOI3vtVoUARHIhMBMM1J8KI4hTR0A4LBEBDYhkOJ0MNXksAkn1Z1NQAvQ2VxKzj1z5kwW5tO3dAiQRShkRIYEchmnGaLxblKKNUuKtZl3cFKYlED4D/iSunes8SQHACkmh2OeK0MEREAEIhJgc6a5LyLwCE3lFlMdAkQIupoojkBu47Q4gCsarPfcisBUPAsCwQ8A5niZarwkOQCYwyB4dqrgBndMDUQhkKr/pJocokBtoBG+9s+nT2zOGnC3CRdzjin9jA1PE4GQkyKwhIDm3iWAKnqcao1WEUK5EpBAbqqTHQCwgIoNQ5NDbOJ1taf+U1c8Y3jDRox+o0OcGLTjtMG7K/eY6hAgTl9QK/kSYJzu7e0Zzb35xkiWiUBDBGa6yjw180GEzGQHABF8UxMiUAUBLWDKCiMTOht/ffJUVtwWWTuMKZv/RWVzecYhABsg+iKSi12yQwRCEWCcIsy9pYzTUCxS6k21ZlHMU0a9/LZPnz4d0In8VCc7AEgxQegfCcmvA5ZkkV4uJUVrvK39gpFF46bChot+wubLxxyHLqTXh87SBPvHR8NPyZJjSqwRX9zQhdA3N+3ffX0dKPjpp/O0wLdnHetKm/PsCZnvyz/6N2MGYY4MabN0LyfAHLy8lN8SxN6vRmkTAU8E5qhJOVc1dQAAf00QUJCsQyDFAVKKl+g6bEqvwyTsQ3xxYJ7CnpMnTxqEk2n6X6nii8sqeuDnQ1Zpc1HZsTEl1ghxt9YaNu+L9K7yzAePXscq7ars6gR6zjGvq1u5eQ1f/m1uiTSUToD3Y+k+yP40BHy+Z2d5kGNesgOAVDBaDHIq1jW1y+I9hT8sjlK0qzbTEKCfEXM2f1rMpImB71Y3jSmHAdb6PQjw7aP0iYAIiEAOBJhvc7BDNojAgMDcJOu9uQ8DP2juACAwT6mvlIBeKpUGNiO3OJzUxj+jgHgwxWdMOQhAnwezpEIEREAEghJItbHRWi1oWKtVHrbf5Ikt2QFAqslBn6rl2RFllQi0TICNHRu8lhnU5nuImNJHUr07a4uP/BEBEQhHINU81eJGLlwU29EcdG+4AGOqcYJJyQ4AaDzV32/WBAF9ySoEWHivUt5XWTYRvnRJT54EmI9S9a88iZRvVciYslBJuWgoPzryQAREIDSBVHMU82No36S/LgK8r0N6NE93qj1wb0/SA4BUE4Q2VX34dR1DIFV/ST05jGGjMpsT4Gv/m2uRhpwIhI4pi9xUi5acOMsWERCBfAmkWsNobsy3T+RoWeD+MtflVHvg3qAmDwB653UVgZwJpJ4ccmZTi22pDpdq4ZejH7FiGqudHBnLJhEQARGYR0Bz4zwyyp9FIOw3MGe1OMlLvcZv8gBAn55MOp9+jyOQanIYZ51KlUxAfavk6M22PVZM9R6bzV+5IiACeRBItRFnbsyDgKzInUDwProAQNMHAHBJ9RWhlEHHb0kZBFL2k5RtlxGdsq1UfMuO3yzrY3+VUH1oVhSUJwIi0DqB2HNx67zl/2wC83JT7X2H9iT9BsDQkNhpnRDGJq72REAERKBuArEXnXqP1d2f5J0IlEyATzhTbXR0OFpyz4lne+Bv7M11hLEx92GkB8kPAFIO0tiLtUgxVTMeCaSaHE6dOuXRC6nKkYDmnxyjsplNKWKaos3NKKm2CIiACIQloMPRsHxr0B5+/5k3peQHACnxtB78lOxLaFv9o4QoyUYREAEREAEREIEcCaRcR+lwNMce0ZBNC1xNOS56s5IfAPA1iFRfEdIJYd8NdM2NAOMiN5tkj18Cmn/88sxBm2KaQxRkgwiIgAgYk8MmS3HIl0Dob/jm6/nEsuQHABMz0v3WBJGOfc4tc3KccnLQAUDOvUO2iYAIiIAIiIAILCPAWiblh3ys5ZbZqOftEYiw95sLNZe/4pvFAUDKQKTc5M3tHXqQnEDKl0Yuk0PyIMgAERABERABERABEViTQMr9xZomq1oEAuH3fvOd4FBs/tN4T7I4AABGqhNCUKfc7NG+JD8Cmhzyi4ksEgEREAEREAERKItAyk04fy1La/yy+ktoa6P0xwVOsOdd8DjaoywOAKJ5O6eh1J1hjlnKTkQgdX/IZXJIgb8l31MeeqaIrdoUAREYR6CleXAcEZVah0Au/Qg7Ur7vUq/p1omd6oQjEOMDvnnW5/QN32wOAFIO0FAnhEx68zqB8vMloMkh39iEsEzjNARV6RQBERABEegJ6D3Tk4h/ZY0folXFNATVQ50h+Ebaax46MZUK4dNUE6NvszkAAEqNJ4QpfRrdCwotSJ/xbbomB99EV9MXIqarWaDSNRBQPwobRfEV37AEpL02AqnXVqnbry2epfoT56+DzKeT07szmwOA+bjiPOGEMHXHiONpPa2EGEgpP/0nMiF8Qm9JEvvQLBVzLUjC9cpUMQ3nUX6aY4/T/AiEsSinr4iG8bBNrcxJscdMTu+YFP4PexprO99r/NQ+Df2rLR1iHmQ8sNcLzmpOAyF8mtPUqOysDgAIziirAxU6efKkd82pffLuUCYKQwyk1LEK4VMm4VrJjNhx4CW+koGeCtNu7AWhJ9OzVwPb7I0s3MDY47RwXDJfBKIS0HriOO4Qc5beNcc555rDIVAM2+a1kVtfyeoAADipF8S+J4gcfJrXGUvO9x0n9GlyyKNHxBwzqRdJ9Ls8qNdjReqY1kNysScxx+liS+p6qjmhrngOvYkZ25htDX1clE5tE5/++v4WQGqfFvEu9RnvcN9cfetbwHbuI95yKIkrAAAQAElEQVSZcx8meJDVAQD+pwbEJlATBJHIV5gcfFvnO+br2Je6769jc6g6MSZr+lGMdhYxIuapDz0X2VfaM1imjmlpzDaxV6w3oXe8LnPS8Vzl1EKA+T5GjGO0sU5M8J85ep26vuqEmLNy5e2LWQ162NvF8WN2Kzn2kewOAEIMztnhmJ/r2wYmvRyDP59Avk/g6Ds+6ONkOKXX+JWy/dzajjFmiHsOfudiRw4sNrVBLDcluFr9GON0NYvKLc07QP233PiNtZwYh9wEo5s2xtoTu1xq21jr+bYBfXCPzbLG9kLMg8QnGqs5DeVgw7Rp2R0AYGDqgcQE4fsTYYJPx8Y/yXoE6BdwXK/2/FqpTwaxLIRf6C1ZYELMQ/iQ01jUJspPhIkpLP1ok5axBEKO07E2lF6OeQ6Opfsh+8cR8L2+HLaaez9ijqa/D22OnQ6x5iOmqf2KzdF3e7zDffdf9IWI9zzfZ+Xj16z81HlZHgAQsNRgQv2DgLl2hNS8l7XPxMoEu6zcqs9z6GvqE/OjRsx98zlz5ozJIe5Dr7HHt59D/bWnc4xp7cyH/oUYp0P9NacZ9/Cr2Uf5dpzA3t6eYV1z/Ml6OehiHmSDvZ6GeLVysDGEDYxjxnM8kvW0BDfWQb49irz5n2l+CL9mNrRiZpYHAAxMJrMVffFeHDt8K6Uj0NF9661ZH7yYWH37SCw0Ofim6l8fcaIPbKqZOYVFV4hxvalt1MdP7PPhK/paEGJayqK39njQf9V3V4syvOC2Wi2VroUA6xr6wKb+MA+iK9d327R/OfR5vukbwg50+ojpNLNa7+m7vMPh5tvHEDoX23j8ac59IcsDABDmELiQE0S/0Kfz46/kKAG4IHAK0Rd4Weaw+c95cjgakbR39AH6wjq86Ee8YIh5Wi/GtY6v+ImMq9FeqWFMS1n0thAl+u6647QFPvhI32Vswwle5EnaJUAfoC/QJ1alQF8q6d029G8df4f1faRZA4ZYF2wSUx9+laBj2HdDvMOJAfGNyqKwxrI9AKBD0EFS86QDhZgg8IsOiu5+8mdCbF14mSFwQeAUQmAfQu+qOnOxY1W7p8sTKwR/hkIeMl1+3Xt0M16QZWOFfkQ52mc+WbfNFPXwE8H+ZX6u8jzFnEqbq9i4qGzJMQ3Vj+jf9JVNBT2+bMQW+i6yKJ4tPaPvInCGjy/W6EPQuan4sqkWPXDtZZptn+/LV/QzXugjy8YFZSiLDaW923peudgN994m31d0EyfitSymrTyHBRKy76KbvZvveC7TN/2cmNIHpvNzuc/2AABAuYCLYQdtSHYMLwWE+IcSOPPtjlD6x+plchhbNsdyu7u7XbystYZ/MwNh0h0KeYi1tiu7s7PjzRV0LZLQ/cibI0sULfJx1WdLmgrymDisaue88ugKYmTBSofjbZN0qnE6L9a15dN3ER9dbczcu2pfyOGd6IONDx30PWLFmOhlmmefb63t/k0Z6vhom3bRtUgo46OtlDrwgcPhlDbQNv0e1qRDCb7ShmSnWwfCIxRr9DI2uUaW4prL+gCATpLLBIEtxUVXBh8jwATMi/zYgwQZ2JKg2Y2bxG5rbbfp5+U5ViFlYW/tZME0tp7KiYAIxCOgcRqP9aot7e5ODl1Z4BKnVeur/GICOzs7xlpreE+twpfyiLW2OwxY3Iqe9gTg3adTXoldLrak5FBD2+nieJxeTrYct86YrA8AMDgXgLwMcrEFLpLVCbB4YqJfvab/GqV++s9BmA+G6NB48t+vpFEEfBLQOPVJczNdzJfa+G/GcF5t1gZ6t82jEy4f5jl8yIeHzHX0A9KSMgkwRxLHJNZPNVrCGj/7A4DcJgg62FScdVsAASZ2Fk+5mEq/zsWWsXZgMwdhY8svK8dEjc5l5fRcBEQgHQGN03Ts+5aZJ4lDf6+rPwL92sD3u01rxXExyokTa0T6wzjLVSonAvSjlHPkNAvsmc7L7T77AwCA5QSSDpaTPfCRLCfAxL68VJwSnAyyoIvTmp9WsNfnAqm3Cp0aTz0NXUUgTwKMU+aAPK2r2yrmR/jX7WU67+AbonWtFcdRZV5hTTSudPhSOa0Vw3tbRwuMYcZbQm+ONJ1Tfz5i2NRNEQcATBC5fE0IfnQ0nRJCogyh/+RkKZNVTvYsswV7Qy5AGU+0scwOPRcBEUhHgDlA4zQuf3gzP8ZttZ3W4Eu/DuUxsdNacTld4rC8VLwSua0Z43leXkuML8ZZWssPW2fzn1t/PrTuaKqIAwBMzg0op4R0PGyT5EuAiTzkC35Vz5kcVq2TunyMyTVGG6k5qn0RKJ2AxmncCIp3ON6sKWPwpZ1wXtSjOae1EWtG1o710K3TE/Zg7MWSezcwoKTxXswBAIMxpwmCeNPx6ICkJfkRYCAykediGd9iwaZc7BljR0x7Y7Y1xneVEQEROE5A4/Q4kxA54hyCanydrEG0TlzOnf7OGml5yTgliBs2xWlNraxKgDHFHmzVeiHK9zpz26P2ds27FnMAgAMMxpwmCGyiA9IRSUvyIcCBUYzT/VU8xqZVyudQNiZDjaMcIi4bRGAxgZhzwmJL6n4qzmHjG5Mva9ew3tShPTdO9JES12119Ib5XrBWZO81v0TUJweN5dZ/DwybkyjqAAAfcgRMR8zRLni1KEzYnN7m5Dsng6X1ESbZmAyJWew2Y/qntkSgFgIap2EjKb5h+cZ+F/NuC+tRHdpZu+X2IR+xw646CJfvBXMje658PJlYwhp/kirnd3EHAAzE3CYIws1JYeyXCu1KDgkwMVhrDRP2YW4eqRL7BjzzoCcrREAEciKguSFsNMQ3LN8U2hXTcdRzXCuxprTWGsVwXAxDlaJvZLf5d86y+cc2lyzqp7gDAOjmClqHAEQnjTAx5zgxQIPJgatkOQHiuLyUSoiACIiACIjAegT0nlmPW4xa29vbJtc1E2tM9Z0YveB4G+z72GMdf5I2h9bps1xLkyIPAICd6wRBB6WjltYRSraXCZmJOUcf+LZKqf0BrjkylU0iIAJpCWhuSMtfrZdHQGNmfMxYM7F2Gl8jXknWmtgXr0W1BG/2VhmS6A6r2JPmaNsym4o8AMApOkSuEwQdlQ6hCZ9IhRX6ARNy2FbW164+sD471RQBERABERABEWiPAGu7XL1mjZ+zfblyW9Uu1s/speC9at0Y5U+dOmVK7gfFHgAQXDoH1xyFvzPExrTkzpEj194mYp/zxICduX5LBdskIiACIiACIiACIpAjAdZ3Z86cydG0ziY2pdjIWrTL0C+vBNg7sYdiL+VVsUdlOzs7HrXFV1X0AQC4cp4gsI9Jgo5MWuKHADxznxjY/GOnH4+lRQREQAREQAREQATaIcAGm7VUrh6zOWUtqrWe3wjBk72TX61+tdEv/WqMr634A4DcJwhCSke2Vv+CKCw2FeINz031hKzPX01hAgvZhnSLgAjkR4Cxn59VskgE8iSg8ZJnXHKyirVU7v2ENSl25sStRFv4NkUJa3w2/zs7OyUiPmJz8QcAeMPAy32CwE6dFEJhPWFisNZm+b/4m/aI/jidp3sREAEREAEREIE2CbCxadPzzb0uYU3FIYC1tui/E755pNbXQIzZI/GtivW1hK/JXhNbjQnfVugWqjgAAFIpAdEkQbTGCxt/XpxMDONrpSvJySD2prNALYuACIiACIhA/gRSvStTtJuizfx7wDgLYcfaalzptKVY42NvKXuStLSMgZO11sAttS1j2sferlwFv6o5AGDAlTJB0G/o7NhcU2fCL18y3PjnfiLY+0z/Uzx7GrqKQHsENP7bi7k8Lo8Aa6+YVvOpYcz2amyLubUUjqxZWeNjc42x8OFTv8aHkw99MXSwxu/njhjthW6jmgMAQDHYCBDpEkSTxOwoEUc+8YfP7BL55fJiwu78LJNFIiACsQjUtDiIxUzttEsg1Tsz9jiN3V6tPYpNI2utUvxjc2ut7T7lLsXm0HYSQ8ZDaWt89paD+So0pij6qzoAgBgBIlCkS5HhJIH9pdjt004mBXy31hbzVaCh/9g/vFdaBESgTQKlvX/ajJK8Tk0g9TiJ2T5rm9S8a2m/RJbDNX4tcVjVD9bIJW788ZO54mi/I7d8qe4AgJAQqJJOCbEZYZJAsB8hr3YZTgr4XqK/uf+vKEtkKptFoFQCrczdpcZHdudBIPU4idU+m4c8iNdhBZvIUtdcrHGttU19I2C4xi/pW739aGEveWyu6B8Wfq3yAICY0OkIHOnShEkCsbbeiYL4MJGX9jWg6b7Eiwg/pvN1LwIi0C4BLfrbjb08X04gl/HB+3u5teuXYA1a6+ZhfSqb12TNFTp2m1s5X8NwfV9r/6hhjc/4xY/pSNZyX+0BAAGqIXA1TRTEg4nbWmtK3/jTv1jE4A9piQiIgAj0BFjUMT/097qKgAhMCDAuGB+Tu7S/eX9jTygrWPOE0t263tCxi8GX9T1i7eTDvtL7C/YTF2vrWOPjz4x+UE1W1QcARKnkU0Ls74VJArF2MlHk8gLt7Zt3ZQAxISA1bPp7P1k0lBKD3mZdRUAE4hFgfmCeiNeiWhKBvAkwHhgXOVmJPdjl0yY+Oaxl7emTi29dIWLn28ax+ljfs0a2drLGZ+08tm7KctjJ+t7aOjb9Pcv547cvUf61+gMAOmZtgWSiQKy1Bv+YBBmEOXRH7ECwy1p78El/iX/3Zx5PFgswn/dc+SIgAiIAAeYJ5gvSEhFomQDjgPGQIwPswj4ftrH579dAPvRJx2ICPmO3uKV4T1nfDw8D8JE+Fc+C+S1hB/ZMr/Hn1yjvCXtG/JtpeUWZ1R8AECsC6WtyR19OwsZ6OFngK4MTYaCGtBX9CG3RrrWTDT8TF3aFbDuVbvoR/qZqX+2KgAiURYD5Ym9vzzB3lGW5rBWBzQnQ7+n/Ozs7mysLqAH7sBN712mGjT8bB9ZE69RXnfUJELt147Z+q3Fqsr5HWFdba4986Be6r6EfYX2PWGu7D/Wwp+Y1Pr7Oi25N+U0cABCwmicI/OuFQcngRPoJw1p7MGnAoRcG9hjpyzMoEGutsdZ2EwFt0Bbt9jbUeuUFA4ta/ZNf4wlMj5vxNVUyVwKhY8rcwQaDTQJzCRsGH5IrzxzsCh3THHz0aYOP/tjroJ/T3+n3Pm0MHVPsxW7sHzNOKYdgF+ujknz1aWtqXcSNeKW2I3T7rLVZc7P2RqydrMfpezAYCn1yjPR10IFYO9GJfoQ2kdC+pdZP/4HFAjuqetTMAQBRI7BM1KRbEwYvk8ZQGNhjpK+DDqQ1dvjb2sSAz5JDArxEZ70Y+/Fj7eSFae3k7+8x1xzWVipHAqliSj+if9C+D2HDlSPfFDbBE77WTsZjPz77q7WTfGs1TqfjQz+Cny8hDtNtrHOPPeiydhK7Ppb91dpJvrV+Y0qbY8Yp5ZB1fBvWwU/aQ5e1E596H/urtZN8ylCWOkMdradhwlqtRQ6szfu1en/t+82ya18eHUiLXWZ7mQAAEABJREFU/Ngb0n8W+17X06YOAAgdEyeBJi0RgTEEeKG0NjGM4dJCGeJu7eTbLmNfjP3L1NrJgrQFTiX5yKLZWsW0pJgts5WY8m5noatxuoxWGc9bienQT94dY/ovZShLf+cdhZQR1fBWwoI1W/iW1EItBNgT8v5Y6k9lBZo7ACB+BJqveHHizb1EBOYR4EXCC2Xec+XXSaBflLHI2sRD6jPfbKJDdf0Q6GPKonkTjYrpJvT812V8EVM2RetqV0zXJRemXisxZW3ho+/Sf9EVJhrlaYUFa7fyLJfFMQmwB1xl8x/TthhtNXkA0INlQUgH6O91FYEhASYGXiTDPKXrJ8C8sOmibEiJjYm11qB3mK90PAKwV0zj8Y7REjG11hrGl4/20GOt1Tj1AXNNHS3FlLUFG/c1UR2rhi50HnvQaAYsWMM16r7cXkKAvR/zzfb29pKSB4+rSzR9AEA06QA6KYSEZEiAF0fLE8OQRWtpNoohfGZBEkKvdC4nECqmofQu90glQrEPpVcRW04gFHv0stZbbkGcErwL2LD7bg2d6Patt1R9rOFYy5Vqv+wOQ6Df/K+mvb7SzR8AEFImTB0CQELCxMALgxeHaLRHIGTc+YQxpP72ojXO49DMQ+sf52VbpUIzD62/rWiN8zY0c9Z54ywJWwo72KiHagXdtBFKf2l66Vf6K7+lRS2cvez11joMDGdSMs06ANhHz4RJx9i/1aVBAmz+mRh4YTTofvMuMwewSQ8JAv30sZBtSPchAcX0kEUtKcW0lkge+hErprRz2GqaFBv00C3HaCO0D771897VGt831bL0Ef9154CyPB1nrQ4ABpzoGHz6O8hSshECTAy8IBpxV27OIBBr0cQ8M6N5ZQUgoJgGgJpYpWKaOAABmo8V01jtzEMUc+6P2dY8f3PLhwlrvdzskj1hCfDhHns74r9mS1VW0wHAVFj59JevC2mSmAJT6a0mhkoDu6JbMV8M+hbAisFZs7hiuia4jKspphkHZ03TYsYUE1Me9MdsO2ZbcC1F6G9sBkuxV3ZuRoA1PmOBvd36muqsqQOAOXFlktAhwBw4lWQTX00MlQSzMDeYXwozWeYuIaCYLgFU4GPFtMCgLTE5ZUw5/F1inrfHtMX6xpvCihSxGdQHfRUFdI4r/Rp/zuPx2ZWW1AHAgsDyouCkkBOkBcX0qEACTAzEt0DTZXIAAqm/GhrApeZVKqb1dYHYMWUTVR/FvDxqJaZab+TV77CGmLAWJC2phwB7NvZuxNeHV7Xq0AHAkshyUsgpqiaJJaAKeayJoZBAVW6mNhb1BVgxrS+m8kgESibA2rVk+2PYziaRbwOwNozRntoIS4C9Gv2evZunlqpVowOAkaFlkqBjjSyuYhkSIH6aGDIMTGKT6BOJTVDzIiACIiACkQi0Mue34qePbgMr1og+dElHfAIc4IT51D++L7Fa1AHACqQ5BOCkUJPECtAyKKqJIYMgyAQRiEiAxVzE5tRUxQTUlyoOrlwTgQEBrfEHMApKsidjng7yqX9BHFY1VQcAqxJz5TVJOAgF/PQbf00MBQRLJoqACIiACIiACIhAYgKs8dlUJjZDzS8h0K/xideSoms/rrmiDgA2iC6djkmCTriBGlUNQIC4aOMfAKxUioAIiIAIiIAIiEDFBFjf6xu/eQaYPRdf94+wxs8TgCerdACwIUgmCTohG84NVam6BwJMDEzaxMWDOqkQAREokIC+Clhg0GSyCEQioPkhEugKmmEtyZpSa/w8gkkc2HPFGcN5+BzKCh0AeCKrScITyDXVsPHvTwTXVKFqjRLQi6TRwMttERABERABERhBgDU+a0w2oCOKq4hnAnDnIIY4eFY9X13lT3QA4DnAdE46KZ3Vs2qpm0FguPHXRm4GIGWJgAiIgAiIQKYEeIdnaprMEoEjBFhjssZnfY8ceaibIATgzJ4K7kEaWKC09kc6AAgUYTornZbOG6iJptWyaOA0Vl8FarobeHOe/uRN2QhFmhdGQNqwiGK6IUBVF4EKCWjurTCokV1ifY9ojR8GPO9u1vfwhXOYVpZqrb6ADgACh5jOSyfmpYMEbq569TCEpzb+1Yc6qoOM06gNqrHgBBTT4IjVgAhsTEDjdGOEUpCQAP2XNSlr04RmVNF0v/HPY31fBdKFTugAYCEefw+ZJBAmCcSf5vo19ZMCkywM6/dYHsYmwFf7YrapfhyeNjFl7gjf0qQFxXTCQb9FYBUCGqer0FLZXAkw/7NG1fp+9QjxnuYT/6w2/qu7UVwNHQBEDhmTBNJPFHT8yCYU0RxcEE0KRYSrCiPpazEc0QIhBuVJG8y1k1TY34ppWL7SXjcBjdO649uSd/Rl1vesJ/RemB/5fn0Ppxw3/vMtr+eJDgASxpKJgo7PZMFEwYBIaE7ypvEf6ScE2PDpQHLDZEATBOhr9L+QzjLOGfch25DuQwKK6SELpUQgVwIxxilzu+beXHtAfXbRp+lvrO9Z0/Lur8/L1TxiDMIC6df3cFpNS5TSTTSiA4BMwsxEwYBgsmCiYKBkYlpwM/C1nxBgoAkhOHI1MIcA/W/Oo42z6eeM840VScFKBELGFEMUUyhIRGAzAoxT5sjNtMyvjf75T/VEBMIRYE3Le4L1PWtd1vjhWstLM2ManxHGICyQvKyctqaNex0AZBhnJgoGCpMFEwWSoZlrm8SEgE9MCPiIr5oQ1sapip4J0C89qzT0eca1b73SN45AqJiG0DvOI5USgfoIMEcyV/r2TOPUN1HpW5cAa136OWtf+iVrYWRdfbnVY/wi+Ib063v8zs3WufY08kAHAJkHmokCYbJAmCgQBljmpnfmYSfCRIDgAxMCPmlC6BDpV2YE6Jf0U/qtD9PQQ59Hrw990rE6AdgrpqtzUw0RiEmAccpcyRrHR7vMvYx79PrQJx0i4JMA/ZK1MEI/ZY1M30d8thNSF2MMwXaE8YvgGxKy7VC6W9GrA4DCIs1EgTDApicMBmFKd2gfYfJiIkCwE2EiQFLap7ZFYBUC9Fv68ip1hmUZC/0YGOYrnY6AYpqOvVoWgbEEWONo7h1LS+VqIcAamb6PsL5HGAe9sKZI5Stt94I9rG2wj3cqgu1IKvs8ttuMKh0AFB5qBhyTBcIgZEAiDE6EgYr0A7e/ruJ2X2d4RSf6EdpDaB/BFuxCVmlHZUUgNwL0Zfo2/R1ZZl8/RhgXjAWNgWXE4j9XTOMzV4sisCoBjdNVial8jQQYB72wpmA9grDGYE3SS7/26K9jWfTlh1d0or8X2qPtXrCn3rXNWHLll9MBQPkxnOkBgxNhoCL9wO2vDOix0tcZXtGJfmSmAcoUgTUInD592lhrNxL6JEIfRdYw41gV9CDLxkw/Rmj/mJJGMxTT+gJ/9uzZjcaoteuN8RQkT548Gd3X024eTOFrjm0y7yKae3OMjmxKRYA1BuOil37t0V+XjZf+eV9+eEUn+ntJ5WOSdhtqVAcADQVbropACwTYnCAsohFrreGF1oLvtfpIPBHiiVirmNYaa/klAiIgAiIgAikItNSmDgBairZ8FYFGCWjTWF/gFdP6YiqPREAEREAERCARgaaa1QFAU+GWsyLQNgE2jfo2QF19QDGtK57yRgREQAREQATiE2irRR0AtBVveSsCzRPQhrG+LqCY1hdTeSQCIiACIiAC0Qg01pAOABoLuNwVAREwhg0j/+iNWNRDgJjq2x31xFOeiIAIiIAIiEAsAq21owOA1iIuf0VABDoC/OveXUK/qiHAIUA1zsgRERABERABERCBGASaa0MHAM2FXA6LgAj0BPSJcU+inqtiWk8s5YkIiIAIiIAIhCfQXgs6AGgv5vJYBERgn4A+Md4HUdFFMa0omHJFBERABERABEITaFC/DgAaDLpcFgEROCSgfwvgkEUtKcW0lkjKDxEQAREQAREIS6BF7ToAaDHq8lkEROCAgL4yfoCimoRiWk0o5YgIiIAIiIAIhCTQpG4dADQZdjktAiIgAiIgAiIgAiIgAiIgAi0TaNN3HQC0GXd5LQIiIAIiIAIiIAIiIAIiIALtEmjUcx0ANBp4uS0CIiACIiACIiACIiACIiACrRJo1W8dALQaefktAiIgAiIgAiIgAiIgAiIgAm0SaNZrHQA0G3o5LgIiIAIiIAIiIAIiIAIiIAItEmjXZx0AtBt7eS4CIiACIiACIiACZnt7WxREQAREoC0CDXurA4CGgy/XRUAE2iKgRX5b8Za3IiACIiACIiACswm0nKsDgJajL99FQAREoEICOuioMKhySQREQAREQAT8EWhakw4Amg6/nBcBEWiJgDbGLUVbvorAeAKaG8azUkkREIEaCLTtgw4A2o6/vBcBEWiIQCuL/J2dnYaiKldFYHMCrcwNm5OSBhEQgSoINO6EDgAa7wByXwREoC0Cp06dqtrh2v2rOnhyLgkBjZkk2NWoCIhAQgKtN60DgNZ7gPwXARFoioA+HW8q3HJWBJYS0JywFJEKiIAI1EWgeW90ANB8FxAAERCB1gjU+okffmkz01pvlr+bEGDMbFJfdUVABESgPAKyWAcA6gMiIAIi0BgBNsnnn39+VV7jD35V5ZScEYGABNj8a8wEBCzVIiACeRKQVUYHAOoEIiACItAggd3dXcOmuRbXd3Z2anFFfohAcAKMfY2Z4JjVgAiIQIYEZJLRAYA6gQiIgAi0SoBDAD4FLNl/NjJ7e3tG/4p5yVGU7TEJMOYZ+zHbVFsiIAIikAkBmeEI6BsADoJ+REAERKBVAnwKyIagRP+xWxuZEiMnm1MQ4LDszJkzhjGfon21KQIiIALpCcgCCOgAAAoSERABEWiYABsCPkVnQ43kjKLfxGAvdudsq2wTgRwI9GOGwzJ9UyaHiMgGERCBZATUcEdABwAdhsNfvCBZVCK8KCXb3Vdrt7e3dfXEgL7Vy2HPU0oE0hPo+yWbaz4pzE2wizl6241FH7TQheA3OkuUs2fP+kCxko5+Q5lb/whhD76uBMdDYQ7hfPmiMbOdxdqFecZD11hJBXPDtpsrJdtL+wDvgF5SxGqlwGZaGG5Iz3F70Pf6PK6pzVf7EwI6AHAc6LB0VGutOXnypDl9+nQnTJ6Ss0YM/DLo+xdXa233YtKk6AaifrIiwJyYm/gC1M/5zPcIY7HUec4Xk1X15NY3QtmzKhdf5X3548se3lHYxHhBSh4zqca6r1isoieVr6W1S3/uhf5trTX0+VVYt1p21vsUlsM+wH0v1lpjbTK+rYbpmN/NHwAwwBnsdNRjdJQhAhEI0PeYGK3VhBgBt5pomMBwocK4axiFXBeBUQRYI1lrDz4UGVVJhUSgAgJaly0O4qbv0zR8F/vU0tOmDwA4zaYDthRw+Zo3AfojC668rZR1IlAeAcaVDnvLi5ssTkeAMcM7KZ0FalkE0hNgDDAW0luSjwXw8PU+jco3H4TJLWn2AIDNvz4BSt7/ZMAMApoMZ0BRljhHptMAABAASURBVAhsQIDFCuNqAxWqKgJNEWCNpDHTVMjl7AICjAXGxIIizTwK8T6FL3pDQ5T+QwJNHgDQybT5P+wESuVHQJNhfjGRRWUSYL5nPJVpvawWgfgEGDNaI8XnrhbzJsCYaP0QgLkh1PsUvegP2AukekCguQMAOhedbMBASRHIkgD9lL9jlaVxMkoECiHAOCrEVJkpAskJaI2UPAQyIGMCHAIwRjI2Mahpod+n6A+37g2KpjjlzR0A0LmKi5IMbpZAyy+aZoMux70R0PjxhlKKGiGgNVIjgZabaxNodYzEep8Ga2ftiNdZsakDAHWqOjtxzV5x2qzT0JojLN9CEmh1oRaSqXTXS0BrpHpjK8/8EmhxrMR6n4Za9/rtAeVra+oAQBup8jusPBABERCBMQRaXKCN4aIyIiACIiACmxFobT8R+30aoL3NAl5h7aYOADhVqjCGcqlyApoIKw+w3AtCoLUFWhCIUtoUgVif8DUFVc5WSYD9hN4xJYVWtk4TaOYAQAN1OvS6L4UAL5pSbJWdIpALAY2bXCIhO0ogoDVSCVGSjSKQhkDs+cH7+zsNtqxb1QFA1uGRcSIgAiIgAiIgAiIgAiIgAiKQhkCKDbnPQ4c01PJutZkDgLzDIOtEQAREQAR8EdDCwRdJ6REBERABEZhFQO+ZWVSyzJNRMwjoAGAGFGWJgAiIgAiIgAiIgAiIgAiIgAiUTEC2zyKgA4BZVJQnAiIgAiIgAiIgAiIgAiIgAiJQLgFZPpOADgBmYlGmCIiACIiACIjALALb29uzspUnAiIgAiIgAlkRkDGzCTRzAKAFy+wOoFwREAERqI2A5vvaItqWP+q/bcVb3oqACAQjIMVzCDRzADDHf2WLgAjMIdDKIrQVP+eEWdkiIAIiIAIiIAIrEtDaYUVgSYqr0XkEdAAwj4zyRSATAqdOnUpiiV5uSbCrUU8Ezj//fE+apGaaQEtzQwpfW2lzul/pXgRKIpBinJbEJwtbZcRcAs0cADBQtSCc2w/0QASOEWDMHMusMKMVPysM3UKXFNeFeDZ62BLb2L6mXKekbHujDqnKIhCZgMZKZOBrNqdq8wk0cwAAgtgvctqUiMCmBHZ2djZVsXb9Fl5ymhfW7h5ZV1Rcw4Qn1TeSwnizXCv9KOY8SHvLrQpTIuW7JoxH0ioCYQikHKdhPKpSq5xaQKCpAwC93Bb0BD3KkkDqxXbtYyY13yw7XSVGsUCLuXGrBNtSN2qfE2YBiOlzzLamfdWYmSaiexGYTSDlOJ1tkXKPE1DOIgJNHQAAQgt+KEhKIZD6JVPzgpDNYWq+pfTDUu1UfP1GrtX3Z6x5MAe+GjN+x4y01Ucgh3FaH9UAHknlQgLNHQDwcmPhv5CKHopABgRyecns7u6aGsfMzs5OBlGWCSEJsHHLZRyF9DOGbuaAlsdMaN/pp6HbGNNPNGbGUFKZVgnkMk5b5b+K3yq7mEBzBwDgqHVDg2+SOgjk9pLJYWHqM7LwZaHrU6d05UmAvku887SuHKvgWI61/i1lvjhz5ox/xU5jbocrxBqbnGn6EQER2CfAmGBs7N/qkjcBWbeEQJMHADDRIQAUJDkSYLOS20sm5OI3dgxYxOfGNzaD1toj3oyr1vz24S+LXsYMc4APfSXrgIHvfgRf1iO5ccEm377m5qPsEYGxBHIdp2Ptb6+cPF5GoNkDAMDoBQcFSS4EeMGw0GazkotNQztY/O7t7ZlSF4U9X/wY+qV0GwR2dnaK7bupIsSY4T2pMXMYAfoR87SPeRAd8D3UnlcKX7ExL6tkjQjEJcAYyHmcxqVRSGsycymBpg8AoMMLruRNDT5IyibAIpsFJS+YEhbajBns5aVYAvnS+JbAtFQb6bua75dHbzhmlpdurwTzNH2JORBZlQB16IfoWLVu7PLYiK3YHLtttScCKQn08yBjIKUdant1AqqxnEDzBwA9IgY4L7l+Y8PLDmEC2ER6/bVfN2G0bt1UTNe1d1iPvkVfQ3xu/NG1THxw6xfAjBl8GcrQzxTp3hbYYh88sNeH3+jKUXz4loOOZWx92djP9/SPvr9w3bS/+rJvFT2b2kx9fEdCjJlVfPFVNmY/6vsS/HqB6VD6/J4vdUr0lfGCD70/XId+Kn1+9w/mzuLgK96r6plli/Jmx4n+jNDH6evMI7WvHfBxjKza73yUH2PXnDImh3wfDELq0AHAFN3t7W3Dy7mXTToROkwjf/B1E1br1GWijo2XF+c6tk7XgRd9DfHhA3qQkydPmmVirT3o4z7axpehTPsa+763BR4+/MN+dCHL2KZ6bq3fmPrgNlZHz9daO6rvEgdiPFb/snLo6gVbNpFlbYV4ju2b2ExddCCwDWFjDJ34gf3IsnForTXWTsaML9vg1wu2DKXPxzYf7aEbXdaOGzN9+z7apt1eH1dskeya3d3dhVLyemV3iW+1PN/Z2enWRtvb2z6GioHL9vZ2N9csm5Nyf+4FyIpKTp8+vXRNMJvb8nVwjHrWWkP8d1y/WtH1KMV1ABAFsxoRgTAEmFistebs2bOdjG3ltJtYEerzkhpbr6VycGHy5kWxKt8UnIgnUkpMp/mOZUYs8NNavxu4se2rXF4EpvsR/WOshaX1o2lfV/GzNF/H+qZyIpAbgXXHaW5+FGtPRobzPsp17tUBQEYdRaaIwFgC/QuGiWVsnVnlqM8Gl03jrOet5sEXLkzepTEoIab0Nx988ZVDmtJiJHv9EPA1TulH1uZ9oORzzKDLTwSkRQREYEiAseXj3TbUqfRqBHItzXuG/pGLfToAyCUSskMERhLwtegdNpfbxDS0LXaaCZoXeOx2fbeXa0zhi22+/OWQxlprGBe+dEpP/gToR77HKf0Svbl5v729bbDNePqDLnR6Uic1IiACjgBjirHlkvpJRyDrlukf9JMcjNQBQA5RkA0isAIB34vevmkmphwXv719Ma5sIuEQo60YbeBLTjHFFmwK4Tu6Q+iVzvwIhByn9E/05+I1/ZpDLt/2oDOXhahv36RPBGITCDVOY/tRfnv5e5DL3KsDgPz7iiwUgQMCvGQObgIkclv8BnBxocpQhysLGw38MJeY0nexJZS7ubxUQ/knvYcEQo/T0PoPPVmcijFmaGOxFXoqAiKwiABjKOS7bVHbejZFoJBb1iv0m5Tm6gAgJX21LQIrEGCyiPGSoZ0VzKqmaM1+1+zbsAPyUs3p09uhbUr7IRCrL8dqZxGVGPN9jDYW+ahnIlA6AY2hfCJYkiX0m5TrFR0AlNRbZGvTBJgsYgBodRMVi2+MGE63kTqmbKZi8aWtaf91Xw+BWP0oVjvzIhOzH8dsa56/yheBEglo7GQVteKMSdl/dABQXHeRwS0SiH1KmHJSShHfFvxtwUf6TurDDmyQhCEQuw/HnneH1GIeQMRsa+ij0iJQOoGUc0Tp7PzbX55G1iuprNYBQCryalcEViCgl8wKsFQ0OwLaYGQXEhk0gkDsA4fepBTzfYo2e391FYFSCaTcwJXKLJjdhSpONffqAKDQDiOz2yIQe4LgpRa7zZQRbWGDmiqmKfpRqo1byj7cQtuxxyljJgXXFGMmRZsp2KpNEfBFQO8ZXyT96ClVS6q5VwcApfYY2S0CIiACIiACIiACIiACIiACbRMo1nsdABQbOhkuAuEJpPokKrxn6VtINfmm9zyOBeIbh7NaCUOglf7bip9heom0ioAIpCWg1lcloG8ArEpM5UVABERABERABERABERABERABNITkAUrE9ABwMrIVEEEREAEREAEREAEREAEREAERCA1AbW/OgEdAKzOTDVEQAREQAREQAREQAREQAREQATSElDraxDQAcAa0FRFBESgHgLb29v1OJOhJ+KbYVBk0mgCrfTfVvwcHfgKCiqmFQRRLowgoCLrENABwDrUVEcEREAEREAEREAEREAEREAERCAdgcJbTnVQpwOAwjtOLuan6sC5+C87yiZw/vnnl+2ArD9CQPPRERzV3LQyTtV/q+myB44opgcolBABrwSkbD0COgBYj5tqDQicOnVqcKekCIiACBwSYOHbysbt0GulaiCQ6t3GmInNb2dnJ3aTTbWnmDYVbjkbj0DxLaWYG4CmAwAoSERABJomoMVvXeFXPOuKZ+9NS3GNeWgWs60+li1eY3KO2VaLsZTPuRAo3w4dAJQfw2Y9aGlR1myQK3ecCVgLpnBB3t3dDad8SnOqT22nzNBtAAIxxyn9aGdnJ4AX41TGbBuu46xSqU0IKKab0FNdEZhBoPAs3jOpXNA3AFKRr6TdlJ23EoRyIxMCMRdnmbgc1YxYc4XiGDWs0RtrJb5symMcSjIuW2EavbNONRgrpjSrmEJBUjuB0v1LOU51AFB670lovxYOCeGrae8EWJzRp70rlsKOAC+60Bsaxa9DXfWvGOOUfkR/TQ0yhg3wTO1nS+3HiOmZM2daQipf2yVQtOepx6kOAIruPmmNj/EiS+uhWm+NAH069Ca1NaZDf+E7vPeZzmXT5tMn6ZpNgH4UapyiF/2zW46by+Y85CKRMUMbcb1quzV4K6Zt9wF574tAuXpymHt1AFBu/0lmOQukkC+wZI6pYRFwBPj76vRxl9SPZwKhFr+8THPZtHlGJnVzCDBOifucx2tlM+7Ru1blQJUYM779xFR0asxAIr4opvGZq8UKCRTqUi5zrw4ACu1AqczuF0i8wFLZoHZFIDQBNgFM0qHbaVE/c8fe3p7xxRc9Ozs7LaJs3mfiTvx9gEAP496HLt868NPXoTvvcHSh07ed0jeeAPyJA/EYX2t2SXSgC52zSyhXBOojUKJHOY1THQCU2IMS2Ny/YHJdICVAoiYrJ8BiyudGtXJcK7sHXzZdzC0rV3YVqEt80ONu9dMoAeJPP6A/rIOA/pfTomyeDz4OzvCTdzi65rWj/HgEiAPxWLfvYil10YEu7iUi0AiBotxknPKeymmc6gCgqC4Ux1gWRL2wYED0gonDXq3kR2C4wWASZ2zkZ2WZFsGWuYU5pmc7iy95vVCWFyl1y/RaVocgQH+gX9CPkL6/DNvq87jSjxD6X06LsqG9s9K9n9g+z0/q4WMvlIVNSX7iQyuySUyp2won+SkChwTyTfXzLtd+7s1xnOoAYL8PsQhAeEFaa421m8vJkyf3tce98KLfRODQCzyQuB7k29rZs2e99A1rV+tf+RJpxzImcISxscn46uumIMecZO1qfc/a2eVhgfjwgzkGXbBFekb9lbxeKOujTfShC7F2to/Wrpbvw65VdfiMqbWr+Wvt5uXh38d+Vd9nlUcXQnyRvg9x5b4X2kVm6SghD9vn+TnL1xJ8at1GxTRcD2DcM15gbO3m85a11pw+fTqcwZlpZk7JSvb2TK720Nd6ob9lFsoDc3QA4FAwKbCIQtjguSz9iIAIiIAILCDA4gex1hrm0AVFs3rEi5mXcj/fa85PGx7404+IB/0ISWuRWhcBEaiFwHDAVKcmAAAQAElEQVS+Z55hvqnFt5b9kO+bE2j6AICJwVrb1Cne5l1GGkRABETgKAEWVtba7A8Chhv/ox7oLgcC9CNEhwA5REM2iEDZBJhHOFjUpr/sOM6wXlkeCDR7ANBPDB4YSoUIiIAIiIAjkOvmjcNeNv9aCLogFfCTaz8qAJ1MFAERcASY75lHXFI/1RGQQz4INHkAwOZfE4OP7iMdIiACInCUAHMrc+zR3LR3+hQoLf91WqcfsYhfp67qiIAItEuA948OeyuOv1zzQqC5AwA+CWJh4YWelIiACIiACBwjwBzLXHvsQYIMbSITQPfUJIt4FvOe1EmNCIhA5QSYL3j/VO5m0+7JeT8EmjwA8INOWkRABERABOYRYCE271msfGxgExmrPbXjnwCL+VwOk/x7J40iIAI+CTBf+NQnXdkRkEGeCDR1AMBiUJODp54jNSIgAiKwgAAb79QbN833CwJU0CPe3QWZK1NFQAQSENA8kQB69CbVoC8CTR0A+IImPSIgAiIgAssJpFyQpWx7ORmVWIUAh0mrlFdZERCB9gjowLeBmMtFbwSaOgDQ5OCt30iRCIiACCwloI3bUkQqMJJA6m+TjDRTxURABBIQ0IFvAugJmlST/gg0cwCgxYO/TiNNIiACIjCWQKq5Vwe+YyNURjkt8MuIk6wUAREQgUAEpNYjAR0AeIQpVSIgAiIgAkcJpDoAOGqF7kRABERABGoloPdMrZEd+qW0TwLNHAD4hCZdIiACIiACIiACIiACIiACIiACEQioCa8EdADgFaeUiYAIiIAIpCagT4NSR8B/+/r3JPwzlUYREAERKIWA7PRLQAcAfnlKmwiIgAiIgAiIgAiIgAiIgAiIgB8C0uKZgA4APAOVOhEQAREQAREQAREQAREQAREQAR8EpMM3AR0A+CYqfSIgAiIwgsD5558/opSKrENge3t7nWqqkzEBjZeMgyPTREAERCAkAen2TqCZAwAtCL33HSkUAREQAREQAREQAREQAREQgWAEpNg/gWYOAPyjk0YREAEREAEREIEYBHSIH4Oy2hCBMglofigzbiOtVrEABJo5ANDkEKD3SKUIiMDaBHZ2dtauW1LFVH7qK+Ml9RLZKgIiIALrE9Aaf312+deUhSEINHMAADwtCKEgEQEREIE4BFLOuakOHuKQba8VxbO9mMtjERhLQAcAY0kVWE4mByHQ1AGAFhBB+pCUioAIrEGABUvKDfIaJq9cBR9XruSpAm3XztcTquzVnDp1KnsbZaAIiEBaAprv0/IP1br0hiHQ1AGAFoRhOpG0ioAIrEeg9kPJ1P6lbn+9XqFa0wQUx2kiuhcBEZgmoHlimkgV93IiEIGmDgBgqAkCChIREIEcCHAoWeunmzn4BV99KpRDT1/fhhz60frWq6YIiEAsAsz3mi9i0Y7VjtoJRaC5AwBNEKG6kvSKgAisQ4BDydo2qSzC8GsdHr7r7O7u+lYpfZEI5NSPIrmsZkRABDYgsLOzY2p7n26Ao/yq8iAYgeYOACDJBMHCgrREBERABFITYJNay6KFuZU5NjXTYftnzpwZ3ipdAAHGQ279qABsMlEEmifA+5T3UPMgKgAgF8IRaPIAAJwsLDRBQEIiAiKQA4EaFi3MqcytOfAc2sA3v/b29vTJ0BBKxmn6EeMhYxNlmgiIQMYEeA8xj2RsokxbTkAlAhJo9gAApkwQLAo1SUBDIgIikJoAc1KJ8xGf1vIpO/anZriofTaVJfJd5FNNz0rpRzUxly8iUCsB3kfM90itPtbtl7wLSaDpA4AeLJNEfxDAAqTP11UEREAEYhMYzkc5L1yYK7GPjT8baz5lj81qnfZK4buObyXWoR8hpfWjElnLZhFojQDzPcK7CmnN/6L9lfFBCWR7AMCCkkHLonKRUMYXIXTRLocBCAuSTUSTzdHIwBbGi+K5yjP0HW0h/F2/UN2kX6xTN7xnx1vwGatV4uqrLPan6CPHSa6Xg/0Ic1Ev6/Qd33V6W2CLfcRrPQ/T1sJ2pPeHq29W0nfGzGMAb4R+hJTaj9L2YrUeikDfJ+mX84T5AwllQwy9+InM8zFlPmwRHxzQgzDn9DJvbso5P9W+wlc/IAbImJjmWobxgixjgp+Uy9WP7A4AgGWtNSdPnjSnT582Z8+eXSinXRlrrbHWGmD7BL0suGOe+7SnVF3EFFZjY7os5sPnKZjgS2xJ4eeQc4lp5gb6nLX+54YU8aDN2P1uVnvYUavM8ld522Z7e9u71NqH5FfZBFhHWjtZgy577/GOQaydvGOoW4r3w3UZ78llvqZ4DlvE2glf32y3A8xrMXT65jBGn6/4E0/E2qUxHWNW1DKrjhn8ZGxZm6ev2RwADMGuG1FglzQBr+tnKfWGMWXyKMVu2VkfAeYGa/OchOujLY9EQAREoCwCrFestd0HT+tYzjsGKWENio1sTEpal8HWWmuwfZ34qE5+BBbHNC97OdjZZMz0vjLP5OJZFgcADOhNwA5h5gh5aF8raZ8xbYWZ/AxPgPmBvhm+JbUgAiIgAiJQAgHeCaxBfdjKO8Zaa3Ja6Pd+YdP29vbahxwmgz/wJV4ZmCITPBEgpvTLI+oyuWHMWGu7b6L7MIl5Jpf+m/wAABAE3wfYoQ4gE7hhntJxCISKaRzr1UrtBJhv6KO1+yn/REAEREAEFhPgXcA7YXGp1Z/muAbFppI+9Z9HnXjlumGcZ7PyFxOgXw5jurh0nKfsIRkzvluj/zLv+Na7qr6kBwDABcSqRo8tnwPgsbbWUi50TGvhJD/SEmDeoa+mtUKti4AIiIAIpCLAGpF3Qaj20R9K96p6c7JlVdtnlWfDWJtPs/xsKW8Q0yzcDrH57x1j3km9Bk16ABASLpDpTLmdKGFXzRI6pjWzk29xCaivxuWt1kRABEQgJwIswkPawxo0h00qNoT2NSTHebrxKfUmap5tyl+PwCSmu+tV9lhrZ2fHo7bZqmK0MbvlSW6yA4BYjjMBa4KYBDv071gxDe2H9LdDQH22nVjLUxEQARHoCcSa+3PY0GBD73dt11hxrI1bzv7s7OwkNy/GmEm9P012ABADbt+DNEH0JMJeddASlq+0+ycQcx7yb700ioAIiIAIrEMg5tyfcg2asu114rJqndSbqFXtVfnlBFLHNOaYidnWNPlkBwDThoS8pzOF1C/dEwLiPOGg32UR0MFVWfGStSIgAiKwCQHN+ZvQy69uyk1UfjSKt6hzIGVMYx4Osm9KNR8lOQBIEdhUgLue3MCvFDFtAKtcjEBAc0MEyGpCBERABDIhEHvOT7nIj7mZySS8MqNoAhPjGTOTVNzfseeGuN4dbS3JAcBRE3QnAiIgAukItDThp6OslkVABEQgDwKtzPmt+Jlqs5hHb67MisTupBgzKdoEc5IDgBTOpmgTwBIREAEREAEREAEREAEREIEwBLTGD8M1ttZhe63ENJWfSQ4AhgFWug4CqTpwHfTkhQiIgAiIgAiIQK0EtEaqNbLyyyMBqYpIQAcAEWGrKREQAREQAREQAREQAREQAREQgSEBpWMS0AFATNpqSwREQAREQAREQAREQAREQARE4JCAUlEJ6AAgKm41JgIiIAIiIAJ+CNz07vebx/7wL5m/9dd/IqrQ5o3vep8fJ6RFBERABESgeQICEJeADgDi8lZrIiACIiACIrCQwPXX3Wguu+TypfKKl+6aN+xeZd549q1R5fVnrjS0PcZGfFnorB6KgAiIwIYEtre3N9Sg6okJNNt8qr6b5AAghbMp2my2N1fsuPpRfcFVTOuLaekePefpF7lP9v/1UvlPO08wt9/+meju3nHHneY/n/6DpfY99of/tXn20y6Mbp8aFAEREIEaCdS7XskjWi3x1QFAHn1OVoiACIiACDRC4IbrbzI/+/gd8/gf/ZWZcubyK8z9959bKufOnUtGjLbH2Lj7uitn+ojvMNA3BJKFUA1XToDNzPnnn1+5l8a04OMwiFX6O3RQ6SgEmjgA0GCJ0peaaGRnZ6cJP1tyUjFtKdpxfb3t458yr3jpWfPyS8+Yl192KJddfLm58EWvMC/+n7PlA+/7SFxDA7aGL/P8JB8WHR8YIY7TKx0z2AU0S6pFQAQqIcBBRyWuNOtGLo7Tl2LvGVOtQZMcABDomIAJKG1KRGATAqdOndqkuupmSEAxzTAoFZl0zdXvNI//sV8xj/2RXzKP/eFD+d3/+nRz9133VOTpeq7cc/c95n/89jNMxwdGiOP0uB/9N+aat75jPaWqJQIicEAg1ebiwIAIiRZ8HGKs0N+he8nTMfeMKdegyQ4AYnbgmG0l77kyQAREQAREIAmBpz7xheanHvvvD+RJv/dc86Uv3mXuuefeI3LfffcnsS/HRmExzeeuL91tnvT7zzvgCFPY7u3t5eiCbBKBbAmwmYn5gVtsECk3ULF97durL6a9Z3lc2TPGGjO0lcrrZAcAdOAYAzdGG6mCp3bjEaAfpRyo8TxtpyXFtJ1Yh/D0Yx/9hHnly15/RC5+8avNi57/0gN54+uvNvxd+RDt16wTZrAbsrzogleZV738DUd4E4OaOcg3EfBBoOa1S82+LYp9VX4vcjTRsxh8WYMmcq9rNtkBAK0DOOQpC3Bpg7YkIrAuAfqo+tG69PKsp5jmGZeSrLrqiuuOfnX9R37JvPXK650LVmL8M7j6qhuO8b7yLdc51voRARFYRCDWB26LbAjxjDV+CL0l6KwppjnyDs03hzVo0gMAgr67u8vFu+QA17tTUpiEwM7OTpJ21Wg4AoppOLY1auYr6k/+/eebn/mJnQN52pNeZPiq+lD4V/Fr9D8Hn2A7ZE36aU/6nwfxIDbEiFjlYK9sEIGcCPDOq2nDjC/4lBPj2LbgPxxit+u5vWzVwZe9pG8D0Rlq77uKrckPADCWv9cHENI+hAGRA1wfvkhHOgL0SfomJ4HprFDLPgkQ0zNnzhjF1CfVOnWx4bz2mneZ17zyjea1r3qjufBFrzQveM6lB/KmN7ytTscL8urNb7zmIB7E5sIXvaqLFzEjdsSwIHdkqggEJcCGhvVx0EYiKMcHfInQVPZNwAEe2Rs618C8H7CX9MmXNSg6c/A6iwMAQABkU8iAZXHPgECnRATWJUBfpE+uW1/18iPQx1Sb//xik6NF/Av1v/Nf+Bfqf9n85I//e3Pd29+do5myaUDgure/y8Xq35nH/sgvm//+W083d9919+CpkiIgAqyPeRcipdHQGn92xIgpe58SY2pmu5RVLnx9sEVHTvuKbA4AiDaQ+cQVSAx08sYIZen8gNXifgwxlZlFgH5E36MP0hdnlVFeWQQU07Lildpavlb+pN9/vvm5n/pV8ws/9+vmmqvfYb7w+S92wr9Wn9o+tb+YADH64he+1MXr7W97VxdDYvnE33te99c1FtfWUxFogwDrG4T1DpK717zHtcZfHCX2PiXFtPemlCts2RswXuiPY+2mLH2XuugYWy9GvK9oOgAAEABJREFUuawOAHqHgcRmHmCAA/i0kI9QhrJ0/r5+61f4xZazZ89Gx87Amu4Xq97Th3qhH8HNhyPoQtDnQ3zYtKoOH3xXjYeP8n08ufYxWNX3eeV7fYtiOq+u8vMjcOstt5nXveYtB3L5a95sLnjBy81zn3mJeeFzLzM8z89qWTSGwK23fNz8z+e9tIslMSW2w1jf6mI/Ro/K5EFgd3fX7OzseJEU65U8KB61YmefJ+to3peIj3fwpjqwoxdsI/Ylr/GxH+l5z7ry/Gh01rvrdcOtZ7hpPKi/njVLay0sAJPen02v6FrY2MiH2IGuRXx77pShbK59N8sDgGEcAAfwaSEfGZZVekLg9OnTJrZMWo77m/hP94tV79HRiw/r+8F+8uRJg/iKgw/bVtWxKstcyvfx5Lqqz7PK9zG11o6KqbW2+zcG4DFLn/LyIXD2dVeax/7ILx3ITz/uP5h3XH9TPgbKEi8E3nnDzYbYDmO9e/kVXnRLSTgCq869Y9+34SwuVzPvS4T3VmrBjl7KJWpM7wNrQWRR/+S5tbY74PLlc9++j3j6sumonsV3i3it+iwm3577Yu/SP83+ACA9IlkgAssJ9AsVJhl9urCcVwklNokpfYAXlLXWoKcEf1ux8Y2vv9r8y5/5T50871kvMZ+98wsH8rnPftHcd985h8L//8bOBPhf40nnuDgRU2I7jPXzn31p1wfoC296vf5BR5PRH+bM7e3t7sD17NmzGVkmU0RgOQE23NZaQ99Fltc4LHHafYBnrd+DgEPtmaUSmCO+h9B1AHDIQikRWIsAk702/muhy7aSz5jSN9CXrbONGMb/Hu66t7/bvOzSM+ZZT7uokyvefG0j3svNaQLEvu8Hl73kdd0/8kgfmS6n+7gEmCuZM1fdOMW1Uq2JwGwC2+7gik3m7Kfjc9GBLg7Dxtcqq2RKa+HLXJPShtRt6wAgdQTUftEEmECYSIp2QsYfIRAipvQR9B5pSDdRCXzus583v/lrTzbPecYlUdtVY/kT4N98+I3/+CTz2Ts/l7+xFVvIHMlcWbGLcq1iAmzYfR5coYvDsEoPAZL3BOYaYpbckEQG6AAgEXg1Wz4BLVbKj+G0ByFjystGL/Jp4mHvP3vn580f/O5zzS/+3K+bU//md8z1b7/R3PXFu/RlfId93JfnTROs6BP0jZ1f+d2urzzhd55j7vyMDgNMxD8h596IbqipRgnQf9mwh3Af3SH0ptWZR+vErNVDAB0A5NEHZUWBBNjQFWi2TF5AIHRMdZq/AL6nR/fcfY+5/tobzRvPXm12X3dF96/5P+MpL3bXl5qPf+yTnlqRmtoI3PbxT3V9ZNJXLnN958quD/HXRu6+6+7a3M3On9Bzb3YOy6BqCOzs7HT/8HYoh6rcpIaCtYZe+O64GK5RtegqOgAoOnwyPhWBFieLVKxjtRsrprHaicUtt3Zuv/0z5j/v/IF57A//svmFn/nP5j03fTA3E2VP5gTee/OHzC/+7H/u+hB96Y477szc4rLN05xYdvxatz7G4RWb1Jq+QZhbn4kRw9x81gFAbhGRPdkTYBJucbLIPjAbGhgrpnqRbxioGdU//enPGr62/cv/8rfc5v+J5vprbzK3f+oz5o47Pmvuvfd+V0NfeDdNfJnfT5zpM/Qd+tAN191s/tOpPzC/9C9+s+tjOgww3v/Emnu9Gy6FzROIeXgVs63Agc1SfWt8dQCQZTeUUTkT4AAgZ/tk2+oEWpv4VyeUb42P3voJc/Z1V5rnPetS89Qnvsi84DmXmU/cdnu+BsuyogjQl1743Jeapz3pgq6P0dduveW2onzI2VjNvTlHR7YtIxDz8IoPD5bZU8bzPK1sbW2vA4A8+6GsyphAa5NExqHwZlrsmGrR6y105hWX7Zpf+vnfMh9430f8KZUmEZhBgD72y//iv5hXvvTsjKfKEgERaIlA7HUDbFO0SbteJVNlHLC0xFcHAJl2RJmVLwEmiXytk2XrEIgd09jtrcMk5zpnX3eV+be/+NudXPziV5vbb/+0ufe++4y+5W6MGBgTigF9jL520QWv6voefXD38iuN/qxPIOYnqOtbqZoicJxAis1iijaPe75ZjmrnQUAHAHnEQVaIgAiIgAgsIXDXl+4277j+ZnPpxa81T37CCzq54s3XLqmlxyLgl8CVb7mu63v0wcsuubzrk/RNv61ImwiIgAgcJVDBAcBRh3SXjIAOAJKhV8MlEtDkW2LUFtusmC7mk9NT/ldtv/rvfs9cfMGrczJLtjRMgL54+t/9D/0vJhvuA3JdBERgLIG8y7W0HtQBQN59UdaJgAiIgAg4Anzt/7d/82nm+utuMp/97Oddjn5EID0B+iL/1wn6pv46QPp4yAIREIGMCci0bAjoACCbUMgQERABERCBIQH+hf+rr7rBIJdefLl5/rMvNZ/65B3DIkqLQHICt3/q093/feJS10fpqwh9N7lhMkAEREAEMiIgU/IhoAOAfGIhS0RABERABAYELrvkdeZx/+TfdnLJi1/jnlhJqH/hTno37lsvufC1XV+lz3IY4BTqRwREQAREYEJAvzMioAOAjIIhU0RABERABIz55CfuMH/wu881l170WvORD3+skzvv/JzQiEDWBOijfX+l7z7hd55rPnHb7VnbLONEQAREIA4BtZITAR0A5BQN2ZI9ge3t7extlIEiUDKBj330E+aNr3+bedpTXmz419ZL9kW2t0vgqiuuN09/ygXmzW+4xnzso59sF4Q8FwERKJ7A+eefv7kPBWhoaY2vA4ACOqRMnE0g1UBtZSKcTV25IhCWwEsuutyc+je/Yz526yfCNiTtIhCYABv//+D68iUX8tdXAjdWqHq9TwsNnMwWgRUJlFA81b4iBRsdAKSgrja9EGhpoHoBJiUikCmBM6+9wvzH//CETi67+HLDP6B2zz33ZmqtzBKBcQTow/Tll17yuq5v08df99q3jKvcSKmdnZ1GPJWbIlAuAQ/jtFznK7VcBwCVBrZ2t06dOpXMRU2EydCr4coIfOmLd5kb3/1+85KLXmt+978+sxN97b+yIMud7q+y9P2bfyiQPk/fFxoREAERaINA/l6m3FekoKMDgBTU1ebGBFJuwvnmgb62uHEIpUAEzIc/9DHz737xv5mXv2TXWP0nAg0QeMWlZ82//YXfNh/60Ec1AzgCep86CPoRgcwJbDxOM/cP83Z2drg0IzoAaCbU9TiawyldaxNFPb1HnuRC4MxrrzRP/L3nmevffqP59Kc/m4tZskMEghKgr9Pnn/R7zze7bgwEbawQ5XqfFhIomdk0gU3Gae7gcthXxGakA4DYxNXeRgT45D2HSYjT0BYnjI2Cp8oi4Ajc9aW7zc03fsDwD6M975mXavPvmOinLQKf+cznDH3/4gtf042F1v86gN6nbfV/eVsmgQ3GadYO57KviA1JBwCxiau9jQjs7u5uVN9n5Z2dHcPE4VOndIlA7QQ+8IFbzK/8wm+bV152tnZX5Z8ILCTAGGAsMCYWFmzgIe9THao3EGi5WDSB9cZp3i7ntK+ISUoHADFpq621CbDRPnPmzNr1Q1Vk4tCiJRRd6a2NAF/7f8rvv9Bcd827zR133Fmbe/JHBFYiwBi49m3vNowJ/XUAY3bcobrepyt1IRUWgegEVh6n0S0c1yD7ir29vXGFKyylA4AKg1qbSwzS3d1dw9ePcvRtR4uWHMMimzIiwNf+3/eeD5uLX/xq89xnvsTwFeiMzJMpIpCMwJ13fs4871mXmgsveJV5780fMq3/dQC9T5N1RTUsAqMJrDJORyuNWJCDRvYVEZvMrikdAGQXEhnUE2Djz6f+JQxSJkNOEplUevt1FQERmBB4//s+bH7pX/yWedXL3jDJ0G8REIEjBF798jeaX/6X/8V84P23HMlv8Ubv0xajLp9LIzBynGblVr+vwPasDEtgTPYHAGz+5kkCXkU0SQcvVdhAs+lnM03cc/3Uf15HYFLBdnzAl142jce89kLmw78VCcmxdd187f+pT7zA8FXnO27/zAwcdk4e+ciMx8eypsv19/11usK8fMr1z/oreQj3QyGvl3n5PJ/3jPz+OddZ0peZfkZ+L8Nn5HHfX0nPEp4jw2f9fX8dPiM9L3/Rs3l1yO+F+r2QN52eldeX6a99mf46nT/vnvy+Tn8lD+G+F+6nZdGzvixl+jTX/r6/kjcRxsbbr36X+cM/eJH+7wATJN1fCdD7dNfs7u4ekX08VVx2p3wb3lfhYANO7OzsGMYp0q95uU7Wved3/1ZWqjR2IKzJsY/+tb293UBUlruY5QFAHyBrrTl58uRcsdYaa62h8yHL3W2jBPxKFeJYw+DEB3zpZdN4pOi5p0+fnjv2Fo3L0p7hZwq+tbfJ1/4/8L5bzEUXvNo85xkvMXfe+Xnnsp0hLstM55PXy/SzWfeUHeb39/11+Iz0vPzhs+ky3A+Fsr3My+f5vGfk98+5zpK+zPQz8nsZPiOP+/5KepbwHBk+6+/76/AZ6Xn5i57Nq0N+L9Tvhbzp9Ky8vkx/7cv01+n8effk93X6K3kI971wPy2LnvVlKdOnufb3/ZW8Q/nsZ7/Q/RUZxgxjhzFEydbF9/uUzUhspmfPnvX2PrW23HUvayHWRcTU2uVrfMpRPna81N56BIhVL8R6d3fX7CaUHXc4gWxvb6/nUMW1sjoAoJMQJDYQTJZjuZ92GxWEICNj66mcCIiACIhAGALve++Hzb/++d80r3nFm8I0IK0iUCmBV7sx84s/95vmve/5UKUeyq1NCbDmRaydHAZsqi9GfdbnrO+xe+wan3KUt7YcP2OwLKUN2ZkvgWwOAPqJgcG+Li4mCQRd6+pQPREQAREQgc0I7F5+lXn6k19s3nbVO83tn/r0ZspUWwQaI8CYuebqd7oxdKHhr9A05r7cXZFA7uve/sM97FzRtSPFqW+tDgKOQMn7RtZlTCCLAwA+9Wdg++KELh0C+KIpPSIgAiIwjgBfWf7QB241F/7PV5pnP/0S87nPfWFcRZUSARE4QuBzn/2Cec4zLunGEmOKsXWkgG5EYECAdS9r6UFWFkk2/3zqv8mHe9OO4KvW+NNUcryXTTkTSH4AwCD2OTH0sDVB9CR0FQEREIE4BN5z8wcNX11+zSv1tf84xNVK7QRe+6o3m1/4579hbr7pg7W7Kv82JMBaOrdDADb/G7o1szprfA4XZj5UZh4EZEXWBJIeALD5ZxCHIoRuTRCh6EqvCIiACBwS2H3dVeaZT73YXN197X/Wv/Z/WFYpERCBcQRu/9RnujH1rKddbM5cfuW4SirVLAEOAVhb5wAg9GFEqMOFHNjVYIN8yJtA0gMANuih8eQyEYb2U/pFQAREIAUBvpr84Q99zLz4BYOv/VtrjEQM1Ae89IHPf/6L3V+pYYwx1hhzRn9EYA6BGGvrOU0fZLP25jDiICNQgnYCqZbazQioduYEkh0AxBq0TMxs2nwAABAASURBVED6FkDmvVDmiYAIFEvgphs/YH7hZ3/DXP6atxTrgwwXgRIIvO61V5h/9TO/bm589/tLMFc2JiQQa409z8VYhxC0ozX+vCikzFfbuRNIdgDAoI0FJ/VEGMtPtSMCIiACMQmcfd1V5jnPeIl565XXm099Uv/af0z2aqs9Aoyxq6+6wTz3mZcaxl57BOTxWAIx19jTNmnNPU2kwXu5nD2BJAcAsScHvgWQfSRkoAiIgAgURuDll501z37axeYLn/+Ssc52iREHY8TAmGAMGGuMuZddumv0RwQWEWjlk/GdnZ1FGPQsAQE1mT+BJAcAKbC0MhGmYKs2RUAEREAEREAEREAE8iGQat0bu119yJdPn9u3RJcCCDRzAFBALGSiCIiACBRB4JaPfNw84ykXmndcf3MR9spIEaiNwDtveG83Bm/9yG21uSZ/CiegDXnhAdzYfCkogUCSA4DYp4MEIkWbtCsRAREQgZoIfOYznzNvveIG8xu/+uTuWpNv8kUESiHw1iuuN79++knmyrdcZxiTpdgtO+MRaGnd25Kv8XrQmi2pWhEEkhwAFEFGRoqACIiACBwj8NxnvMT8t998pvnc577onulv/Ztgf9tbbMV2cR/4/Oe/1I3F5zz9EqM/IiACIpADAdlQBgEdAJQRJ1kpAiIgAkkJ3PKR28yznnqxecVLX29uevf7zX333Z/UHjUuAq0TYAzefOMHujH5zD+8yNzy4Y+3jkT+i4AIpCWg1gshoAOAQgIlM0VABEQgJYH3vedD5j+deqK+9p8yCGpbBGYQuPrKd7ix+STzXjdGZzxWlgiIgAhEIqBmSiGgA4BSIiU7RUAEREAEREAEREAERGAEge3t7RGlVEQEPBKQqmII6AAgYKg0+QaEK9UiIALRCLzh7Nu6rxnffc+90dpUQyIgAuMJ3H3PPW6MvsG8fvfq8ZVUUgREQAQ8EpCqcgjoAKCcWI2y9Pzzzx9VToVEQATSEShlnN7rNvyf+uSnzQuedZl5+pMvNF/64l3poBXR8p6zUmJMKAYOr35mErjrS3d3/1tAxipjlrE7s6AyRUAERCAMAWktiIAOAAIHK/ZCX986CBxQqRcBDwRKGac3XP8e888f/2uGbwAY/Wv3xhxhYGb8Wfyvtpsj9VV2dR5mxh9xNIN+9cbXX2N+9id+zVx/3c1Gf2YT2NnZmf2gstxW/KwsbAW7I9NLIqADgMDRij0Bl7KxCIxd6kUgawIljFM2/S96/iu6zf9tH789a54yTgREYEKAsfrG17/NXPCCV3Zjd5Kr30MCJcy/Q3vXScf+8GkdG1WnMgJypygCOgAIHC5eNLEm4lOnThnaC+yS1IuACGxAoJRx+mK3geBr/3ffdc8G3tZYtf96e42+leiT4jEdNcYsY/eC579y+pHu9wkwD+8nq7xoLVhlWLN2SsaVRUAHABHiFftbABFcUhMiIAIi0BCBfpPJtSG3N3F1jW/m77k6EO5lteb7WlxXq6nS7RGofV1Wu3/t9djsPZaBhRHQAUCEgHESG/pbAJxma8KPEEw1IQIbEChhnN7ykdvM85/9UvPe93x4A09rqqoN5crRdBv5lev0FQZ11ye/fs3ejBqu733Ph8zznnWZueXDH6/BHe8+MB97V5qBwjNnzmRghUxoi4C8LY2ADgAiRWx3d9eEOgTgJbazsxPJEzUjAiKwDgHGf+7j9Itf+JK5+sobzL/5V//NvPWKG9Zxs7I6HjaSbGhbkxV6AYR7Oag24NV9K8Ddd1dXoC/L1d0u+FleYkHlKh5dfeU7JmPZXRnbVTjl0QnmY9ZPHlUmV4U/fOiU3BAZ0BYBeVscAR0ARAxZiEOAEjYVERGrKRHIkgDjlPGfpXEDo57xhxeZ3/9vzzX33H3P4N8VN42m91bz221S7SxxWmxp4hyx1lkdTIxxSDpxTZiZYoyxxhwVlzEsa/b/uOyj5Vz+JG/FGB7UM3P0lZfP/w7wCf/9uebpT7nQ6M9xAjUdArD5x5/jXipHBMISkPbyCOgAIHLM2AQwSftoFj3o86FLOkRABMIQKGmc3vjO95sbrrvZnLv/XBgYtWplt9n5RmJaugeDX9PPJ/fWbTmzELfDHmuHcTYfFzPiz6QFM7O+NYZ8LmbJnzFllqio/TFjmTF94zs/ULura/vHppl5em0FGVTka//4kYEpMqE9AvK4QAI6AEgQNCZpXjbIOs3zaaIm+3XIqY4IxCNQ0ji97777zec+9wVzr7saNl9Ni9n/w+5yibjNskHMjHLk74u11li7WFwBs0isXVzfWk/PzVE9xumdJ9YeLWutXejDtB5rrcuaiEscrWvs0XtX1iDG5Q/F5fE5fy+ukjHD56b/M1XvSJn6n917333dGGes90R0PSTAumxvb8+suy471BQ3hb3Yra/9x+Wu1oYElC6RgA4AEkVtZ2fH7DhhI88EzmYBmWUO+QhlET7112Q/i5TyRCAdAcYowhhFShqn111zo/npx/6queKN16YDWFrL7BkPbHY3biPa7ykPki5hbf/s8GqtNdbWJc4hg1g72y+ejRNjjDXGbFljnK4DMft/XPZ+6vAyyNs7zFVqQODKN13XjXHG+iBbySkCrMvYULMuQ5jTp4oku8WWXnjHYCf2JjNIDYsABCRFEtABQOKwsZFnAmezgDChTwv5CGWRTU1GF22iy1rr1lezheeUQzZtM1V9fMUPxNrZflqbf34Kfv0CY7o/6n7PzGJAX0Poa0iKmK3b5qc++Wmze/lV5mMf/eS6KtqoZ52bvbhk9+PmD0MeN+7KreFXJy6zu+4/sFvu0X6aDe5ArEsfiiu3dVSMu+/FuvQRsa7saLGdDfZIey5veO9sttYaV9D92GPiMrpnB9f9usZdjbNtltjumTWTMtYcvxqXh1gz0WuM2XJie3EJ92NmiStykE9acowAY/vMa680n/zEHcee5ZwxnFOttcba2cKcy1oF8eEPehDanzXfp8jDll7w14ef6EMXYu1sttaulu/DLukoh0Brlo4dM8wfSK58eL3mapvs8kyg77QnT540p0+fNmfPnl3YAs9Pu3KItbb7xsLCChk9ZNBZaw2+4geSkXkyRQSyIXDP3feau++5xxhrjMR9fryIg3F/jjx3N+4HbtZaY6017tdE2PC6e2uty9oXl8dGuJNhvt1yZYayX/5ImQV5Q71L064dt0m3x9p0+V3eVDtL9S0vb5wOxLorQnpayLd2oqt75tIGcXWMNcZsOeEe6fMseWNlSWxX0jW2zfzK3X3PvYYx7yzL+me4XuH9jSwymOesVRBry1qvLPIr1LNV+YayQ3qLJ9CMA6vuK5iLEGvznI94pTYTvJYdpeP2m+F1OdCROSVet36MerzUrLXdAUeM9tSGCJRO4GlPfrF5wu883/CvhZfuS3D72SQeNOJu3A+31rqE+yFtXNpaa7r/7Jax1qU6mU5z38uwTJ83+7rV6Zz9zE49o+w8mZTt2x1enW4OCHqZ0jmpN1WmK+t0uI25te66L8bdI9ZdrStj9oW07fKsMe5qXPlOSCPcU5brMekom6682f9j969cXNpt9Q3CreSQwH333ufG+vMMY/4wN78U6wwf6xXWPfl5l9Yi1kg++Kb1Qq3nQ6B+Sxgz1m62r2D/ZK3N6oPUrfpDJw+Z7Ol8Pkhwym6tNQwIH/p86uBlz6LBp07pEoHaCbzj+veYa9/2bnPuXOtbpiX+u43lYV9wN+6He2v3E8ZdXdr2V9JOjN0yFnEbW66GjS1pd7VOtvaF9FD6/OkrZabz5t3PK3uYf8KZszVTDsscPicPoT2uh+K8dn4c3m8Zp9S5vtUJaYTnXI3zf3J1z+1WV9a4+hOxpntuHV3KcbXul/sxnbhf7sc9NYZ8M+NP//zYoyUxPla+rgzGOP8GAP9XgFw9297eXvrtxLG2s+6xNs/1ylgffJZj3cYaiXWcT73S1TCByl33va9gTkJnDtjcmzcHM2RDKAJ0tBCTPS8RXiah7F5VL34ysFatp/Ii0CoBNgN333WPuV//yz/XBZZsDI9sKN2N+3GV3P6TxESste7evVK7q0u7Da21XJGt7pnt8vbTdrKx7vLI3zph+vTxDfakTv9pvnV1Z0n/fHhdXu6EobztbNia2OD0k4ccqT9V5uDZMH+YdnqO6B0+c2nTCXyQLWPY8Ls8212tmdxbY9wjY63pxLg/Xdpd+SHNdVpc8emsyf2SWE8KVf2bMZ/j2Pe5+R8GkPXB8L7FNOs11m0t+i6fwxGoWTPzRoh9BTrRnZodr9XUNqj9QAToYHS0QOoN+kPpXlVvSD9XtUXlRaAEAm+/+l3mp378tLnyzdc5c9ktSYwZwaDbcFpjLa9Pa4yxxpLu8reMdWnEdFe3qbcnXBGXzwbfpa2TLdKIS3OPkNeLHTzbcmU6IW8gfdmDqyuHnl66Oi5v5tXpoV7XjktzHZbrdPT5+9e+DFdkuj55R+TECWORvr5LmxNwcNKl95+Tdpt+04vd2uc1uZr9+8nVds/cL/dD2olxf6y7IsZdB7I3SBuljdlncNVbru/GPt/8MZn8YT0R4sMK3EMvhwukWxX4tuq7/A5GoFrFHJiF3FegO/WYdG/YauPXtGN0LDpYSAi8VGknZBtjdOdgwxg7VUYEciFw1RU3mEsuvNy88mVvMB+99ZO5mJWnHewpO8tcottkGmOtSxv+2Em6u9/q0nZ/w9pd3aaWa7cxdvlb7h6x9oTZ2t8Yc0X6PNLdZtw9J01drtNi93VtcbVbpruSHiN2uvzEnq39NrvrMRu3TNfmft0uvd+WdfUQ6nE9svF3ZeyBnDDGpRHyuCKU7677z0i7xtyPNV26y7fG8M0Aa41BzP61S5vJH5c1Sej3IgKMecY+cwBzwaKyMZ7xDo+xXmFRH8Of3NqAL+u13OySPaUTqNf+GHNF6DlvWXS2lhXQcxFYRCB1B+bFltqGRXz0TARyJPD0J19knvKEF+nr/11w9rrfM38NN5TDdFfYGmutcb+MMdZYOxGXcD+TtLVbxrrN65YTyybZbaq7a3e/ZbbI25cuzXMnpIdCneH9lnV1XTnrZAtxOo48H3NPvaHs17HOtq1eaGc/bfefb5044XwaCj729y59womrYw/EPXN1jKtvEZfurqRdGbMv1tUj3V1JI+6ZZdOPWOswO9kyxrhLJ4Y/R27MYb5Z8GdBzBfUqukRfw2AOeBpT7owuVux3uGsF5I7m8CAWHwTuKYmUxKotG3miVhjhrZSYeRVmqpttRuQQKzOiwsxTspoRyICIiACaQiwyZy0bO1+mkuXtsbaiZhuw7rl7rfMMG3tltnqnp0wbH63us3vYXpyv+XKnOiEMr1suXpbdstYJ1w7cfW39oVyfXp4tcPNPen98sMyR9KU6do4Yfr8Tjf5+3W5Ry/XLexyYt2GnrQl7crZXlw+z8z+1Z7YMhM50V1Nd0/ayaCua9xYd8/VWGsOZHinwHfWAAAQAElEQVQIcJBvjHFFDsRM/eHZVJZu8yIQcwHMp+CtrVdi8s2rZ8ma0ASkf3MCMfdq09ZuTWfovnwCsSf82O0NI5Ry8AztUFoESiBw6y2fMC+58HJzy4c/XoK5+droNqC223UaY61LOXEJ9zNJs4G1dstYxG1mJ/cnzJZLI9ZtkrecWHePkEYm6a2Dcls8t9SbiHV1tjqZKuPKbc0QO8yzR+vMLk87k3LDuvjRl+/zuSLkc52W4/knzGGZSdo4+zgUMO6QgDRCmcnVGq6ItRbQU2KMId/0fyjTpw+v+qz/kMWs1K233NbNCR91c8Os57XlpVyvpGDZ2oFHCsaNtlmt27H3FanG6Fa1EZRj0Qhwqh6tsUFDqQbNwAQlRaAoAtdc/U7zkz922rz1yhuKsjs3Y91W07D5ZLPaS7fhtVvGdhv0E2Zr6zyzdcJdT5xnbCekkfPcfveEOeHKnejKPMBsuefIif0raeSEe97ncUXI73TzbCDkdeX7PKdrUv6E2TqxL67NrYFMbDhhuG6dcNdOzjMHutz91okTZuuEE+pxRbq0K+fa6PRxdWLPm+TZE+c5n12dExOx/dU9t524AwCuLp9n9rwTxvRyYsvV3TKGZ+dxRU4Yu+WuvZywxpA21sXBGC6dTH6Z6T86BJgmcnj/1ituMI//0R1z9VvfeZgZMRX7PZ5qvRIR6ZGmWvP3iPO6CUigTtWx5yMopmiTdt0blYukJgIpOlOKNmuKmXwRgTgE3Iapa4irpEPRbRqXsLCT59a6V2aX3jIP/IbvMA/7B//KPOwx/8I87NE/bx72Qz9vHvH3f85859/9WfNdf+dnzHf/7X9mvvv//Wfme37wp8yj/p+fNN/r5FF/8/Hme3/gJ8yf/YHHO/kJ8+d/4HHm+/76PzXf9zceZ/7iX5/IX/prjzN/2cn2//04s+2uJ931/3LyV5x8//f/hPm/nfz173+8+RvIX328+QEnf/OvPN784L78v+76t/+vx5u/6+TvnXy8+fsnf9L8kJNHO3nM9k+af3j+T5p/5OQfO/lH7v4xlPkrP2H+3l95nPk73/8487dcOz/41/6p+YG/8Vjz15x8/w881vzVv/nj5uQP/rjZ/sEfM3/5b/2o+b6/8/+Zv+Dkz/7df2Ie9ff+ifnuv//D5hGP/mHz8Ef/Y/PQx/xj85B/8I/Mtzv5ln/0D803/fA/MN/o5Ot/5DHmT/+Tx5iv+/8ebR70Y482/9uP/5D5mn/6aPNVj3u0eeBP/JD5Yz/5aPMVP/1D5st/9tHmj/zco80Dfv7RZutfPsac+9ePNvf98qPNPb/yGHP3v3+M+eJ/eIz5wql/aL6w8w/NfY/4RhfCSWyM4WrcH65jxBXt6owpW3sZWKQRbVDDcde6LBzb5jVXCiDFmEnRJuFzqxkukpoItPJCTTVoauor8qVFAmxmWvR7ls/jWVjbl3VX9/NlD/wT5k8+7C+YP/nQv2AehDzkz5sHPeTPma/9Diff/mfN1zr537/9e83//uBHmT/14O81f+rPuKuTr/u2R5mv+7ZHdvKnv/WR5utd+uu/9XvM/9HJI803uLxv+JZHmm90129y129y129GXPqbnXxrL9/8SPNtLv1n3PXBA/n2b3qk+XZ3/x3f9CjzkH156Dc+yiAPc/cPd+lHDOThLu8hlHe6vv2bv8c8+FucOFu+7Vu/23zLtzn5M99tvtnJNzn5xgd/t/k/nHz9t3+X+dPf8Z3mTz/kO82fesh3ma911699yCPMgx76CMfk4eZ/e9gjzNc8/BHmqx/xcPNV3/lw88DvfJj549/1MPPH3PV/ddev/O6HmT/6PchDzf/yPQ81X/7Ih5kvf9RDzQO+96HmvD/3UHPCydaff6ix3/dQs/cXH2rO/aWHmvv/z4eZ+/6yk/MfZu7ddnLy4ebcgx5oTBcXFxDDn/3r/oWc+TKq0PzqVT1pi4XWDlV1XjmTgICaLJ+ADgDKj6E8EAEREAERyJ3A0j3W0gIzPaQWwsP+SnpzWUEbRZG+0T4979qXW+Xa65pVh2dDoQz3XCUiIAIiIAI+CUhXBQR0AFBBEOWCCIiACCwisLe3Z/7wDy4wf/j7LzLGpdkbSYxZyMA9dD8HZYz7Y93dUFzW8h87pwifXCNOp+nEuD8Utu7OunTqn83+5vzEA/d730drtiZ+cd+JMaa7ujJmtT97rsr9W86+LTNRYYxxWRJj1mLAnPDUJ1zQ/a9BmSuM/oiACIjAXAJ6UAMB9/qswQ35IAIiIAIisIjAW694h7nqihvcWt9tnBYV1LOZBNhgDh9M3w+fLUxT0Yn7mSo2nTN9P1V8jVv/GmcZsd+K29y7H1eAe8Ql++0pt5OHZG4oKNtQhap3cwNzhA4A1BlEQAQWEtDDKgjoAKCKMMoJERABERCBGATYbiLrt2XdNti66ovFdqWsK5fqZ5O2qdvLAvv7It1hQH+zoPz+I+vOsE6cs8byVYAuz7rfiLs4bvyWiIAIiIAI+CcgjXUQ0AFAHXE84sX5559/5F43IiAC7RJ421XvND/92P9orrn6Xe1C8OU5e8xe1tBprd3fnto1ai+v4vbFywuNLuFX29JmQYJ0BQ8S3d3SXxRHlhZUgUUEmCN+5p/+mmHOWFROz0RABJolIMcrIZDkAGB7ezs6vhRtRncyYYPimxC+mhaBBQRu+cjHzUUveo255cMfX1BKj+YTmLWznJU3XwNPDmscpsjfVNimI5vqOV7/0M4w+o+3OMnp2+2vk9z5v4fl+nR/nV9LT44TuPUjt3VzxUc0VxyHU2CO1mUFBi17k2VgLQR0AFBLJAd+xJ709Y2DAXwlRSA7AmyGJKb77H0dDsb9ma7nspb99FWOlCPzSEbWN3uO2d7KFlIDWbni8grgQ/ZLkkSMs9Mc+esAxv3hicTAZmUx+lMJAa3PKglkLm7IjmoINHEA0NoEGPsAIHZ71Yw+OSICAQmcO3fOPO1JF5pnPOXigK20q/rOW95j3n3RH5gbL36iefclTzY3XvoU8+7Lnmre9bKnm3e94plOnmVufduuOe++c+Y8tx/u/tF6d2VL6i4G+fCNV5lrdl/Yydt2X2Cu3n2+ucrJFbvPM2928qbd55o3nXmeecOZ55qzZ55jds88y7zOyeVOXnvmmebVTl515hnmFWeebl7u5GVOXnrmaeYyJy9xcsnuU83FTi46+1RzoZMLnLzo9U81L3TyAicvPPuH5kU8f93TzCWXP91cevkzzGWvfbp52aufYV75qmea177qWeZ1r3i22XXy+pc/27zhZc8xb37pc82Vlz3fvPXSF5i3veSF5u2XvtDccMmLzLsuvsBxeLG56eKLzHsuvti876KLzIdefIm55YKXmFsvuNR87MUvNbdd8FLzqRe9zNzxwpebB1x+k3nwh7/afMeHvto8xMnDPvg15rve9yfM97z3T5hH3vw15qsuusHYJ77MPOD3X2b+yP94qfny/36p+aP/9SXmK37rEvOVv3Gx+Ypfv8ic966PTDogMCcp/fZA4Jl/eIl56hNfbM6dE1gPOKVCBKohIEfqIZDkAAB8p06d4hJFWtug4m/MQ4+dnZ0ocVQjIiAC4wnsubX7W95wrbniTdeNr6SSownc9elPmtuufb35+HVvMLdd/0bz8RveZG57x5vNbe98i/nYu65wcqX5zEduNue5TdQJF4vuAMBp5wAAcUlzx20fNB95z9vMR26+2nz4PU7c9UPveav5oJMP3HyVed/NbzXve89V5r0ujbzn5ivNTTddYW68+S2dvPumt5h3uTTyDpd+x01vNje4++vd9bqb32Su3Ze3uytyjbu+7T1vMsjV7oqQdy3lb3yzuc7JDe9+i3mHk3c5ufGdV5ibOrnS3PzOK81733GVeb+TD17/VvOh6529Tm657m3mo9ddYz523dvNbdddaz7h5JPXXms+de115o63X2c+8/brzZ1vv8F89pobzOeueYf5vJMvXf1Oc+Lm28yDPv1Hzdd++ivMn7rjK8zX3f4V5us/9RXmGz75leYbPvEV5o9e91Gz9QZX7uw7zAPO3GAe8Donl19vvuw1yHXmy159rdn62GfAKPFMgDmDueOcO0T0rFrqIhPQ+iwy8Lqbk3cVEUh2ABBzUorZVi59I5bPMQ9ycmErO0RABBol4Dby3Uf37som3u5fTZfZM3GZnL7s33blXNoa/jPu93Ex/OnqTOryv2JzKZe7Z0i7X+7nnDnnynC/5zZmk/Q5Q3pvz1337jeTK+lzruz9TtyVsudceplQ35VF3zmnj83fOeq4dKeXZ10am84daWuvs8vldWV47qx3eR0Wd7WdGMO1y3MU7N58HtYYV8J0f6xTRaLLc3UO0y7FMyc8c3f6EQERmCIQ+wOhqeZ1WxUBOVMTgWQHAECMsXmM0Qa+5CaxJv1YBw258ZU9IiAClRNwG8tFHvK4l67c/o3b63a3/GJjykt2Inum+xaAK9dfee520u7HbZpdBfeoS3OgsLe/2XYZ7sdtrt29cTLJd/fdZvvc4SbfPTvctLPhd89cmXNuY99t6Hk+kD2Xv+fueznn0udcHtc9V68Tl7fnDgG6dJ/HlXzknLObe8Q5vufEuLRx1y7trt2Gf+IYbrlDAONkr9vg9xwOrsaYCSuX2DOu3KFM9LhM9zNJm9l/aJMnlOMqEYHGCWid1ngH8OW+9FRFgHdtMoeYlEJu0NFNG8kcTNzw7u6uCflXAc6cOZPYQzUvAiIwi8DHP/Ypc+a1V5pPfOKOWY+VtwoBaw9L98n+evikS83ac/KSnSfdRraryS+3md7fvHYX94tN9B4b7YM0Zc65/fXkes5ttnnOpp10d3XluR7kc+/Kdc/dZv7cgZxze/V9mVWmzxteB+k9p5M29jrbzrnNvfO+S3M9vHfGHjw7TJtucz+PC/kdYqfK9H+G6f28rswwPaNMd9KwX0aX8QQ++clPd3MIc8n4WiqZIwE+ENJ6LcfIlGWTrK2LAO/ZpB7t7OwYNuq+jUAnun3rLU1fKAbw5aVSGg/ZKwItEHjrFe8wP/mjv2quufrdxrCBlazPwbg/PT+XNP2ukytCHjJMc++ErINPt93mlK/A85X2XlyRyRmAK+geu9s9d0+Kq9s3u7tzTribbLS7lOk3+Hvm3JH0ntug77lN+LlOzrn99kTOufyF4jbzPKcucm6//jlXj/u97jrRRZuTzf+e0z8RZ/ggTZ7LcTrc72M/ztVJnnOz59Bfj7IyHWrKd8+Ncfe2E1KGmBhjrDn8Y627Q8jl6sS6tLXWGMlKDJg7furH/qO56i03GP0pnwDrNdZt5XsiDxIRULOVEUh+AABPNqk+JyZ0oRPdrQuT/p5biMHEFwtOksXXF03pEQH/BO699z7z+c9/0dx33/3+lbeo0W1W3Q73qOfTeW6eZcs+KdQ97JJu69l92t1tYl32kavb3FOHObrT756Txf3e/qab/MmG+9xks+8238elzgAAEABJREFU63uurcnm/Jx7fG6S78qTd859wr/nZJJ2z7ry57pye64M0j1z6eF1z5U7t1+PMnvunus5d6Vcd+/Sk6vb5JN2OigzyXNtkHfOOeHs20P20/iE4Ht/tS7B/SJxRcDTcZykJ7qdM46pS0+ezP89osj8ym0/Ye5gDmEuaZtEPd6zbmP9Vo9H8iQeAbVUG4EsDgCAysTEJhXhfh3h6+5Mbuhap37NdWCyCVvYUJ9FHYcK3EtEQAREoF0C/e7SXd3PhAMJZHLH5nZrzx78vXZeuFtuJzu5mskft1Ge7HLdpto969NscpG9bpPtnrlypM/tX7s0G+7u+TnDRr3Lc/fnnAzT3Hfiynfl9q+kj4ird3C/n+439+dcuzzr7t0z9JM2bpPPFcFe5Gja8XB1+fbDoXt7bgNvprgcvYfdkTpd5QkyO7lMUPVpXUVABJYSYP2258Yj67mlhVVABHoCulZHgHVINk6xSUWYmJAxhrHpR9j483femdzG1GuxDGz7iX8VvrBFqN8iN/ksAiJQM4GD7eQCJ/cmz9zFrZ3Z407u+e3yup1o98BluCvzLIX4lJuX7JaxbrOLGMP/EvCEK7NljNsEu409G1t3736cGnffba7d1eWjpxNzzqk7lHN9GVep25S7K+WOpw/r7Lk651y5XvZces/l7XVX197Bta/T53Hv0u7Q4KDsftoZZYabfePyO3G6jDsYMFyRLm06/8hjc7/luG05LhMexvFBrLtOxBr3x5XhEABxOFz9Sd5B2t0epF1Zbrt6JJwM0+528DP/yaCQkiJQLQHWc4xn1oKsoat1VI55ISAl9RHYytElJiaEyQlh8zlLeMamH/Gx8UcPgq55gl0I5XJkN8Ym7Efgh8xjyzP87FmM0V17GV6Us3iFzqudawn+MRYYN/14mHXlOZLKH762+8ynXmKe/+yXpTKhgXbZaTpxP2xm2ZUyV7otsvPdZbqfLp+Nr8sZ/rDxZevZCc/3hYtxm3HjEu7HqXRKJgmX5TS7tPu9n55syNnI77k65J/jihwcFLhc6pDXXft7rtTvZXhPeiBuM793UJfy+8/Id7tuNv48d8Y6u/p/9M9560x3GS7bJfqNv8vu87rNfJe/1x2AdCzcc9i4y+HPnku69l1TTpdxZZE9d91z9wMxgz8um/K9zsETJdck8ILnvNw866kv0V8nWpPfKtV4xyCz3i19Hu8XZBW9i8qiizYZy4iPtcyi9vRsMwJnz541fV+IePXWJv0N2YyCavsgkOUBwLRj8zr5dLl175n8aOPkyZMGYYDNk9OnTxuEctZaU0NHxvdpWZdlC/WmWcW4b4Frjj72c4O1tpsbGPvz5gbyeY5Ym2ZuYFN29vKrzRvPXpMjzgpsYofZu7Gf3r90uWxY2YFObsxdX/ysue3Wm8xdX/is27ga93m3OfjDJvWPP/BB5qu+5uvMlusvkwcocxvtwUbe7Xbdj8tzut3vLj3ZTA825TxzQj6L+D238T9Mu1rufpLXb9RdO8Pyzua9/TaNK2v2nxmX3nNpxLir4d6VNV16z10mNriE++F+IsNP/7sN/355NvlbZst81Vd/nXngH3/QMR48v+uLd5qP33qjuftLE2Y0NxFsnlDqf8OwT+sahgBzyZnXXmXO3e/6Tpgmmtfav2dYVyK8S+YJ7xfEWmus9f+e8bGeaT6ggQHM6xvh8s8aX7rpu4i1/vtuYOzVqS/iACAkdSa7fsJdp52+IzOBr1NfdURABPIkwOGej7kBPbE9tK5BiTEbM3B7Tjal6DH7f0gj+7fusufacdJtcrndm2zS3X7pjts+ZN70qqebT330vd1X/7uvvbvH/fXbvuP7zEO+66+a8857wKSOe8aGmTadpv08l+k258Ztvg1tuN3wnku7rbYr4p65T+S7fPdsb/+Tde4pw3Uoe5SZku75kXpOsyvjGnc/Tj9pJ3uuza6sS3cbfGdHdz9o33RlnOOUQfbLWKe/88nlnXfiPPPwR/xV8+Bv/0um59Bf+esAsHrja55qbr/tg1371um0rh71J9c9d5jixHnPz2GecXGQ0DdDiNGfIAR8rEHRoTVokPBIKQQCSb9/SrFGCuRSUWqbPQBgsmTS5FTLR8TYKKgT+yApHSKQngBzAy8nH5agJ/7cEGIL0LjOPXqDY8B1KC7b7U8N4pKTa3ezZ+6//173SfYXzN599x7bnLLp/SMP+DKDsE+mrtvxTpK9fjLRxX2XdiWOpPdvXJk9J+6pa58NPIXdnXtM9oG4bJfVtXHs6jL6ck4JP/vCA1fR/fC8qzyV7vJcMZftGjWHvrq8buNu3J8ubd2zLefzlzv5su4AwLpHQzl3/33mni99wZy77z630XcPXb0D/X3aaTnII92JK9v97Gvb2792z5Q2G3Ew+uOZAGtQa233yeqmqlnHag26KUXVn0cgdH6aNVJor/LX3+wBAJMlk6bPEKkT+6QpXSKQhgCb9RLnhk9+4tPmLW+63txx+51pwBXdar9BXOSEK8MGdLoIeYjLn2zCXcL9uG14txne/3Vk+8Xmn5fvwebYlWdDO9lgdzUn1boMl0Q/4grRBtmIu93fpKNgv9wk2eXvJ7tLV71LuV/cIC4596drYPKUNmnLteD0Ovt45sT9uHuXS4IC6JwWVLg8fKUI4kh2m3sYwKK7d+W6qyvblemu7pf7cY8Of7hHyOGKkB7KrLzueddCl9Kv8QRud3PKW950nWGOGV9LJecRYPPPGnTe83XzWYOie936qicCMwhEyaLv8sFLlMbUSEeA92+XaOlXyE5GJ9YE3FJvkq81EWDzzxgO4RN60R9CNzqvcAv0n37sr5lrr7mRW4l3AuwqkX3FJNn4IuxY+6s55zbF7qH7cVtj99Ml9iuZbuPLNtS4P1y7jbFLu4Ld78kv6rDRdrkkXSabcMQl3Q+Z7nmXOpoml3Ld1dnVpSdFJsoO7HSZpI9Ip9DVckVJds9cwv2gp3vg0ofXfR19nrsl2Umf5oqQ2enbW8CAQk72y3XtHKT3Jka5xw7wYbq7d7/c4668S+rHL4Hr3n6TYW5hjvGruU1tITb/PUl0aw3a09B1cwLxNPDBS8g1UjxPymipuQMAOhedLGR4aCOkfukWARHwT4Bxyybdv+ZDjegPtTi7+657zKc++Wlzz933HjaolB8CbC4Hmia3/Rbb7UXdJnWyQXZ5PHT3bFLJQ9534xXm5ne+wZj77ze8dBH+vjvyVQ/8WvOoP/+3zJ980De5FqjsLgt/+jJcEdc+5Wmzu3I/yZ9siJ1NLjH5zbNFsl+q1+X0keOqu9T+z77qI3n7jw4ugzLdIQcPnM4HOR//7J/72+arnc/4jmy5ZwhsYPS+G9/iDHStuvIwnCmuTpe/0AgKSXwQYE65/VOfMXd96W4f6prWwXsmNIAYbYT2QfozIRDZjJBrpMiuZN9c997N3kqPBtK5PKqbqYoDhlCL/JkNKlMERKAYAlqcFROq+Ya6Da772X8+SJFk4+o2pmz8EbebNbd++F3mlg9cb+y5c5O/CuDK8fJF/tev/Crz4O/4PvPAr/paijpxD93PRDkJJ53OSU73m3uXfZjev3EXt3Xusp0J7uoy3O+1fmhjv+KBzu6eO/QiXYYZfovhIO0es/mflNjr/MbHB3/HXzR/7Cu/+uAghPKUg82tH7y+Y9XZ7tqnpa7+nvuNuEv/jGSXnvzqbvVLBHInoDVo7hGSfUMCKdJaI8WhvhWnmTxaidmpYraVB11ZIQLlEmC8xliYQUgHhFAoV9y+1BnvdqPup9t7cnU5bufufnPjtq2uULf5d9fuk2p37Ta67nH/d95d4e6n2/y6fK5dxuAXecgga+WkU31Yh5tFsl+SIl3S2d1d+eUyD25dmqyh9P6Rh80I6QmjyR1l8L/L3//FE/K6xQh6XSMH7M65DHcPQ/I66RTuV+biikzYc+Oku3dX/YhAZgR4z8QyKWZbsXxSO9EJJGlQa6Q42Lt3bpym0rcSa4GPp+rAUJCIgAjMIrC7uzsr20Me2ymJ6T5vXpWDcX/G1HHFpn7296hd7mHa7UT5ccIG1R0LuOd7xyxzmV3eN3/rI81DHvp/mgec92Xd/WSfu2+PtS5vIsalJmL2/1h3Rdxl6tmR1sb8q/iDMod1p/VaY611mdbYwW/Dncu3XPfFOn3cn3feHzEPechfNt/ifLTG7D89ejX9nz2X6CC6Kz9dmkx3w8XJQZZLu1yHd57W6XxKT+fp3syMyCwuRn82IBB7DbqBqaoqAsaYdBB2dnbSNd5Iy80cAIRbcDfSU+SmCFRMIObCDIw+56Nz586Z9978YfOB99+KasnaBPoNzxgFlJ2UYzPKJ9TcTdKknLjN6f/P3n/ASXZd573ot6onIw1ymBmkGcRBznl6COYEkiIVSJEKJBUoS5ZkyZKDND2yLPvZkv2uZPv+7J8kX/v5Pt/n+959sgKTKM4MCQYwB4AJJAiAAEhEIoeZ6Tp3ffvUqT7dXdVd4eTzFWrVzmuv9d8nrV3Vg4hRvFfym+uXXnwejzz8Xbz4wjMh3PIe4c2bMGXrlvNw5lmXYmZmjdcbzMxTf3tqMGaCWMgza/xwSd4sD8ondZOmC3otmbuvyno5phR6Yst6rZlZizPPvBTbtpy/8NN/H2kuHEEmj/zgHmfznKMM4Dz1RmfXQ+hBvtd71fI3tSyvXV7DfpTlLaoZjcB373kId3/zPnT5y4zRhqhXj0CW1/yeylWTMuZc1Sh1EAERqAQB3nsrYUgTjdAOVhNXVT6JwPQE+Auh6bXEGg4dPIx/92/+O/78P/5FXKHPfAgw/qRQO1MXxqcsBmEh6nq86sI06oaglcE/5dFH7sW+v/1z/ODBuxF+8u7jmVpILdQtDU/NrB9MexZJwYz1hpFfPkcufYPS2A43KTHPa83zFlJ4Dv4KJbejw18FhBSxz54nE7J57JF7+8xAhh5okp1X+ts7BsauzLMO2jOp96C6VLOy0xP4z//pL/Dv/u1/x8GXDk6vrGUaygjGy5izZcsqd3MikOUzUk4m1l5tazYAdCGs/bEqB0RABAYQYID0wyeexpM/fHpAq6ryIBC+2Q+K46iTa0CJq7yOgSq8l6eh3tPDhw/i2Wd/iEOHFv4ldfMBHQ+Qw7+G74FxCI49kvY3zCwI4KlLP/V65uEvo3jZjDkWEHoivGwhb6FitI9FfVOFXtZc6zIJ83utp2bm8xjMKIABQTqOZcZ9nPGUPrMevdfhwy8FNmTkkb6/Izgyb2XaE5a80kvM9YRdXaGX9M6fAK8xP3z8aV8bMc+f9vQz6Ll3eobSUB4BHb/5su/kq17aRUAERKDaBHSTqfb6VNW6OBBdbB2DfY9RQ2XkMRLLHqJ6ORQ8G+Hppx7Fk08+HPLmoTF/AWDegzfjDes24qQTT8fGjUd7Tfxmm3fzAnPmWYvzIeFHXPQGz/BtC1kvmkt49zOhNPgj1SeVdX29EhMKRy01l00AABAASURBVHuA7w2eM09i8QJCtTEHmP+3aeNROOmEM7Bh3abw838Dwv81wLzNI8nAgkyYJy8K85SEZfi2Pyk4SvReoW8vr0QEREAEREAERGA0Ap3RuqmXCIiACIiACLSBgLmTFE8GvVMBaGgOZX4sCANTChD/OQD/ZjqUPYi986v78cXPfxDdw4d6gXDQEj6OP34Ldu96J7ZtPT+UwSCZEbWnTCjwF1NjXcjHueTTq/xtLgPeQ6pDz1RbKtubBSG15NMNMCAuMQPAq2D+n+f8kzkDX1u3XICXzb4TJxy3hcUgbOHGR3T4ML70hQ/hq84k4ROFn/13vZ+L8+JGAOIdAK9LGHs2/WZ1urwoH2ZbVKOCCIiACIiACLSZgDYA2rz68l0EREAERGByAh54hl8CMPVg1d8er3pNFLnOOA2BrQewTCkvvvgMXnjh6RDThtDUx3pz2AxY21mLo484Fhecex0uuiD5PwIYzHqCXupleJ7iNUheZl5yYTlOjNlez5BFv8CmtAD9JoSXIdaBkCZ5+MtbwifgOW8wMyDJe8o8/28G9OHC864LPq2dWRt8THzlCPJ44fmnwX8EkHkKwTClpPMJW/grtLHC83qLgAiIgAiIgAiMR6AzXnf1FgEREAEREAERSBPwUL9XZDTPrNd4gOpvFvqbAl4b8i+99DweffR+D3yf7YXL6Ke8KZ+x9UKcu+MqrF2zDvAWM+MnzAwdl1BiauztpZA38MVPLzLr/ZmEGmbAXMgM+FhoY86Q1uElH+GfXmlmvXzH+xjCf15nFnIwi9M1a9bi3O1Xgb50wgjAgL68+MKzePSx+0EWDgXpYN8LoSoE+twxYEUvjetChT5KI8CVLG1yTSwCIiACIjAlAd6Xp1Sh4SIgAiIgAuUT4EO5BP0Qc1oWvD0O0RF5vUsc7nuec3oZLgz6I2+IA1UP+b1iaZ7B/0f+7s/x4IPf5Mgg8FfQ5GP7/1Aeg2mK9zAP9ilAB+b5jovB/wup1zHvgr50AM+bGeBpIub5QZK0MzUzwPvB54pT81IiHViY0xBsCPlOKu/9fLyZtwOgL/y5v3meb6aUhx76Jj7ykT/HI4/eh+4ARgsbAp5zJmQbBBztdUyd90Id65dKx6dcWqcyyG4qQa1fs7OztbZ/VOPb4id5tMlX+tsGacualuUn745tOI7kowiIgAg0jsBXv3Q3/vU//8+4+5v3T/U4r5AIE/PjV9Xkx5A0EdaBLw9s47xHsEneU/6fAJ56+jEcOvgie/XnZiHWBWw++kRcc+VrcerJZ3u7wcwF5oG2p0vzLDMQD6m3ez8zTykAPHHxMgADhot39Hfc7hkz87wL0yAdmMXl9C8R0nlvdZvPwrVXvDb4AH+ZC99MKcwfdN/J4DD/rwjOJHBiihQrdkzqWO8SxnsXphKgaAbf/tb9+MM/+M/4yhe/Bb1GJ1DWQ/7oFmbXc9euXdkpq7CmNq1phZchU9PatKadTMlJmQiIgAiIQGEEvnbXd/C//i//A/fe82Bhc2qixQQYgIXgNamOEOc8cA3f/HvK9iTPNIr4D9x18fQzj+Oppx71Zi/7KH5T7kl4H33kcbj84pdhx5mX4tjNJ2OmMwMzC9L/5t2D/hB89+rNy2ZJH8BzMOMn8y6e9woABqTF681soSbkzTcbADOvD9Lp5+M5We54H6ZxH9pIW7e7zZdfciuOPup4JK/EN/pOn59x3+EcWMYSRixHvbow3gP+kPLD642ppBQCvNbwmvO1u+7JZP5dBQeLRc+XCSQpWZGA1nRFPLVs1Jrmv2yd/KfQDCIgAiIgArkRYDQkAXJh4Er9PVQ3/Dt/b+cv0T3bezNaTcTb/VvrEMzy/wjQk14tvnLXfnzmC+/HocMH0fEhvCG7uv50rLvo/Btx/VWvx4b1m2Bmfel0enlPO51OXO9583yn3w+9+g4zQcx8HItp8TrvGLf7eDPvYywagi7Wdcy7eHlRPq4zi9P16zcGWy8+/6bgjwFIxKcLdYcPH8Jn3ecv37mfZBCz6HqemyCeeoAfeckb/O1QQp6pF/1N1hTPoq88mWRR6gV/r9wHUDswEQNk85qbm8tG0YhayvqGj/MWHdQUzTZZgqLnJdtk7iJTzlv0mhbpX5lzkW0Z83Peote06PMl4cp7cpJXKgIiIAIiIAIisIgAo8hFFUMKkYeqEeCtSS6kHtCGINfTeCPAa3v5559/Cg88+A3c8bm/xsOP3usjF7+5AXDkhqPCv6IfB/mAmQXxD1gvKPcaD9Q7XuU5c2GQztTFK/3tdZ73t+cXdJgNrmcns15bSlf45QGSeqMimFlP4DbMuK2bQZtpO5a8Hn70Pnz6c3+F7z34TdB38qAM5NOj6bSCljhd2AgIlUM/bGiLGqpFgA/cRVo0NzdX5HSL5irS1z179iyau8hCkX7Sr7asKX1ti7RlTcs8TzttOZjkpwiIgAiIgAjkTSDywDXM4UE+KF5mkLtU2Ma6J596BJ//0odwz71fAf8mPurym3CAIWwi69esxwnHnoZNvhlg3hIkBN4dL7kYxdDhf6Hee7CuF7zDe5l5nafMD5LQ6n3YZualMLan18vUbeb11OvzGFOW4XUutO2EY0/FujUbvEQtscBfUdQNvt1z35eDr08+9bC778G884kGCJyZd/DE+3A8y57q3UwCRT0EFzXPsFUqMqgpcq5B/hbFuqh5BvnIurI504amSZvWtMzjp9O0A0f+iIAIiEB7CJi7KsGikDMPHrxVDtHL36O7RLQhgget3i9CeHls24tjfVvA6xjsJv/ifZIytu12I3z5ax/DHV/4G/AfxeO358nfzDM9YfOpeNXNP4mzt10MC4E3w/EOLATiM7BeXUhDnbexzvP81p4S2jyoZ36QmLexT9IW617Qw7YF8TnRCf8ldWdtuwivvuWdONFtpc3wF1P6cvjgS+7b+/Hluz4G+kqfB7GIeSWsXAHfzg3OF55GINueMD9QOj7K+wxsUz0y44LMXkU9BBc1z0pgighuiphjJR/ZVhTrouahT8OkCryH2VbH+rasadnHDe+UdTw+ZLMIiIAIiIAIVIxAbE7kCYNZT3wDwANaz/CTQa9X+NtL3oHlrn87zvS555/E08884W29XwAEJT7Q32vXrMOxR5+EC3Zcg4vPuxHr120AGOAHMZinDNzN4jzLi8XQYRs6MO9rxn5p8frQltR5OfRLp9SRlJln3w7WuS206cId1wYbaSv4cvu5ARCy7uszzz4B+khfu15mmog77W9n4lG+Dwv5eJzvpzAjaTyBffv25epj2Q/biXMMbvL8G2Pq5hzJfGWmWtMy6ddz7iqdp3naUoXztFPPQ0RWi4AIiIAIiEDFCARzGMIy4wGtB7oh5ymD3cV5tsf/6B34jwN6n4OHXsTjP/wBXnrxOZh3TsSz4X32tp24YucsTjnhTGzacCTMLEgI7j1gD5sAnaTOv6HvtZu3xRK3DcuH8aGvoeNj47KP6bDcgXlbJ9R7nec3ug2nnnAGLnebaBt6L/M0Efry+JPfB/+3fzED+hwLGPC733G9l5bkvcY18Z0wZV7SRAL8u/G8HriptypBMddu//79YADAfJZCndSdpc5pdGlNp6HXvrFVO0/n5uZyOU+5slU4Tzs0RCICIiACIiACIrASAYa0K7RHAMNUin+F7aEtw9fIU9a4hOCWgS/znnZdvA694J9B8KOPP4AP7P/fcO8DXw8Tcca08Of0Jx59Cl5909uxI/w5gHmg3oF5MG5msA6D/p50vM3LbOuY570P/yHBIMwHmQGD/FDnfUPe+4YxLHd647yvednM5wjSgZm5DRfh1Te+A7SJthmAtMBf9z34dXxw/3/BI49/z7E4j7TPzmDB/y68g4/wPoEaUxbj1Kl5u5dXfHP2FTuoscIE5ubmwCAgSxOpj3qz1JmFLgYAtC0LXdRRteCfNlHIPks/qZP6qJf5KknWa1ol3/K2pS1ryvOU9/q8eY6ivzNKJ/URAREQAREQARFYMcDsB6iLglUGvC4Rg1qmaUkF/1HUxUsHX8DjP/w+7rr7U7jrW5/C4cMHY+RUSPESf2J/wjGn4KIdV+Oyc2/A+nUbYWYuHZc4ZSBvDNpdmGeAb2YIea8zi/uZMV1cv9CH+uLNhFhX3Jf5DT7npT73zu3X4ITNp2DdmnUIL9pI8cK8237X3Z92Pz6Nx554KPhGH6PE/8T3rpPp1/lgz8cbAa6ERU/C2/MhHfphQ1vUUB8CDOz403EGBNNYzQdt6qG+afTkOZa2Tesn7aMOBp/MV1HoJ9eCdk5jX5vWdBpOdRrbpjXl8V+l87RTpwNFtoqACIiACMQE7r/v+3jkB4/HBX1WgEDPhH6g6hl/s5Yxrcf/zHpsGyH8DbxXMBgOee/AfOSbAHD59r1fxhfu2u/fmj+AF196zsdFYHib/E0989u37sTVO18G/gR/4/ojYGbgfwzgjUE+4uCd5SDhG/wOzNviDYEB+V5b6O95cx2hf8i7dk83+VynnHC6z70bO7bthAGxRHHKXRDa/PATD+CLd+3D3fd+yau6oG9Rz8++z84gyYMv1+FdmPMxcRI+vT6k+qgMgUcffgK8BuVhEH86zqCRD8yUceZIAgo+aFPPOGPL6Es/eV7QT9o+qg3syzEcSx2jjiurH9eCdtJmyjh20FduIDR9TcdhUve+bVlT+kmp4nnaqftBJPtFoGgCvIkVLUX7yPl4s83KT+qTZEvg93/nP+G//NlfZqtU2kYgwJB3QLeBVZEHvnEDHwAocWTLegbFHtl6wB8FYd2CPPrEg3j/gf+K737vax5gGxj8m6syD5qDDh963FEn4tXX/zjOOf1imBniwN76eZb7YjOhPS4znxbfLPANgk7H66yX76VmPX1eNjMP+i/2OX8Cxx11UjAj/ohgQM9GC3/C8IH9/9U3MB50/2OfPONv5vlT/9h3+p2Mjzzyp8BfnuVnTzxZ9c3ZV+2kDhkS4LWH16AMVS5Tldx/eFwwAGTgOEjYRmE/3rcYbC5TVvEK+krb6QN9WclPtrMvx2TlVqKPOgcJ27OYK9G9kp/0nT5S2I9zN3VN6eu4ksU6jKtjXBsH9ed6UrJeUx4flOTYGpSO6++w/tTNuegDfVnJT7azL2WYvjLrO2VOrrlFoG4EDhw4gL179xYuZXDK0k8zg5mBF88yfGninN/59gN46IFHm+haDXwyt5HiSe+9NIlCRdwnzvdCXS8wwI2FAbHXe4EPFH3xIP+lQy+CmwB3ffsO3HX3HTh0+CXXyMG9/t4n/DnA5lOw8+yrcOk512ODfzsfvr3vBfLmQXvHA39z6TDAZxrqekF+qPN8qJsB+1gYOwOzDjqUUO647k1hDs7Fn/1zbrc+BPVuSrDtsNtIW+90ex/xDQz6kPTp+xZ87flAd3riCsLbiyEF4q0OrPgiX8qKndSYAwFee77z7Qdz0DxYJQNA3j8GCdsog0fWr5a+rOQn27M1L5LhAAAQAElEQVTwioEJdZkZdu/eveJzDdvN4ns4bctifs5NXYOEbZQs5qmCDvoyyM9x66inDH/GtXNQf9pOycL+pccuj8+VnlnNDJybdmUxP3Uk+qgzLaxPhP2qKp2qGia7REAEmkeAF2iz+CGied4V7ZH5hBJ4oFgBAdJ2RPG6LASzDIPhUa9LiJbjFo+Fe38O4E1e8Hfc6pko8m/KvXT3vV/B5+78qG8GPICXXno+zEItHnl7axTK27fsxDX8c4DjT8fGDUemAvcZGIN4D/zNhQF+pxfQz3g9pR/k+2ZA6OP9zNtCv17fjeuPxCmu+5oLXwb+6QG9Cx65nfAXy7SNQf/n7voo7r73y17rPdyHyPtEXur6x0KebV4Z3t5ATzzxt9ekP11zjyXgeQlQKQbQq4YEkuCJQRO/1BjHBd7DKQx4xhmnviKQFQEG15McuzzWeeya6RmUa6ENAFKQiIAIFEqAF2E9QBSKXJPlSmCAcsaxLv726N7bPRCOM/7p+ciDY8+xAVG3i4h14R/Gi/Ne4W8PlL3u0R8+hPff/r/jOw/cxVDZh7lWf3sHf/tGgY897ogT8MqrfwTnbrsEnRDMd0LKPGWm0ytbL03KTHt1M53FbcZ6l3O3XYxXXfNWHHfkCWHuiLb7nG5MXPbMdx74mtv433yj4iEvud2hPU7ZP3I/Iq+jrz4o9tv1sM4L/naHvN0H85108Xq9RUAEsiLA++4kwdPS+XkPN1MgtZSLyvkRSDauGMhPOwuPX54L0+qp83htANR59WS7CNSYAC/A3MmtsQsyXQRiAqt8emgbejBNAl6mi8TD3oVyvAmQlA8eehEPP/4A7vzOZ3Hntz+DgwdfdH1BG0eF/No1a8O/yH/BGZfh4rOvwcb1mxZ+CdAL7Gc6HczMUGZ6aSrvbZ2+zISx1HHx9mtwwZmXB92cg5F55LMypdAW2nTXdz6DR9xG2hr1AvvIA/oonfdxUahzDb3UjfdNDPrCHDXGqT5FQASyJcCAh/fdLLVSHwOzLHVKlwgsJcBjLIuNq7ReHrttfgbtpGEoLwIiIAJFEuBObpsvwNOw5g+ipxmvsVkQiFdhRU292DYk4cODXA9+wximFA+MPQpmg+cWguPIvzX3Sm/iwAh33/8VfPauj4K/COBP7vkPA3qjq4oQxQWcfdr5uOaCWZx87BbfBDgCMx0P8jsz6FBmZjATxOtCynKcD+0dLxulE8ZSx9UX7Ao6gx29OTgns7SBttAm2uaGeJPb6j5Fbns/2Edc543eJZ13rd7XK0OTtzDrlXGy8ucI7FdWoNYpCWgFpgRY4PA8gv/EfAZmDNCSslIRyJoAj7GsdVIfn0F5bjDfNum0zWH5KwIiUC0Cbb4AT7sSfACXACUzGGP+fojbD3L7QbJ/Ux4qu/FP+uEBNKNitoMBdE8ef+phfPjT/wPfefBrXkN9UUjZj8IxxxyxGS+74vU4Z+tOD/w7QWZmOljjQf/atWuwbt1arF8fC/NrvW7tmhlv977er+NyztYLg47NRxzr0/s8HqhTP2fzijDnPW4DbXnCbWJdIqGP90fPB9AnjnAfg47QBniVf8Rv/pN/5lkJxjieyu0LvWpBgAEOv+3M01jOkad+6W4vgbyPLZ4bec9RxdXTBkAVV0U2iUDLCPAC3DKX5W5jCCQh6woOefzcb03lk2w/9cA4BMgeGXvWY3m2MJz21N9ejUOHXsIjP3wQ37j3i/jad7+Al7zM+kQiD7rXzKzB8cecjB1bL8DlO67FZedcjS0nbg1B/4YN67Bx0wZsOmJjEOZZt279WpzmfdiXY3ZsuTDooC7qpD3JHJyTc3/dbaAtB3s2hD501DPBD9rsg+J8KHiJHRbF/osLcbe408DPEXgPHKdKERCBvAhwI1+/AsiLbnv1MjAv4vmwiDmqtoqdqhkke0RABNpJgBf6dno+qddJIKQUZX5nOurcUfIdN0LAG8e50UJA3AuavbXX3uvBhOINXGn05vv2A1/D575+AI89+XC8CRA0ecegp4tuNI9tJ52F63bO4roLd/lmwHnYfPRmHHnUES6bcJSnRx21KeRZx7YdW88LfTlm28lnBR2Rf2vvOxEIRvkcDP4f82/8P/f1j4E2wO0xF6bwl0/vn/Gb3iXlyDMUtriVnrA1JP5B7eYfLn1dyqMWLKBXhQnwvlpUcMO5KoxCponAigTatoGlDYAVDwc1ioAIFEWgbRfforhqnnwJLGhnwLpQWjXnAbHH097Nw2HmPcc3w2JKnOfngnhPJDGh+XRPPvs4Pvr5v8Q9D34jxOgMsLuutOtBe9Sd97rD3n8eNjOPs7Zsx7UX3YiTTjgRx2w+CpuPpRwd8id63TXexj7sC3MtvoFAHUGX63RlfOO7Pte+z/0lnnz2MZjbQIGnHr0jEdpJ8QofSW+SktcEX73s76DQq0Z/h4lG766eIiAChRHQrwAKQ92aiYravCLQtm1gaQOAqy4RAREonYAeHkpfAhkwPoGxRzDuTQaFvH/EIXLyGbcymGeA7M0eRMehddzCTw+EPfI+dPgQHvvhQ7j7e1/FF+/+FL707TvwyBMP+bCuf3vf9XFdMJjvzABHH30Utp66DRecvRMX77gEF50TC/MXnn0htp2yLfRhX46JMB/r8M2Eh10ndX/J5/iWz/Woz8m5zdyOOPrHspcH+sEHb4h9SPzzUvz2lvjtxTijTxEQgUwJFBlA0fC2BVH0WZIPgaKPpbY9g2oDIJ/jVlpFQAREQAQaT2BMB3uRbi8Jg9N5j9h7delazzPOZosH3GYGMxd04tQ6+O73v4VPfPXD+MSdf4t7vv8NPP/Sc5iPDiPyb/JtJsLMWsPadTM4xjcBLtpxMa644CqXq3tyFS7yDYFjjjkK67zPjPe1mW4YSx3Pv/ic6/+m6/4Ibv/Khz3/LZ+3g07KBq9AEPjLXOA2M3Fh2O/JovdCa2pjI125qLcKIiACIiACIiACWRLoZKlMukRABERgGgL6M4Bp6Gls4QSWTRii32W1CxULUW6c4ydloYd/fb8QFbs6f4OCEHAzF4uZwdCB+QaAdXqp57/z/W/is9/8OF44+By8Czozhpm1HazbsAYbNq7Dhk0uR6zHBpeNm9aDEuq9ba33mVk7E8ZwLHV89lsfx3ce+obrMnR8HopZB4ALO8HCf/BPhDIWv+he5B/+XmhgYenWAOsWeizP2fIq1YiACAwloPvpUDRqqAEBHb/5LpLfwfOdQNpFQAREQAREoIkEBvu0SqDKYHjwQK8dFARTnyH85wG2mec8ADeKB+RGYd6l4/Lci8/g+098D99+6Gt44rlHYTOGNWtmsNa/3V+7fg3Wrl8bhP/qfzq/jm3eZ82aThjzw+ceCzq+/8QDeNZ1hvlc/6AUod7A/+CfsWDJa5BvvS4rMmEf44dEBESg4gT4M+qKmyjzRGAogTZtOnSGUlCDCIiACIiACIjAMAKT1w8NeHuBLhMKg2kzmMWCEGh30Oml1ktZppixX8e//X8Bd933JTz81PdhM95/jWHGNwH47f6atWuwZs0azMzMYCbUeTnUzWCNlzvel2MefuohfM11vHDweViYx2BM0YF52kltPLAMr6OYGdAXAF5EePUzodT/GMqi30MZERABERABERCBDAl0MtQlVSIgAiIgAkUS6AdaHlwpDxTKYBhzYLAdwOJ6xK/EZizoMzMvdWDmqQtCcD3jidd54O0Zb/N8qO+AZYqZ9/E6Mx/XMa8Hut7cnTFEXjYY+i/28XKo8Q+zuA/7cgz7g2O83nxOc92gbuZdQt7LcWowzy8Iyy7owMzgH7EgnQdYRLrdmxeXvSK0A4Prk3alpfCBXiIgAiIgAnUk0Kmj0bJZBERABETAgx5BKI/A0JlHWJekC4PbRA/rWF4iFgJrQycE4x2YuXRcmLp0XEKdp/B6WAfr123CGaeeg81Hnxj+SYH5boT5bjdI1/NB5uPy/Ly3uRzutc97O7+U33zUCa7jXGxwXT47zPUOFJ/T+mKAmb87IfXMkhQLL+8XChY+V/kYqdMqOtScPQGtS/ZMpVEEREAE8ifgd+n8J9EMIiACIlBVArOzs1U1TXZVmMB4pqX+/r0fM/UzfVWMic0Mhg7MPPWg2zP+ZnmxeKW/2YfCtjhdu2adB/4n4KKzr8LJx25F1AW6hyMcOjSPg4cO49BBF6aHD+Owp5RDnr7kctD7sC/HcOxFZ18JbgRQp7ktZvEcZkxjSW9AxH06QGjveOJ9+r5gwMviul4SF1Ks4gp9ioAIiIAIiIAIZEigk6GuSqsq4yG/jDkrvQgyTgREQASaQWCIFwxeKelmlhdFuOnGkDfzdgoMZgbw7amFoLsD8xQMpGEwz5t56t+6w/PsbOAr/jxzy/m4/PybsHH9UYiijn/rbzjMDYCXunjpxcN44YWDePH5g3jpuYMhfcHzrGPbIe/DvvNdC2Op47ILbsKZWy8Agvrw4XlPOTfFGyyxzdPlGwIGMwMQi3lqWOnFVjJL92GZkq5TXgREoGoEdu3aVTWTZI8IiMAAAp0BdaoSAREQgVYRKPqhpej5WrWYhTg7ySQMbJePM4vrzQPjuNVzDKxdzOK88ef/HvAbJdR5PTow89TlpBO24rztl+Pcsy/DGaedixM2n4KZmfWuroPIg/n5Q/Bv/rt49pkX8N0H7sW37v0W7r737lju+5bXfTe0HTrYBftG/EcAXD91UNcZW84NujkH5/JZe3O7DcE2r6FtLt7gb693uzyDIDDAxYwpgCTF0levfWm1yiIgAmMTKONLqDLmHBuMBoiACPgdviUQeFEq+qF7bm6uJXTlpgiIwDgEeD0ap7/6VozAWOYMDmoZA5uxLRF4XGxLJA6kzTroeF+mC2LodNZg3fpNOPuMnbj+ilfiustfji0nnwWzGRgFM0B3BvPzHbz4wmE8/sQPcefdX8Hnv/Y5fO7rPfH8nXd/NbSxD/tyjGENjDpcTjvpTFzrujnH2WdcFObk3Ga0lzYmkpTTKfMUxC8fA7BMwZCXDalXtQiIwDgEin7uHcc29RUBESiPQKe8qTWzCIiACFSDQNGbdUXPVw3KzbFisCcr/USdbS79uLafCarMDGYUvyWHNJ3vwNABXMxzSMT7HX3Ucbj+yldi25Zz4M0w68A6Fot53oN3szW+CdDB/d+/D5//+mfw6ONP4Omnn8NTTz0bhHnWse3+798b+loYx/EuKX2cY9uWHT7nq3DM0ce5KQYgFgup9/d5Oy5mhiQ189ZenZlh8atXDokzAmVxj4XSSm0LvZQTARGICRR9ryl6vthLfYqACIxLoDPugDr3L/LCtGfPnjqjku0i0CoC/Ea+qG9KdG2o/aE1gQMe3fo7HmiIY2ALRTOm5nV+O/a8hUC5AzPrBdCe7wXh6Ld1cOIJW7H97Itx2mln44gjjkZkBr4i7xN1OKaDx596DHff/3V8+/5v4L6HvouHH3sYzz7zHJ579kVPXwgSNhB67wAAEABJREFU55/Dw48+jHsf/G7oe7eP4VhzPdRFnXD1nINzbfE5t591CU46cSvM5+tLsNPn7tXBbTLPgwKD9VOjqS4GM08QPhAnvTz0EgERmJaA7m3TEtR4EWgmgU4z3RrsFS+ERT18F7nZMNhb1YqACIxDoKhzNtt5GCxJECLHojgsnQe917B6b2ZTz0YzFlyYekBsZjAz+Ie/zaXjkqTMp8XrOzNYt25DCP4v2nk91q3f6ME/wosBeuRBeNf1Heoexr3f/zbu+OoB3HHnx8Bv9w++NI8Xe/8Q4PPPHwSF/wAg6w4enMf3fnC/9/047vjKAdz70N2gDuqizgjWmwNYu34Ddu68Dmf7JgBt6bhNZobkG38EvzqwkBospB0AzMfCPjADYDAzAD1hgvSLFWlJ2tJ1yiPhV2gKvWpAINt7znCHi5pnuAVqEQERGJUA78ij9m1EP16g8v6mb9++fY1gJSdEoE0EitggzHIDUiEPCg11+ryB8eb1gf6Ox4RAtzfeK/0NeIuZwYzS8TTUeGqesZAavB5x/phjjse1174Gp23ZgQhYEB/PDQB4+sxzT+GOL+/D/Q9+G1EUuXg//u8A5yPMH3Y51MVhD/gp855nXdfbom7kfWO5/6HvBB3URZ3UTfEpw5tzn7Z1e7DlmGNOAPv4B4y2ug3wnJnbHFIvMd8TL3mtf5oL4peZxXVe9OxCnmVJZXn40uhdcQJ1u7dVHKfME4FGEOg0wosxndi/f/+YI0bvzgd8XmxHH6GeIiACVSEwNzeHvDYIeW2g/qr4KjsmIzD5KAtDw6dHuEzNDP7u1Xvec2aedjpe7ynzLl7wt+HEk7bi7O0Xe/C/HUccyZ/9e2DvWwCRAR7fg+mjT3wf37nvLjzwg3vw9HNPxgG9B/Zd3wgI4vl5D/bT0vU6Stgs8HyEKIz9nuv4zn13gjrhczDo73ra9XbOxT8H4CbAWdsvCraZeaOLmcE6Luay1JfgI2DmbfBXknoWMOglAiKQPQHee3Rvy56rNIpAXQl06mr4tHbzQSfriyG/+edFdlrbNF4ERKA8AtwgZLCepQXUp2tDlkRL07VkYobES6qWFRnUUhCHtx7whkwvNTOYpcVvy6Hc8fqODzJ0PIhes3adB/+XYOfFN2DN+vUegqMvDMi7vgVw6PBB3OPB/5fvuh0vvPhcHPx74M/7XSwAA/1B4t1CW9zPtwC84kXX8eW7PoF77r0T1D3vc3hLf156v2bd+mDT9h2XgjbSVjfc350g/uFv5uHpgp8wAO4neikThBdzlFBY4YOzr9CsJhEQgUUEdG9bhEMFEWg1gU6bvc/qYsiNBAb/+ua/zUeTfG8SAQbrDNqz8Il6qC8LXdJRNgHOP0bgmY5jmWfA6yrMo14z/3SBi5kBfHvqCczCJ/gyGI7ZfCKuvfH1OG3rDlYF4TfwsAhdF+affuaHuOPzH8b9D3zLA/9uT7zdA3l+8+/JsgA/HeyHPq45XRdFsZ77H7wbn/78h8A5OBfn5NzM+5DwPnXL9mAjbaXNrGRqxk/AzFOLUy/422KBIby8PcnG5fA54scYazKiRnUTgSYSmJubA+9J0/qWPPdS37S6NF4ERKB4Aq3eACBuXrwYvE9yQUwugNxIUPBPmhIRaA4BXhsij5omuTaQAsdxPPWwnL30AqfsFUvjMAKhfkTuDGiTiNaHmPmHjzfzlOJtZgYzA6zTS5l3gcEsluNP2oozdlyEU7ftwKYjjwnfviO8ojhvwGOPfz98S3//A3fj6Wd/CAbz3W4cvPMYDGU/lpmPBb5BkBbX1Wtf6NsFdbDMwJ+6+UuAR30u+JxxyL3wSdtoI209/mT+3wG8k/sAdmYapOPFDswsiBf8neSZNf9A78W8S6+0cjJqv5W1qHVcAuI+LrEq9Oc9idcB3qPGtUfPveMSU38RqCaBTjXNKtYqBu/pCyIvihRe6JYK67lhQGlC4E8fhkmxq1Cf2ZYeE00tl7Eiw47FceuztD25NvCc5/lPGbbmbGM/PlxxXJZ2LNW1fsM6rF231qv5EC4B8mewMAd6r6VzJtWsX8ib9cpMXcwMZuYdOp5SPO+bAF4Aeql1OphZsw5nn3sZLrjkRsysX9/7tj8Ouhn98x/tOzx/GPd890585au3gz/Zj0LgHwf0DOD75VQ9j89Bwv4M+DmG+YU+Xdf9fJjjnu9+FZwz6rod/oa/IouCbbSRtp597uXBdvqQ9ol5M/Ok46M6njJv8EwsgGd7ZfRe3r+X88TbkBavCu90nfJYxCgfHrz28BqEFryG3X/q7jrvUTzHed9KZNi9jfc1ClnwmTkr36lPsh/79+8fWbJiP46e/WPYl1XfcexT3/EJdMYf0uwRc3NzmOvJoIOYbbOzs5h1qSsJ+kX7zQy7d+8eKmYW/KTPdfU1a7t5cyS/Ngh9zZrfavoOHDgw9Hhc6Vhd2mZmMDPw2KWsNu8o7TxnqIsybP3Zxn6j6Ju2zz/9vffgXe9+/bRqNH5kApH3ZMRL8ezAt8EPPMSvOO+fvaJ5k8E/gpj18jDEWaZ+SzZvhuHo407CVbvegJNOPxvdTsR4PwTZ8x5sH7Yu+PP7Z555Anfc8UF873vfCt/W82Ge0o26oCT5yMsLEoU2ticShW//u4h6/VgfeV2Xkt448PwD37sbd3z6g3jm6SeCDbSFNvHPAkiGtp607axg+zHug7kv4e0bG2ZeMvjLYBaLZ0Axs5DCX54D6/wD4cU2hNpQXP7BmRNZ3qqa7Anw2sNrUPaay9fI6zuv42YGMxt6TzKL23ndp5Rv+WQW0PZE6PsgIQ/KZDMsHkX91GU2nO3Se7rK8bP63r17F8MsqFQGfz4PFuReK6fxp41W+t1Kp3mBN4svuKOeWOzHC45ZHEy1Epycri0BHrsUs+Ydv9fddDF2Xry9tmtTP8NHsNhSfTzv716Fgf+Bn34smplnDWYWUs/EKQDz/044eSvO3HExtpx5LjYdxZ/9Rx5sU4AuInR9E+Cxxx/CPffcie/d/y1wI6DrwTu/tWcaB+/dEOiHvAfurA/ieX57H/ouyffbGfhTnwvHR0y9L9uf9k2H733vm+CvDmgDbem6TXH4HYUcbd5y5nk4w3044ZSt7pEhvIK/HZh5uSdmFpfhqQuC9D4NC690fqFWuZIIXHjR2eA1qKTpc5k2CUwZ7PDZZ9RJeI+h8Blr1DFt7Ec+ZuM9g7aRk3wWgSIIdIqYRHOUT4C7rbxBTWMJx5s1L5CahonG1ocAj18+gNTHYllaHQIREALT0aPQfk+/Zpp5ycXMXIsBniZiHZb9Vux1/Ml8Z80abL/gSuy84masWbcO/Hk9v+2PGJQjCsH/fHce3/7Ol/GlLx8I/9o/g/mIQXo0H4J+BuosM6UwnwjLlMj1UZinRBzvQT5TlimR6/MZ+zq73odzvfji82Huu90G2sINAErk9iUbAWvWrsXOy2/GDveFPtE3M/rqEnz2tFc2+H9JvpfCX+Yy+pu9KbRg9FHqKQIkwGekcQN/jksL7zFmekZKM2E+2VghH5YlIiAC5RPwp47yjZAF+RHghdfMMM5u9mrW8CKuQGo1SmqvIgEeu3zQq6JtsqnaBODBbSxD7GTsmTQleb/2Iog3eJ1Z+IDxP8+bGeDibybYfMIpuPbWN+OkM87GYf7s37/pZ/DP4HqeP/tHF08/+Rg++4n348Hv3Y0oBPHe6oF5FMRDcKa+QRD1gvkkZeBOifulx8T5ENxzLCU1tuu62LZ8XISH3IbPfuJv8JTbFLltXbex27OZGxeHZyKcePp2XOc+bT7xFPfV3z1nzcx9doGxEmZMAXiCkGcGQC8BX+k8y4uEgT9lUaUKIrAqAd4T9Iy0KqaJOvAZdNqNlYkm1iAREIEVCWgDYEU89W/khTcPLxhI8cKeh27pFIE8CfBBjw98ec4h3U0iEILKlR1KB6ZJflEQazAzgG9PzZjpwMyCwDoADOs3HYlTzzwXGzZvRgikwS2HCAymu+ji8Ucfwn3fvhPfu/frePqpx/2b+XlEvWCdQTqFZQb6lJD3gD7kfbOA7cwPFO8XsY/rY78wlnmXkPf2UM+UddF8sOF+t+W+73wVjz/2kFvYDbbS3rBx4ZsBGzYfg1POOg8b3De4j7DYZzPzYseLFgTmxVDnGfhrUd7LybvXnBQHpyOs2eCBqm0ZAd4LeE/I2m0+I+mLEoR/PyFrttInAiIwPYHO9CqkoaoE8r75cHNBmwBVXX3ZtRIBPvDlfX6sNL/a6kIgCSRXiDrTTb28mWco7qaZeWxrgKexAOiYZw3+0Rfr+O14xjA/AzD45z+mxxT+YmAeeeB9z7e+hK9+YT/4r/13/Zv5yKXrgXg/z7JL5H0ZrFOYp8R530zwNpYXC+sj31DwAL7Xzv4U9qN+SpjP9Xd7c7LupRefx51fOADaFvePmdH2xIf5Ga9z/6zjzvU5mLtvgLOAuZO9evOCmXmFvz01S/JeTt69qqS4OE0afc7FDSqJwCICvAfwXrCoMsMCNwHa/IzEzZUMcUqVCIhAhgT8iSNDbVJVGQK8sfHmk7dBnCfvOaRfBPIgwPOjGQ9nDHgk8MAxNwFfSxmzLpGlbSwDZhbEP2DowPyb/gVhW1JnOOvSa3De9bOw9WsRdYCI/1mE+U6EJ598BJ898Nd46P67lwfpDMj9G/kuhYG5B/Bxvhv6JvnI62Nxzf5Nf7RIuoh67V3WB13dReO71M36IPOg3qg/phts++yBvwq20ubwKwD64L7Y+nU4130767KrYbbYb0szcUYI7exjiF9Ml0rcEn8OaltapzKQNQPU/sV7QN5OtPUZiX7nubmS97pJvwg0nYDfmpvuYjv9Kyqw4QW+qLnauZLyOk8CfEjJU790N4PAyl4wsEr18ACWJTOv74l5kIuQ91vuorxhw5FHY8u5F2Hr+Rfj+K1nwtbMgD+fjzqGrnfnN+kvvPQ8Hrrvm3jmycdC4M3gm9++9yUE53FQHtpC2QN4BusepIc65iksDxK2JeLtUT+f0svNhqDb65K014+2PXjft+J/lNA3Lmg7faAvNtNx387A1vMuDr5udJ8XeJCTO9rjYr0UzsvM22KY/ExJrz5Vo6wIjEOgqGt/W5+RithcGWe91VcERGAxAb/rLq5Qqf4E9u/fn+k/+rcakbm5udW6qF0EKkmAD2eVNExGVYQAA00bYEvv5+VsTlqZXxSwegXLQQDzgN7MPK6ldOK008Hmk7fg6te+DSedsSPURd6nGwT+7T9/CeDiAbmH8/4tfeTiOQbiiSSBeJKG+q73m0fkeUqX43uBetfruv18t7ehMN9LvZzSE4W814Ux3ieUU2mvPv4lQGybf4J05jtA1ygG+mRmwcerX/ejwWdz383Mfe64MHVxRjAAXh8EXmAe/mLqRc/F736es8VVC59spCzUKCcCaQJFBqhte0Zqm7/p40p5EagLgU5dDJWdoxPYv3//6J3VUwRaTqDW55deOvsAABAASURBVAtjHAkYJ2YvHlj6N9kwpsBI+gGYWRD43dWzvbyxAWCA2xNuCJx9+XU474ZZROvX4rD3nzfAZ0PE1AX++u7Xv4CvfWY/Dr70ArroBd8MxHv5ec8HYTDu+e4AYSAfef+Q+mZANFDmkfTpDtDBOv4v/8JcSbvrZH0Qzx88+ILbug+02U1H4gd9om/0EevW4Fz3+ewrrgcZpJk4LLBsZiELZ2LmeTIz1ziy+Izjrt3Iusexo+F93b06vufm5go1WxvNheLWZCIgAiMQ8NvrCL3UpVYEig5odHOr1eEhY5cQKPphcMn0UxW3nX4yXv36G3DyKcdNpUeDlxLwADKpGpYyYGQbU4rnPVaNA1cvm5nnDf7hb1sQD2bNDPBvwI/bsg3Hn34WsKaDqAPwG3MGzUxfeOE5fP+eb+KBu+/CIw/cg/lDB9H1wD2WeYRv8RmIM/DvHkY3cmE+pMx3va4nyTf+6fGD8kv7hbLrCjp9zpB6OczjZbbThp4u2vjIA991m+/EQ247faAviU/0MXJf6fNxp20NDMwM1mNi5nkXh+XvJO8IARh6L2YoLCYp80NlhLUcOlYNSwnwWvMav+bw2rO0TeXhBPbv3z+8sWEtbfK1YUsnd1pEwB85WuStXM2NgC74uaGVYhEYSuC6Gy/GH/+n38Qll+0IARLjIQmmZBEtGr+UJ+DtXulv72cuvfk8cDWzUOglnjeY9aQf5HZgHvybWQj6GRR7R4RXqPN6A5564hF8/iN/gR/cdzci/sN8HmRHHnBHSepBeCiHdB5ROvWgPJSZLpIuwnjq6NcPqnN9bKfOJGV+kfi4UPaU+hLb3NYf3PdtfP5v/8J9eBgM/iP33UEEFwH3r+MUvc7MELPowIx5F6YuXgEDwCw8Y2YwcwFggIu5eGrwl6+JfzI7WFZrR6wLUAqsyODiS3fg//kffwPX33QJ6vrS80q+K6cvhfLlK+0ikAWBThZKpKNaBHTxrdZ6yBoRyIuAmaHDYBK8lA8OfbDi47zGrMIHWMQP/hrAzNfBjPXezP7MW8dzBjMDPA9fIzPzvOGYk0/DZa9/K44982wk/2I+vymn8G/nQ8AMD5I9mI4oiOL/mPdAO/4VQBdd5tPiwXq/LpWPGKBzbEi7qU2ApXmfx/sM0tFN6Vto74K2hI2IoN/H09KQ73rOffBAnz7xHwWkf/y/A9DnY888C5e/4W045pQtcEj+NsAZwVmZGfgfPA8zr6fAs572y56Hbya4eAviV1yHfp3KWbMwM4RrjqfQSwREQAREoJYEOrW0WkaLgAiIgAiIQO4EFk8Qf4+c1DG4XJL3oMjM6/vit1jPmxnMDLBOSDccfQxOvfBibDj2uPCzfwbH4Zty78L0yUe+j8cfvA/zhw97BO1BdQiome3GATeD9KWSbASwPskvSufRD9wX1bvOfnlIn7RO5lMS9fIhBW2M+IHu/DyeePB+0Bf6FKSD3v/ZAMH3Uy9wBkcdHZiAG1m+WWDmEIaJ6we8Hctf0ZD65T1VIwLFE9CvDopnrhlFQASGE/Db8fBGtYiACIiACIhAawmkHI+SfIg/wwdCzBmCVQCemnm9i5l50QAPaD0T2vp5mJcBBsTMwvtyAwB+N/YsAMN9X/kCvvnJ/Tj00kv+bT28s28CeJAehY2AXj6Uu4jSP8P3YDz+Nt7rme8Jv6WPhQH+PCL/Nj8tXdfR9bqu96dEni6SZC7WM+/9F7UjQpe2eZsr9xJw6OBLwYf7vvJ5d8Dcq5CgO8PUwIpux6mmGRFAIl4fZw1m5v0TAbzCBeHltUD4cEzQSwREQAREQAREYDUC/sixWhe1i4AIiIAIiEAbCHhAmnJz8qxHpAxaXYFZL++pmWHbVdfijBtvxuENMzg4E+GQCzcD+DP5J594GHd++K/w2L3fRsRg2sczrI08pKZlEYNsBuEsM+994rbFAX/EPkHmsZAf1mdY/ZCx8P6cn3PTBornYzsRt3qddwlzP3bvd/DVD/8l6Bt9pK/0mb4fXj+DM264KTCBs1kkWODGbECx7MP7LKkjpyVVveLwll4HJSIgAiIgAiLQCgLaAGjFMjfTydnZ2WY6Jq9EQASqQGBlG1KxpyURaj+IjYeaGeBiZp5YyG8+/XRsPussdNd0wIB43qI49W/Dn3/+GTz0zTvx3A8f9/iZAWsU0sgD6l7Og2rPJWUP8r0ClNDHy9FS8eCcmwl98fau16UljPG6dB/Wdb0v0wXpzc35Q1u6HNtLW9wgUCLvR1++/4078fxzz7ifC77SdzIgCzKBM+qLf/sPCutcE+vNnB/zaQlV4QNwjtBLBERABERABERgVQLaAFgVUf067Nq1q35Gy+LKEdAGS+WWRAYVSmBhMoa2Sclg4Bt8MesSyr0A1cxgFotnsFT4D+FRwJd5mOx9wyaA55P6ZD4Pr+N4mn09mE4KDKyDeH1IvS3u65/ML5KuDxtUv1LdkDHcjkh0p+b27MIcSR9PQ71/0B/6Nu8+0tfIfYbnvQmsp5gZzBaLV2BBgMV5xC+Lk/CpTYCAQR/VI6D7afXWRBaJQJsJaAOgzaufoe9tubm1xU8eGm3ylf7WVdauXYN3v+9NeMdPv6auLlTT7p5VDF4RglnPpYPN0M6KWMw8DeINIY3LZnF61Kmn4rzbbsPRZ57uQa8H3x6s8l/Ep/DfAIjMxw18+7zxO271ADxkmLqEDQCv6Kdw3Uk906Vl1q0kqf4e1fvb9YU6p+DjfCp/u0Fe5zWe55tlpi69LBOK1wD0zYU+MtgPGnv+dz09+ozTcf5tb8KRp53qfb1jjxmSFP5K570YtzGzVKh9aZ3KWRB4+0+9Gu9535vBa04W+qRDBERABESgHALaACiHe66zzs3N5ap/qfKyfnHAALXouTnnUv9VFoEyCczMdHDjLZfi6ut2lmlG4+Ze5pDHpYvqGJCygvUUGMzMa3hbdfG8mZddzDpYf8xmnHTZpVh3/HEIP3/3nl2KwTcEgGcfeRhPP/gguvOs9QZ4AyNmz4ZA2j/87SXWe5J6h7icjcwwTbXFWVaOKNQRD1r45FCED98Q8Oo465n43R/Sq48Tt9PfzPPPDZ5+6EE8++jDwVduAtBLClmQyUmXXhoYwXkNFLgyvpP2MLVXhHT5B+ddXquaaQhcff3OcK1Zs4b/kuM0msodW/QzEr3VswMpSERABKpCwJ9SqmKK7KgrgTbd2Nrma9EbLHU9B6pjNwMiCRgsjiXovfrsvBznbZEeVhvAIBT+CinLfitlnpL87boH/eiLITIDA97D1gWFP4VPy4Nf/ALuu/3jmD90kIpdkrfrT7JYmmeZwg6eRi7MujAo7wvL44hHz0vHIsyd6DdEXo58viiCv1iG11HYh+LVfHt2/tAh3Ou+PfCFz/vmR7RIyIJCFpFj7P/tv/NCX7yhnzfwP/gn+ErqQ9m8ZiXx5vBeqY/aMJQlGvEq+j6+Z8+eRnCTEyIgAs0h4HfV5jgjT2ICvLkVGbiVsZseewoUOXcbb+JF8k3WVKkIlE9gwYJefLtQkeQ88DTzYJHCupCah04uzPfELCkD/Lm7x8yghDzH9aQ7P4/u4XmExl7d8MS8ieKJv/u5fsYrs3ivpo/tlGSudD6pY+oQ5+mfC4sUr1rGA04PzistZhaKvQ+El/lnIp4FWED8Cllqd5RxjT5FYBmBIu/nuo8uw68KERCBkgloA6DkBchr+qJuOEXeRAexKnKzoyimg/wsq65IvmX5qHlFYBmBXsXyMDJEl96apJ71d7/kwWqIRb0iznrGKzaecjI2bjkV3ZmFb8rDz+A7EQ6+8Dye+u69OPj002lNnueb45lSPB8bxEJPvC7kDJwvZGFxkuGnpXUuTLQwgy1k012jdMG7vPTM03jyu98NPnfddzLgZgiFbDY5o03OCpzDxWDgG56HZ2PxDMvgy/NMBko0sFaVIkACRd3Py35Goq8SERABEVhKQBsAS4k0pMzALe8bD39lUNRNdKVl2b9//0rNmbTlzTITI3NSMjc3l5NmqRWBahJYsCodRA4ONkOtB6RmBn8jfDBD6f05wMnXX4NTdt2A7toODnvgm8ghzz/1yA/w7f/5V3jqnvsw+GVeTVlIwCIlVPUy6UrPmyX13mnCt1GPSzzc4oSfQTfLiYRKfgRhQJ+Qi3w8y2x40jc6vuW+Puk+0/eEA1OyOeWWG3DyDdcC1E8J/Pwxhfm0wF+h7CloA1OJCIxHoIj7uu6f462JeouACBRDwO+sxUykWYonwBsPg/S8Zi4i8B7V9n379o3adex+fEggy7EHNmRAEZtJDUFVqhtXXH0+/uDf/BJ2Xnx2qXbUb/JoqclDy4w5F+JNDzxZEcSHeBGh0fwzJWxfvwZdl0MzkW8AAPyH7/qCLuYPHkLU7YbhZvHYuAB/xWWzOEUvZQnGZoOZeQYhNYvz8JeZ9es8B2PdUDFvd0mN8QrE0qv3gmHhZSx7f4TUP5N8r+yJVwJgvSH4OH/oIOb5n29+zPeEGwDcECAjrFvT62+IfFwsAHw8vIyQYuGVlJkmtel8UrcoHX3NFw1raYHXlD/4o/fhyqsvaBQB3td5f8/LqTyfS/KyWXpFQATaQUAbAA1fZwbpedzgqnZjyytIJTs+JDT8MFnVPTIgi1U7qkNpBM7afhp+/Cdfia2nn1yaDc2YeLAXjD3jFo8u+XYJ5dDQK3hiSYQa/gHA0AP8qTsDfga6Ieg1hDrWM8CNe8FHeoN/xrk4z0/05jDE/yXtLDEPbzczAC6emnnKfFoG1aXb4a90n1TerKePKcXHmRn8zUFxGgqsM6/jmymFeRe2U8DAfsH/ee9CJjGbuN57L3l7Jx+3UJmUmSa1nvd3Ukq6K9TvE5k4s2XbSfgxv7bwGjOxkooOzOvexmckPpdU1G2ZJQIi0HIC2gBowQGQ5Q2OvyiIoghVvLHRT950s1pSBrzUmZW+uushCzKpux/tsJ+RkAQhChyTQ29MHDgOHmvgrTPVFgJb1rkwz+Df9bCfeT7yrvxH/wDrBf6xdiSvMMY7eTtSYsz7eKYUhHwH5inMazw18xQU1jN1CfW9cr89Xc+2AUI97E/p5zuA58E6CqjHxVP4PDADAg/vF/IGJPWejdsN9DgCK7DoRS7cCGFTP99xXYmYj1kk3tYrR55S4Cm8G8IHM4nAX5w7KSvFMkajMkFjX1ne2/iMxOeQKj4jNXYB5ZgIiMDYBPxOOvYYDaghAd7gGLhPGsAlNzX+oqDK7vOmO42f9C3xlcxYliwQIJNp+S5oUy4PAuYP+OaKJXAS4wu5wV/mo42pf5jnPRs+jRkXM4OZeQ4w/ud5M8+lZMOWk3HyW16BdWec2g/8GeTyG+9DnS5++OW78MSnv4jo0Dw1wCwe3+mlZuahdVxnxjwW+sDrKV5vHnCbeTlIB55DWoeZ12QlHpibGQ3xeZgYrONicd4nhvXyZub5tPg3/PPzeOwzX8TjX7kTh3p/AkD9k0TyAAAQAElEQVQmQby8wVmd+qZXguxgsU6zkIEZUwBMKACzPbFemq5byKP3Mk8lWJHVID5o+Gvae1vy3MBnJD6HNByX3BMBEag5gU7N7Zf5YxJI3+R4w6IMU8E2Cnez63ZTS/vJTQ/6MYqfdfR1mF951o/DN087pHsxgY4HYufvPAPnnn/64gaVRiUQ+jEAWpxBCJjQe/XbvWxmoc2YD2Jx2evXHr8ZR193GdacdCwY9Kfl8EyEZ+/9Hp791j3AfBdmPo6S6Aj5TlyPXhvrKKlyB70+Xp/Om5m3eFuqr9kSPauVXYNZPKbTS8283HG9TJcIOBfF69ET781qFwsSdefx9N334Gn3nQzSTJhfc+Kx2OzM1h232VVwDAAmLui/egUmlKX1/fLizKKui5tUGkLgHL+WnL/zTHR8zYd0aVT1OPc2PldQ9NzQqENAzohAKwh0quglg00Kd1EpZgaz5cI2XqwpVfSjyjaRGRlT+I3uIGEbhZyz8CXRRX1my9fTzMKfFtA2ShZzUg+Fcw/ykXVso9AuyrTzUhfnpC6K2WBfzYqvpz20jTZO6yfHUxeF+shyWuFmDfUWKQcOHBh4fTEbf32y5jsuh5k1M/j5X34Lfubn3zDuUPUPBNIfUboQ582TRGC9/1hngB8viwQWfvbOoPaw32n5N+6LBYjCsA7MDOn/kJQ9DXlP2Q7zvvCcUTzcZ5n5UOdtnvdPdJJ6lj3PMgP4QWJGXUvFtfg4M3NdsZixD+uZep0HhEZhfWp+LwL8cPGe/Tz4Mv/werZHHYR/EDFmwzz/gcRY+O8lxH8W4AN6/TlmQRb0AEkfgNkg0CsrAj/r15Jf+JW3YM3amaxU1kIP72uUle5tbKPwul8LpwYYmdhPH8wMZtPLgGkaWcXnlWmfecYdz82mMmCOa2cW/bm5VoavbZnTb8HVcTW5EO3evRsUPphThlnItr1794JiZuDFelhf1ZdHgOtiZo1f0/Txy2OSxyelPPLLZ6Y9tI3nl5nOmeWEpqtJ8+VxT5lO4/ijjzxqE444cuP4AzUC6DEYEPr3WpYk5mU/jwzxf/CUYuZliwN8BrjzFiH8Y3det5BGvgFg8YjQ3wAvmRk/PetpL28W5xnA94Nur4OLmYHfzprFfRbaO7BOr86YetkozK8ki/uAY5JA3zgubk/mNjMg1Q7rIGljCgNg/rFIYjaLuVjMqBPhsPPi5gjXIeqNYx6uJhZzdtCrAAKbjtgIXlMKmEpTFEgg/bzC+xalwOk1lQiIQMkE/E5dsgW96fmgzKBkmosQAxszAy9sPbVKSiTANTWzsEEzqRl1WdPZ2dn+BsekvpYxjnxn3fYy5m76nGRL4XnQdF/r618IK/vmM7O8hrWJMAJl3lN/MxeklzePTi1U8INBahLUovcnAEwXJGJnv0bCx1HMQgXMzKUD/4SZf3pQzW/xzVMzQxzwd8C6OO91/Xrv7wF5aDPX0cvHY73MupQk/YIe79vvxzzF9cL7w/Mw6qbEemCeer2ZgW3wvBvl2aTcSz1hvTfE/bx/14Xf9C+WqL8JELMB4GPDmnh/hJdXhLT3saTYqx0hCVpH6KcuItAsArznT/u83Swi8kYE2kegUwWX+YDMB+WsbOGFjTqz0ic94xMg/zasKTebeDOdZuNqfLrZjqDtZto4y5bqgjaeBzxGFmqUqwaBZQEgltfElvrpAYQP+CuJOJmmhO1JEXGG+uI/AYiw+Of/cTnyMYaO97YFYZ1LqDX/pLCVqQsDdvPUPNgO4nnWhQA+yTNlO1MX9mP7SkKdiZ7Qz8eF1PWE+l6Z/YJ4PfWGvLfFeffDbYe3wVMzLye/QoDnvewJ4GlkWM6kV8dNAbazH1KvyMelioD3x0qv1dqHrvhKStUmAvUkwOcVMwPv+fX0QFaLgAhkRaCTlaJJ9WQdKCZ28KGbF7ukrLQ4Am1aU242NeVmSl90zuRznvAYKXIT4JLLz8Hcv/w5XHjxWYA/8Ek8ElyVgzkmc14APAH7wzNMKfAX00S8iCSfSs3Mq2PxTPzNv0X+zXaEbmexwIISwMckYtaBucCDaDODmZc7MwgBdqjzvM2g0xMLbb06b+94mWL9fAedkE9SH9vr0/HUesJ8LEm/JJ1ZmLvX11xfbFen1+Z2si4R87ILrOO+9cQ3AmDm5Vj4bwBwc2SgOC+2w7siNSbkXU/YCGA9/LWoD8tewba+sI6ytF7lwLPPaTGPCy8+G3v+xXtxyeU7HJ7eTSDAe3wT/JAPIiAC0xPwO/P0SibVkFegmNjDi50CmoRGMWmb1pS+FkO1uFma6FNx9FaeiZsARfE9e8cW/NR7X48zzz5tZaPUukBgUM5jon41A6V+AR47pRvRe7FuQSLP8u/Zw9+6e/DfT5l3YbuZd4LBjMJbMoV5Ssfrl4gH2R2XEIR7yjzF+sG5B+y9zQHWd7w+EfP6pZK09VP28TFpfZ0Z19mvc3tC3lMG+G4DKG5/SJnviwGsTwviOvoeeHiw30+dCfP8tQTbkYzrAPBhlLgeYB5shzf4m0lcCb0yIHDGWaeGa8j2c7ZmoE0qyiZQ5AZ02b5qfhEQgdUJ8La6eq+cevBb+pxU99UW9cDdn7DlmbasKY+rInwt+nAqMkgt2rcqzMdjRpuSVViJ5TaMWtOPNX1AnDePPRcEXkLvFf4EwLDwK4BegMsgl9IN/cxHpMSDWrMOQk3Iey6kHXS8vpPOe6DdYcDu0unlO+zDvAfpnZRYv971hPZeOqw+9JlBx9OFsRbKrKNYr43tcd5thUuw0dNeHl4GDOEV8kDXi8u+/Q+bAc7LU7KL+/PTO3OcJyzFqligIPyQn/0poV0fIiACfQJ8XuG9vV+hjAiIQOsJdMoiwAtSEXPzoqcH7iJIA21aUwZyxVAtfpYm+1Y8zeUzFnWeLJ9ZNSsQSDUxqFwqqeZFWfZbVBEK5hGqeY7fVh+e6eKQB/6Ug56mhe3sR4GPgb/M01g6MPOcMaUwb0C/7HVwMUOn42Ie0FM6vdTzlhIG7EOF/Xyc9YSbCCHPeheOS5fNDKHs85r18kxTAs8HgbeHPACmiF9dD/LJZJhwg4ABPYUjmFKYBwzJiwyTfKhmE6VfqYwItJuA7untXn95LwKDCHQGVRZRV+QFSQ/cRawopvrX/se1sMw1LXPucTlN2l+bZpOSW31cUZuSZoaztm9x0Z8BrL4q2fVYiD0tfMvNn7MfnokwSBgEJzNznHkEa15h5p8UdEKNmXnqeQ/GLYiXWRckVc8APrTHdQzkF2QGHf5SYJHEmwXm4zo+jhL098pJPqTezn4h7+1mtKEDSzYBrAOYAV5marC4zDr4K0k9y0CeAf4h57JIfIOEZbIKbFyFdw/f8DNdKouC/6WNA8qcd0C1qpYQOGv7aeG6YdZbgCXtKtaHQBueV+qzGrJUBKpDwO/YxRtTdHDBB+7ivWzXjFrTZq23HhryXc8i+HY8EHvvL70J7/7F2/J1pgnaB/oQMYQNMrB5pcooboz8W24Gs8kmwHyni7SEANb7GmfxNIzqBV2sWyRez3LHUwbqQTpxAO+fHnf7pwfh/Xq2rSozMPbhOE9D3lPqWJZnHxfWWzpl3gxwMc97BkBcjlMA3obk5U1wIZs0i5D3DYF53wQgr8AmGbMsjTCsPcHIOZYN84p+u+f1HkzgZ3/hjfi5v/dmzMyU8og42CjVTkSg6GeziYzUIBEQgcIJlHJ1L+OCVMacha9miROWwbeMOYm4yF+vcL4yRJtmZVDPfs7jjj8axx57lCv2iCtEREoROMBfCywQ6tJl+ItlT/pt6bzhyFNOx1mveBvOevlbcdbL3oKzdr8ZZ+96E86+5TZsv+WN2H7T67HjzBtwzkPH47wHjsX536MchwvuPw4XuuyknHgldl71qliufjUuuurVuNjl0qteg8u8fPnVrwHlCk+vvPq1uPqa1+Gaq1+Pa12uu+b1uP7qN+BGl5uueQNu8vRml1uufiN2uex2edlVt4Fy65W34eUur3B5lcurU/JK73PrNW/EbpfZa9+AXde9ATdf/3rceMPrcN2Nr8U1N70GV7tcdfNrcIXLZbe8ChfvehV27nolLtz9CpzvsuNlL8f2W2/FWbfuxpkuZ7x8N7a+fBanveIWnOxy0itvxokux73qJhzrcsyrb8SRF52LjYdmsP5wB2vnO5jp8nGEv5qIML8G6N50AeZ/7CYcfMdNeOmdN+GFn7oZz//MLXj23bvwzHtm8ezP7cbhHScD/fVZul4spwX+SpeTvFcv0pHUtzc99rijcNzxRxOMpOYEdC+v+QLKfBHIiQDvuDmplloREIE6Eyhrg6XOzEa1vciHsmOPOxqXXXkuNh975KjmtaAfg7u+mwMySXuSsks6D2w8/hRsuf6V2HLtK2K5+uXYevWt2HrVy7Dtyllsu2IXTt9yKc545Bic+YNjcDbl+8dgu8uOIJux/dgLsf2iG4Ps2HkTdlx0E87x9NydN+J8Ty+geN2FF92MnZSdt+Dii27BJZSdu3DpRbtwmcvlO2dxxUWzuLInV3l69c7duMblWpfrenKDpzdeuBs3pYR113r/ay7ehatdrrxkF668dBcuv9TnufxmXHzFzbjoiptwocsFV96I81x2XHUDtl99A86++nqc5XL6tddh67XXOgfKNTj12qtxynVX48QbrsbxN1yF4264EptvuAKbb7wSx9x4BY68+XJs2nEGNnjwn2wArOkazL+e5zf73Y4huvwsdF9zOQ697nIcfMMVeOm2K/Dim67EC2+5Cs+/9eogh7cdz4VJiaXyS7PD2obVLx3f/PJm3yzkteLYYxX8N2G1dQ9vwirKBxHIh0ApGwBlXJTKmDOfJaum1jL4tmXOaq64rKoLgSuuOQ///s9+E1dcfX5dTC7YzpWm84gUlJX6DGgbOiTdkM6ndQyrT/dZnGcIS1lcW6NS5D53Xfw9ntVjDxhPfct6X3HVefh3f/obuPJaXStatvRyVwREoGUEStkAaBljuSsCIiACpRHYtGkDtp5+EjYdsaE0Gyo98UDjMggsqYKyTH+6kvmlsmxADSrow1IzWUdZWr+4vLjH4tLingul+FcC3nelXQ9vXhixkFtpyEKvduY2HrHerxUng9eMdhKQ1yIgAiLQDgLaAGjHOstLERCBlhM4/cxTQGk5hmXuL68YEjkOqV4+fpSaBWWDcgsaovDX6QvlquYGhNWR20pZ9AuKyEteyW/8Kd7FmHqVZ8d6cwjFFS6MY0UiC7X93AAr+21tz/DacIZfI7AIaNupyH8REAERaCYBbQA0c13llQiIgAj0CZgZ3vMLb8R7f+k2zHQsBJXmrRIsYuFIlpVDnQeVCSuWsxFXGoKtXlAclC7UTRKI0cagZoSPcfqOoG5IF/cnBPhdb+/lez4H/7pdL3m9f3qHgW/aSUk38t8K6HQNHR/KNpaDAGH94K9QvyT1Ymgf1Nbmuo5fH977vtvwnl+8DZ2O7f3rPgAAEABJREFUHgt5nEhEQAREoMkEdKVv8urKNxGoGYHZ2dmaWVwfc084aTNOPHFzfQwuxNJBkzAUHFTv0eag6lQdQ/lUcdXs6hpXVRE6JHqSNFSW+ZEYkqS0hRsBTHvSL6b79NpGScIqhbHhY9GQ0LaoJi4Mq49b2/15gl8beI1oNwV5LwIiIALtIKANgHass7zMiIAC1IxASk2JBBQG9eEPzaQZpfKMNRm5UoaOZadU45JiqiXTbEHTjG8zDVsqKS0puqnapVkqWFrXK4em8NGrUCICIiACIiACIrASgVI2AMoIosqYcyXwahOBqhPQOVP1FZrEviTcYirBkh+EW78Mf1lPPBlUPyzmZP3SDYJQ53qYejLNmyqWyjT6ho3lHGxjSmF+kbBymLAj25iuItEitoM6R6lKrkmqGLJex38VsN/Ny4lO1id5pU4rxWYZD2/WWwREQAQqQqCMZ9Ay5iwLtzYAyiKveWtLYNeuXbW1veqGt+Xiu2fPnlKW4twLtuHX/9Hbcf6FZ5Qyf8UmHWgOQySE4AhY9Kfp/QCT9RGee/gB3PfRv8B9+yj/E/fudznwl7jnY3+J73z8r4J8++N/jW/f/je4+xN/jW9+4m/wzU++H9+gfMrTT30AX//0B3BXT+684/24844P4KsuX/nMB/Ally+m5POe/9xn3w/KZz397Ofej8+4fNrlk59/Pyif8PQTX3g/bvf0455+7At/gwMu+ylf/Bt81OXvvvQ3+FtPE2Hdgc9/AB/73Adw++c+iE989oP45Gc+iDvu+BA++6kP4fOf/DC+8Mm/xRc9/dLtf4uvunztYx/B112+ceDv8E2Xb+/7KO756Edxb5B9uO/v9uF7Lg99eD8e/vABPPyhj+FRl8c+8DE88f6P4cm//jieofzV7XjuLz+O5//nx/HiX3wcB/+v23H4/3s75v/P2xH9f26H/R+3Y+3//gms+2+fwIb/ejs2/pfbccT/djuO/M8fx5F//jGs+c4jvkaphUllfZVS73hVUxXK9gjwWvAP/vHbcZ6uCT0iSkRABKpAYHZ2tnAzypizcCd7E7ZiA0ABW2+1lWRCYG5uLhM9VVZSVoBKJjpfSSEf2XHuNvzyb/wozrtAGwDAcMaLwsUQVIYPDzZ9TO/b/ecfeRD3H/irIPd9zNOP/w3updz+fnz3kx/APZ9w8fQ7Hujf/akP4u5Pu9zxQXzLA+tv3vFhfNPTb7h8/TMfwtc/82F8zeUuz9/12Q/hqy5fcfny5z4Eypc8/dLnP4QvunzB5fNf+BA+5+lnXT7j+Tt68mlPP+XyyS9+CLd/8YP4+Jc+FORjX/4QDnh+v8tHKV7+O5ePfvmDYN3Hvf8nvvBhfOLzH8anPvdhfPqzf4vPfuYj+PwdH8EXXb706Y/gy5/6O3zF5c5PfhRf/8RH8Y3b9+GbLnd/fB/uObAf97rct/8A7t93AN9zefCjH8P3/+7jePgjH8ejf/txPPbh2/G4yw8/dDue+sAn8PT7P4ln3/8JPOfpC3/9Cbz4V5/Aof/5Scz//z+J7v/1SUT/v0+i839+Emv+x6ew9v/4FNb/909h4//7k9j03z6JI/5fsaz57qPxmviyJO9Faxcql9eEan0EAueef3q4Juw4d2so60MEREAEqkBgdna2UDPKfO4t1NHeZKVsAHDuIh/yiz6I6J+kuQTacDyVuclR5txFHbVt8LEolhPPE77lHy047IX//alYjrgR4MI8mEZdD0Yjz7p0me963sXzkbdRusx35xG5dD1PiUI6j4V8N+RZzlbiOWKdzFNWmcvtjvvH/WJbF/JJmSmFfaNu7H/kfiUS1zuTVJ07iSDzC/Wh7H3i1Mn2dMH5BvFySL0p/DqDKVcltDPjktR5dvX3aOu/uh71EAEREAERyJpAkbFi1rZXXV9pGwBFPgAXOVfVF1z2ZUOgyTuFZfvGDZYmX/TL5ssz4DVvvB5veMtN6HTaGwCRw3iSiiwZcCaDPR9amHrAzAA1Cnmv9WA28rogzHvgz3yXaU+S4DiKPCDvCfsk0k3GM3UdHBuk17fraeTCdGXxwL3fj/meBJ2e9zRy6fo8scwjlL2OadSrX5ZP2j04j4J0EXlQH3k9A/mQZzmI6/QUQXp578c+oY5514EgrsfLcZ4sXfwdB/7M+AIwcdaeC+/xjubxeocJGvTBc5/XgNe88YYGeSVXREAEmkSgqPiNz5xFzVWV9SltA4AP+UU8CBcxR1UWU3YUR6DJF4oq+FYFG/I4mqpyk+FD/0+861XhTwGOOnpTHq5WXecI9qUCRAaaYYRn/B1n/ZvuJPj0NFT7R+R5uDAAZj6IB7KRB9AL9R7cepl1fen1YZkBONNEuElAScpLU/ZPZGnbKOVkLNNgd8+WUE7sZF0iHsAzaA82hbp5dOfnEfU2Nfo6Qlv8DT9S+bjdYXmgz7wPBEKedezfY+sc+wG/NyGUPePvkA8L4R9eTq2WVyx/r9a+fERza446+gjwp/8//s5X4rW3aQOguSstz0Sg3gSKihU5T71JjW99aRsANJUP+XwgZj4PYfDPOfLQLZ0isG/fvsZB4DlTBad4Ma6KLVny2L9/f5bqptJ16RU78Md/+g9wzfU7XQ/DozZJ4qu73v9TgKQuTm1JfeRlCkfA80EihDjUE8+Et3948Mpg1isjD1gjzyfBbdeDYArrmFIiD5q7Qbro9trj8ryXFyQKfVhO91vIRz6W0vV0oHjQPrDe+0eum9L1dEG6iLytm5JQ9g2B/saAt0VejugnU5ZXEDgL6oD3ocR5BxXq4xSeh+sLqe8FhNSbQl1I4YwpFqf9tWDZhWX+6/8U8BGnV8f6ReI6FpWH9Wte/dXXXYg/+bPfwGVXnkMIEhEQARGoLIG5uTkoVsx+eXh3zF7rGBr5QJzHwjJ44EEzhinqKgJjEWhakFq1c4bnL20aa1Eq3LlqG0ZHHrUpfAt49DFHVphaTqb11TK46xcWZRhrIgSIiF9xxUI+KTNYTeUZDMfBaoTIg9mIgbH3iTzoXZ73IDu091L2GSTeh0F3IkHPkn5LA/UwX7qP61hW5+2xzsjj7AgR7UyEbS79MT6effvldFvI+3j62xf3yeuREo6Ft1OiXgpvj+YdYCh7xB/SXtltCb8AYJ1XhTzTeBXiz6XluHbR5+BVHly7aGBDC0cfE/8CgNeAhroot0RABBpEQLFi9otZ+gYAXeLCZvmgT10MHqhbIgJ5EuBxVrXAbhJ/6QN9mWRsnmNoE8/nPOfIWzc3OMmXG0Z5zzWJ/pNOORannHo8zNoTEI3HKcXFg01/LwxPCh6oMnj2CNq/lfZA2CPVyAPmyOtZF6Xy6OUZAAfxPlEQD5hD2wopg+VEVujLQH1UiahvgK5usMl9SVIPwiNKUk5S1rmgJ+xDH1lmPi3pOuYpbGe6TFx/qGM6RMz5c3WY9hfF6/p5z7DdE72dgJmFc53nvBf1FgEREIHaEFCsmO1SVWIDgC5l8aCfPGhTF3VKRKAIAgzs+ABfx0A1OWfoQxGsJpmD53Nd+fKY4E2rynx/+r2vxS/8/TdjzdqZSZanjmNGspmBI2VZZw8wPSxmiO9NoeCpvz1I5XHqNWDqH6z0xHuHNg/sGWx7oByF1MseeCff3Md13rfX3vW06/1iidD1cuT9I9fF4Lzr+W6/vRvau96nG+rYn3WJJGWmFNZ7Sh2UMIZ1C0J7Yl2L61g/TNg/cn1JuxsFSlJmynIicdmJ+fxxnefdP7gf6BKfl5n3xIHDYXqlv73cD/o97zVL3lw5ypLqlhd5jv/8r7wJP/Nzr2s5CbkvAiJQRwJ8HtyzZ89UpifPvdQ1laKaD67MBgA5cjEiv/lzcSmsW024kBR+w1b1B+3VfFF7vQmkj18ek1X1hrZR6nbOkC+vC5SqsqVdCVtey2gz66osp209EVtPPwmdTqVuBzkiG0/16mHkkgjU72GcIdT28iwvCFt6EtrjfOQRbuRRbyyRl7ouTCnMU1J5H8vSgrCdwpokZZ6SlJlSenXLdLB+FeGYnsAtTISjQt7bUtVgMV2O896bDYkswAkqWDR2JBoWKOwbUmD1NYFeAwiYWTjXec4PaFaVCIiACFSeAJ+r+HzFZ0HKKAbzuYxSt+feUXybtE8ln/i4uBQuMIULNkjYxqCfMjs7OymDReOoi3NTn2QWs7OzI8mBAwcWcSyisHfv3pFsm13FB643JSubqYvHEY/PQcdtmXW0ibZRyGVan6mHQp+pb6mwPpFp5+L4RBf9oJTJctDctIk8yIH21kU2bdqAM846BUcctREhumKE1VRZ5pdX+HssvxG/wr8zx7EMVoPE9XEU60Gu1/GYSKLgXg1rF8QDW/ahhH5ejlPXxQA4Jf0mr/O360hmilMfMcJ7ycieUs6/VGI7vH+vD8uhj88cfPH6UPaUbZSknKSsS8uw+n4f1x288WmJlhsB5vrjPMIyIf1KGpK6pOypx7sIAzy/OPUKfy+uA5pc5rnNc3zTERtQtxevqbz287o6SNhGYb+6+dZEewfdG/OuY3DXRJZV8WnQeTduHc9RSlbnKXVRknvKsGOM7ZyTQpurwrRsOyq5AbAUChdskCztN2k5OSjMDLt37wYDSwa0kgMYlcGk7KcdN6p9K/XjelPMDGYGXlCmtSsZP+i4LbMusWvaNDlneL5QyG8QY9YnYhazFd9p6Wc//pLLd+B/+Y+/hmtv4P8RIHv9VdI42BYbXN2vHdLuQarHpnHsGvp6BQPYXsIsG/kAspos7+ff1PPn9GNI+LMA779yGqHrRi+V1exL2mmnK0DUjRaL62QfeLpUWJ9I3OawFjFi2Ss41vVSf9yPdd7Gt2cDT+YTSeqYJnUYslYjt/c7NirDc/uP/9Ov49LL6/Mv//NeYbb6c1lyj+G9yCy+zzRq8WrmTBnPODVDVDtzBz3fjVuX93k67LirHeyCDK7FBkCeLHjA8KbBAznPeaS7PgR4kTIzMMitj9XFWEoms7OzYaNsknOGbCl8sCvGYs0yCoGjjt6ECy8+C8ced1SqOwOpRFi9NM+6tLA9KSf5QWlSx77MU5gfJOm2JJ9OmU9LoiOpS5eZN36kJOmXpKmmZdmkTzpd3CmOQ9m+uD6U4saQHfSxSvOgIaXVDbSVlWnpWceqXnZ4wk6JDOrFtkH1oY680xIqh2wDsF/cvvDJukQWatHXMKgNqRfbk2I6z7qknE6TPNvTwvqlwnbWDUpZlwj7LJWkjalh87FHhXOc5zprqiy8P5hZ+DJmEjt5jzEzUM8k4zVGBEQgfwI6T/NnvNIMrd0ASAKZSYKYlYCqrTkEuDGkB4iF9eQ5QyZZnDPJhZ86F2ZQrmwCxx9/DE448ViYLb01MLhIrEvyTNPC9qSc5AelSR37Mk9hfpCk25J8OmU+LYmOpC5dZp71TBNhOZGkbnlqWPwfvLxM+PcALvwSe9k31ei9GMj2xcIv3UPfXh3HrizmX4wPF54r/PwAABAASURBVPj8i8Xn7enGKunK87qpPj7ps5outo/T1630CchjiKR5p30M9Rzt40I+Ti2Vx6p5pF7m+UQ8G8YypST1S9N0WzrPfkk5nSZ5tqeF9UuF7awblLIuEfZZKnGb+bl8wombcfzxRy/tUMky77m8P2RhHPVQXxa6pEMERCAfAjpP8+G6mtalT3mr9W9Me1aBTGOAyJGBBHRhirEwUOc5E5ey+6RO6s5OozRNQ+Bd73kN3verb8GG9WsRhw9oVgqs4o+t0r7a+LgdfHnAzEB4kPBfsA9/1+594jwwWhp5v+HiuwMeSEcpgedHkxXndxW2gnjTsveK+tzEZe2uYeAcS/su6me+XhR4CvCBhmJAKC9ObUDdoH7Nqlu/bq2f02/Gu97zWlT9xWCd99ws7aS+2dnZLFVKlwiIQMYEdJ5mDHQEdbxXjtCtWV10M2jWeubtDS9MbQ9SGajnxZkPfXnplt7xCGw742TsuvVyvPt9b8R5F5yOpr1G88dW7bZ6j1VV1KuDB+HDDF6hadiQ0evHUL7ymqzcOrpB9ep57vnb/Fx+g5/TV+D0M0+utPG8D/Bem4eR/NUa9eehWzpFQASyIaDzNBuOo2pp3QYAbwI8yEYFpH4iQAI8bpi2UfL2neejNuWqc2TtOHcrfvOfvgOXXFGffyxsRHpjdGPASBk+hK2W+k45zif9LckMTBnXUgY2VrWSBhcty1iQ64Is5JZ17FUkPXrFliU8h//h7/wkeE5X3fW8gv/Eb+pv+0Z+wkKpCFSVgM7T4lamdRsAPLiKw6uZmkKAQWobHx4Y/BdxzrSVb1POj3r4kY+V6RDTfEMgFvRzcTn+hF6rEDBvX0ngXBcEejWCAO8zRThS1DxF+KI5RKCpBHSeFrOyrdoA0EFVzEHV1Fl0/OS7suKbL99xtd88eyle9frrsHbdmnGHVrP/RFYxGJ1ooAaVTqC9a8dzlufuLbsvK30VRjGgiE1m2qGNZlKQiEC1Ceg8LWZ9WrUBUNRNppil0yxFE2jjRanIc4Z8i15TzTecwBt/5Gb8zM+9DttOPxkbN64f3rEmLZObmV0gaf79dVrg5bpL2p9R8iv7i/Ay/xwm3jTCm6NH6NbALjxXt247CT/93teC53DVXSx647fo+arOX/aJQBUJ6DzNf1VatQGQP07NIALNIVDGBbiNf2ZR5SPmgovOxB/9h1/BDbdc7GYyqKqtyP6KbDaY27GawPtIDJiAw/U3XxzO2QsvPgt1eOmaX4dVko0iIAJNI9CaDQDdZJp26JbjTxlBcTmeljOrztNyuA+b9ZjNR+Lyq87FbW+9Ba983bVYt37tsK4Vr5/WPHMFS8Wr9K4AgaXrwnIFzCrYBJ6bPEff9LZbcMXV54HnbsEmTDRd0b/8Knq+iaBokAi0nIDO0/wPAG0A5M9YM4iACIhArQnwp8TvfPer6/unALnQZ6CZllwmkdJlBNLMmV/WoZUVGzasw0/+7Ktq8bP/Vi6QnBYBERiLgL4QGgvX2J1bswEwNhkNEIGWE9DFt+UHQIPcL8YVBqMSTPCz9fHGQC8RmIqA7m1T4dNgERCBBhDQBkADFlEuiIAIiEDeBE7bcgJ+/J0vx7nnb8t7qqz1S58INJrAOedtDecmz9FGOyrnREAEREAEMiGgDYBMMEqJCIiACDSbwPZztuAf7X0Xdt16OY46ehM6nbrcPpq9LvKuvQTMLJyLu269Av/4934KO87d2l4Y8lwEREAERGBkAnqCGxmVOoqACIiACPzET70Cv/KbP4ojjtzoMGrwk/fcf5IuBhBjoAQGPAd/+TfeBp6T0EsEREAEREAERiTQmg2A2dnZEZGomwiIgAiIwDACZ+/Ygpe98kr8xLteUYs/Bxjmh+pFoM4E+LN/noO3vuoq8Nc5dfalaNv1PFg0cc0nAiJQNQKt2QCoGnjZU08CbXpwaJOv9Tway7OaAcc//r134dobd5ZnxGgzq5cINJIAz71/8s9+SsF/I1dXTtWBgJ6R6rBKsnEYAW0ADCOjehFoOYEybm5lzNnyZW64+3JPBESgygR27dpVqHlFz1eocy2ebG5urnDv9bxSOHJNmCGB1mwA8ETVhT/DI6elqsq4yZSFmudM0XOXMWfRPjZpviuvOS/8OQD/H+SV9EtGiUDDCPBc45/gXHXt+Y3wrOh7qu4xjThsSndC8UTpSyADpiTQmg0Acir6RsM5Jc0hsGfPnuY4M6InRd7k2sh3xGWobLc3ve0WvO9X34xTTjsO69atKeGfQcOKc+qf5xOfJh0DPMdOPe14/OLffzN47kGvsQnoOXBsZLUYwI2dIp9XOF8twMhIERhCoFUbADphhxwFqhaBIQSKfFgqcq4h7qp6AgI7ztuGf/FvfzH87wEnGJ7nEOkWgUYRuOVll+EP/u0v4JzztzXGLz6XFbX5W9Q8jVmcmjlS5DNEkXPVbBlkbk0ItGoDgGuiGwApSMYlwOOmjRf8oh7OyHfcNVH/ahDYfOyRuP7mi/D6N9+I3a+4Ahs3ra+GYZAZItAMAjyneG7xHOO5xnOuGZ7FXhR1by1qntgrfRZNgM8rRfwKQM8rRa+s5suDQOs2AHgD0Mmbx6HUbJ08bprt4XDv6HueN1Wej5xjuAVqqQOB2956M37pH7wVJ596PNasWwOYlSuaX/wbcAzwXDr5lOPwvl//kUb/7H/fvn3I88X7TJ76pbsaBPbv35+rITyO5ubmcp1DykWgCAKt2wAgVJ68eQY0nEPSHAJ5P5jUgRTPmTzs5HmYl+487JXOlQnwfw/4+3/0c9j98itW7lhAq6YQgSYQmL31Cvz+v/l57Dh3axPcGeoDv71lcDW0wxQN1Kv7zBQAazY0r2c2Pa/U7ECQuSsSaOUGAIlwl5A3BeYlIjCIAC/2vJHwwWRQe5vqyCCKIpBJVn5TF8/DrPRJT/kE+NPkG2+5GK970w2Yffnl2LixtD8HKB+GLBCBKQjw3OE5xHOJ5xTPrSnU1WIog/Ssn8uoj3prAUBGZkKAzyt8dstEWU8JjyM9r/RgKGkEgdZuAHD1eFPgSc28RATSBJLglDeSdH3b87wBZnHOUAd1tZ1nU/3nnwP8ym++DSefcizWrJkpwU1NKQL1JcBz5iQ/d375N96KN73t5vo6MoHlfC5j8MZ7xATD+0N4D6ce6utXKtMaAnx245cW0x5HBEYdOo5IQtIkAq3eAOBC8qROLhK8YbBO0l4CPAb40KDgdPgxkD5nhvda3kK2vJHyfKOO5T1U0yQCZ20/Df/sD38O/H+WF+6XJhSBGhPgP/j3+37unL1jS429mNx0Bm+8R/B+QRlHE+8zyT2cesYZq77NI8DjiM8ckxxHHMOx1NE8MvKo7QRavwGQHAA8wRn08WTnSZ+VJPqLTLOyvS16+LBA4drzGMjqoYG6KDy2qiK0J6tjkT6RGdmtdKywncK5OSar+cvQQx8o9GOQsK0Mu6o4J3+yfNPsJXjtbdeH/0Xgpk0bCjNTE4lAHQnwHNl16+V+ztwAnjs8h+roR1Y2J9fY1e4zvL9Q2I/X4KLu4ZwrK1+lJ18CPJZ4fPA4KeN5hccKhXZMK/mSqo72rHhNy3uS8bS9OiQHW6INgAFcJlnsQWOyugkNMHHFqkG2qG4Oc3NzA4XrRFkR6oiNPOmpy8ywe/fuIHv37kVVhDaZWZ/DiG6t2I3+zg1hy3q2U1ZUUuHGcdY0D74VRjOSafxzgF/77R/DiScfi5kZ/jmA+bhcRfohvqgZA54bJ568GTxX2vazf4zw4j2E95NBwjbKCGpW7ZJc76mP13PKsPs328wM7Eu7VlWuDqUTSNaK6zVI2E7JwtDkWDKz8CzI42XYsTRq/YEDB7IwrRY69lbo2XlcW7jWZgaz+Hm7isC1AVDFVZFNtSOQXOh50tfhAp1czMyqe3Eq+yCYZk0TvnzAoJ6yfSl7/jPPPhW/96/ejVtfdVUBpmgKEagfAZ4bv/ev3oMzzjqlfsY3xGIGfsk9fJz7OPvymm+m+2lDDoWp3OB93ywO+nlsTKVMg2tPoKrXBm0A1P7QkgNlE+DFPnloKNuWSebnxYk+TDK2qWPII4s1JVvqob6mshrFr2M2H4FbXnYZ+OcATI84Isc/BxjFIPURgYoQ2LRpPW7efWn/3Gj7z/7LWBZu0jL4zyJY4zW/7df7MtawKnNy7XkMVMUe2VEdAjwueJ2pikXaAKjKSsiOWhJoysWeFyb6UstFyNhociCPLNVSH/VmqbOOum576034jX/6EzjhpM3wL0hycUFKRaAuBHgO8Gf/v+nnBM+NutjdJDsZ/HOTNovgP+Gi631Col0pgzuufbu8lrfjEOB1xszA68444/Loqw2APKhKZysIMKBr0sWevtCnVizeECfpPzkMaZ6qmnqrcNGfyokMBp9+xsmY+5c/i1e+9poMtC1ToQoRqA2BV7zmGj8X3o3Tz9TP/staNAb/eczN6z3vJ3nols7qEeBaM7irnmWyqIoEeLyUbZc2AMpeAc1fWwK8wdfW+CGG06c2B6n0fwiaTKrzetjMxLiClByz+QjMvvzy8JPnm2YvwaZM/xygICc0jQhMQYB/AnOTH/v8kxieCzwnplCnoRMSyPshnPeTNt9PJ1yW2g3jccS1rp3hMrg0Atwsmp2dLW1+TqwNAFKQiMCYBHjBH3NIbbo32beVFqEov4uaZyVfq9D2xh+5Cb+95ydx0snHIrOXFIlADQiceNJm/Naed0A/+y9vsXgdLiJo4zzleamZiyBQxHFUhB+ao1gC3AQoc4NQGwDFrrdmawiBJl/wy74olXWIFLWmRc1TFsdx5t16+on43T/4abzqddfCMvhPOkSg6gT4py+/+y9+FttOP3mcU0V9a0qgrffTmi7X2GZrg2dsZBqQIlDm8aMNgNRCKCsCoxAo84Qdxb4s+rTBxzSnov0tc9c37XfZ+WM2H4ndr7gCr33jdXj1G64NsuPcLZOapXEiUEkC28/ZEo5tHuOvu+16P+Yvh372X+5SFbkRW/T9pVyy7Zq9yOOoXWTb4S03CMvyVBsAZZHXvLUloOCttks31PCi11QPhIuX4g0/ciP+5M9+Lcir33Dd4saRS+ooAtUkwMA/Ob5f/5Ybq2lki6wq+vpb5kN+i5ZVropALQkU/fyZQNIGQEJCqQiMSKANN3P6WNZFacRlyLQb/c1U4SrKip5vFXNKbzYzzMx0grz2tuvw23M/iVNOOx5jvdRZBCpG4ORTjwt/6/+6N10fjm0e452OVcxKmVMEgTbdT4vgWYU5it5IqoLPsiF7AmVdG7QBkP1aSqMIiIAIiMCEBM7feQbe4N+Svup114A/nR5VjfqJQJUI8NjlMcxjmcd0lWxruy1lPXC3nbv8FwERWE6grOuRNgCWr4VqRGAogbJO1KEGqWFqAlrTqRFmruCU047DP/ln7wK/OR1RubqJQKUI8Jcs//T3fwqnbtEvWSq1MCUZo/tEcy/GAAAQAElEQVRMSeA1rQiIwEAC2gAYiEWVIiACIiACZREwM6xZOxP+4bQ/+l//HiiveeN1bg5/Pj1IVAeIQdkM+O9X8Fil8HjlMWzGdYFeIiACIiACIlAZAtoAqMxSyBAREAEREIE0Af50+s0/egsor73telx/004cdfSmdJc4r08RKJHAkUdtDMfma2+7LhyrPF557JZokqYWAREQAREQgaEEtAEwFI0aREAEREAEqkLg1a+/Br/7L34aW08/cZlJqhCBMgnwmPydP/hpvOYN15ZphuYWAREQAREQgZEIaANgJEzqJAIi0FQCs7OzTXWtUX7NrJnBlm0n4tf/0Y+BP69OOaesCJRGgMcij8kt204Aj9HSDNHEIiACIiACIjAiAW0AjAhK3USABBQskoJEBMohwJ9a3/rqK8GfWs++4nJQtp+zpRxjNGtrCZy947Rw7PH447H48tdcpT9Nae3RMJrjbXl22LVr12hA1EsERKBUAtoAKBW/Jq8jgbbc4NrywMJjsOg1LXo++tgkeeVrr8a/+7NfDXLb226C/v07QAyAohjc5sdccvzxWIRetSJQxr1Nc9bqEJGxItB4AtoAaPwSy0ERGJ/Anj17xh+kESMTKONhcGTjatBx7bo12HTEhiCv8G9ff2vPO3D6GSfXwHKZWGcC2844Cf/wd98OHnPJ8cdjsc4+tdH2oq+/ZW74ljl3G48t+SwCdSGgDYC6rJTsrAyBubm5ytgiQ7IhUPSaFv0Amg2lSmrBeReejh/58V142auuwC0vuxTX3nAhjj7miGoaK6tqR4D/1wkeUzy2bn3VleFY07/wX7tlXGRw0dffoudLO1v0va3o+dK+Ki8CIjA6AW0AjM5KPUUgEODNvOm76m27iRe5pvx1BecLB5M+piQQDz/u+KPxG//kx/Enf/qr+L1//W6ctf00bzBJUb+Jb/A8PJZ+71+9OxxbPMaOP+EYP670rjsBXoeL8qHM+ynvNUU9rxTJtKi10zwi0FQC2gBo6srKr1wJlHlDz9UxV97Wm3hRa1rUPL6UzX/3POx0LPw5AL+t3bLtRLzv196Ef/5v3ovfnnsHzjjrlF4vJSIwGoHTzzwZv7Xn7eEY+qVffzO2bDsh/CN/m47YAB5ro2lRryoT4HW4iMC4CvdT+lrEWhQ1TxG+aA4RaDoBbQA0fYXlXy4EuKtehRt71s7Rp7bexItYU/LNes3arG+Q75s2rQ9/o/0T77oVb3v7btz6qitw466Lcc31F+CYzfrTgEHMVIdwbPAY4bHCY+ZH/djhMZT8vb8YNY9A3vc6bjDkPccoqzI7OwvaMkrfSfvo3jYpOY0TgXIIaAOgHO6atQEEeGPP+6ZaJCb6Qp+KnLNqc9F/csjDLj4gUX8euluqc1W3GfD/6m+9DX/yp38ff/Bv34tzztva4B+rQ74BEzPYce6W8I0/j5Vf++0fxTHHHgm9mk2AgTGvy3l5uX///rxUj62XtujeNjY2DRCBxhLQBkBjl1aOFUGAN9U8HyCK8IFz8MGAvjDfdiGHrNeU+ubm5tqONmP/V1fHn2sfedRGbPZg7rStJ+Dn/t4b8Po337D6QPVoFQEeEz//y2/EaVuPD8cKjxkeO62C0FJneV3m9TlL93k/3bdvX5YqM9HFextty0RZTwnZkWGvqEQERKAmBLQBUJOFkpnVJcCbH2+C1bVwZctoOx8MVu7VrtYs15R8qa9dBAvwdswpNmxYh5e/5iq84S034LqbdgY5a/upY2pR96YQ4Nonx8Hr33x9ODY2blzfFPfkxxgEeH3OKmBngM37KX9dMIYJhXWlbbwnZTEhmZFdFrqkQwREoFgC2gAolrdmaygB3gSjKEJWN9YiMPFBRTfw4aTn5uYwzZryWOB46hk+i1omJTDpuJt2X4I/+bO/H+TH3nWrqzHJxD+cry+7H3vny8IxwGPh5pdd6seA3m0mwICd12tetyfhkNxPGWBPMr7IMbwnTeMrGXE8mRVpt+YSARHIjkAtNgB4Qa2rZLdUo2vKgtXos6lnmkD6xsqbJB8KqiS0iUE/b948TppwA6cfSyW9JtPmx1nTNF+Om3ZujR9KYOIG/hKA/9tAyi4P/Pb8y59GIr+99x3Yfu6WiXVrYDUJ8O/7ubZc57n/x8+E9d5162XgMUDhMVFNy2XVUgJLr/UsL+0zTZnXbd4feZ/k9Zyy0j2c/difdtTtfpr4Sh8pK/nJ9sRXjpuG8dKxZLdUlvZReYHASuuUV9vC7MXl8vJlJb3FeVf+TJXcAOCFgBdSiplh9+7dtZS9e/eWssJZ8DIzmBm4Bllf7EuBUvCkZEbhsVwloU1c04JxZDYdWSY+mMXH6KDj3SxuY19KFgZQD4U2DBO215lvFpyK0ZHNLOdesA3ves+r+vKOn3kFXvaKy8P/MeDKa88Lfw+ezUzSUjQB/rsPXEP+y/6zL78MP+lry7V+57tfGdaba1+0TZpvfAK81vKaahZf04u63nNOXs8ptGGYsN/4XlVrBH2kDPOR9WzPylfqoy6zYte0WtQns4bBK/kVLZNZO90oHnNF+8mNrumsrs/oSm0AcKF5UeAF/sCBA6DUB2UzLeUa7PWNDDMDT8Zmeimvqk4gfW3g8cjjchSb2ZdipuN3FF616ZOToRs3rsMv/tqb8Md/9iv4o//wPuy85KycZpLavAlcePGZ+MN//4thLd/362/GBl/bvOeU/uwI8HnDzMKXP7reZ8e1TE1a0zLpa24RWEygMhsAvDAkgf9iE1WqCoEkkGIwVhWbZEfzCfB4y+LawOOX15nmE2u+h3l5aGbg/zrwxJM249TTjse73vsq/M4/fxf483F9Y5wX9ez0nnP+1rBWXDOu3WlbTgDXkmtqZtlNJE25EeD1nl8E8Xo9zSQcTz3UN40ejc2GANeCazKNNo43M2hNp6GosSIQE6jEBsDs7Cx4YkOvWhBgMKZAqhZLVXsjeZzxeMvKEV5neL3JSp/0lEKgkEnXrJ3By199JX7651+Dn/KNgN2vuBz8SXki/FfkCzFEkwwlwDVI1oMp14g/8+eaveI1V4FrOHSwGipHgIEdr/ejfuO/mgPUQ33Uu1pftedDgOzNLNNf9GpN81kraW0XgdI3APiAz4t0u7DX31sGUryw198TeVBVArw28DjL2j5eb7QJkDXVIvUVP9fatWvw3r/3evzJn/5KXxhkFm+JZkwT+Kmfe3V/Pbg2P//Lb8C6dWvSXZSvEQEGdnmYS716XsmD7Oo6yX71XuP3oF6t6fjcNEIEEgKlbgDk9YCfOKc0XwK8AOc7g7S3lQBv7HkE/wlPbgLw+pOUldaIQAmmmhmOPe4onHzqcX254ZaL8E/+2TsXyYUXnenWmQTZM7jgojPwj3/vJxfx5hqk12Szr5EZ5/Yl0LtWBGZnZ3O1V9f7XPEOVK41HYhFlSJQCQKlbgDk+YBfCbotMCLvC3wLEMrFAQS4ATCgOtMqXn+KmCdTo6UMVUFw9o5T8bO/+NpFsvuVl+Pyq3b0hT9RN1NAOu6amRnILs2SP+9fynv7OaeNq1r9K0iAwTk3ZfM0jfo5T55zSPcCAbIm84Wa7HPUz3my1yyNItB8AqVtAOikbcbBxQuwgqhmrGVVvOC1gcF5EfZwriLm0RyZEai0op/5+dfgj//0V/rCPxuYWVPabRZ1fXVmDO/5e6/rcyTTn/2F18JMmyl1XdOV7C7qel/UPCv52pa2olgXNU9b1k1+todApyxXddKWRT77ebUBkD1TaSyGADewiplJs2RDoNpajj3+KJy29YS+XHfThfiHv/MT+Ed737FI3vaOWazV36oHBm99+65FbMjqt/a8HdfdeGGfI5mSLfRqHIGiN2H1vJL/IaQ1zZ+xZhCBaQmUsgGgC/C0y1at8VrPaq1H3a0penNQx2+NjpiamXrGWSfj3e97Ld7zS69bJG97+ywuv3IHLrl8+0A5/oSja+bpcHOP802RYX6SAVks5fPuX3wtzjz7lOFK1SICExIoOjid0EwNG4OA1nQMWOoqAj0C2gDogVAyOQF9izo5O41cTKCMYFwPD4vXoMqlpth24SVn4A//w/vwx3/6ywPlxl0XNcVV3DR7yUAf6fu//ve/iJ2X8h9ObIy7cmRMAkVv+Op5ZcwFmqB70fdxrekEi6QhrSdQygZA66k3EEDRF/wGIpRLIiACKxNoTOvGjeuxZdsJ2HbGSQPlzT92C/7h7/7EqvKOn3k5jjp6U/jbeDMrLOWc7/iZV6xqH314y4/dPNBH+r719BNBFo1ZWDkiAiIABeQ6CESg+gRK2QBQsFj9A0MWikAZBHRtKIN6XeZsj523vOwS/PyvvGFV+ZGf2IWTTt6MjZvWFyonnrQZP/Ljt6xqH3242X1pz8rJ0zoQ0H2mDqs0no1a0/F4qbcIlLIBIOwiIAIiIAIiMBYBdV5G4NIrtuPDn/pDfPW+Py9U/vbTf4hLr9y+zB5ViIAIiIAIiIAIVJ+ANgCqv0ayUAREQARaT0AAREAEREAEREAEREAEpiegDYDpGUqDCIiACIhAvgSkXQREQAREQAREQAREIAMC2gDIAKJUiIAIZENgdnY2G0XS0jACckcEREAEREAEREAERCALAtoAyIKidIiACIiACORHQJpFQAREQAREQARaQ0BfCOW71NoAyJdva7TrRG3NUjfOUR271V9SWSgCIiACIiACIlAOgV27dpUzsWbNjYA2AHJD2x7FujC0Z63z9pTBuI6nvCnXTr8MFgEREAEREAERKIkAn82KnHrPnj1FTtfKubQB0Mplz9bpoi8M2VovbW0nMDc313YEFfdf5omACIiACIiACJRFQM/5ZZHPb15tAOTHtjWaFUC1ZqkLcbTI40m7zIUs6XSTaLQIiIAIiIAIiEBpBLgBUOSvM4t8DiwNaskTawOg5AWo+/QKoOq+gtWzv8gbjW4y1Vv/pRapLAIiIAIiIAIiUC6Bop6XFFcUs87aACiGcyNn4W5gUReERgKUU0MJFHFc6SYzFH+VGmSLCIiACIiACIhAyQT45Uzez02KK4pbZG0AFMe6cTMVEaQ1DpocGokAbzT79u0bqe8knXgT0/E7Cbmix2g+ERABERABERCBKhDgcxOD9Lxs2b9/f16qpXcJAW0ALAGi4mgEGJwxSButt3qJwPgEeHwxUB9/5MojqHNubm7lTmqtBgFZIQIiIAIiIAIiUBkCDNLz2ARgXFEZJ1tgiDYAWrDIWbrIk54nKYOzLPVKlwgMIsBAncfboLZJ6hT8T0KtvDGaWQREQAREQAREoFoEuAnA56ksrGJcEUURFFdkQXN0HdoAGJ1Vq3vyBGUgxpNeJ2mrD4XCnefxxpvDNDeb5PjlhkLhDmjCSQlonAiIgAiIgAiIQAUJ8HmKz2WUScxLnssYV0wyXmOmI6ANgOn4NXo0T06KAv9GL3NtnOPNJtkI4A2Hx+ZKxrOdxy6FNxhuJKzUX21VIyB7wk9WGwAAEABJREFUREAEREAEREAEqkqAz2UUPmeN+lyWPJvpuazcVW3NBgAPTAYPkgijMuDJSalz4JTYTx8oZgaz8oW28KJJKfcSUL/ZyYzCtV3pWGY7OVPq56UsRkMRpI9Ls/KvRWaxDTxPeF5R6oqebCn0hWIW+2a2kLKePlLq6iftTvtJn8wWfDSrT56+FC27d++e+jmAzCk8jrgWRfug+RYTyGJNzcY7b/bu3bvYiAJKBw4cmPrYNbPwc3seu5QszE6fC6s9l/F8Yf8s5k10UR/FbLw1NFvcf28Ja5oFh0l0tGYDYBI4GlNfAslFgTcFXjATqYpHtIcXGoqZIauLcFX8kx0iMC2BJo1PrkdmhvQ1qUo+1vmalPAlWwp9oQziy3pedylm8bW3Ttdf2mq2+DiiT4N8VV1+BMicwuOIx5xZfCzlN6M0i0B2BJJjl8evWf2OXV0Hpz8WtAEwPUNpqBCB9IMgL3AVMm1FU+p6EV7RKTWKwOQEGjOSDyoMEOp0PSL85JrEayrLVZVp+dJPCvVU1UfaxXXgN1y0lWVJ9QhwbbhG1bNMFonAygR47JpVfyOA12kzA+1d2SO1rkZAGwCrEVJ7bQjwAamOD9ppwLyo8QKXrlNeBNpHoBke81zmOV1nb3hNpR9V9IHBVlZ8qYf6qugn+XMd6raJVEWWedvENTIz/aovb9DSnwsBXgd5vclF+ZRKaRftm1KNhvcIaAOgB0JJvQkkwX+9vYit5wWuqg+isYX6FIGcCTRAfZMeVnhNoj9VWhZeIxlsZWkT9VFvljqn1UXu5D+tHo0vlgDXjM8lxc6q2URgegI8dnndmV5TdhpoD+3KTqM0aQNAx0AjCPDbkUY40nOCD6K84PWKSkSgVQTq7izP3aY9rNCfqgQ05MtrZB7HCfVSfx66x9VJ3uQ+7jj1rwaBqhxH1aAhK+pEgNedqhy/tIP21IlfHWzVBkAdVkk2rkiAF4cVO9S0kRc8PgDW1HyZLQKTEqj9OJ67tXdigANVuNbShrz5Un8Vrr1VsGHAYaCqEQlwM6lqvygZ0XR1E4Hwd/ZVuAbxeqzlyJ6ANgCyZyqNBRNo8sWBD7sF49R0IlAygXpP3+RzlgFNFR4IizhCyl5Hzt/ke1sRa1iFOdp0zlSBt2zIlgCvQ9lqHE9b2fOPZ229emsDoF7rJWuXEGj6xUEPD0sWXMXmE6i5h00P2sq85nLuovjq2lvzE7FC5vO4rZA5MkUERiZQ9nWwqOv9yEAa1FEbAA1azDa60oaLQ1u+cWvj8SuflxOoc00bHvT5QFjnNRrH9jLXsw33tnHWQn1FQATaRUDPvvmutzYA8uUr7TkSaMvFoS1+5nioSHV9CMjSGhAo65rUlqC4zI2HGhx+tTORm2ZlnTO1gyWDK0egrOuRzpl8DwVtAOTLV9pFYGoCfHiYWokUiEAtCNTbyLY8sLTFT117630+ynoREAEREIHBBLQBMJiLamtAoC0PoTVYCpkoAtkQkBYREAEREAEREIHKEChrI1TP+PkeAtoAyJevtIuACIiACIxIoO7dynpQKppbmx7M2uRr0cdRm+bTcdSm1ZavIlB9AtoAqP4ayUIREAERaAMB+SgCIiACIiACIiACIpAzAW0A5AxY6kVABERABEYhoD4iIAIiIAIiIAIiIAJ5E9AGQN6EpV8EREAERGB1AupRGwKzs7O1sVWGioAIiIAIiIAILCagDYDFPFSqEQE9hNZosWSqCKxCQM0iIAIi0FQCel5p6srKLxGYjkBZ14ZSNgDKcLaMOac7JDRaBGICu3btijP6FIHmEpBnIiACIiACDSCgZ5YGLGIFXFDclu8iaAMgX77SniOBtlwc2uJnjoeKVFeegAysEwFdk+q0WrK1CgR0zlRhFWRDnQjonMl3tVqxAaDdyHwPojK1a23LpK+5RSAjAlJTKwJ6MKvVcsnYkgns2bOnZAuKnX5ubq7YCTVbIwm05T5T1vlSygYAj9QiA7e2HETk2jYp68QpknMbfCySp+aqHgFZVB8CbQtm6rMyslQEqkFAz9zVWIcmWFFkrFgGrzLvp6VtABQZ1BQ5VxkHUJvn5I2myReIMi8ObT6u5HuhBDRZjQjoflqjxZKppRPgPbyN58y+fftKZy8D6k+g6edOmf6VtgHAwI0XxrwPzyLmyNsH6V+ZQJkn0MqWTdfKjY2m+jYdGY1uFgF5UxcCup/WZaVkpwiUS4DP+HyGKdcKzV53AjyOmnrfKduv0jYAeFAyuMnzAkG4nINzSZpLoKkXiP379zd30eSZCCQElNaCgO6ntVgmGVkhAm0/Z+bm5iq0GjKlrgR4HOUZK5bBpQrXhlI3AAidQU4eC1sFuPRPUgwBXiC45sXMlv8s+vlc/ow1QzUIyIrqE+A9mtfY6lsqC0WgGgT4PNL2c4ZfzuhZphrHY92tyCtWLINLVe6npW8AED4XlhdL5rMQ6mr7hTcLjnXTwTXn2tfN7rS9vDDwhskbZ7peeRFoKAG5VXECvKbyHl1xM2WeCFSGAM8ZPo9UxqASDeGzDJ9p+GxTohmaugEEeB/iuVVnV2g//aiCD5XYACAIXiwJhvlJhRcYXmioa1IdGldvAlx7HkeUunlCm3lh4A2zbrbLXhGYjIBGVZWA7qdVXRnZVVUCOmcGrwyfafhsw2ecwT1UKwKjEUie8UfrXZ1eVbw2VGYDgMvEhY2iCLxIUFg3iiRgeYHhhWaUMerTXAJzc3OYc+ExRKmypzx2aaM2rqq8SrItNwJSXDkCvCbxeqT7aeWWRgZVkADPF4rOmdUXh89lyTM+ma0+Qj1EYDmB9HHE5+flPapTw+O8qteGSm0AJEvGxaXwQkFwKwn76EElITd6SmYUcuamSRWEtiQyuifDeya6eIxQVjqOymijTek1GO7JaC3URaHfg9aT9RT2GU1jdXvRB/pCGeRr0XW0IxHaVl1yo1lGH+hP3hybpn80utn24gNQVtev5JrEdcnCyuQ4yupYysKmcXVkZTuZjirkNq6d6j86gSzPGa4VhWs7ugXDe1JXGccc7R8ktCWR4VaP10J99JPXm6yuXQy0xrNCvetOgMcRJcvjKKvjkXpoF49znldVZF3JDYA0KIJbSdJ9lV+dQHIw7t69G5S9e/fiwIEDlZC9bksiZha+xV/do9F7rHQcldE2uuUr9xx1TRO2XHez7PmubOX0rYmfZtY/dulTFY5f2pFIk/jmzLYS150sfZz+KB9fQ5bXrvFnXz4iz/N0+Wz512R5fIyjK3/P2jtDHc6ZcY6VPPsm9zWmZgayY9CV1dFDfVlIVvZITz0JZHEMZa2j6iQrvwFQdYB1sS95KGNwwptFHexObjhZ3mzq4PeoNk67pnXiy2OgTscu17BOfHnjK54vKUmaRKCO52mT+MuX+hGo27WXz4/JvY3PIPUjLotFQARIQBsApNBwqftDGW82vEk2fJnGci/LNSVf6hvLgAI7c+1pY4FTZjoVba8qXz7AkS8f6jJ1ehRl6tMoAjyOeKw3yik5IwI5EWjCtZebxlW9t+W0bFIrAo0hoA2AxizlYEd4cW7CQxkDFDMDb5qDPW1PbR5rymNkdna2chBpE9e+coaNaRD5ct3GHJZrd55LfIAri2+uzkl5oQSacp4WCk2TtZpAU669Vby3tfrAkvMiMCIBbQCMCKqO3Rhw8OJcR9uH2UyfhrW1oZ7+57WmDASpvyocaQttqoo909rBdaNP0+rJajwfQLPSNYEeDWkIAR7TTTpPG7IscqPCBLhhVmHzxjaN9zZuKI89UANEQARKI6ANgNLQ5z8xL8r5z1LsDHzQ5ANnsbNWZ7a815T6q3Aj5xrTluqQz8YS+lQVvtl4NKkWjWsCgaaep01YG/lQTQI8Z/gcU03rJrdKG8qTs9NIESiDgDYAyqBewJy8yRQwTSlTVCWIKtr5ota0qHlW4sc1Xqm9zm1l8+X8pfOt8wLK9j4BHUd9FMqIwEgEmnzO8N4yEgR1EgERKJ2ANgBKX4J8DGjyTYbE2nijKWpN+e1Emd9SN31ty+bL86ds0fz1J9D087T+KyQPqkag6edMUc8oVVtX2SMCdSSgDYA6rtoqNjf9JrOK+41sLnpNi54vvWhlbj6k7WhqvgIPaU1F2yq/dJ62arnlbAYE2nDt1XUhgwNFKkSgAALaACgAsqbInoC+Rc2eaVoj+abLRebLnLsoP8vaYClr3sVcVWoCgTacp01YJ/lQDQJtCYx1j6nG8SYrRGA1AtoAWI1QDdvbcqOp4dJMbHIZa9qWOSdelCkGtjp4moKbhlaDQBnXhmp4LitEYDICOmcm46ZRIiAC+RDQBkA+XEvV2pbgok03VK1pqaeUJs+QgFSJgAiIgAiIgAiIgAiUR0AbAOWx18wiIAIiUCiBCmyaFeqvJhMBERABESiOQFu+rCiOqGYSgXwIaAMgH67SKgIiIAIisIyAKkRABERABERABERABMokoA2AMulrbhEQARFoEwH5KgIiIAIiIAIiIAIiUCoBbQCUil+Ti4AIiEB7CMhTERABERABERABERCBcgloA6Bc/rnMvmvXrlz0SqkIiEC9CczOzpbpgOYWAREQAREQAREQAREomYA2AEpeAE0vAiIgAu0gIC9FQAREQAREQATqREBfKtZptUa3VRsAo7NSTxEQARGoNYFSfwFQa3IyPk1Ax1GahvIiIAIi0FwCut43c221AdDAdZ2bm2ugV3JJBERgWgJl3sintV3jq0VA3wpVaz1kjQiIgAiIgAiMSkAbAKOSqlE/PeTXaLFkqggUTKCkwK1gLzVd3gS00Zw3YekXAREQgfIJ6Fpf/hrkYYE2APKgWgGde/bsqYAVMkEERKBqBMq5mVeNguyZlgA3mrWZNC1FjRcBERCB6hJQLFHdtZnWMm0ATEuwouP1kF/RhZFZIlAygVICt5J91vT5ENB9Jh+u0ioCIiACVSCga3wVViEfG7QBkA/XSmjdt29fJeyQESIgAtUisH//fhT57W21vJc1WRHgZpK+IcqKpvSIgAiIQHUIKIaozlrkYYk2APKgWhGdejiryELIDBGoIIG5ubmirNI8DSbA40ibSQ1eYLkmAiLQOgLc2GUM0TrHW+SwNgAavth8OOOJ3HA35Z4IiMCYBHhzj6KogF8CjGmYuteOAH9RovtM7ZZNBouACIjAMgL85p+xw7IGVTSKgDYAGrWcg53hicwTWg9og/moVgTaTCD34K3NcFvkO+8zuse0aMHlqgiIQKMI8JdcjBX45UCjHJMzAwloA2AgluZV8oROHtD0kNa89ZVHIjANAV4b+GuAPK4N09ilsfUioOOoXusla0VABEQgCfz5ZQBjBRFpB4HKbwDwgKTwwSItrKM0ZZnoSyJpP5lP6rPwlfooycM+H/izEF5AsrBvHB3kQl/aIONwyapvGXw5Z1b2V11PFscteVGy8pU28drAbwGyuC7s2bOntD8xyMr+cfRktZCJH2UAABAASURBVA5115McRzyWxuGnvntABmXcT3nMce6ihfNKmkWA53/RcuDAgWZBXMGbrM5R3ud5jeYzRFaBP3UlUvQxUKX5yGCFJaxEUyU3AAiOB6OZYffu3UH27t2LtCT1Zgb25cJXgugYRgzyk36l/WSedRQzQ5Z+UldWMobbmXXlBZ982iCZQRtDURlcuaZjmFjrrlnw5XWBYhZfG3g+ZwEluaZS33QyF67PWdg0jg4GUNPaPcn4cWxsS99JOLZ9DM+/oo8PnTNFE2/ufFnc28bV0Vyaiz3L8jzN6jqzf//+cJ+nPj6PJDLuGjapPxmYVTs+rdQGwNzcHMwsBPzjBALsywPHLH4IXny6VK+UnCw8QGj7OBbWyc9x/FJfERCB6Qjw2kDhdZQynbaMRkuNCIiACIiACIhAIwkkQT9jGUojnZzCKTLhc5lZ9eLTymwA8CAipCk4h6HUUeWHX9o2SeAfnEt90E8zAzcTUtXKioAItJwArw0UXmvKRqH5RUAEREAEREAEmkWAsYeZgQFuszzLzxs+l83OzuY3wZiaK7EBQCBZHkRVg5ysCR/IaVtSziLlZgJPxCx0SYcIiEBzCPBaw2tOiR5pahEQAREQAREQgQYR4HMFY48GuVSYK4x1zayw+VaaqPQNgKyD/8RZQuZBmpTLTmkLH8jzsIMnojYB8iArnSJQbwK85vDaU44XmlUEREAEREAERKApBBhr8LmiKf6U5Qdj37LmTuYtdQOAD6YM1BNjsk55kPJgzVrvJPpoyyTjRh1DlqP2VT8REIH2EOC1p5TrYHsQy1MREAEREAERaDwBfuHYeCcLcJCxb9lxW6kbAHwwzZtz2YDpXxE2VOFgoq8SERCB6hEo4hq01GuVRUAEREAEREAEmkFAzxHZriNj4DK/nCltA6CoA6kKgTEXOdvDZrC2ouYZPLtqRUAEqkqA18GCbzRVRSG7REAEREAEREAExiSgGGNMYCN0LyoWHmRKaRsARR5IZT74Fr24Zfo66ABTnQiIQDUIFHstqobPskIEREAEREAERGA6Anp+mI7fsNH8cmZYW971pWwAFH0gEXBZgXHR8xbNNu8DVPpFQASyIcDrYDaaRtCiLiIgAiIgAiIgAiIgAisSKDpOTIwpZQMgmbwNqR6627DK8lEE6kGgqBtNPWjIShEQAREQAREQgdUI6NlhNUKTt5fFtjUbAGUBnvyQmGykNhwm46ZRIiACmRGQIhEQAREQAREQgYYQUGyR30KWFZ+WsgFQlrP5Ld9gzW3xc7D3qhUBEWgnAXktAiIgAiIgAiIgAiJQVQKlbABUFYbsEgEREAERmJKAhouACIiACIiACIiACFSWgDYAKrs0MkwEREAE6kdAFouACIiACIiACIiACFSXgDYAqrs2skwEREAE6kZA9oqACIiACIiACIiACFSYgDYAKrw4Mk0EREAE6kVgubWzs7PLKxtas2vXroZ6JreaTqBN52nT11L+iYAIiMBqBErZAGjLjaYtfvIga5Ov9FciAiIwgICqREAEREAEREAEGkVAm9uNWs7gTGs2ANoSoO7ZsycsbNEfbeFbNFfNJwJ1IlAVW9t0PWqTr1U5vvK2Q2uaN2HpFwEREIF2EyhlA6AM5GXdULVrVsZqa04REIESCAycktfetlwH5+bmBjLIq7ItXPPiV1W9PGeKtq3oY7do/zSfCIjA5AR0fZicXVVHlrIBwJtbkQ8uZX0rzkUv+qQpej76SCl6TTmnRAREoEoEhtvC68Pw1uxbyrwOZu/NcI1Fcx1uiVqyJtCWZ6SsuUmfCIiACIjA6gRK2QCgWUU+oBU5F31LCx/QirqRl7nRQZ/L5Mz5JSIgAiUSWGHqIq8NZV8Hi5y/SK4rLK+aciCgtc0BqlSKgAhMRKDIWGYiAzVobAKlbQAUdTAV+TA2jH5RN/Ki5hnmZ1FrOmx+1YuACJRHYLWZi7oWl30dLGr+oniutq5qz4dAUfdTHkdFHbP5kJJWERCBIgjoOlEE5eLmKG0DgC4WcTAVMQd9WUl4I+dNdqU+07blrX9U+6rAe1Rb1U8ERCAzAqsq4rUh719DVeU6mLcd5Eieq0JXh1oTKGKN+XxSa0gyXgREoBACvFbkfW8rxBFNEgiUugGQ98G0b9++4GQVPngj50NbHrbwhKT+PHSPqzPvNR3XHvUXAREogsBoc+zfv3+0jhP0qtJ1cG5uDrRnAjdGGpInx5EMUKdCCPB+mudzDI9RzlGIM5pEBESg9gTyvrfVHlCNHCh1A4Cc8jqYeNOs2o2ND21ZbwLwBk6GZFkVoT20qyr2yA4REIGcCYyhntdmXQfHAJbqSm7kl6pStuEE+ByTx/2UxxHv1Q3HJ/dEQAQyJsDrRh7XpIzNlLpVCJS+AUD7eDDxZsT8tMIHpCiKwJvmtLryGM9NgKxOHOohuzzsnFYn7cpqTae1ReNFQATyJTCOdl6bs7wO8jrD6804NhTVl3bxOp3FfLy3kRv5ZaFPOupDgMcRj3MeA9NaTR3UpeNoWpIaLwLtJcBrUlb3tvZSLNfzSmwAEAFvRgzcJz2gkpsaH5Cor8rCE2daXzmeeqrs57RrWmXfZJsIiECfwEQZXr94vadMooDjeB3kdWaS8UWNoZ+0k/ZOMmed7m2T+KcxoxHgcc7nmyyOI+oabVb1EgEREIHBBKa9tw3WqtqiCFRmAyBxODmguEPNGx0fflYS9qPwxli3m1riK/2krOQn2+gnHyTpa8KrDmniJ+0fxU/6KtmFshnU4djKysYyWGdle/l6JreA1wYKr2u8NlBWWwteR9if4yafufiRtJd20/5R/WRfXu/rdm8rnu7gGckuLYN71at23OOIx1pex1Ga7aT5etGvn7WrXU/VPvmzVllHw6TnWjIua7uTaxKvNZSsjqms7ZS+xQQqtwGQmMcHHh5UyQE7LGU/SjKujin9pAzzMamvu5+0fxQ/E3+V7sf+/ftLE17E63g+jWsz/dxfAudx7axs/4wMm5ubw5zLamsxOzub0YzlqKH9o/rJvuVYWc9ZeeyQmZnBzLB79+5FYhbXmxm4BpR6egrQT9pPn1cS9mHfLPzkPNRlFnNcyneSchZ2ScdgAmXd23ictEEY7A4mn1/tgQMHFl3TJjnnzOLz1yzb6yCvNZSs1p7Hb34kpbmyGwBaGhEQAREQgeoTkIUiUDYBPnAyMOXDMB+QR7Fn7969oJjFD8GjjGlrHz7Um8UbKqPybSsr+S0CdSLAayDFTNfBOq1bFrZqAyALitIhAiIgAu0kIK9FoFQC4wb+g4zlAzD1DGprcx03VswsbJS0mYN8F4E2EOB1kJt9bfBVPgLaANBRIAIiIAIiMCEBDROBcggkwWlW30hTj5mBesvxqFqzMhDgLyqqZZWsEQERyJMANwFmZ2eh62CelKuhWxsA1VgHWSECIiAC9SMgi0WgJAJ5Bad56S0J00TT8uGfgcBEgzVIBESg1gS4GcoNwFo7IeNXJaANgFURqYMIiIAIiMAgAqoTgTIIzPo3VHnOm7f+PG3PQrc2QbKgKB0iUF8C2gSo79qNark2AEYlpX4iIAIiIAJpAsqLQOEE+M0UH07znJj6+S14nnNUVTf5VtU22SUCIlAcAf4KqK3XweIolzeTNgDKY6+ZRUAERKDGBGS6CBRPgA+lRcza1m/Bi+JbxBpqDhEQgekIaENwOn5VHq0NgCqvjmwTAREQgaoSkF0iUDCBoh9G2/btV9F8Cz58NJ0IiMCYBNr8a6gxUdWuuzYAardkMlgEREAEyicgC0Sg6QTaFhDr2/+mH9HyTwREQARiAtoAiDnoUwREQAREYHQC6ikChRMoOkDlt1+FO6kJRUAERKBCBNq2EVoh9Lmaog2AXPFKuQiIgAg0kYB8EgERaBKBtv25Q5PWTr6IgAiIwLgEtAEwLjH1FwEREIG2E5D/IiACIiACIiACjSegX0I1c4m1AdDMdZVXIiACIpAbASkWgbYQ0DfjbVlp+SkCIiAC7SGgDYD2rLU8FQEREIEsCEiHCIiACIiACIiACIhATQloA6CmCyezRUAERKAcAppVBERABERABERABESgrgS0AVDXlZPdIiACIlAGAc0pAiIgAiIgAiIgAiJQWwLaAKjt0slwEciXwOzsbL4TSHstCchoERABERABERCBdhDYtWtXOxwtycuynrW1AVDSgmtaEag6gbIuSlXn0nL75L4IiIAIiIAIiIAIiECNCWgDoMaLJ9NFQAREoFgCmk0EREAEREAERKAtBPRlUL4rXRZfbQDku67SLgK1JcCLkn76Vdvly8dwaRUBERABERABEWgNAT4LtsbZEhwti682AEpYbE0pAnUhUNaFqS582man/BUBERABERABEWgHgT179kDPgfmtNfnmp31lzdoAWJmPWkWg1QTm5uagXwG0+hBIO6+8CIiACIiACIiACIhABgT4jJ2BmolUaANgImwaJALtIVDmBao9lOvgqWwUAREQAREQARFoAwF+O63nv/xWmnzz0766Zm0ArM5IPUSg1QT486+yL1StXoCqOC87REAEREAEREAEGk+Av/xU8J/fMvOZumy+2gDIb32lWQQaQ4AXKl6wGuOQHBmbgAaIgAiIgAiIgAg0mwCD//379zfbyRK947P03NxciRbEU2sDIOagTxEQgVUI8ILFC9cq3dTcTALySgREQAREQAREoMEE+Iyn4D+/BSZfPkvnN8PomrUBMDor9RSB1hPghSuKIvAi1noYrQIgZ0VABERABERABJpIgN/679u3D3Nzc010r3SfqshXGwClHxYyQATqR4A3iWQjgBe2+nkgi8cioM4iIAIiIAIiIAKNIcBnNwoDf37rz3/vqTHOVcARsuWXZVXlqw2AChwkeZrAk5rCgC0RnuSDxMzC/+9zaVsyLp1SZ552S3c9CPCY4LHAzYAshBfLenheTyt3794NMxtbzModk1yTeLxR6kk/tprnS+IPU7Ny2ZrVZ/6YoD5JIOvjiNcG6pWIQBEEVjt+eW3ktZ5ShD11mYNBZRbPWtTBNaCQdV38z9tOPoOSTRZCtjx+q8pXGwB5H00F6OdBRkkONB5sZvFDHW/qlL179yKRAwcOYJDQ1EH1e1Njkzx1msVzcD4K56fQFuqSiIAINIJA6U4k16Xk+mNmtfupIq+NZgZeOxN/mJYOVwbUigDvr7zf6jiq1bLJWCeQHLtmq18HeW1cer3nNdTV6C0CIpABAW0AZACxSBW8gFL4AEAxiy+kfBjgxZIXTUqRNnE+Cuen0BazeHOAF2wKbS7SJs0lAiKQFYFq6uG1xqz6GwG8/plZ2ICtJklZVQcCvIfyns/7K++3dbBZNopAQoDXwWmOXV7vKdST6FQqAiIwOQFtAEzOrpCRvOlTeOOn8AJK4QMApRAjppiEF2wKbTaz8CcGvIDTpynUaqgIiEBRBCo+D68vvKZU0UzaRfuqaJtsqg8BHke8h9ZsqFrMAAAQAElEQVThnl8fqrK0KAJ8ds3qOkg91FeU7ZpHBJpKQBsAFVxZBse8wJlZ+LlocuNvws2fPvACTp/MLPyMlw83FVwGmSQCIgCgDhB4TanadYT20K468JON1SWg46i6ayPLVifA45fPfav3HL0H9fEZefQR6ikCIrCUgDYAlhIpqbw06OcFriRTCp2WD8gUM20GFApek4nAaARq04vXET5sVsFg2kF7qmCLbKgvAT4X6Diq7/q13fI8r4N8Rqb+tjOW/yIwKQFtAExKLoNxvLlzF5PCb8R5QctAbW1V8EGHYqbNgNouogxvGIF6ucPrRxUsroodVWAhGyYnwGeEyUdrpAiUR4DBed7XQerXOVLeGmvmehPQBkAJ68cLYzrob3vgP2gJeGGnmMWbAYP6qE4ERCBnAjVUz+trmWaXPX+Zvmvu7AjwOOI9MDuN0iQCzSPA86R5XskjEcifgDYA8mccZuAuJYN+Mwv/GrSC/oBlpA8+BJmZ/r2AkWipkwhkR6COmni9KNPusucv03fNLQIiIAJ83i3qOshnac4n6iIgAuMR0AbAeLzG7s0LEwN//cR/bHTLBvCGQiFP7fouw6MKEciaQG318bpbhvG6LpVBvZlz8l7XTM/kVdMJFH391XW36UeU/MuDgDYA8qDqOnkBZKCqwN9hZPzmji8fjsziXwVkrF7qREAEAoH6fuiBsL5rJ8sBHb86CupMgM+/dbZftotAGwhoAyDjVeaFT4F/xlBXUKeNgBXgqEkEpiGgsWMT4PV/7EEaIAIiIAINIsAvaYp0p+j5ivRNc4lAXgS0AZARWT74KfDPCOYEarQRMAE0DRGBFQioSQREQAREQATqQIDP4HWwUzaKQFUIaAMgg5VQ4J8BxIxUcCOA66GfUGYEVGraSkB+T0BA30RNAE1DREAEREAEREAECiWgDYApcDPINDPooW8KiDkM5XpwI4Drk4N6qRSBFhCQiyIgAiIgAiIgAiIgAk0koA2ACVaVPzXit8wMMicYriEFEeD6mOkfCiwIt6ZpEgH5IgIiIAIiIAIiIAIi0EgC2gAYY1mTwF//sv8Y0CrQVRsBFVgEmVArAjJ2MgK7du2abKBGiYAIiIAIiIAIiEBBBLQBMCJo/pxcgf+IsCrajRsBXMeKmiezRKAqBGSHCIiACIiACNSGAH+VWxtjZagIVICANgBGWAQGjQweR+iqLhUnwHXkjYK/5qi4qTJPBEoioGlFQAREQAREYDIC+iXUZNw0ajEBPqsvrsm/VMac+Xs1eAZtAAzmEmoZJPJgYNAYKvTRCAL8RwL5aw5u7DTCITkhAlkSkK6JCeiaMjE6DRQBERCBiQhow2EibJUfxPiraCPLmLNoH5P5tAGQkFiS8kGOQSKDxSVNKjaEADd2uM4NcUduiEAmBKREBERABERABCYlUPRzVZuCtknXpI7jil7Xtm0kaQNgwFnBg47B4YCm/5u984C3ojj78Bx7772LKAIqiooFFVCxdw0aTewlxiSa8iUmmkjUVBNr1Ghi7x2xiwr2gh0EbCCKPfaK9Tv/A4vn3nvKlpnd2d2HH3PPObsz77zvM7O7M++U5VDBCKicKxXeFFCwYsUcCGRCQM+OsjUiMgFNphCAgLcEdB9MU7m0HQ5p2lb2vNJ8nqZdb7MuWxwAdSWgKf+VSqv3+tdF5muhCMgRwEOkUEWKMRDIhAD3kUywkykEIOARgWOOOSYVbdLKJxVjyKQLgTSfp2nm1cXQDA7gAJgOXQWvKf/Tfzb+4GihCeAEKHTxYhwEUiGgUYQ0Ry1SMYpMIAABCEQgoDZ1GvdB5RNBLaLmjICep2k4edLIwzf0OACqJaIbiDp/1a8t/3Oy+ARUD3TDKb6lWAgBCLgioNlkaTR+XemPXAhAAAJJCahtnVRGq/Rl7LS14lHUc6pHLp+nqkfKo6j8mtlVegeACl2dvmaA6o7ztSQEtPEjToCSFDZmQsARAT1bHIlGLAQgAAHvCagdNXLkSCd6lrXT5gRmDoTKqe5CzTLXo1I7AHRzCt/5d1H1kOkrATkBKpWKcXXT8dVu9IIABOwQGDhwoPn222+Ny5ELO5oiBQIQgIAbAroP2nYCSB4OVjfl5bNUPU/VYbelo2SVuR6V1gGgm5I6eaErEhFLSUD7QuAEKGXRYzQErBDQ/UMNDSvCEAIBCEAgZwTU3rbReZMzVZ1/ycsZAtS1REAd9qTP06AeSZYltXIppnQOADXGdPOI2vnPZemitBUCcgKU/UZhBSRCIFBSArp/BA1gNT5KigGzIQCBEhOovw+GxaD7pYI6/kH7PWxa4hWTQH09Ut0Ia6XiUo++o1UqB4BuHurMxej8f0csx99U+YMgD1qUEKTLsfmJVNdSEd10EgkpaGJdV2KjIOdakiBZaWPS/SCJznHTpm2n8tM1rwdgmkH3DuVNMEbXiOq4nAG2ygC+bmuWyizuNR43neqIW6uQDoHsCOia0j1Qod19UNeCgq6l7DT2J2cb7RXxD4I/lkXXRDaoboSpR4qjuNSj7ziXxgGgglfn/zvTo3zLV1w1CBXqG/tB5RcHBV04UYLSKEiOgm7akq+gvPJFKJ62OAG+46a6oBtppVIxuq7ERkEPp6Thu1zS+5ZU5zjp07Puu5xUZlmE7zTgW0DAVjkE8vh0QyDOtW0jjRtrkAoBvwi0uw/6pa0f2iS9v6itFoRKpWJUBuoP+GFdPC1kQ6sQT2qxU5XGAaBOSuyi9DyhOuDqiKtTrs65OmcKuqCDC8K2CZIr+QrKS/kqf+mhYDs/X+TppimbfdEnCz1U9rqe9BDKIn/yhAAEIAABCEAAAhBITkBtObVt1bZTez65RCTkgUApHACq1EkKw7e06vArqMOtjrcuWHVKs7ZT+UsPBemlIGeAdPWNYRJ9dKMU8yQy8phWNquM9bDIo/7oDAEIQAACEIAABCDQlYDadhrcURu+61mOFI1A4R0AFjosXpS5OtEK6vSrI6Yg27xQroUSupFI16I5A3STlF0tTC/UKdkqm/WAKJRhGAMBCEAAAhCAAAQgUCOgQS613Ws/+FNYAoV2AKgCJ++wZFv2eez0NyOm8lBHMnAGNIuXl+PqEMuevOibRE/ZmiQ9aSEAAQhAAAIQgAAE/CcgJ0BZ2rf+l4YbDQvrAFBnUxU4MbaMBGjqvDrKugDzMNIfFZPKR/bJzqhpfYovO3zSx4UuZbDRBTdkQgACEIAABCAAgTwSYOAnj6UWXudCOgDUYbHV+Q+PMnnMYLRfHWPZkFyi/xJkp+yVI0DBf407aqgZJkV00ARWqnzyeC0F+vMJAQhAAAIQgAAEIBCdgNqA0VORIg8ECucAUGW12GFJpQyDjn9RR/vDQFS5KWiPg7w5AoruBAhTfsSBAAQgAAEIQAACECgOgbz1p4pD3r0lhXIAqANpt7K6LwB1dsvc8e9MWKPpKkdx6XzO599yAkhvn3WMo1verqc4NpIGAhCAAAQgAAEIQKArAfVRuh7lSN4JFMoBYL2z4rB0Neqvqe9F7DTawCYu4pMnR4DqX5FulCoDG2WJDAhAAAIQgAAEIACB/BGgLZi/MgujcWEcAC4qaBiAUeOo469p7kXqKEZlECW+yjVPjgA2TYlSusSFAAQgAAEIQAACEIAABNIkUAgHgDqJGn21DM66OI1mq+Ovae7WhRdcoMpYjhM5UHw3lfL1vYTQDwIQgAAEIAABCECgHQEtcW0Xh/P5I5B7B4A61G46//YKU51WdV7VibUntXyS1LFWecuR4rP1ulkWoazF2mfO6AYBCEAAAhCAAAQgAAEIRCOQeweAs45WNI5NY6uzqo6UOq9NI3EiEgGVubhGSpRyZDmlVO4pZ0t2EIAABCAAAQhAAAIQgAAEmhLItQNAHUGNtja1LsEJG0kZ9bdBsbEMlb32BtDsisYxsj8qHbPXAg0gAAEIQAACEIAABCAAAQhMI5BbB4A6VxplnWaG9b+JBKpTqs4/o/6JMIZKrFF2X2cDyDlFHQhVjESCAAQgAAEIQAACEIAABFIgkFsHgNvOf3zy6oyqU0rHLz7DqCnlDBL3qOnSiC8ngOpDGnmRBwR8JMC90G2pwNctX6QXjwDXTPHKFIsgAIFoBHLpAFCHL5qZEWPHjK5OqK+6xTQpN8nEXfx9VJhXA/pYKugEAQhAAAIQgAAEIACB8hHInQNAHT3Xo/9xqoE6n9ItTlrS2CEg/lp6YUeaXSnSza5EpEEgOoEsRr7Kkmf00rCTIgu+djRHCgTSJ6AlmunnSo4QgAAE/CKQOwdACtOpI5cQnf/IyJwlUGPYRyeAnFY+1l1nBYFg7wjoPpWVUmk3unUfyMrWtPMtk61psyW/4hHgeilemWIRBCAQnUCuHAAaRdWa6uhmRkkRLa4a1dIrWipiuySgB7yPbwignrgsdWT7TCDtuq97gM88bOuWtoPFtv7Ig0BaBMp2b0iLK/lAAAL5IpArB4BGUZ3jjZABnf8IsDKIqhF3nxrGcl5JpwxQkCUETNqd8HrkanSndS3qvlyfdxm+Z1m2ZeCLjcUgoHuD7kXFsAYrIAABCMQnkBsHQFoNnLAo9SDxTaewupcpnm9l5Js+ZaoLZbZV96us7U+r7qeVT9Y86/NXpyYtB0t9vnyHQJ4IlPHekKfyQVcIQCA9ArlxAKQ0+h+KvBrTPEhCoco8khrGPu0JoFkA1J3Mq0WpFPDlfqVrUbq4hO/Tte7SzkayNbsIJ0AjMhyDgDGu7z0whgAEIJAnArlwAKTXYWpfdHqI+KRPe42JoY6HTx0Dn5xZ1I5iE1CH0Kf7lXSRTi6o696sa92F7LzIFN+86IqeEEiLgO4NXBtp0SYfCEAgDwS8dwDopp1ah6lNifEQaQPI49PqGKj8fFFR+viiC3oUk4Dqu0aFfbNOOkk3m3rJwadnhU2ZeZSl+4pYuHKy5JEJOpebgO413BvKXQewHgIQ6ErAewdAV5XdHWklWQ0qHiKtCPl/TuWnxoAPmmopgDpCPuiCDsUjoHqu+u6rZdJNOibVT/dldXjV8U0qqyjpxUL3Fht8i8IEO8pHILg36F5TPuuxGAIQgEBrAl47AHTjTnH0vyUpNahaRuBkLgioTqlh4IOy1CkfSqE4Oqheq9OnV2CqnvtumXSUrtI5qq6yVR1/XUPq8EZNX4b4SfiWgQ82FpOA7g26p3BvKGb5YhUEIGCHgNcOADsmhpXSPJ4eJs3P2jmjhxVhlBk1apQdoC2kpJFHi+xnnPLFuTVDIQ++qPGWRcjCdBt26t6kjrCC6vXQoUOzMCVRntJZjgDZIHuCUM8nOKY4iitbBw4cmCjfILFktQpBvLx+BnwDhsFnPV++DzDNGGRR7s104XjjclKd1r1BQdey6nwW5eZjnuJBGGVGjRplPfhY3q50GmWRnysd05bbjkna+kTNz2sHQKodpCbk9GAZOnRok7PJDqvyDBw40AyshkGDBhnCNAaVSsWIuUIy73XBlQAAEABJREFUws1Tq6HQ/Gx6Z1QH0svN/5x0LYhJmsFlPWtF3IaN0l3MFFrllYdzskH2BKGeT3BMcWzYItmSpdDuvlupVEylMu2eZCPvrGQEDINPMSCMMqNGjWoZ1OlOu8wGDhxoRrXRi/OjZjAaOnSoGVhlppB2Wfmcn5Yatru/cX5auzMOBx/6KGnVvzh8mqWpVKY9T3XdpqW/rXxGjRpVu9dUKpW2fbZKpVKLO7R6f7KVv0053joA0gbWCKoe/C70CCqQLg7doBUa5V/mY7qxKlQq024UtlmooSDnjm25UeW5qF9RdSA+BMpCIMm91+X9qCz8sRMCEIAABCCg56lCXtrAndsOYUtQ/TvZWam46cuE1aNRPG8dAALWSGFHxxqKdVExVYmCjn/DTDnYhYDqgouykEw5ebpkmOIB3RxUJ1LMkqwgUEoCus5s3Ht1P6pUKkbySgkSoyEAAQhAAAIWCATPU7XHLYhzIkK62Wo7SJYTJWMI9dIBkD6gruQ0Ojxw4MCuJxIckV2qRAlElDapbhLiZxuAC5lRdfRBh6g6Ex8CeSKga8z2vVfyJDdPHNAVAhCAAAQg4BsBV238pHbqGS/dksoJ0kuW7b5lIDvqp5cOAAGKakii+A0Sq9AbHI59SPJ8sCu2AR4kFD9xtKmKLkQ5e2zKjCqLWQBRiREfAuEJaKRe947wKcLHlFzJD5+CmBCAAAQgAAEIdCbg2/NU/Q3p1FnPpL/V5lffI6mcpOm9cwAIeFKjoqbvHN9Fh9BFJeqsdxl+i6PtBrcPdc4HHcpQf7CxfAQ0Uu/SatfyXeqObAhAAAIQgIAvBPQ8td3Gj2Ob2uTqb8RJGyaNnADKI0xcV3G8cwBkUPAd2Krzb7tQbMvroHAJf7jgmfVbAXQzyLrul7AqYXLBCbi4VzRCllY+jfLmGAQgAAEIQKAoBHx4nrrs/AflpDyybPd75wBQRyiAk85nx1xcVDwVcsdc+JWEgOqI7XLSdJysNwRMwoS0EIBAVwJp3XvTyqerhRyBAAQgAAEIFIeA2vhZdoxt9y9alUyaeXXWwysHQCYg6oho9L/up5WvWdtkxQgPhbi4OWRdVlnn72ExoxIEYhNI+3pycU+KbTwJIQABCEAAAjklkOXzNM285ezIqoi8cgCkCT0AXv/posGYtU319hXpuy4a22yzngXgwqYilTm2QMBnAi6eHz7bi24QgAAEIAABFwRst++j6Ki2eJT4SeNmZatXDoC0oRtjZpSbi9F/Cc/SJuVPiEaARnw0XsSGgK8E0p6Wz73e15qAXhCAAAQgkCcCWT1Ps+iMZ5Gn6oI3DoBsOl5CMC1knf80LfgbhYCLiybrWQDUwyg1gLgQgAAEIAABCEAAAkUj4KKN345RWfIUB28cAFlANyJQDa5G/7O0qWoW/2MSyLITLq8n9SZmwZEMAhCAAAQgAAEIQAACEGhJwBsHgDo+LTV1cDIQmWWHL9CBT38IZD0LwB8SaAKBfBLAiZbPckNrCEAAAhCAAATcE/DCAZBRB7xG19Xof004f3JLIMs6mWXeuS0wFIcABCAAAQhAAAIQgAAE2hLwwgGQzWjNNDZ0tqZx4G9HAlnOAtBsmCyviY4k+AUBCEAAAhCAAAQgAAEIFIWAFw4AdXhSB1rNkNH/KgT+NyWAc6gpGk5AwGsCcuB5rSDKQQACEIAABCAAgYwIZO4AyKqTlRFvss0RgSw7EVwXOaooqAoBCEAAAhCAAAQgAIGcEMjcAZARp1q2dLJqGPjTgsCAAQNanOUUBCDgK4G0r9208/OVO3pBAAJdCWQ5oNBVG45AAAJlJ5C5AyCbtc7GMP2/7FU/nP1ZOYmyWhYTjgqxIACBzgRo4Hcmwm8IQCAgwP0hIMEnBCDgA4HMHQCZdHR8II8OuSCQ5UM7K+dYLgoGJSHQhkDazrss7xVtUHAaAhDwgACzhDwoBFSAAARqBDJ1AGTVwZHlaTcOlSchnwSyemhTR/NZX9DaDwLqkKd17WpGmfLzw3K0gAAEfCTAM93HUkEnCJSTQBkdAEz/L2ddj201D+3Y6EgIgUwJcO1mip/MIQCBOgJyEqbllKzLlq8QgAAEuhDI1AHQRZtUDpAJBKIR0EM7Wgo7sVkeY4cjUspLQNeuRuddEpB8HA0uCSMbAsUhwL2iOGWJJRDIM4FMHQB//OMf02dXzZEbcBUC/yMRyMprn+UymUiAiAwBTwnofu/q+pVcyffUdNSCAAQ8IyCn5MiRIz3TCnUgAIGyEcjUAZAFbDXYssiXPPNNQA/tLCzAAZAFdfIsGgFdRxqpt2mXniWSa1MmsiAAgeITUHvC9v2o+NSwEAIQsEkgMwdARg0noxuvTYDIKgcB6k05yhkri0tAI/W2Gt2Sk9UzrLglhGUQKA8B3Y80E0COxPJYjaUQgIAvBErmAPAFO3rkjUBWDgA6GXmrKejrMwE1ur/99tvYG8Gqsa5G+9ChQ302E90gAIEcEFC7Qs94ORRzoC4qQgACBSKQmQMgE4bVTGm4VSHwPxYBNf5jJSQRBCDgFQE9BwJHgBrfurYV6pXU7yCo06+gxroa7fXx+A4BCEAgCYHgfqR7TLP7URL5pIUABCDQmUCpHACdjec3BHwnwJsAfC8h9MszATW8FdSxV5BTIAj6HQR1+hXyaGu9DZVKxVQqzYNsFI882imdZatsUKhUmttZqYQ/xz1YZLMLLsq0Uglf/pVK67i6XhRsEFK9lSzZrBDci+J+yqFgQ688yJCtcTnFTSdnTR7Y5FXHQYMGtXxeVSqtr81KJfr5rDanz6KMMnMA6OaWssFGozlp50l+xSGgB3MW1mRxrWRhJ3lCAAL2COi+oQ6FGlEKYTqyiqMGUKVSMVnd7+IQqLdVNijEkUMafwjkpUx1vShUKvm6ZvwpaTSBAASyIJCZAyD9B7QxagxlAZk8IQABCEAAAmkRUOc9bKe/mU556dTouZ7U1mYMOJ4NgbyWaXDNyHmRDTlyhQAEIBCOQGYOgHDqWYyFKAgkJKBGSUIRJIcABCDglIA6/+qI2MpEsiTTljxbctTJ0j05i8EEWzYgpyOBopSpHFI+XjMdafMLAhAoM4FMHAC6yacNXfmpsaBPAgTyRCCr6yVPjNAVAhAwRp0Oddhts5BMybYtN4k8dbLo/Cch6F9a1bGilKmuGZ7d/tUxNIIABKYRyMQBMC3rVP+SGQSsEMhiHwkaEVaKDiEQKDQBdZ7U6XBlpGT7ci+Sra7sRG42BFSmRen8BwTlpPLlmgl04hMCEICACGTiAEj/hihTjWEGwDQO/IUABCAAgWIRUAfdtUXqpLnOo5186ZCGre304Lw9AkUuU9lmjxSSIAABCNghkIkDwI7qEaQQFQKWCOBEsgQSMRCAgDUCaXUyNEKblQM/gEXnPyBRnM8il6kP10xxagqWQAACtgiUwgEgWFlM3Va+BAhAAAIQgIBLAml2ytNyNjTilWXejfThWHICZSjTMtiYvCYgAQIQSJNAGRwAafIkLwhAAAIQgECqBDTKmFaGyitNh0NadpEPBFwR0DXjSjZyIQABCMQhUAIHQBwspIFAYwIsAWjMhaMQgEA2BMo0uljkqeLZ1J7scy1LmeI0y76uoQEEIPAdgeI7AL6zlW8QyCUBRg9yWWwoDYHCEqAzU9iixTAIQAACECgBgUwcAGk2HoIyZOQ2IMEnBCAAAQhAID6BLJ7h8bUlJQQgAAEIQAAC9QQycQDUK+D4O+IhAAEIQAAChSVAZ7ywRYthBSLAdVqgwsQUCBSAQMEdAAUoIUyAAAQgAAEIQAACEIAABCAAAQhYIFBsB4AFQIiAAAQgAAEIQAACEIAABCAAAQgUgUChHQBFKCBsgAAEIAABCPhEgD11fCoNdIEABCAAAQhEI5CJAyClxkMHEqy/6oCDHxCAwHQCWdyPpmfNBwQSE6D+JkbonQDK1LsiSawQZZoYYUsB8G2Jh5MeE8iq7mbiAEinHMgFAvYJ4EiyzxSJEIBAfAJZNR7ia0xKCEAgDQLcG9xShq9bvkh3S6C4DgC33JAOgdQIDBgwILW8yppR2oyPOeaYsqLG7gIQGDp0aAGs8NcEOhb+lk1czbIq07SfbXH5JEmX1fM0qzJNwoq0/hHIqh4V1gHgXxGjEQQg4CsBOjS+lgx6tSOgxkMZGvntOBTlfFadmaLw89EOytTHUrGjE/deOxzLLEXP8CzsL6oDIAuW5AkBCOSUQNo3YBwOOa0onqqdZn2iM+NpJUAtCDQgkOa9oUH2qRzK0sYs804FLpk4JZDl8zQTB4D7xnbX8rr77ru7HuQIBCISYA+AiMByFD2tG3Fa+eQIPaomJKBnalojUTR4ExZWi+S6N8C3BaAcnsq6TNO8N2RRPOKbRb5BnkXnG9jJpxsCWd7vM3EAuMFYJ7XJVzpvTcBw2GsCesB4rWBBlNON2HUnSvKVT0GQYYZHBNKoV1k3tj3C7USVNMrQieIIbUrAh+d3Udu+vjxPuW6bVn9OtCCQ9fO0kA6AFrw5BYFEBJhJkgif94ldP8iL2hDzvmBLoKA6Gi4bFJLt+vooQTE1NVF8m57kRC4JqEx1Xfqg/MiRI31Qw6oOvtyPVMYqa6vGIazQBFRfsq6/mTgAdLE4LFlEQwACEIhFQPcmVw0lV3JjGUqiQhJQg0INC9vGSaZk25aLvGkE4DuNQ5H++lamerZJp6Iw1vNUNvlij+6PReLrC9ci6uHLzJVMHABuC7S5dEbfmrPhTHsCWdUfnx5y7SnlP4Z4f/vtt0Y3aRvWSI7kSa4NeciAQCsCthuiatRKZqs8ORefgDoy8I3Pz8eUvpap6pl085FZWJ30PJUNPj5PxVf3y7C2EK98BFQ/supLdKadmQNAF3FnZaz8biHEF+gtVOSUxwSyqj8+Pug8LiZrqqm8dbOOK1D3ODVUJCeuDNJBIA4BNUTldLJRfyUrjg6kaU1AZaMy4v7emlOezuqe73uZqr5JR9W/PLGVrtJZz1PZoN8+Bt0v88rXR55F0Un3BrUHVT98sSkzB4ArAMiFAAQgYIuAbtbBw1yNjzBygxu97w2VMLYQJ98EVH/V6FDdVb1sZ43iKK7SUH/b0Yp+XnzFVkFlE10CKXwjUF+mumZ806+ZPqp/UZ9tzWS5PB7wla7S2WVeNmVLV+ms+6lssCkbWfkgoHJX0P1e9wbfHFeZOQAcgWhZK7SBmwqhZSROQqAJgSzqjm4eTdThcIoE9DBX0AM9CLqp14fguOpJFve3FHFYz0rMFMTNt6ByV7BudEoCxVP6i29QR+vrrb4HxxVHcZUmqXqSpSBZtkJSneKkVwNejJKEer4Bizi6ZJ1G5akQ2GDjMwubKNPvqOt6VwjqaJJ6bjNtoE9Q377TOF/fxFY2BPYkZaS6mwWBpHqXKX1Q1ip3Bd0nsyizdnkWzAHQzlzOQyA+ATmQ4qcmZdEI6KZeH4pmXxr2BA/HQYMGGQVdY76FP4WR+aEAABAASURBVP7xj0ahUqkYNebS4OI6j/p6q+8283NZpjb1DCtLfJKGsHn5Go8yHWgGDhzYIfhaVkn1GtjJzqx+J7XD1/Q2eGZhmw29yyIji/KJk2dmDoA4yrZNEyJCURpwIUwlikUCagBZFBdalG6YoSMTEQI5IqC6HXT686J20RwBtrnnsUxtMyiaPMq0aCWKPRCAAASMKZQDgAKFgCsCWTkAXNmDXAhkRUDXkjoVGunPSoek+coRgDP5O4pFKNPvrOGbCFCmokCAAAQgUEwCmTkA1AC0jDSUuDw3OkMZSCQnBNQYciK4jdCsrpM2anEaArEJ5G3Uv5mhcgJwfU6jU5QynWYNf0WAMhUFAgQgAIFiEsjMASCcdjc4k8RwIavOXDjtiOUjgawcR3QwfKwN6BSXQNHqs+4LZZ8JULQyjVu3i5SOMi1SaWILBCAAga4EMnUAWH3IdLWt6ZGyN9iaguFEQwJZ1ZesHGQNIXAQAgkJ6DpShzmhGO+SayZAWZ3KRS1T7ypZigpRpinCJisIQAACGREojAMgCr8iNkKj2E/cfBDIykGWDzpomTcC6ijnTeew+qrTFDZukeIVuUyLVE5RbKFMo9AiLgQgAIF8EiiKAyAy/bKO2EQGRYLaK8DAAAEIxCdQ9A6ynMple6YUvUzj1/b8pqRM81t2aA4BCEAgCoFMHQBS1M40Z0mKFnjQReNV1thZ1pMs8y5reWO3GwJl6ByX7XotQ5m6uRr8lUqZ+ls2aAYBCEDAJoHMHQBWjIkhRCM2MZKRBAIQgAAEIhLgfhsRWA6iU6Y5KKSIKlKmEYERHQIQgEBOCWTuALAxahKXPd7uuOTKky6r9ZDHHHNMeSBjaaEJlOU+W6bOU1nKtNAXZifjKNNOQPgJAQhAoMAEMncAWNjoLHbxZOl8iK00CVMjQP1IDTUZQQACEIAABCAAAQhAAAIpEMjcASAbk+0DIAnxgkZs8HrHY1eGVFnWDZwPZahh5bAxy+uoHISxEgIQgAAEIAABCIQn4IUDILy6DWImPERHKyHAgiZXvZCDqKDmYRYEIAABCEAAAhCAAAQgUEICXjgA1NmKyz5pOjp5SQmS3jYB1v/bJoo8CEAAAhCAAAQgAAEIQEAEvHAAaB+AmMsAZEPikKUDIrHyCHBCIKvN/2QM9VEUCEUhoPt7UWzBjvIRoP6Wr8yxGAIQgEDRCXjhABDkeJ0epUwesuzsJdceCbYJZFkXs3SE2eaIPAhAAAIQgAAEIAABCEDALwLeOABiYbGYyMVGVYwcWCygFEVl6RCizqRY0GQFAQhAAAIQgAAEckIgizYiA1M5qRwR1fTGAaBKHbWSRbS1ZXRXo75Z2tTS4AKcdFFmLmRGQZ11/lF0JS4EwhDQvT1MvLzHYe+OvJdgV/0p065MOAIBCGRLIO1+RVme4dmWavq5e+MAkOkROz9KYi1oM0AX+XPhWCuiDoJc3AA1CyTL0X8XNnWAxg8IZESAup0ReLKFAAQgAAEIJCBAPyYBPI+TeuUAiMbJfmx1/tQJtCmZC8cmze9kueBqu+y/0zbcNxc2hcuZWBBwS8CFc9WtxtGll8HG6FTynYIyzXf5oT0Eikgg7fsSbdMi1iJjvHIAqJKFHilyVB62LywfbHKEKlOxtstJ8uQAytIo6ZBl/uQNAVcEin4fZKq4q5qTnVzKNDv25AwBCDQnkObzlPtg83LI+xmvHACCGbYTpLgugpYC2B4JztomF5yylOnihpR159+FTVmWEXlDoDOBIt8Hi2xb53Isy2/KtCwljZ0QyB+BNO5PGpBNI5/80S+Gxt45AOTZCoHWaRTbFV42jRw50qnOZRGujrLt8rEtryxlgZ0QiEJA90Fdv1HS5CEu9/Y8lFI0HYtYT6MRIDYEIOAzgTSep7YHQ33mWUbdvHMAqBDaP3wVy13QLADbncI0LlZ3RPyQ7MobmfXov+jarm+SSYCAbwRUz7O+v9tkIlt0b7cpE1nZElCZqp5mqwW5QwACEGhNQPcp3a9ax4p31pXceNqQygUBLx0AqtQtjU3hpDqFtr1fsouLKl7hiZvt8pAmPjTeZZt0IUCgDASKch/UyL9sKUOZlcVGyrQsJY2dECgGAT2DbLYhNdDGfbAYdaOdFV46AKS0KqE+G4W0junCsp2XZOrisnnB2tbRJ3mqB+Ilbrb1kkzN9rAtN6o86RE1DfEhkGcCqvN5vQcG9yQfnId5rgM+6U6Z+lQa6AIBCEQhoOep2slJn6m6D2qgjWdbFPr5jeutA0AVugnW1A6rc+hCD11ckquLVSE1g3KUkW5EuqG5uhmJv2Z5ZI2E8s+6BMg/KwK6Br/99luja0AhKz3C5Kv7kYLLe1IYPYhjlwBlapcn0iAAgWwIxO1X6B6oEDzbstGeXLMg4K0DQJVZlbIrlHSPqJOoTqiLXIcOHWqGVoMawbr4FNQQLmuQ/QriIeaqAy64S6bKVZ9ZB5V/1jqQv98EdC2onvgWpJcNcoFduu51/Sv4cA+UHkGQrQou70k2WLaSIf0VAt5JP1vl5epc0noRlKc+Vd/EI89l6oozcrMjoDqp0Or61PnsNMx3zmLXiq3OKU5erZT+Crq/6T6n0Pm+qWNBkK0Ktu6DkqX8W4W8si2a3t46AARaFUifHUIGPwYNGmRUqV1mPXDgQDOwGmRzWYPsV3DJWbLFV59ZB92Us9aB/P0koPuNroVKpWJ0/5HDyrcgvSqVirF5PclmBcnMOkiPIPhZS9pr1bkeqcxs1CPNjmufu/0YSetEUJ76tK8dEiEQj0DU61TXcaVi994bT/N8pOrMt909sCh8dZ9T6Hzf1LEg2CjBqHwrlcqM/o6N/JERj4DXDgBV0M6zAOKZmTyVLqDkUpCQNQGVo27+Weuh/KWLPgkQCAgED1I1QLLqZAW6hP3U9VSp0BgNyyuteLq/5KkepcWFfCDgE4Ek1yn33vYlqX5E3PsgfFvzTdJeUfsGvq35uj7rtQNAxuvmqM/pIbMPVVZfdMkMQs4zVvnphuODGYz++1AKfumgh2nchooPlujaUmPLB13KrIPqkcpB5VFmDtgOAd8J2LpOda1Llq59321OSz+xqFQqRm33pHmKr9qPSeUUKb142GqvwDebmuG9A0A3te9mAWQDKciVShqQyN+nHgYqP180183TF13QI3sCqg96mGavSTIN1NiqVCrJhJA6EQHVI5VDIiEkhgAEnBKoVOx0TgMldc3r2ldbJzhW1k8xEAub9qv9qP6ITZl5laX2injY1F/yJNemTGS1JuC9A0Dqz6gU+pFxoJJmXAAxsnfxMIihxowkjP7PQMGXKgHVT91Xql8L85+GUjZFCfdsuJMrBKIQcHmd+tRejsLEZlzbnf9ANzlZys5X9rtqr0iu5Ae8+XRLIBcOAN0s1WlyiyK8dCppeFY+xHT1MIhrGze4uOSKmc63+mmDMg0lGxSjydB9RdyjpSI2BCCQJgHX16nuAWozp2mTT3mJr0t9yt7+l/2u+WpQxGUeyJ5GIBcOAKk6dOhQfXgTdBFQSb0pjqaK+PYg9MmR1RQaJ1Ij4LqxkpohDTLiHtkAisND4u1QPKIhAAELBNK4TuUEKGP7VM/TNPimkYeFqmZdhPhaF9pAYFr5NMi6VIdy4wAwxhjfOk8auaOi+nu9qPOvB6EvGqr+Ul98KQ0/9Ch6Q4L6nk49g3M6nMkFAkkIpHmdpplXEiY206bp9EgzL5uMkshKq72idnsZ+SYpmzhp8+MAqFqnG5ovGwJW1an91wUhvWo/+OMFAd04fOv8C4x00icBAiKgeqrPIgc9yItsny+26Tnkiy7oAQEINCaQ5nVaxntvmjaXrd2ftr1p59f4ii320dw4AIJi8LFS6Kbuo14BszJ9qlOlmRlpPgjC8NXoPw6AMKTKE0d1tQzWlsXOrMoSvlmRJ18IhCeQxXWaRZ7hidiNmXYb3Lc2pl2aSCsDgbw4AGaUhTpRvs0CkHI4AUQh26CHnTr/2WrROPe0H06NteCoTwRUX33Sx5UuZbHTFb92cuHbjhDnIZA9gSyu0yzyzJ50ehqUiW/atuJgcV+Pc+IA6AjC184UToCO5ZTmL9UJXzv/Gv1PkwV5QQACEIAABCBQbgJpd9qypF0mW7PgnEWHnDJ1W9L5cAB0YqBZAL52qnACdCqsFH6q8y/uKWQVOQvVU+kXOSEJCk8giwdq4aFiIAQgAAEIQCAFAnRQU4BMFs4I5MIB0Mh6darUuWp0Lutj6oxWKhUjHbPWpej5yxkk3r7aSR3wtWTQCwLFIEAjtBjliBUQgAAEIACBtAjkwQHQlIU6Vz7uBxAorI6pdAx+82mPgBq9lUrF+DyK6quDyl4pIAkCEIAABCAAAQhAAAIQyBOBHDgAWuP0vYMtJ4BGqVtbwdkoBFTmvq73D+xQ5196Br/5hAAEIAABCEAAAhCAAAQgkDUB/x0AbQipc63OVptomZ7WKHWlwpKApIWgUX+Vt5wqSWW5TK/6SOffJWFkQwACEIAABCAAAQhAAAJxCHjvAAhjlDpbPi8FCGxQx1W6Br/5DE9A3DTqL2dK+FTZxJSu2eRsN1c5W+xKRBoEIAABCEAAAhCAAAQgkCUB3x0AodlodDh05AwjyglQqTAbIGwRqFwrlYoRt7Bpsoyn0f8s87eZdxYOgCzytMkMWRCAAAQgAAEIQAACEPCZgOcOgGjoRo4cGS1BhrHVoa1UKrwpoEkZqOOvzqBG/ZtE8e6wOv9FGf0XXPHXZ5ohizzTtI+8IAABCEAAAhCAAAQgkCUBvx0AEcmo86BOWMRkmUaXI0B6F6njmARofcc/D9P9A1u1BKWIZSi7Ahtdf+bt2nXNA/kQgAAEIAABCEAAAhCwTcBrB0AcY9UJy1tHQh1dOQIqlfLOCMhrx191VJ1k6a/vRQu6ntKyKc280rKJfCAAAQhAAAIQgAAEIOATAZ8dALE5qSORNydAYGzZHAHqOGsGhKb6yxEScMjTp2zIk75RdFXZyMERJU2cuHm9XuPYShoIQAACEIAABCAAAQhkRcBjB0AyJHICpNFxSaZl89T1joCidTBlj4I6l3nu+Kv08rTvhPSNE1RWcdKFTaPrVNdr2PjEgwAEIAABCEAAAhCAAATiEfDXARDPng6p1HFR56LDwZz9kCNAneRKZdryANmUMxNmqCvdg06/bMrriH9gkDr/sif4XeRP2erKPtULV7KRCwEIQAACEIAABCAAAQh8R8BbB8B3Kib7ps5F3p0AAYHOzoDguM+f4q9OcqVSMUXo9AesNWVddgW/i/4pW207AXRd2pZZ9HLAPghAAAIQgAAEIAABCCQh4KsDIIlNXdIWcXqxnAGVSsVUKtNmBshGdba7GJ/iAeWvoM6iQqVSrE5/gFKdf/EOfpflU2X67bffGtmf1GZ1/oO6klQW6SEAAQhAAAIQgAAEIACBcAQ8dQCEUz5sLHVcijzSKGeAgkbYK5WKkb0s420IAAAQAElEQVRDhw41Q6tBnaywnKLEk1wF5aH8FJS/gqb2K0SRl5e46vzK5rzo60JP2S8OClHlq+Ova1F1J2pa4kMAAhCAAAQgAAEIQAACyQj46QBIZlPD1OqgquPR8GTBDqrzLYeAgjrklcq0mQJioKAOXKOgTplCo3NKp1CpTJMluQrKQ/kpFAxjF3PU4RWbLidKeEAcFIIZAWKjoA5+56DjuvYUV/VL9cgGMsnKc7DBIA8y8lxG0j0PjMuio8qDMMqMGjXKSShLPSqTnaMc1RXf5JapTKPYaqucouRZlrjt2PrOwUsHgCtoAwcONOqIuJLvu1x10hXUaW8U1KFXaHRO6RR8t9GVfurEDh061JX4XMsVlyA0uiHqnK49G0ZKvmQpqK7mOdjgkQcZum/kuZwqle9mVeWBd5F1zHM98l13PfeLXHfKaFve771RrhnZWsYy7mxzfRupUqnU9t6KwrFZ3M75lPV3wLdSac+2UvluibaPvHx0ADjlpI6DRiI1Suk0I4QXhoCcRurEFsagHBoS3HT1cNKDXiGHZqByTgmovqmDVKlMe6Dn1AzUhgAEIACBAhKgjeS2UDvzDZub2g0KlYp/bQcPHQBhsSaLp8LECZCMYRlSq/Mvp1EZbPXVRjlfgo6/rzqiV3kIBA9zPUPKYzWWQgACEICAjwT0LKKN5K5kbLVB1XaQLHeaRpPsnwMgmv6JYuui0dTuREJIXEgCcg7R+c++aHWz1E0ze03QAAIdCajBpWdIx6P8ggAEIAABCKRDQG0kPYvSya18uYivzTaoZPkyqOidAyDt6qXCxQmQNnW/81PnXw17Xy5Sv2m5007Xpm6W7nJAMgSSEVDDS/eKZFJIDQEIQAACEIhGgDZSNF5RY7viqyWFPvQvfHMARC0fK/FVyDgBrKDMvZCg8597Q3JugK5JOv85L8SSqK+6WhJTMRMCEIAABDwhQBvJXUHoue6Sr5wAysOdBe0le+YAaK+wqxgqCJwArujmQ67Kn9G8fJQVWkLAFwI+PMh9YYEeEIAABCDgnoD6LO5zKW8OLjv/AVXlkWWfwy8HQEAlo09dUHpDgDqCGalAthkR0Hp/lX9G2ZNtHQGVg26MdYf4CgGvCVBfvS4elIMABCBQKAI8c9wVp9qg7qR3lJxmXh1zNsYrB0Bn5bL6rQLBCZAV/XTz1ZR/OX18WI+TruXkBgEI2CSQpSffph3IggAEIAABfwmoj+KvdvnXLM1nuWYQZkXMJwdAVgwa5qsLDCdAQzSFOajyTfNCLww4x4bg2XYMGPFOCOiZ4UQwQiEAAQhAAALTCdBunQ7C0UfanfKsytMjB4CjkkwgVg06jQ6ro5hADEk9I6BRf6b8e1Yo09XJ6kY4PXs+IBCbQNqNhtiKkhACEIAABHJLgGeNu6LLog2aRZ4i6I8DQNp4GuQIwAngaeFEVEudf11sTPmPCI7oEIAABCAAAQhAAAKZEVD7NbPMS5BxFnyzyFNF6Y0DQMr4HOQE0KgxjgCfS6m1biq/rC601ppxNiBA+QQk+IQABCAAAQhAAAIQgIB9Ar44AOxb5kCiRo3lCMAJ4ACuQ5EqLy3lUPk5zAbREIAABCAAAQhAAAIQgAAEvCbgiQPAa0ZdlJMTQB1KdSy7nOSANwQ03V+j/iovb5RCEQhAAAIQgAAEIAABCEAAAhkR8MMBkJHxSbNVxxJHQFKK9tMHHX9NJ2fU3z5fJEIAAhCAAAQgAAEIQAAC+STghQMgn+i+01qOAGYDfMcjy28qBzr+WZZAsrxx2CTjR+ryEeCaKV+ZY3EyAlwzyfiRGgIQyD8BHxwA+adYtUBOAGYDVEFk9F+j/uKvcshIBbKFAAQgAAEIQAACECgBARxJbgs5C75lyVMl54EDQGoUJ6gDqo6oRqLVKS2OZX5aIs7irVF/PzVEKwhAAALuCGTRYHFnDZIhUEwCXKfFLNe0raIepU28uPll7wAoKFs5AtQpVQdVoaBmZmKWHCva3E8df3HORAkydUJADzeVrxPhCIWAQwJZ3ed1zTg0C9EQKBQBrtNCFWemxmR17y1DG6lM12lW9ShzB0CmV28KmauDqqDOalYVOgUzU8lCNz11/OVYyeqCScVQMoEABCAQgYDujRGiExUCEMiAANdpBtAdZZlle159CkdmIbZKIO3rNKv+TNYOgCrq8vzXRYsjIHp562Kk4x+dW15T6DrJq+7oXU4CagxmWW+zzLucJY7VeSWQ5bWSZd55LS9f9c6yLLPqMKZZFlnyTTNvtR3S5FqfV8YOgHpVyvNdlStwBGRZ+D4TDzr94sSIv88lZV83PdxU/vYlIxECxSTANVPMcsUquwSybm9xndotz6ykZV2PZLcPOkgPFyFr29K8TtUfdMEwjMxsHQBhNCxwHBW8gjq5qvAKBTa3rWnq9GmkXzzo9LfFVegIKn/Vh0IbiXGFIKD7tu7jWRvjgw5ZMyB/CDQjwHXajAzHoxLw4V4rHYrYRirTdSpbo9Y9m/EzdQDYNCTvsnQxK6jzq0qhkHebwuivG5g6/Qrq9MnzFiYdcYpPQNdD8a3EwjwT0P3Ll3qqe2dZnht5rjPonj4B365TtXfSp0CONgj4VHZqM9uwyScZPj1PXZa1ntVZ25qlA8CnOueVLqoUCnIGqAKqoih4pWRMZfQgVpBdsk83MDVcFWKKJFlBCahOFKXeF7SISm2W7mO6f/kEQc8NrhmfSgRdsibg43XKsy3rWhEvf7VbVXbxUrtJJZ3cSE5Xqq5T32xRWbt4nkqmntXpEu6aW4YOgK7KcKQrAVVAVRQFdZh1gajyKHSN7d8RXdTSVXpLfzWYFWSXf9qikW8EgnqveuSbbuhTXgK6p+k+5iMBXTO63/qoGzpBIE0CXKdp0i5uXmp/6J7qY7tVOqltrbqe1xIQXz1PZYtvNth+nqoeSaYPdmbnAPDB+hzqoAtElUdBF72CKpQufgVdSAppm6Y8FaSD9FGQbrqopav0Tlsn8isOAdUj1a3iWIQleSSge5zubbqn+ay/7re6/3LN+FxK6OaKANepK7LlkhvUI7U/dE/12Xo9k3S/l84+61mvm3TV81R864/79l1ln/R5qrKRDMnyxb7MHAC+ACiCHqpQuvgVdCEpqKIp6OJSxasPuug6h3oOnc8Fv+tlSK6C8lBQngrSQfoo1MvkOwSSElDdUl1TvVNdDOplUrmkh0AzAkEdU51T0D0uT/e24JrR9aIge5rZynEI5JWA6rWCrlGFIlynsiev5ZFXvcU8CHmtR6r70j2438seX8pDuihIPwXpmsfnqXRvxVc2BkFx1W7Vs9iXcgj0yMoBEOTPp2MCurhU8eqDLrrOQRU0CJ3PBb/rZUiugmP1EQ+BLgRU71QXg3oZ1Fs+vzUwsMsgqGOqcwpdKmNODuh6UZA91BG7dQSe2fNUvVbQNaqQk8uyi5q6RhVkiwJ1K926JeZByHM9ku4+1qN6ttKxywWQkwPSvRXfwE59Kq6vZmXkAPAVB3pBAAIQgAAEIAABCEAAAhCAAASKSSAbB0AxWWIVBCAAAQhAAAIQgAAEIAABCEDAWwKZOAC8pYFiEIAABCAAAQhAAAIQgAAEIACBghLIwgFQUJSYBQEIQAACEIAABCAAAQhAAAIQ8JdABg4Af2GgGQQgAAEIQAACEIAABCAAAQhAoKgE0ncAFJUkdkEAAhCAAAQgAAEIQAACEIAABDwmkLoDwGMWqAYBCEAAAhCAAAQgAAEIQAACECgsgbQdAIUFiWEQgAAEIAABCEAAAhCAAAQgAAGfCaTsAPAZBbpBAAIQgAAEIAABCEAAAhCAAASKSyBdB0BxOWIZBCAAAQhAAAIQgAAEIAABCEDAawKpOgC8JoFyEIAABCAAAQhAAAIQgAAEIACBAhNI0wFQYIyYBgEIQAACEIAABCAAAQhAAAIQ8JtAig4Av0GgHQQgAAEIQAACEIAABCAAAQhAoMgE0nMAFJkitkEAAhCAAAQgAAEIQAACEIAABDwnkJoDwHMOqAcBCEAAAhCAAAQgAAEIQAACECg0gbQcAIWGiHEQgAAEIAABCEAAAhCAAAQgAAHfCaTkAPAdA/pBAAIQgAAEIAABCEAAAhCAAASKTSAdB0CxGWIdBCAAAQhAAAIQgAAEIAABCEDAewKpOAC8p4CCEIAABCAAAQhAAAIQgAAEIACBghNIwwFQcISYBwEIQAACEIAABCAAAQhAAAIQ8J9ACg4A/yGgIQQgAAEIQAACEIAABCAAAQhAoOgE3DsAik4Q+yAAAQhAAAIQgAAEIAABCEAAAjkg4NwBkAMGqAgBCEAAAhCAAAQgAAEIQAACECg8AdcOgMIDxEAIQAACEIAABCAAAQhAAAIQgEAeCDh2AOQBATpCAAIQgAAEIAABCEAAAhCAAASKT8CtA6D4/LAQAhCAAAQgAAEIQAACEIAABCCQCwJOHQC5IICSEIAABCAAAQhAAAIQgAAEIACBEhBw6QAoAT5MhAAEIAABCEAAAhCAAAQgAAEI5IOAQwdAPgCgJQQgAAEIQAACEIAABCAAAQhAoAwE3DkAykAPGyEAAQhAAAIQgAAEIAABCEAAAjkh4MwBkBP7URMCEIAABCAAAQhAAAIQgAAEIFAKAq4cAKWAh5EQgAAEIAABCEAAAhCAAAQgAIG8EHDkAMiL+egJAQhAAAIQgAAEIAABCEAAAhAoBwE3DoBysMNKCEAAAhCAAAQgAAEIQAACEIBAbgg4cQDkxnoUhQAEIAABCEAAAhCAAAQgAAEIlISACwdASdBhJgQgAAEIQAACEIAABCAAAQhAID8EHDgA8mM8mkIAAhCAAAQgAAEIQAACEIAABMpCwL4DoCzksBMCEIAABCAAAQhAAAIQgAAEIJAjAtYdADmyHVUhAAEIQAACEIAABCAAAQhAAAKlIWDbAVAacBgKAQhAAAIQgAAEIAABCEAAAhDIEwHLDoA8mY6uEIAABCAAAQhAAAIQgAAEIACB8hCw6wAoDzcshQAEIAABCEAAAhCAAAQgAAEI5IqAVQdArixHWQhAAAIQgAAEIAABCEAAAhCAQIkI2HQAlAgbpkIAAhCAAAQgAAEIQAACEIAABPJFwKIDIF+Goy0EIAABCEAAAhCAAAQgAAEIQKBMBOw5AMpEDVshAAEIQAACEIAABCAAAQhAAAI5I2DNAZAzu1EXAhCAAAQgAAEIQAACEIAABCBQKgK2HAClgoaxEIAABCAAAQhAAAIQgAAEIACBvBGw5ADIm9noCwEIQAACEIAABCAAAQhAAAIQKBcBOw6AcjHDWghAAAIQgAAEIAABCEAAAhCAQO4IWHEA5M5qFIYABCAAAQhAAAIQgAAEIAABCJSMgA0HQMmQYS4EIAABCEAAAhCAAAQgAAEIQCB/BCw4APJnNBpDAAIQgAAEIAABCEAAAhCAAATKRiC5A6BsxLAXAhCAAAQgAAEIQAACEIAABCCQQwKJHQA59hTywAAAEABJREFUtBmVIQABCEAAAhCAAAQgAAEIQAACpSOQ1AFQOmAYDAEIQAACEIAABCAAAQhAAAIQyCOBhA6APJqMzhCAAAQgAAEIQAACEIAABCAAgfIRSOYAKB8vLIYABCAAAQhAAAIQgAAEIAABCOSSQCIHQC4tRmkIQAACEIAABCAAAQhAAAIQgEAJCSRxAJQQFyZDAAIQgAAEIAABCEAAAhCAAATySSCBAyCfBqM1BCAAAQhAAAIQgAAEIAABCECgjATiOwDKSAubIQABCEAAAhCAAAQgAAEIQAACOSUQ2wGQU3tRGwIQgAAEIAABCEAAAhCAAAQgUEoCcR0ApYSF0RCAAAQgAAEIQAACEIAABCAAgbwSiOkAyKu56A0BCEAAAhCAAAQgAAEIQAACECgngXgOgHKywmoIQAACEIAABCAAAQhAAAIQgEBuCcRyAOTWWhSHAAQgAAEIQAACEIAABCAAAQiUlEAcB0BJUWE2BCAAAQhAAAIQgAAEIAABCEAgvwRiOADyayyaQwACEIAABCAAAQhAAAIQgAAEykogugOgrKSwGwIQgAAEIAABCEAAAhCAAAQgkGMCkR0AObYV1SEAAQhAAAIQgAAEIAABCEAAAqUlENUBUFpQGA4BCEAAAhCAAAQgAAEIQAACEMgzgYgOgDybiu4QgAAEIAABCEAAAhCAAAQgAIHyEojmACgvJyyHAAQgAAEIQAACEIAABCAAAQjkmkAkB0CuLUV5CEAAAhCAAAQgAAEIQAACEIBAiQlEcQCUGBOmQwACEIAABCAAAQhAAAIQgAAE8k0gggMg34aiPQQgAAEIQAACEIAABCAAAQhAoMwEwjsAykwJ2yEAAQhAAAIQgAAEIAABCEAAAjknENoBkHM7UR8CEIAABCAAAQhAAAIQgAAEIFBqAmEdAKWGhPEQgAAEIAABCEAAAhCAAAQgAIG8EwjpAMi7megPAQhAAAIQgAAEIAABCEAAAhAoN4FwDoByM8J6CEAAAhCAAAQgAAEIQAACEIBA7gmEcgDk3koMgAAEIAABCEAAAhCAAAQgAAEIlJxAGAdAyRFhPgQgAAEIQAACEIAABCAAAQhAIP8EQjgA8m8kFkAAAhCAAAQgAAEIQAACEIAABMpOoL0DoOyEsB8CEIAABCAAAQhAAAIQgAAEIFAAAm0dAAWwERMgAAEIQAACEIAABCAAAQhAAAKlJ9DOAVB6QACAAAQgAAEIQAACEIAABCAAAQgUgUAbB0ARTMQGCEAAAhCAAAQgAAEIQAACEIAABFo7AOADAQhAAAIQgAAEIAABCEAAAhCAQCEItHQAFMJCjIAABCAAAQhAAAIQgAAEIAABCEDAtHIAgAcCEIAABCAAAQhAAAIQgAAEIACBghBo4QAoiIWYAQEIQAACEIAABCAAAQhAAAIQgECLGQDAgQAEIAABCEAAAhCAAAQgAAEIQKAwBJrOACiMhRgCAQhAAAIQgAAEIAABCEAAAhCAQNMZAKCBAAQgAAEIQAACEIAABCAAAQhAoEAEmswAKJCFmAIBCEAAAhCAAAQgAAEIQAACEIBAkxkAgIEABCAAAQhAAAIQgAAEIAABCECgUAQazgAolIUYAwEIQAACEIAABCAAAQhAAAIQgEDDGQBggQAEIAABCEAAAhCAAAQgAAEIQKBgBBrMACiYhZgDAQhAAAIQgAAEIAABCEAAAhCAQIMZAECBAAQgAAEIQAACEIAABCAAAQhAoHAEuswAKJyFGAQBCEAAAhCAAAQgAAEIQAACEIBAlxkAIIEABCAAAQhAAAIQgAAEIAABCECggAQ6zQAooIWYBAEIQAACEIAABCAAAQhAAAIQgECnGQAAgQAEIAABCEAAAhCAAAQgAAEIQKCQBDrMACikhRgFAQhAAAIQgAAEIAABCEAAAhCAQIcZAOCAAAQgAAEIQAACEIAABCAAAQhAoKAE6mYAFNRCzIIABCAAAQhAAAIQgAAEIAABCECgbgYAMCAAAQhAAAIQgAAEIAABCEAAAhAoLIEZMwAKayGGQQACEIAABCAAAQhAAAIQgAAEIDBjBgAoIAABCEAAAhCAAAQgAAEIQAACECgwgekzAApsIaZBAAIQgAAEIAABCEAAAhCAAAQgMH0GACAgAAEIQAACEIAABCAAAQhAAAIQKDSB2gyAQluIcRCAAAQgAAEIQAACEIAABCAAAQjUZgCAAQIQgAAEIAABCEAAAhCAAAQgAIGCE5jJmIJbiHkQgAAEIAABCEAAAhCAAAQgAAEImJkMECAAAQhAAAIQgAAEIAABCEAAAhAoPIGZCm8hBkIAAhCAAAQgAAEIQAACEIAABCBg2ASQSgABCEAAAhCAAAQgAAEIQAACECg+ATYBLEEZYyIEIAABCEAAAhCAAAQgAAEIlJ6AwQFAHYAABCAAAQhAAAIQgAAEIAABCBSeQNVAlgBUIfAfAhCAAAQgAAEIQAACEIAABCBQZAKyDQeAKBAgAAEIQAACEIAABCAAAQhAAALFJVCzDAdADQN/IAABCEAAAhCAAAQgAAEIQAACRSUwzS4cANM48BcCEIAABCAAAQhAAAIQgAAEIFBMAtOtwgEwHQQfEIAABCAAAQhAAAIQgAAEIACBIhIIbMIBEJDgEwIQgAAEIAABCEAAAhCAAAQgUDwCMyzCATADBV8gAAEIQAACEIAABCAAAQhAAAJFI/CdPTgAvmPBNwhAAAIQgAAEIAABCEAAAhCAQLEI1FmDA6AOBl8hAAEIQAACEIAABCAAAQhAAAJFIlBvCw6Aehp8hwAEIAABCEAAAhCAAAQgAAEIFIdAB0twAHTAwQ8IQAACEIAABCAAAQhAAAIQgEBRCHS0AwdARx78ggAEIAABCEAAAhCAAAQgAAEIFINAJytwAHQCwk8IQAACEIAABCAAAQhAAAIQgEARCHS2AQdAZyL8hgAEIAABCEAAAhCAAAQgAAEI5J9AFwtwAHRBwgEIQAACEIAABCAAAQhAAAIQgEDeCXTVHwdAVyYcgQAEIAABCEAAAhCAAAQgAAEI5JtAA+1xADSAwiEIQAACEIAABCAAAQhAAAIQgECeCTTSHQdAIyocgwAEIAABCEAAAhCAAAQgAAEI5JdAQ81xADTEwkEIQAACEIAABCAAAQhAAAIQgEBeCTTWGwdAYy4chQAEIAABCEAAAhCAAAQgAAEI5JNAE61xADQBw2EIQAACEIAABCAAAQhAAAIQgEAeCTTTGQdAMzIchwAEIAABCEAAAhCAAAQgAAEI5I9AU41xADRFwwkIQAACEIAABCAAAQhAAAIQgEDeCDTXFwdAczacgQAEIAABCEAAAhCAAAQgAAEI5ItAC21xALSAwykIQAACEIAABCAAAQhAAAIQgECeCLTSFQdAKzqcgwAEIAABCEAAAhCAAAQgAAEI5IdAS01xALTEw0kIQAACEIAABCAAAQhAAAIQgEBeCLTWEwdAaz6chQAEIAABCEAAAhCAAAQgAAEI5INAGy1xALQBxOl0CLzz9qfm2gvHWg1vvvpROsqTCwQgAAEIQAACEIAABCAAAQ8ItFMBB0A7QpxPhcD/3vjEHH/EHVbD66/gAEil8MgEAhCAAAQgAAEIQAACEPCBQFsdcAC0RUQECEAAAhCAAAQgAAEIQAACEICA7wTa64cDoD0jYkAAAhCAAAQgAAEIQAACEIAABPwmEEI7HAAhIBEFAhCAAAQgAAEIQAACEIAABCDgM4EwuuEACEMpxTivTHzfPDTqZXP1eU+bE347yvxmv5vMj3e51vxgs8vM9muda/oudHIt7LjO+WavTS81B+9wtTliz+HmqINvMaf+8T5zw2XjzJMPv2b+9+YnKWpNVhCAAAQgAAEIQAACEIAABCCQIYFQWeMACIXJTaQP359qRt/7irno9MfML/e+YUbHXh3+P//yLnPZWU+aEdc/X3MIjHviTfPq5A9nKCJHwfgn3zKP3jfF3HPrRHPL1c+a80951Bxz2O1m/62vNFv0/E8tHHnAzeaa88eYF8a/MyMtXyAAAQhAAAIQgAAE/CSg9qHtNyNJXpbW3n/HS1be9DTx2XczM0Ntb3G0GUbe9GJm9rTL+OG7X7ZSZgGvyS++1y5LzicmEE4ADoBwnKzF+vSTL83IG18wv973JjOw25nmkB2vMSf9/t7qMfs3AM0CuP2658yffnGnGdL/IrPD2ueZU4651zx412Qz9fOvrNmEIAhAAAIQgAAEykXg+J/fWRu4CGYm+vqpGZOaRXnITteYX/zgBvOHH99mTv/TA+a6i8aaB0dONupQfvTBVK8Kb445ZzF//81Iq29G0puW3pjyUWZ2/uN3d1ux57Zrn83MBs3QFUebYcyjr2dmT6uMv/ziazO0Oqho09arznm6VZacs0EgpAwcACFBJY323Ni3zd+PHGU2Wvb06mj/jeaO4c8nFRk5/ZRJH5gLTnvMHLbbdWb7tc4zF5z6qHnz1eweBpENIAEEIAABCEAAAhCIQECjtppFOfqeV8yom180N14+3pzzz0fMcYffYQ7b9Tqz2wYXmgErnmn2Hnx5bSbl2MffMF9/9U2EHOxHnW32mc36g5a3LvilF7IZgVVbc7KlvDXz1TqYkALVlg8ZNXS0nn0WCx03zYiPP/iqefO1j61mOfzScUYDoVaFIqwDgbA/cACEJRUznqa76CGzxyaXmMvPfjKmFPvJNDvglKH3ma1XP6e2bODp0X56IO1bjkQIQAACEIAABCDQkcDYx96o7aW09+aX19pGGrTRiG/HWOn96tNvSeuZTcxoOeizY962ZssT1Y7pJx9/YU1eFEFPPWK/rbxy70WiqJBa3Duutz9Q+fGHU80Dd76Umg0lzCi0yTgAQqOKFvGdtz81Jx59j9l53Qtq08yipU43tjYO3HfLK8zQn9xu3n6DzQPTpU9uEIAABCAAAQj4RECDJBq00Z5MWj6gWQNpj1z2WH1R60gmjHnLuswwAp954s0w0ULHGf9k+nZ88O7n5oVx/wutY5iI88w3u1l2xQXCRE01jjrqN10x3kmet1w1wYlchIpA+IADIDyrUDG//dYYrU/aa+Cl5uIzHg+VxpdImprzvQ0vrL2BQGt/fNELPSAAAQhAAAIQgEAWBLR8QPsGaAnneSePNh+893kqanTvZX9k+KGRL6eie+dMtOF152NJftt2KITR5eWJ9pdPbLjZ8mbmWfzrit1z2yTz+Wdu9grTpodaEhKGOXEiEogQ3b9aF0F536K+OvkD8/O9hpvfHniLeev1j31TL5Q+H74/1egNBD8ZMozZAKGIEQkCEIAABCAAgTIQOO3Y+80eG19c20fgqy+/cWryYkvOY5Zabj6reWhmg4JVoW2EffLRF+bJh15rEyva6ScfejVaAguxtVmkBTEdRKyxjv1lHh0yiPlj+KXPxEwZLtldN9rf+DxczsWOFcU6HABRaLWIq3Vie2x8Se2VfC2i5eaUNsvZb1+jiQsAABAASURBVKsrDHsD5KbIUBQCEIAABCAAAccEtDGaZgTorQK2O7adVd9o8IqdDyX+/dLz9keyWyk1/in70/WzeJvV85an/4vZKg6WeUhukvDyi++bR+5+JYmItmmvOf9p880337aNR4RIBCJFxgEQCVfXyJryf8V/njJaJ5bVpiRdtbJz5LWXPzQHbndVbUmA7LQjFSkQgAAEIAABCEAg3wS0Gd3+21xptKGyq9kAvda0v0P8xGffSRX8uCfftJ7fF1O/Ni+kvKHhmNFvWLdjpVUXti4zqcBRt7yYVETb9JpNoaU1bSMSIQKBaFFxAETj1SG2OsVn/OkB87ffjOxwvEg/9FDTkoBT/3ifkb1Fsg1bIAABCEAAAhCAQBICeqXyL/e+wbz/zmdJxDRMu8pq9jcCfG6s3Y3sGiped1COkrqf1r6Od+BYaKacNoAc86jdNwCsuMpCZsFF5myWZSbHNSp/9XlPp5L3nTe8kEo+pckkoqE4ACICC6KrM3z23x8y55z4SHCo0J96wJ3zz3LYWuiCxDgIQAACEIAABKwSuPe2SWa/ra80zz9jt3PdrTpCPNvsM1vV9ZF7XrYqr5WwqZ9/ZTRdv1WcuOdcvJKvmS4vv/Bes1Oxj/fffIXYaV0l1LLfKZM+cCW+g9xrzh9jVD86HORHbAJRE+IAiEqsGj/o/J/1t4eqv8rz/4w/P2DkCCiPxVgKAQhAAAIQgAAE2hOYXO0k7l91AtjcoV6d/3U3XrZ95hFiqIPnYrZCIxU0TV/T9RudS3rsgTtfMt98nc468onPvZtU3S7pezpY3tElk4gH7hye3qi8XjXoyjkU0ewiRI9sAw6AyMiMufC0R03ZOv8BJq11u/TfTwQ/+YQABCAAAQhAAAIQqBLQXlA/232YeXGCvXX2ffotVZVs9//kF+2PaDfS8Nmn7W8AGOTz3v8+My9VnS7Bb5efLzrYb2Dl3vaXdyRhoGUO11/idvf/zvrdes2znQ/xOxaB6IlwAERkpt3+1QmOmKxQ0f/xu7uNOBTKKIyBAAQgAAEIQAACCQmoY/rTIcPMay9/mFDStOSr9rHfUdQmbNOku/3repr+BIcOhnoyYx+3uwHgPPPNblZcecH6LDL//tBdk41G5dNU5PbrnjPvvPVJmlkWM68YVuEAiADt1ckfmN8eeHOEFMWNevwRd5gP3v28uAZiGQQgAAEIQAACEIhB4I0pH5nf7HeTlTXO3XsuEkOD1kls71XQKDdNz79vxKRGp6wds70xXyPFtIRBr8ZudC7usXU3WcbMPItfXbCsRuNH3uT+rQNxyykv6eLo6Vfti2NBSmk++/TLauf/Fjq903nLs33SH+6Z/osPCEAAAhCAAAQgAIGAgPYCOP34B4KfsT+XWGZes2y3BWKnb5RwzGi7O9o3yuPlie8ZzYZodM7WsYfucr+h4SuT3rel7gw5LpZ1zBAe44tG4e8Y/nyMlMmTXHfRWN4ylgxjrNQ4AEJiO/fE0WbsY3anALXKetU1FjVHHLuxOeGC7cx/b/yeufrBvc2IZw82j797hLnvlcPM7eMPMtc+so+56M7vm39dtZP583+2NocdvaHpvdbircRaPTf80nFm5I3pbRhiVXmEQQACEIAABCAAAYcELj7jcXPPrRMT52B7I0A5J7TmO7FiLQRMePrtFmftnNJeBhqQsiOtsZSXnre/X4KL1zs21j7c0SxfyTf+ybeMy70iwhHIc6x4us8UL1m5UqlypvG6v2VWnN8cdtSG5tJRe1bDXmbvn6xtNtu+u+m74dKmW4+FzMKLzlUDP9fcs5pFFp/brNB9wVqHf8PNVjBb7drDHPCLfjWHwA2P72f+7y8DzdLLz1eL7/LPqcfeb76Y+pXLLJANAQhAAAIQgEAJCCy/0oJm2917WgsbDV7BdO9lfwp9lKI4Ys/hidc59+5rf3BnkoOd7eu5pDVo9txYt46GF8bZfbWjGHXvubA+vAh6s1nam/91NvxOBhM7Iwn/O2ZMHAAhwJ3wu1EhYiWL8ovjNzFXP7C3OeCX/cyqayyWSNjSK8xvvn/Imubah/cxR5+0WSJZ7RLrtTc3XjGhXTTOQwACEIAABCAAgZYE1hu4nDnuzC2thVOv2Mlced8ParMn7550qLnhif3MWcN2NVvsvEpLPWyfvOK/TyUS6WLEeNKz7ybSqV3i++94qV0UK+efefxNK3KaCRn/lN03Gay4ykK1Qbxm+aV9XKPvGuhMO9/6/IZdONbKfhn1MsvyPa6dOADakLvq3KfNkw+91iZW/NOa6n/Z3XuZH/y4r5lt9pnjC2qQctbZZja77LN67eHXY3X7u8gGWZ79t4fMJx99EfzkEwIQgAAEIAABCHhFYN75ZzdLLz+/WXeTZc1fz9mmtozSRdurkdEXnvaYefuN+Ludr7Sq/RFjFyPbge1vvvqR0QBR8Nvl5yP3vOJM/NdffWMeGjnZqnw5uawKTCjMh9H3d97+1Dx635SElpQyeWyjcQC0QKfXYZx+/P0tYiQ7pdH+827d3bjsnEtDTX875+YhZpe9V9NP6+Gt1z82WU8fsm4UAiEAAQhAAAIQKCwBLaPU7MsbntjfbLzlik7t/GLq1+bys5+Mncccc85i1h+4XOz0jRKOcbiv1bNj3E7Lr7dHbwL44D03b6WaMvkDo7Krzy/p915r2l/OEVenqZ9/Za69YEzc5FbT3Xbts1bllUNYfCtxALRgp03uPnx/aosY8U8dPnSj2nr/2eeYJb6QCCm1b8BRJ21e2ysgQrLQUeXd/oK9AELzIiIEIAABCEAAAtkTWHSJuc0J529nhhzYx6kyF53+mEnSpuyz3lJW9XviwVetd24DBbXJYPA9jc8JT9udph/oPNnBBoAr9852T4rANn1q1N31mxqUT5ig1xC+/85nYaISJyCQ4BMHQBN42h31vJNGNzmb7PDAbVaqTflPJiV66krFmF/+eYBZbMl5oiduk0KzAFxOw2qTPachAAEIQAACEIBALAJagvmbvw2qbaAcS0CIRF99+Y158K746+KT7g/VSMWXnnezD4A6lo3yc3Vs3BNu9gF4ccI7VlVWPdMeAFaFJhB2+3XPJUhtN6muj1G3JH9jhl2t/JaWRDscAE3oyRP1ztufNjkb/7B2uD3m1MFm5lmyQa83CRx5wqD4BrRIeevVTN9pgYdTEIAABCAAAQh4SkCDJNpAef+fr+tMw9uujd/hcjFy7OJNANoTSrMLnEFsIPjxB15tcDT5oQmWX2Wo9f9yAiTXLLkEjbbfcrVfm3gPv+SZ5IaVR0IiS7PphSZS2X1ivRLj0jMfd5LRL/+8iZl/oTmcyA4rVDMQdtizV9jooePdfNWExK+6CZ0ZESEAAQhAAAIQgIBlAvsdsa7Ra5kti62JG3Xzi7E3A1xy2fnMUsvZfb3zC+PtjnDLSNu75ktmu6A3Dmg9e7t4Uc6rL/DgXXY3AOzTz+4yjij2dI57z22TjEbdOx/P8veTD79mXG5OmaVt9vNOJhEHQAN+Tz3ympno4PUoa663lOm/+YoNckz/0H6OPNx33fhi+sakkOMnH39hXpn4vnnphffMuw5mhqRgAllAwGsCWhur6+vlF983H7zrZkMnrwGgnDMCqluvv/JhrWGpKc9vTPnIaPTrs0+/dJYngvNLYO55ZzO//utAZwbcfcuLsWRrhkK/TZaNlbZZonEOXqE37kk30/Gb2RAcf26s3Y0H35jyodFm4IF8G5+uN/2OouNNV4yPEr1l3AUXmbPl+Sgn775lYpTo5Y2b0HIcAA0A3jH8+QZHkx865Mj1jW7gySUll6ClCH03XDq5oE4S5N3udChXP9XRH3nTi+bck0abP//yLnPYrteZrVf7r9l4uTPMjuucb3bpd4HZvMfZpu9CJ5sd1j7PHLLTNeb4I+4wwy5+xjz/zP9yZasrZcc/+ZYZcf3z5uIzHjfHHX6H2X/rK2u8dl73AnPgdleZIw+42Zz8h3vNDZeNM/97M/5rkWzo/+UXX9fK7d6qJ/ya88eY0//0gDnmsNvN4d+/3uy75RW1MldZb9HzP+b7Ay4xP9r5GnPUwbeYE347ymhDJ62fe3r06ziFIhTG5Bffq10vZ/z5ATP0J7ebA7a9qlY/BnY7s3Z97bTu+WZQ93/Xjg3Z6OJaWZwy9D5zz60Ta522CFnlMuqbr31sHrt/itEytAtOfdT87Tcjza/3val2r9ljk0vM4On3H11P+1evrSP2HG7++NMR5sy/PGiuvXCs0UiYi1E932G+9vKH5q4bXjD/POoe88sf3lC7frdZ45xaPVLd2rbPuUb1aZf1LjQ6vunKZ5n+y5xeO69r+zf731xLe+G/HjNqgOo1Zr7bjH7uCGw0eEWzzZBVnWQw+t4pseX27rtE7LSNEj72wBTrGwG6fHV2IxuCY2p7BN9tfMohbUNOvYzuPe2/zrFeftjvGuQcfa+91yf+4rhNwmbdNt7V5z1t1DZrG7HkEZKajwOgE0Ft/jf8knGdjib/uW7Va7veALuvcEmq1ba790wqokv6B++abLT+q8sJjw/o7QUPjpxc6/Cro6/G47+Ou9/oJqTjapA3Un/KpA/M6HteqTW6j/3ZCLP7xhebzVY5q9YYV+Ndchulc31MnQBbQbMewuir0bVLz3yi1mHea9NLzW/2u8mcePQ95rqLxhpN6ZIMdfy0Tk+dZjWy1dE+5se361SqQQ91OR/U+VxvidNq5XZ4tcP/p1/cac755yM1x4QcAurYB/bLUaHXGj1y9yvmlqufNZed9aQ56ff31pwZchTIKSRn0DknPmJko28ji3dWO0ZyZNgIew68JHJ5vTr5AyMHyz5bXGHUcdX18t9/PGL0ppVWa0U1FfDeqnNGHWF1dNVpkxNJv1XnIiviYQI5HdUQO/vvD9c6rXI4HrT91eZ3B91iTqk6Pq74z1NGTmndazTCFexNo+tJ15YcI3oN639OeLjmjPzpkGFmSP+Lavei439+p7n5ygm12Usemp5Ipbff+MTotVH/+N3dZud+F5jt1jzX/GqfG80lZz5u5MTV9ftGdaQ/TCa6tkcMe66WVs7Jn+813Gy9+jlmtw0urDkFVAe/mPp1GFHEKRCBHffq7cSah0fFn1a+ymp2d5BXvZ7y0gfW7NQ0/AfujL/RYRJFdD9Mkr5z2kkT7G6QqOUbiy89b+dsMvkddxZKI2UHbbeSGbzTKma+BWZvdDryMbW5H3O0p0NkZfxNkFgzHACdED5a9YjZnvKjLA49cgN9eBU23mJFJ/rkZSRcIzynHXt/raGnkX51+JMC0etU1BhX433X9S80114wxsiplFRulPSakWArPNtmSp1e9aPRSY2u/eOouyN3NGaZLZ1bkDrucuqoo6BZHHI+qPMZhWu7uOqgnX78A7VZDhpZ/O2BtxjVBdWzdmnzdD7KpkhyhKnDvv1a5xk5WMY8+npiU+VgUcdYde6f1dHewEmTWHCKAtT/uWS/AAAQAElEQVQxlXNMo85yOh6y4zXm33990KjTaksN3Yt0/zn6R7fWHHNyCmiGi64FW3mkLUdrcrVET46NbfucY3SNXfrvJ8zkF95zoopGyeRQkINQM1PkIJQD0UlmCPWOgNZr2+rU1Bv34ftTjTo59cfCfl+596Jho4aO99Jz9jq6mn0kp0LozC1GlKPum6+/tSZxwhi7rxbccLMVrOmWRNDXX31TG5xJIqM+7aBtuhttbLj19+zNmLmj6pCtz4PvnQkk/51O6zu5nqlJSDI1q5mS3XosZNZc35+NPwI9F1l8bjNo25WCn9Y+xzyWvJFvTZkGgtSI1NqnPQddas47ebRRQ7lBtMSHXp38oVFDddf1LqiNGOuhn1hoygJa6awO9AHbXFkbnYyr1iyO34ahzqKmmGvqvpZ1uOooNLJfo5Oami2ng2YGfPTB1EbRcnlMozytFJcTUNzlCFMZtIqb5Jw6Z1qaI4eXOmtJZKWRVs5lzXxQZ/K4w+8wGnVOI1/loYa5OrC6FuSUyWqarnSJGuREveXqCeaAba80+211Zc2xmvbmVXLayIEiB6KWAWl2SlQ7iJ8vAurUbLWbvU5NvfVxHZdzzDmLWXdju/sA6N5Qr1uS788+bbfTHEUXzaZ60eJr+x4a+XKU7NvG7bXW4m3jpBHhiYdeM5rBaiuvDTZbvibK5qDi8MvGlWLJXw1cnD8W0uAAqIP4zTffOmmQDdque10ufn1de8NlrCs04ansHgDtjNFo7K/2vsH8/tDbnHX8O+sgT7/WjO+xycVGU3g7n/f590fvd92M7YupX5m//npkbf32Fwmnxc4y68xOzNfDTWWsjk6rKeZOMu8k9PPPvjKaGaAlIjdePr4Qa9s+/uiLTlZO+6kOrmZayNY0uWvJi6Zra5nBNE38+qvOqspea9C190HS6yapdXLK7F913slBo6UESeW5TK99ZXbf6CJz1MG3Gl+cFrdc/WxtPwE5ceJ25FwyQ7Y9AhsNdjNq+/YbH8dWss96S8ZO2yjh+KfebHQ41rGnHsl2AEjLeWIp3imRlv0pdDqc6Ocqve0u34irjJaUxU3bOZ2uD71eXMfX7r+MkYNK35MGPTO1n01SOUVNb8MuHAB1FCdWPYdvvR7/plwnqsNXXRQdDnj0Y/Fl5rWujRqX1oUmFKhRfzXA9xhwSW19aEJxsZJrBOnA7a42D42y61WOpUzIRJ1Hrd9+4xPz092vN1f+96mQElpHm2WWSusIEc9K37P+9pDZbcMLjWZ5REzuNLrK/w8/vq06inmV0TRs1UmnGToULs714mWL9hnQZmqaaVF/Ls3vWmag/QHSzLNdXo/eN8UcvMPVRmWvOtAufprntUTjexteZOSU0K74aebdLi/t8fCLH9xgFF6d/GG76Jmc1zIOObu0fEzTajNRgkydEujWw82mbR9/+EVsvXv2sTuS/Nj9rxob9VfT7+8bMSm2XTYS2lpG9dLz9pcVdVvVTV2Kwk1O+uGXPBMlScu4m26/8ozzs88xi7G5t9gNl4+bIZsvHQhY+YEDoA6j7Q1EJHqWWWcyffrZ9dZKrq2w+NLz2BI1Q45GvHWTmXHAgy8n/f6eWgM869eLicuPd7k20bT5NHF+8N7nM7LTSPbPdh9W2/hwxsGEX2axOANg0nPvmh9sdpmRAyDrEdZWWMY+9kbtbQL/+N0oIy93q7i+nuu80ec/j7rb/N8+NxofOmraH0AbUmbNTg3qU/94X63z7+LZYss+1cH//uMRoyVRvsxQ0saH2uNBo/+27HQlR/dFvTHml3vfaF572U9HhSvbyyB3/oXmcGJmZydqlExs7ySvdomNe7dmE7laUhmWjxwQckiHjd8sntoTzc7FOb7BoOWtjY7HyT9Io1F13bOC30k/1xvQcTnKJlt2SypyRnoNlLz0vL39KWYIzv0XOwbgAKjj6GLq0sZbrmjmnGvWulz8+rrYkvYdALLw9Vc+0ocXQZtr6ZV0XigzXYmjD7nV5OHG9t47n03X2JjzTxltbE2vC4TOWnWQBd+TfMrrv99WV0TehDBJnknT6k0C2qBN6xaTyko7fdB4VSf3r/830mgjtrR1aJXfP6oOCRsbDrbKo9U57ZGgEf/zT3m0VTSvzml2QtYzlDSC+PcjR9VefegVnBDK6G0M+wy+3Pi8BC6EGUTpRGDueWYz88xnZ3dzU/cvuIfWHQr9dZkVFzDBtOvQidpEtLE/ju32QRuVG57WfexVC281sO0M7bOeH/uAaflSQ3AxDmoviiWXna9Dyr79l7bq6Bh188QO8vlhjLEEAQdAHUgXa1bX3sD+Gvs6lRN/deUAiDoSUrE7E3wGl4tOf8zo9VozDnjyRSPUR//ottTfEBDV/MCbr93+XXCc2cImgDdfNaG2836rDQuj2p1WfL0S8We7X2+0tCKtPG3ko8arOv8a+bzyHDvLQWzoVS9D11cWdUJT6X+x1w2110XW65OH7xoJ1AylYRc/k7q66vzLcXP52U+mnretDPWKxoN3vMabvQps2VV2Od16LGQdwYd1s+uiCld7Kdh4LWraZvFfnPBOs1Ohj2t2W+jIDiO2e3tRmKxtDwiuusaiYbJ1Gkd7YMlRaSuTLXZepYsoOcy23KVHl+NxD1x74Rgry1Pi5u9jOls64QCYTlIP7qid1ulJW34suVxH71jLyBmd/NPZW5mjT97caoi6tMDGlK3O+NQxOen393Y+7M3vcU+8aTRF2BuFGiiiTXC0A/cxP76twdnkh2ZJMANAdUZTlzWbQtOYk2uTjQQ5Hg/e/mqTp9eLqZOr9fZaA50Ntfa5anM2bb7ZPqa9GBp5UgfwwZGT7QnNQNKxPxtR27hSG+Omkb3yyXvnP+BUc6Lsem3uNnwN9OezK4F557c/A0CzhLrmFP7IamsvET5yiJjjLWzerOnlIbJyHiWpI0JLRW2/5aN7r+w3ALxz+AtW2ffbpOP0/0D4JlvZWwagDZ19XkIX2Jzip7WscABMR/nyC/Y3/JDoJR1ssie5NsPWu61qdtl7Nath1TUWs6liLFna4CpWwhQTaTM9jQKnmGWkrNSJuqo6wuvqFWtxXwP45RdfG3VAtXlZJIM8jay1k3qloi+7nLfDdOFpj5osRonb6dX5vDaC1DrCzsdd/J7w9Ftmv62vNLYbji50DSNTr648/og7TNKOSpi89ErRPI/8d7ZRa2y1eaGLTYU758Vv9wTUCbGdS9JlBT1WtzuiLEd0Ehs1umxjGcHy3RdMokYt7UMJHbAvT7TbH1ii2g9YKuPBQDlZNZpeA2Thz+rrLGmW7bZAQ0n9BixrkgzudBY64vrnOx8q8W97puMAmM5ykoMdPyV68aXt77IvuYTiEDjx6HvMF1O/8tagU4be50y3WWJuAnjasfebay8Y40yvLARrucWPdr7GuHK22LTJxoZRNvVpJevSs55oddrKOc0e+9FO1xjNmLEi0BMhcvKccOQop9po01jNOHCaSQbCVSd+ve9NJo97fGSAy9sstTRFDlrbCiadVbCS5R3lde9SnY1r53Nj/xc3aYd0B/1qvQ6/4/zQXgSa1RsnrdLYfgavP3A5ic00PPP4G1bbFtt8b9Wm9mgZQKPlAU0TtDmhtxZoZlWbaOU4bdFKHADTYU6Z9P70b/Y+tHvsgovMaU8gkgpJQKNE997+UiFta2fUTDNX2kXpcv7BuyYb3zZ17KJkzANfTP3aaLmFRhBjiiBZJwJa8/j8M3Yap51E135qNsoffzrCZLHfQE0Bx3+uvXCsue3aZ53lcuJRdzuTnbVgbU7qwxspsuaQ5/zf/d+nTtSfe97ZEsnVDII117e7sVySEfxnnngjkT1KPGDrbsaWTc+NeVsiY4Xnx9l9XtherhHHqLtusDv9f71BrZ0aA7dZKY6aDdOoPeTL8pKGCqZ40GZWOACm09T0pelfrX2s1tfuGi1riiHIOwLDLhrrnU5pKBR1CYBGydXZSkO3rPJ45ok3zb//8mBW2Rcy32EXu7u+9AaE0fe+UkhugVF/+dVd5tXJHwQ/rX2OvPEFU/Tpnf/5x8O5ejuJtcItiCA9c1yYktQBIJ3W3nAZfVgLE5+NvxHg6HunJNaj74ZLG02VX36l5MsAtMdSXIXGjE7uzKjPe+Xe2a7/1zKuay6w9wxcZbVFzQptlmr022Q5q8sAfN5vqL6sHX+3Kh4HwHScLl5bt+IqC02XzgcEWhOQd9PGLrytc/HvbBQHgDb9++v/3WU0Y8I/S+xqdOG/HjOqE3alllfaVec+7WR6/vgn3zIul8j4UmKa3XDs4XcYzXawpZM2Fz3hd3fbEtdFjjoSP/1Df3Pxnd83Nz65vxk18VDz+LtHmPunHGZGPHuwuf7Rfc1/b/ye2XXf1buktXlAG5Se8WccejaZpilLe3u4yM/GG5hW7bOYVdUmPB1v1PyTj74wSfcQkCHBoNlGW6yon4nCY/fHc0jovmT7FbIr97a7X0NUMA+NfNnYnEK/3R4926ow3wKzm822X7ltvLARtJfPlEn2ndBh8/cjnl0tZrIrLp/S1LFwMUV04cXmyicQtM6EwB0l3OhklghvAZAHuOijhfUV77hqh0vrMuuP8T0eAXXCbE9jV4Pq6B/dGk+hHKYafc8r5qLTH7emueS9MeUja/ICQdoc7bQrd6p1+vc7Yl3Ta63Fa6OKapAqzpxzzWoWXnSu2gZWGnE86sTNzIgJB5kf/25DnXYSVPeKsjmkE0AeC73uQnsjp/VmLr9y8lHu7r0WrheZ+PvDo16OJcPGGwSU8SrTNzZco9+S+pkoPFS1Jc7+Gy+/YHcDwHU3XtbMMecsiWxJmtj2htjrD1o+lEoDt+kWKl7YSHff+mLYqMWMZ9kqHABVoGrIxblRVJO2/D/HnLO2PM/JbAlsNHgF8/tTNjenX72zufK+H5g7qqNCGiG6d/KPzW3jDjLXPrKP+ddVO5ndD+qTiqKjbi7fzS3sHgCTnnvXaEdy1wWhXW2POHZjc9IlO5iLqiOHt4w5oDZqOPKFH5mrHvihOfO6XcwfT9/CbL6DPc92M5s00+Gvvx7Z7LT3x9XwOfqkzczp1+xcYyeGur7unnSoEderH9zb/O28bc02Q5pvJmTTyMcfeNWmuNrIv+qlVaENhInPcWduac66fldzzUN7zxjJvump/c2FI/Yw/7xwO3PY0RuaxZeap0Fqu4f+ddz9xtbo2Ijrn7OrXFXaL47fpMak/+YrVH+F/7/wYnObA3/Vz5xx7S7G1b49d91Yvvt7+BLwM6Y2g3PxCrLZZp/ZLLvC/ImNXq7bgjVnVmJB0wXI4fz2G59M/xX+Y9yTb4aP3CTmhputYLR5nE73tPQWqedjbEw4sdrWkA62Qp/1lrQlKpacd976xOoeLpr+H3YDSrUBYindJJGccXqbQZPThT9s28CZbAvMo7xPP/7CidqzZ+z1c2JUzoUus+L85v/+MrA2OnTqFTuZnX+4mtlgQkzsbwAAEABJREFU0+VN916LmIWqo0IyT2vzFl1ibqM1Tnoo/eZvg8yDr/3EHHvGljrtLGjnWlfrDZ0pnVDwLLPMHErCv//6UKh4cSPtuu/q5txbhtSmBe/9k7WNNiPqXR05DN7ioQ099dBbb8ByZvvv9zJ/P39bc8vYA81v/7GpsbFesZne2rgnb0sBfnTkBkade3VYd9lndbNBdbRA7MRQdmr3a3Ht1mMhM3jHlc3x/97K3PPSoUbXmc67CiNvstcB0z4N15zv7i0Uuh/JOamp6uKz7e49jRpTWlY23wKz1xAtuex8RptLDdquuzngF/1q9fHs4bvV6mctgqM/J/3h3sSS3337U3PzlRMSy6kXIMfdD37c18w6W7h7Sn3a4Lt26z7/1t2tdqoC2Tdc9ozVJRSBXD7dEbj9OjebX67dfxkz8yzJm9+VijHrWd5h/qXn340M1Mbra9fZaJkZ+aqdZsOhGWdmwovj4++DMMOAui+2nBl1IiN9vfuWiZHit4u89W49jOpdu3g6rzb1ptt311crQQ45Ww5oKwqlK8R6bsnvQNZVSl/g1M+/dpLpHDgAnHCNK3TLXXqYC2/fw3z/kDVrU0KjyJl9jlmM1j1dN3ofs8a67jy6ZZsmGmYJwCsT3zcjhtkfLVT5qzOlGSCaBrzmekvpUOigBsr39l/DnHfrELPxlsnXLDbLOC+7iGs6tdZVH/zr9Yw6983saXRcO1prps0NT+xnNDOnURwbx9SAsCHn+oufsSGmoYzBO61izr35ezXnpKaqN4zU5KAa0Zqh8rdzt5kxmtYkauzDauwrxBZQTfjAnZOrf+39V6NUjjsbEjUL6M//2dqGqA4y9OrMF8bZ7Vx0yIAfVgmMf/Itc/bfH7YqMxDW0+LafTkBA7k2Pic9G80BMPXzr8wDdyZ/i1Hvvot3UF+OzQ4HYvx48qHos77GPm53A0A5c2OobiWJljdfY/l1yVEdToO2sfc2AEG5c7jdtxlIZj6CfS1xAFSZfjH1q+pf+//VabQvFYlxCAw9bbD5y3+3NgssPGec5DPSaLRXMwc0EjfjoMUvzz0TbxMeiyokErXuJsuaXfZezezz07XNYUdtWBvVPfLvg2rfdSyYcbHI4nPX8gkzCjL80nG1uLb/aK3wBSP2qM0ASSJbdeqfF25vDvhlvyRimqZ9cORk42KPkqYZxjix3xHrGjlS1HmKkXxGkqWXn98c9++tjEaAZhy0+GVigl2uAzU0TdbVWwV+8vv+5i/VzqccIkF+cT5rToRbhkR2xITNS/txhI3bKN7Yx+w2svc8tG+jbGIf033sh4fZlSllXhhv9/VikkmwT0DLQl3u77HWBktbU1rPMWvCqoKeGxutDfJCdcT8i6nJB9G0V0c1+xn/+1jYB+CBqqMxysalskN7k8xQIuEXOXCXWXGBhFLiJ3++2p6UIyu+hI4p1f7tsfpiHQ+2+aUZtm2iRDo9rOp810aNkRIVIbIDG3AAVKFOtXDzqorp8n/2OWbucowD6RPQ1P0d9uptLWONGv/h1M2tyasX9LTl18/Uy3bxffnuC9Y6+Rfcvru575XDzFnDdjVHn7y5OfyPG9c6xBrVHXJgn9p3HdO0ZnUUbx9/UG1tvZwFrfTS7uOXn/1kqyixzqkMT750B2vT9zWTQQ4PzS6JpVCbRK6cIG2yDXVaI6/quNpyeM6/4BxGa95DZR4x0rMxd7muz+amK8YbbSpYf8zGdzmQ9v/5umammSs2xJmVey9iTrlsRyczAW64bJx5/ZUPY+v52sv2dnOWM1HLdWIr0yShnChNTsU+HGdKcuzMSBibwIlH32Nc7e+x4CJzmnU3/m66e2wlpyfUdT79q5WPRyK+0vTZp99KnK8cbsH6/0BYzz4dZwQEx6N8am+vKG9Xenni+1HEt427/qbLh54u31ZYjAg2l70pey1FCzv9X/EVtAxgk6266auVIOfcQ3fZnUFmRTHHQlyIn8mF0LzJ/NKZA2CWvKEonL6H/Gb92tR924b16bdUbdMo23JHOJrqblvPdTdetrZB4nWP7GPUyV99nSXNXHPPajsbc8fw540e4rYFa8q/1qHblnvY0f2N7REZ6XjVuU8ZH/eH2GHPXkZrr6M2CmRTq6Drq51zqFX6ZueefvT1ZqdCHdd010vOfCJU3CiR1IHVOv4oacLEXXqF+c2RJwwKEzVynBsuGx85TZBg8ov2GtpaehLItfmpEcnuPRe2KdJMft7uDuNWlUOY0evs/vSLO41GGV3h0Cy42Wa31zbUbCE9f23pq1etRXnWPPVIsnuq9O5XbU/osz5oNpmW2dUfi/NdeyuFTTfZ8hsAVl97ibBZW4+nmQ/DLrL7BosNNls+lp6bbmt3GcDNV9vdPyaWUekmcpIbDoAq1qksAahSKN5/rcuWA8CVZZtuZ29zk3odNcW4/rdv3zUydsrlOxptkOhSt2++/tZcdNpj1rOQF1s2WBdcFSgnyNB/bVH9Zve/pibqVWJ2pSaTprWNR56waTIhLVJvvKW9UYMgm6TTO++5daKxfX1q9sgfz9jS2auithnS02j/k4CBrc/Lzn4ilnNOdVn7etjSo3vPRWyJ6iBnppkqpt+A5TocS/rj3f99mlQE6R0RmPDUW2a/ra4wLjf3lOoDLa+JlkzbTrCwHWE9o+8bMUkqJAq9G3SU5VQesHXyjuPTERwUL4yzu0RnldUWTcQlSeLHHnjVvPnax0lEdEi7xDLzmp4x967QTIgOwhL+0ObIb75q/xWyCdVymNyNaBwAVa7OXithZyZnVUP+xyGw+4FuX9+36hqLmaWXny+Oai3TfPrxly3PZ3lyx716G03PTmODy8cffNVMftH+iNlPjt7QKULNANC0eNuZXOZgKUQSHcXRZT2wuU42iZ31aV2MDP7wsLWdrdWX7mpI//QP/fXVavjg3c/NfbdHb/xrCqdNRVw58KXjggn3jJGM+hBlNLI+Hd/dEdDrQU855l6z56BLjdazu8vJ1Pabsb1pn/TttWa0ddlK0yqEfRWens9RZgs0y7PXmo2n+69hYR+AUbe8aLQZXrO864+Ps/A6w3p53XvZnUFUL7vd9xHXPdcuSqTzmu0np2ikRNMjL7bkPLW6P/2nlY9RN0+0IicXQhwpiQPAEVjEZk9grrlnc67EVruuaj2PTx29ljKpov0GLFt77d1ss6ezt0XSncYb2bvnoWsZF1P/O+elfQ86H0v6W6OmUdYzJs2vXfqeTRpt7dKFPa99GlyMXMftgGo/igcdrD3UKyjDMokbb6nl5qst1Ymbvlm6R+5+pdmppse1JrTpyRgnXK3VliobbrZCbU8T7WtiK0guIRsCH30w1bw6+QPz5MOvmdOOvd9s1fu/5sDtrjIXOJhp1sjCg/5vvUaHEx/TbKzEQuoEaPO4up9Nv9pwaMnRq3t9o0x6WXBsyEHx8sT2Awlff/WNeXjUy43UiHVMbxXS8oxYiRMmev+dz8wNl49LKKVjct0LOx6J9muzHVaOlqBNbC2LDOvYaSPK+9OuFMQB4IoscktBwIWH18cdTrUW77gztzJpdf5VeUbfF71zoXStwpD93c4KCfJWh8vFGvbxTybfcCnQMQ+fq6xmf3r355/Fe+uLpgjbZqbXSKqu2JbbSN7uB63Z6HCiY1FG1+ozivqayPq0nb9rOuhLltfuBnn0rHZAdB3bDIFsPhsTUCfs94feZmyFn+0+zAzZ6GLTd6GTzYAVzzTbr3We2X/rK815J482b71ub4p0Y2u+O7p5tQOkTuF3R+x9W67bAsZmZ/Pp0eHW9dt4m0e/TZZtCmL57gsZtT2aRgh54rkx7d9sMKXqGNLypJAi20aTY6NtJEcR7r/jJasb1Wr6v/apSaLuetUBpCTpO6fVK33HWZ6x0TkPT347UwMHgDO0CC4DgfkWnMO6mS42vUuq5C//PMAsusS0V/cllRUmvRgkXa/dOR/tCbHcSgt0Puzs99bfsz875KlHXnOmr4+C557X/iyezz75MpapYx+3++o6KbH1bvbriOQ2Cit0X9D6vh0aXXvp+XcbZdfymDb4ahkh4snjDr/DaIPGiMmI7iEBTSvXmzZshftGvGRsr+2Og83V6L900et0N4y5QZvSdw7jq47mMAMR6mh2Thv19+rrNN8oT8uXNtpixagiu8QP46iwvUHnqjHXy3dRPsYB26P/21TbMqpjMVSZkWTp5ec362y0zIzfNr7I+WtDjt8y3GmHA8AdWySXgMB8C9h3APi2BGCNdZc0gxxsXNSqeqgB0up8nHMuNl9qpcfq6yxpFl50rlZRIp9Tg6tM0946vxoqMrAGCeLOAHjsvikNpMU/pLqxeovGb3zJzVNuur39jUvjvNpOI0rNtYx+5okHXzXH/myEsTmCF10LUkCgMQG9KcX26/o657RG9XnT+ViS3xOffadlcm3CFnazwFaCVlt7yVanTZ9+S7U8H+bkPbe236vE9vI61+XdzG7NhoqzNKuZPB1POv1fMhQ239HuMoBhF48tvuNX4BwFHACOwCK2HATmm39264aG8bxbz7SFQN20k3p/W4hveOoZB6OtjV411DBzSwe1XGIryyO8b0z5yIRZz2jJhMzFuJgBEGekWDNSHhw52SqPLXfrYdK+rmxPwxSQsNOFFTcIq/VtPuoXxIn6ecvVz5pjDx9h3n7jk6hJiQ8BZwQ082yvH63lTH4geJXVFw2+Wvmc9GzrmT021v+vXnVaNFv/Hxih13EG3+N+alZJu/vChKfbLxMIm7+WYyy7wvxho1uNd/fNL1qVJ0f1ag3e0hAnk/UHxnuNYLO8NANNS4aanS/CcZc24ABwSRfZhSfgooMSd5MyV7C/zWDI+VHLo616gC2dwQO5/+AVrBeLi7Xo1pW0JHD2OWexJOk7MZ99Gn0JwLMWG4eBJv03s183AtnNPjUNUzN6mp2Pc/yeWyeG3mU7kG9rRCmQF3zefOUEs2Wv/5gz/vyA0aaZwXE+IZAFAc10+cOpg1Nx9HXvaXfH+XbLJp554s3ESNcb2Hz9fyBcS5cWXGTO4Gfsz2fHNN8/R00cmxu89t98hVTKvDMMbWR4zQVjOh9O9HubIata2/tJSzDVFkukUKfEvr0euZN6SX86TY8DoIo37qstqklb/v/2m29bnudk/gm4qDtln8aq0VZNdbdZOwZs1c2muNCybHe2lHGcEVelI0wj8O030z6j/H3mCfvr/22MbEWxIYg7aDu7ywA0K2XKpPcD8aE+1aDfYudVQsWNE+m//3jE7LjO+ebw719v7hj+vPnw/alxxJAGArEJLLL43ObUy3e0vgysmUILLDyn6bnmYs1ORz4+5rHW9zwbTnrNAGin2EwzV4yN5/czjzd3WLwx5UNjc+Bl9ZSXdgUMxzz6hpky6YPgp5XPjQavaEVOIET7CQTfbXxq5tc7bxV11pcNQs1l4ACospl1VjevNZv6+ddV6fyHAASiEHjzVbbtqo0AABAASURBVPs7My+zYjbT8eaae1Zjc8dzcXxh3Dv6IKRIwPYGUdrZen4HG4iGQeJiauprr3wYJusOcQbv5M4BEGR0722TzK/3vckM7Ham+e2Bt5gbLx9vxj/5lokzCySQyScE2hFQ5/+Ma3Y2tl/P1y7fdfov0y5K6PN6DW+z5YiffPSF0b4boYU1ibjqGuEcFjbenvDY/VOaaGGM1s03PRnjxCqr2V2OEVYFOTvDxg0TT8sz+qy3VJiooeOsN3C50HHDRrz7lolho+YrnmNtcQBUAc86mxsMX0yN97qpqkr8h0BpCXzykf3RurRetdao0HpYXpuZ5qurGtlTxmPvvfuZVbN79V3cqrwowlxcCx9/+EUUFWpxtR+BOkq1Hyn80VTRP/z4NrPXppea/sucbvbf5kpz+vEPGDkJ2q0PTkE9sigIAdXpLDr/wtdzTbv3lZdffE9iu4Q4G392FqJO8qIh3yxkY7aUZixodmFnPfR70oTW+x0oTpRgezlGmLzlrBl+6bgwUUPH2Xb3ntam/weZrrjKQkZlH/y28allD1rGYUOWTzJc6+Km5+taa8vyZ52NGQCWkSIOArEJfPSBfQfAEsvMF1ufpAmX775QUhEd0r9eHW3lYdcBifMf771t1wHQbRW763WjANC65Cjxw8T98P3Pw0TrEEcbZf3+lM07HEvzh0Y4zznxkdoyAe0bsPfgy82Zf3nQaPnRu29/mqYq5FUQAhqpPu/WIamP/Af4bO88/9LzjR0A455sPp0+0KXd50YR9sfp1mNhs6CFfQAmPNV4H4AJLfYHaGdH5/NyVmg5Rufjrn8/eNdkq8sYpO9Glqf/S6bCdnv01Ie1MP7Jt8xzY+1t4mhNsWSCnKfGAVBF7MoBwAyAKlz+QyAigTijia2ymGPOWczCi9l9HV+r/Dqfs7384IupX5tPP4k+4tpZL36HJ/D2G3aXpdiuE+EtMUaN0/kXmiNKkrZxP4y5xn7jLVY0exy8Zlv5aUQY+9gb5j8nPGx+OmSY2bzH2Wb/ra80l5z5uPXpwWnYQh7pE/jhYX3NmdftYrTRZvq5T8tRG+bJsTbtV/K/L45/p6EQOc8anohwcPV1Wr/+r16U9gGw0RltNnPhoZEv12eX6PvaGy6dKH3cxDdfNT5u0obp1G7q68iW9R0sAxh50wsN7cjvQfea4wCoMna2B8BnLAGo4uU/BCIRsLkZjzJeYeUFjYvNGiU7TLAxctE5H63B7HyM324IaLbFq5Ojr3Fvpc0CC83Z6rTzcxpRs5nJRzFmAAT5//h3G1jfJyOQneTzyYdfM/886h6zS78LzCE7XWOuv+QZw2ZTSYgWM62caf+4YDvz8+M2MbPPYf+tJVGo6bWiNjtXzzR4He+XX3xtHrjzpShqNYy76hrR1smvuX7yteiN9i3435ufGIWGSsY4aHsZRhgV3nz1IzPyRruv/9tuj17O6vNKPRcxtpcBXH/xM0Z1MwyvXMRJQUkcAFXIc887a/Wv/f+ff44DwD5VJBadQNzRxGZc5px7tmanUjk+m4MlRjgAUim6WiYu9qSYbQ43y85qCof4M+dcdp95H7z3eYhcG0fRiOVJl+xgslg321ijrkdH3/OK+eNPR5jBq/7HHHnAzdXG9gtmKs/3rqBKdGTueWYzPzpyA3P1Az80m25v980aSTCuZnEH+scffNVoxlm9Ps89878ux+rPh/m+/EoLmsWXnjdM1BlxelnY3+D+O17q0klstsxhRsYRv9hehhEm+1E3298ET7OzwuQdJ06lYszWu/WIk7Rpmjdf+9iMvveVpufzdiINfXEAVCm7Go2hgVCFy38IRCTwYYLRxEZZaSpbo+NpHZttdvudPduzJNJikcd8XDhbXM06C8t3jrnsjlS+906yPRKW7baAOXPYrsbFazPDMgkb7/brnjO/3PtG88PNLjN33fCC+ebrb8MmJV4BCAQd/2GP7mMO/vV6ZuHF5vbKqlVXD7ezfhil1fl/pdMrPp99uvE6+jDygjgDt+kWfA392a3HQkbsQydoEFH2PF91YNSfmvScvQ0A5czUMox6+a6/a4baVec+ZTUbtZn69ne7lMHF2wB0b7YKIjthqeSMA6CKWdOmdHOpfrX6/13LG0dZVQ5hEPCUwAfvfm5VM9udnajKzTa73c6W8re9T4JkEhoT+Pgj+/stzF6wGQDvWtg0b+FF5zKnXbmTGbB19M5B45Jze/SF8e+YX+1zozl0l2uNjTXRbrVFelIC6268rDn2jC3NTU8f4GXHP7BvpV52NxjtPEL+1COvB1nF/oyy/j/IRHt1DYjhOAjSB58TxrwdfK192tw8rt+AZY36EzXBKf0Z9+SbZuKz9pwYUnvLXXokdrZITqvQo+qo0kyQVnGinrv5qgnm/YTO6Kh5uomfjlQcANM5L7PiAtO/2fto9goVezkgCQLFI2C7wzXLLPZH4KNQV8MlSvwwcT/95Msw0YhjgcDnDvZymWnmbB+9ttcq23LazTv/7OaE87czR/59kPMGqIWqUROhaad6peBv9ruJDQNrRIrzRx2UQ36zvrnyvh+Ys67f1Wj38vkWmN1rA+VI06vWbCn5wrj/zRCl2S73jZg043fcL6v2iTdLoe8GyUeln37ktQ5qP3y3vQ0As5jBNOomu2v/BWeTrbrpw2nQMgBdTzYz+erLb8w9tyWvnzZ1iiUrpUTZtkJSMjJMNi5ejfRsJ09jGD2IAwEIWCagOXKWRSIOAkkIfEudbIpvlllnMkMO7GMuv3cvk0ZDtKkiEU+MuP55M6T/RbX9ASImJbonBHqsvqjZ9/B1zD8v2t7cMuYAc93ofYwcAN17LeKJhuHU2GDT5cNFDBGrfuf8lye+Z977X7LlPnKqLLVcvNfy9rKwD8C9t0+asWxHjsspkz4IQSFcFNWfcDHtxNIy42svHGNHWJ2UGy4bZ35/6G3OwyP3vFKXq52vwy99xo6gDKWklTUOgOmkl1lh/unf7H289vKHhrW69ngiqRwE5p3P7qZ9WW/G+cXUr6wX3Fxz293EzbqCBRJoe8M8ofnqi2/0kVn4/DO7M0i0E7ptY/Q6NW0O+KeztzIa1bQt34U8jUBpfwC9McCFfGTGI6A9JnqttbhZd5NlzcBtVqqN5B/wy37m6JM3N6dfvbO5+sG9zd2TDjWX3b2X+dkxG5lB264UeZO6eJq5SWWjoxxo9tDIyebrr6bdryY83XH6fBAnyudGW6wYJXqHuCv1XDjxzCA5MOTIkODgU99thLQdRepAyx4butfLGHXzi+amK8Y7D5o9VZ+vje+PP/CqeXFC49dX2pCfgozUssABMB21XhU2/avVD+1MaVUgwiBQcALzLTiHVQtdbOIWRUEXU8jnsewkiWJP2eLOPc+s1k3O2ill+5pYaNG5rDOSQE0T3Xq3VWsjseqspd3Alg5xgt4YcPEZj8dJWvo0Qw7oYx5/9wir4fpH9zUX3/l9c9awXc2JF29fW8t/2FEbml32Xs1otFx7QGn5SVHg29yJ/oupX5spk6eNko997I3EiNbot2RsGVpOl8SBEGQcODJsrp3Xsou0HZVseheUaMdPF8siOubg8ld6snEATGctD/H0r1Y/3nz1I6vyEAaBohOYHwdA2yKeZ77Z28Yhgh0Cc89rd0aKtJrqYF8ByQ0bPvpgatiooeItuPCcoeLFjaT6rs6a1mKfce0uZvBOq8QVlVq6E4++x5z994dTy4+MIBAQWL77gsbm22deeu69mmi9Rq/2JcGfnmssliC1MWttsFSi9EocODI6vxFA5+KG9QctFzdprHTa7E6j9LESFzzR1ec93eV1j7kxOUVFcQBMh611SdO/Wv0IbpxWhVoW1nehk43t8ODIyZa1RFxZCMy7gN0ZALY7O1HL4TMHG/apQxRVD+LHIzD3vPadLban4Ee17MP37ToAFnDsAKi3b/2By5m/nbuNGfHsweb4s7Yyg7Zbqf60V9///dcHzQWnPeaVTihTfALq/G+42QrWDNWUag1mTX5hmiMgruDFl5rHLJ1wuW3vvkvEzX5GuvtHvFT7PubR5DMaaoKqf3pZ2J+gKib0/1G3TAwdt2wRNfM6r29mSbOscADU0db6sLqfVr4+cJffHeHXXv7Qip2dhSyy2NydD/EbAqEI2J6KqTqutbmhMncQ6T0Hr6WZ28GotAPTCyFS09BtzxB7/x27r7qMAvqbb741Uya9HyVJ27jzZbAzuqbbbvO9Vc0/L9ze3PX8Ieb4f29ldtyrd1td045wyjH3mglPv5V2tuRXcgJ9Eky174xOG1ordD4e9feg7bob3U+jpquPv0rvRep/xvo++cX3zKTn3jVjHk3+SsNAgVVWWzT4msrn8EvY7K4VaG3K2uq8p+dSVQsHQB1uG68YqRNX+/rAnS+ZrEcga4o0+aPOUZNTiQ4vtJibNaGJlCJxLgjM42B9+5uvZbcU59WXpq2ftAVfu6SzCaAtmuHkLLK4XYfmFMt1IpwV02K9/cYnxva+FPNZnrUzTdPwfzUDYZshq5pjThtsHnnzZ+bSUXuaI08YZDbdvrvVqdDhNeoY87gj7jDasbvjUX5BwB2BHgmn2tdrNmLYc2bs48lHy204JbQPgI0lQDdePr7exMTftewisZCQAl4Y/4558uGOrzMMmbQ00W68fFwON2FPt3hwANTxduEAkPinR9vzMkqezfDa9M1dbMpUB2XBhea0KRJZJSIwr4P17W+99nFmBF964V2reS/XbQGr8hDWnoBGm9vHCh9jsuU6ET5nY95y4Axzcc1Gsak+rp4/q1Y7P9pM7h8XbFfb3f3SkXuaof/aovZ6QW34Vh8/je/jn3zL3Dn8hTSyIg8I1Ah077lw7dPWn2EXJR9x7tlncSvq2Girn3fyaCu6SMiArbul6mhkkztRbx3k5L7ntkmtI/l2NmV9cADUAe+99hJGjYe6Q1a+Pnb/FCtyXAh5eaLdqaDSscdqi5qZZq7oKwECkQm4mAHw+ivZzQAY9/ibkRm0SrDYkvO0Os05BwQ0wmxT7BgLu2nH1cfFtTBvBksAwto/+xyzmFX7LGZ22LOXOfLvg2qvfLtt3EHmhKpzwMZIYlg9rr1wTNioxINAYgKataSd6RMLmi7gf29+Mv1bvA+t/1/WkvO611qLxVPCUao11o3/ZoOoKn35xdfmmvOfjpqslPGHX5rcaZUmuLTzwgFQR1zTagdubX9DoTuGP2++/bYuI4++2nwNSmCWjU1aAll8lo/AksvOZ93oVx3MdAmj5McfTjVvWp59kJdXoYXhk5c4K6y8oFVVP3j3c6NdnK0KDSns9Vfs7/uy9PLzh8zdj2iLLjG32Wz77rXNBG8ff1Bt6YDrRvzjD7xqbKyj9oMgWuSBQL8By3qj5iZbdUu8/j8wRuvttdFh8Dvrzx6rp7f+X5vb2W5TZM3PVf6P3P2K0X4PruRblpu6OBwAnZCvv+nynY4k/zll0gdkvVgVAAAQAElEQVTmGQvrp5Jr0lGCOiejbn6x40ELv9awuPmMBXUQkTMCGrEbuI1dR9zoe1/JhIKLBn+f9ZbKxJYyZ9q77+LWzZ8w5m3rMsMIHH2v3Rlpy6w4v1lqOftOuzC22IijkVJtHnjuzUPMSZfsYHqvZb+sAz0fvS+b+1CQP5/lItAr5Z3pW9Ht08/ec0tthP6br9Aqu1TPpemUZ3O7aEU76uaJ0RJkFjv9jGdKP0u/c9xg0HJOFLzynKecyE0i9K4b3KxJ1PrLJHqRFgLr9F/GKoRH75uSyYir8rVqSFVYzz5+TX+sqlT4/7qn2R5xymJpmGYePHDntFdg2Sq0QZaddbb0iipHy9a0lveiO79vDvnN+lGTh4o/4elsnD6hlCNS4Qis3HsRb2zquabd59baG9ptI8QFJednWsvyNGinze3i6lrGdFou8fVX3/hvegYa4gDoBF3TjwdtZ3f0UVncePl4Y3s3cMmNG7Qk4erz7a9JXHCROc0K3ReMqxbpIFAj0Htt+6NwmoJbE57in9uve85qbnkfbbUKI0VhGnHacDO7I04jb3TjgG2F5YmHXm11Ota5NSyO7MVSwEGig/5vPbPHwWtal/zwqJety0QgBJoR6NZj4VQ3p2umh9qFy69kt13ooo3QTP9Wx/unOBPhvhEvWX+DSyvbinBOM7B93og9YJzFJw6ABtS32nXVBkeTH7rmAvsd7rhajX3sdTPWwUZUG2+xIhsAxi0U0s0g4GLEdXTK029ffvF9M+k5u28A2HTb7jMY8SVdArZnpWj/FdWRNK14+G77HdBelkf20uTRLK+ZZqqYnx+7sVlt7SWaRYl1XBup+fxa4FhGkchbApq1tN5AN7NaoxitWUKaYRMlTbu4LtoI7fJsdN7lkqHO+Q27eGznQ/wOQUD7sIWIlmWUTPLGAdAAu6tlAOef8qh5561kO6k2UDfWoWsvcHMj2ajqAIilEIkgUEfAxYjrLVdNMJoCXZeN068jb7I/wut6ozKnQHIuvLeDWSku6kgzzJo+qmug2fk4xzUjRbPmwqS9/OwnTd+FTrYSNlz6X+abb9zurDvrbDOb/Q5fJ4xpkeJ8+smXkeITGQJJCPjwzHAxS0hthPUH2d+zKyrrlXunswHgKxPfN9rULqp+xDfmugvHGr/vu9mUEg6ABtznmW92c8Av+jU4k/zQn35xl/nqy2zXo9xc7Qhdf4n912OIW5rToZKXBhJ8JmB7xPXD96eam64Yn4rJ6mxdfPrj1vPq5XCDMuvKFkygixGn804ebVRX0kA1/NJxRteAzbw22y78jJT5FpjDWtaff/aVefv1j63JayZoUAT7msnofPyzT77ofIjfEHBGQPctZ8JDCnY1S2jt/kuH1MBNNM2wWLHHQm6Ed5J6960TOx3hZ1gCel7cf4fdvW/C5h0qXkaRcAA0Ab/b/muYWWa1j0e77v/7rw82ydX9YU07PfZnI5xktPMPe5s555rViWyElo/AupvYf4XR+ac+aj752H0D/LZrnzPvvP2p1UJba4OlzRLLzGtVJsLCE9CI01a79gifIERMdchvufrZEDGTRdHox0X/eiyZkAap+0WYXjzv/LM3kBD/0KuT7b/OsJE2tl+lpsZoo3w4BgEXBLr3XNiF2NAytf5fexGEThAh4mp97S7RiZB1Leo6Gy1r5phzltp3l38022nYRW5m7brU2yfZN1+ZzuBPHJuzSmO/h5uVJZbzXXypecyQA/pYljpN3LknjTZ3OtqBf1oOjf9q7eGR+99kvpj6deMICY8O3mmVhBJIDoHvCKzcexFj+3WAWoN75X/dvpFDHf9zTnzkO0MsfdvzR2tZkoSYuAR22Wf1uEmbpju3WlfefsPt0jDthPzma3ZHzFdZbVGzQYQpuEsua9d5NeWlD5oytXli4UXnsinOLLDQnFblIQwCrQgsvvS8mb6mc6PB7vaFWmX1dKbfmyb/+qT0ymvt16XBuyZqxD78678ONI+/e4R3Ydd97T9n775lonnz1Y9is3KYMDPROABaoNcsgBanE536/Y9uNTdcNs5oN/5EgkIm1mZkP97lWvPC+HdCpogWTaO1vTP2xkbTmNh5IDDkQPtOuNOOvd+4eD2feOp1M0MPu928McXug0Yj/9pgU3kQsiOw+jpLmjXXX8qqAuqYH/Pj25wtDRvz6OvmpN/fa1VnCdvr0GgOqeVWWtDqjuRazpPG8/P5cXafmQtZdiioLAgQaEXA9htMWuXV+Zzt+2W9/Lnnmc30T3EX/vq89T2t5RV3Dn9e2VkP6zt67XlSRTfZsltSEQ3TZzHw2lCRDgez+4EDoAV7vc5u75+s3SJG/FOaBnhMtaNw3OEjnK4BVYfk0jOfMN8fcIl55ok34yvcJuUhv17fVCptInEaAhEJ9Nt4WdO91yIRU7WP/ruDbrHeSVeuWmLgYq3Zvj9bx2rnSboSohPQPe6HP+4bPWGbFA+Netmc9feH2sSKflozC369703RE7ZJoVHxzXZYuU2sjqe1Xrb/4BU6Hkzwa/S9r5j7bp+UQEL7pFM//8q8MO5/7SOGjKFXoYlDyOhEg4AVAr37Lm5FThwhvdZ0m/c6Gy0TRy0rabr3cr+8Qsu3rrvI/p5dmsG1wsoLWeFgW0jf/ks7WVpx7QVjnG8eG5lFhglwALSBv9/P1zWLLD53m1jxTw+7+Blz8A5Xm+efsdfICLSRzJ8OGWb+cdTdzqb9K68BW3czfTdcWl8JELBKQK8O2uen9p1wWgpw6C7XmrGPv2FFX3UUTv/TA+b04x+wIq9eiEY5tv6em1eT1ufD93AE+g9e0agjFy52+Fjn/PMR88+j7jFyDodP1TzmhKfeMofteq3RDIPmseKd2avqBJlr7uj7vdge2dE1Z4tXIxJ3Drf7Jo8VVlmwUTYcg4BTAis7cKKHUVjPrm493HYye2c083Sp5eYzYd+AEoZVszgPV53DLjaK3XZ3f9sUqjdb7tKjGZLYx7WM4hlLbb7YSnRKmOXPmbLMPA95z7/gHOaIP27sVNUJT79t9tr0UqNRyTuGP2+0Vj9Ohnq7wFOPvGb++49HzB6bXGJ23/hio5GlOLKipNm/6iSJEp+4EIhCYPMdV3bihJv8wntm780vN9qT48sv4u+L8VJVzsE7XGPUgYtiV9i4exyyprG9gVrYvInXlYBGcPeMOP29q5TGRy4583FzwLZXmhcnxJ92rllfF5z6qNlz0KXGxZIvbY67/fd7NjagzVHbDoDnxr5tfnvgzeaTj+xv7PnqSx+Yo390axuLop3GUR6NF7HtEOi2qvuR6kaaanBIr9NsdM7WsZ5rLmZLVCQ56w1YLlL8uJFvvcbNJrFR9m+Jq3uSdJts1S1J8qZp78pg/7WmyhiT6SkcACHwbzNkVdNvgP0dyeuzVuddF7qmaw5Y8Uxz9CG3muGXPGPuvW2S0QYgL7/4vvng3c9rSd59+1OjaYkP3jXZ6NVO/znhYaOd/bfs/R+z31ZXmjP+/IBRw6gW2fEf7YqtdbGOs0F8iQlo9/Wo642j4PrXcffXHGbqNKkzHyatNtJ84M6XzNCf3G6G9L/IaJ11mHRx4uy0V+84yUjjkIBGJzRK4SKL8U++VVuypWfAPbdONJpdEiYf7TshB8L3B15qThl6X5gkseJoc9yFF4s3K27BReY023+/V6x8myXS5k4/32v4jOdjs3hRjmuzqJ98b1iUJKHiDtx6pVDxiAQBmwS0U/2Gm9lbfhNWt7793U/P1304i85s77Xdv4Hgnbc+MSOGPRcWd+h4mv6/Uk/7SytDKxAiovpccjaHiBopyjUXjDVaVhEpkbPI2QrGARCS/9Enbm7mmc/ua4xaZX3zVRPM0J+OMId//3qz9+DLzU7rnm8Gdf+36bvQyWbzHmebIRtdbA7b7TqjDsiZf3nQaCnBe//7rJVI6+e0NOKIY93OjrCuNAJzSWDXfVc3LvYCCGBok0x1mnbpd0FtSc4px9xr9LYAbRqjvTO03vjmKyeY804ebf70izvNdmuea9RBkANOzrtAju3Pw47a0Cy9wvy2xSIvIYH5Fpjd/PLPAxJKaZ5cdUrPgCP2HG42WOpf5rjD76jNMLnx8vG1WV2qk+r4XnXu00abWv5s92FmmzXOqS0hkHO4ueRkZ3TP3+dn6yQS4mJjT23que+WVxhdo0lm88gwcf3RzteayS++p5/WgjYrW7bbAtbkIQgCUQiktWN9vU4910hndH7tDPYBWKW3+w70yJterMdp7bsG7rSfjTWBDgTJsbPFzvbfLKblFA+PetmBxjFEZpwEB0DIAlhmxfnNMacNDhm7HNHEY7El5ymHsViZKQE531Tf0lBCnYkLTnvM/PXXI83/7XOj+eFml5lDdrymNh1Yna1rzh9jtIeAa13WXG8p88Of2N9wzrXeZZG/4169zeCUXn163UVjjda7/+HHtxm9zUV1UqPef/nVXTWn1H0jXkoF+1EnbmYWXSLe6H+gYO+1Frc+C0Cy1WHXlH05zOUoieIIef2VD2uv5j14h6uNuGp5kGTaDLZnPtjUDVnFJ5DWjvUBSXXg0tgkT/mtlsE+AC4HJGST3nCi+76+2w6+7v7f2U7br4EO5Gu2dfA9y8+s88YBEKEENtu+u/n+IWtGSFHcqPsevo7pn+HrV4pLFsuaEVDH4fChGzU7Xajjajz98fQtzGyzz1Iou4pkjEZQjvz7IFMWJ+iQA/oYrem1UYYH/Wo9G2Iaynh2zNtGjhLNktOMud/sf3NtWZyW1GlPHC2pG3H98+biMx43cqDstsGFZts+59acfXL+NRRq4eCGmy1vQQoiIBCPQFqd8UC7/oNXMK7X/wd5rdonnZkGQX567bWWVQS/XXw+O+YtM/7Jt6yL1ga2WgJgXbADgf02cbPPgpZVaHmFA5WjiMw8Lg6AiEXws2M2Kn3Hd831lzI/OnKDiOSIDoHkBPb80VpGD9/kkvyW8Jtqx5Lpwn6XkbRbcJE5ze9P2VxfCx3UYPyZReebZtT9/Lh0lo+psaeNcbWkTrMnNEPgN/vdZE48+h6jJRTaGdp14R3/761SXULo2h7k54+AdqzXzvVpad53g/TeDKUlWetu7Hafrnpump1X/9vFd1fT/7Wn2Uwz5eOd3SpXF8sAVF533ehmeYVkhwvZx8IBELEMtCHZX/67tVkngzVHEVV1El0Nwb+du211ZHJmJ/IRCoFWBDSi8Idqh0sPhlbx8nxOD+htd++ZZxNKpbtmQu39k7ULa7M2YjruzC1NnNf+tYKy5yFrmY23XLFVlEKc0zIRXuNZiKLMvRHrD3QzotoITK++izc67OxYmg4A18sptI/J1ec97YTVhpunvxlkEkMGbetm49RhF481WmaRRLdEaT1IjAMgRiFoPfIJF2xn0vACxlDPWRJ1/k+7cqfEa0CdKYjgUhBYevn5jdYiF9FYTc/71Z8GGE0vL6J9RbXp4N+sb4r6NpRf0A0zNAAAEABJREFUHj/ArNzb/oZXM88yk/nDqYPNEsvMW9RqUVseomUiXM+FLeJcGdYrpbXyelXqyr3s3zNawV5tHfe78gf5u7ZNmw672NRb99qeKS+XCJjF/XTl2NHyiglP2V9iEdZOH+LhAIhZCvMvOIf550XbG61LjikiV8no/OequAqvrEbVTqg64TQ6WRRje621uPn3sF3MAgvPWRSTSmOHRsdPvWJH56+LTRvo//1loNn9oD7Osl140bnMqZfvaPR2AWeZZChYjkotE8lQBbKGwAwCq6yWTqd8oy1WNJotOyPjFL70WjOdGQe6Z7l+M8+IYc87IaaNSPMy/T8AsFD1GTFoOzezAO666YUgm7Q/vcgPB0CCYtCD/V9X72xcTVFJoJrVpNr46d/X7cLIv1WqCEtKYLPtu5t/XblzIdbWal+DM67ZxSy+dHFHQ5OWt+/p5RQ+8eIdjF6x5LuuYfT754XbpbLprXbTPuOanY2ep2H0ykscvbWkDEsc8lIe6GlM957pOADW3nCZ1HHPt8DsRvtTuc54g82WdzpD7/13PjM3XTneiRl53Yh00227O+Fx7QVjzNTPv3Iiu7VQP87iAEhYDmr0/f28bc1hR22YUJKfybXZ3z+qI62MSvpZPmXXqt+AZc3Zw3etTbXNKwt5t0++dAejBkxebUDvaQQ0E+DYM7Y0Qw50N2o+LSd3f7W79dnDdzODtnPT6GqkuZwAp1ed6UVwAojfGdfuYvSayEa2cgwCWRFQ3dQz03X+vfumMxrf2Y71Brjf42C1td0uNbj39knmqy+/6Wxa4t+aubBaSktAEivbScAGmy7f6Yidn1pmoeUWdqRFkOJJVBwAFgpCaxkP+GU/c+4tQ0y3HgtZkJi9iPkXmsOoEXPwr9czsi97jdAAAo0JaEOe/9ywm1m++4KNI3h8dKcf9DZ//e82Zs65ZvVYS1SLQkDLUn7zt0HmoP9bL0oyL+KqA37OTUMy2eRW1/EFt+1h1kpx93Db0AN+66e42ZptG5BXbAKu967S+v8eqy+aCcTVU9gHYJXV3Np23YVjnbDbYa/euW3LaxmAq9lUt17zrBPerYT6cg4HgMWS0I31ghF7mH1+to5FqemL0sjFVff/0NCISZ89OcYjoFfmXVi99uSwUgcsnpT0UslZoT1Efn/KYKM3G6SXMzmlQUCbvh362w2MRtJdjxjZskezFq649wem55qL2RIZWY5eD6jlAHKoR06ccYKNBq9gzr9190z5ZYyA7HNAoGcft6PzGq1Ne/1/gL3HGu7vXd17LhxkZ/1z0nPvmicffs26XAnM6/R/6a6wmaMZaTdfOcFo2YXySCl4kw0OAMtFMfc8s5nDh26Uy9kAfTdc2px/2+5GaxeLuimT5eJGnEcE5p1/dqMlK1c98ENvXy+mKZg//UN/c+moPWt7h6ij6BFCVLFMYJ2NljHn3PQ9c/TJm3u7xl3rZi8duafRbvU+3PfVedCSOnFbdQ23o202ilvOvBMv3t6ccvlORo5IGzKRAQFXBFx2YKXz2v2X0UcmQdPcXY7Q616pt4C5Mm7UzS86ES0uq6+zpBPZaQld39EyAOk/0hF3ye4a/DmCA8BRWWg2wCXVRtXQf23hfaNA07WOP2sr898bv2fWWDffNwlHxYnYHBHQq/ROvnRHc8plO3q1JGfwjiubqx/c2+x3xLpM+c9RfUqqqmZ47LL3aubK+39o9vzRWknFWUu/2JLzGO1X8J/hu5lVPXw1lJYCnFcdUf/J7/sbH2f1aKqzHBVy5g3cZiWnG4NZK3QElZ7AUsvPb9QhdAUi63Xmm2y1oivTTF+Hy5O+/uobc91Fbqb/b/29VY3uV87ApCBYz6sNBrnZC+CGS8elYMH0LDz6wAHgsDA0krHDnr2MptP/7bxtvXtFlKb6a+30ZXfvZbap3iAcokA0BFIloJF1rRmTE+6IYzc2mpmTqgJ1mWkUU/tp6B6w1HLz1Z3ha5kIqNH9qz8PMJffs1cma+zrWcsJdcV9PzDb7dHT63Wheobu//N1zZVVXfc6tG+9CZl91z4/2uPhpqf2N1qqwP4dmRUFGccgoGdj/8ErxEgZLsnKKb1qsJk2Lke6ezp81aCm/k+Z9EEzsxId32iwO6dIIsUiJt6sOogSMUmo6GL//DP/CxU3aSSf0uMASKE05HnT6N+/r9vV3PDEfkaNwFVWy2Zq49LLz2fUIbr1mQNrU/2znK6VAnqyKDkBdSD2/sna5qanDzB/+e/WRiN1aSDRJpp7HrqWkYPtwhHfZz+NNKDnJA/d+8+6fjdzyV17Gu1ZkZZTSEu8jj55c3PbuIOMlqHoDTY5QWZWWHkh88s/bWJuH39Q7fm1+FLzpKq6nuG77LN6bZacZnLsflAfs/Bic6eqA5lBwBYBV/uS9N98hUyd7eKjzUT16SKs5HD9/x3Dn3ehcu3tQlq64ER4ykLXG7CssxzvuvEFZ7LrBHv1FQdAysWx9PLz16aBatRdzgBtBKZRBC0ZcKGK1nRqp/Ghpw2ujaIMG72vUYdI02lc5BdX5iJLzF1bJ6sGqq2w5LLzxlUndLo55prVut7rbuzuJhfasIJFnG+B2c2Wu/QwWqt7y9gDzZ//s7XZbb81jM3rQEtptAeBHH03Vx0Ov/rTACMHmw/Tl1dadSHr9XSueWZ1XkuWW3EB63proznnirfJQKNwPddcrLZnxXWP7FPbM+bwP25s1t3E7rW/zZBVa47ea6t5aImXliIsWr3XtlHP29N6nun5df1j+9X2q9F+Oy46M5qtMXinVYzK5JTLdzS6no8+aTMjJ8pMM1W85YNiEAhDQE7IMPGixtGeJ1HT2I6v+5sL+7T2f9kV5retbk3exx9ONddf/Eztu+0/2wzpmfvp/wET9Z9c3O8lf9hFY82XX3ytrw6DX6JxAGRUHmoAqjIP2nYlo3WEeoXgfa8cZjS6cNIlO5hfHL+J2XXf1c2g7VaqNQrVuQhGPfSqIW081HutxWvnNKq5TbWhp2mdv/3HprW1z1qXOOLZg2sjJn84dbDZYa/epnuvRbyd7qkGlxqnNsPiS8/rvHS1qZtNnSUr6T4Mj797hLEZfnjY2s45ppmBrqOtdu1hfvfPTY1mwmhd/mlX7mR+f8rmtRFZOcw22aqbkVNO+wlItwUXmdPo+pFzZtPtu5shB/Qx6nz86eytaju9azqwnHoa0e1X9VL7Ni1YI6iqWzbD3PPMJjROw9LVBpdNnSUrrRH3sGC0R4Dq2j4/XducNWxXM2rioeaC23c3fzt3m9pzQPsGbL1bj9osEi0nCZxWcmRouutGg1cwmsp/wC/61er0yZfuUNtk8qHXf2qO//dWRku9VsjhKzJb8dOIvO6TeuPOhSP2qHXQNdvm7+dvW9vMUE512a3nq5wqPavOlqDcdf2rEalrXHF+eFjf2jNYz07dB254fD+jZ6f4q0w23mJFo9dQtdKnrOfkFLH5rJGsI08YVFacqdmta0esbQddj6kZ0SIjLbOybds9Lx3qrP0s58IDr/7EarstsP/Xfx3YglT+Tul+H9hm81MDQ3oWOyXimXAcAB4VyFxzz2q0Q+uArbuZH/y4rznqxM3MPy/cvtYoVOdCFVQV/s7nDjEaNbrozu/XzmlUUw09Tev83v5r1HZA1zQodao9Mg9VIOAlAa3p1dTFnX+4Wm1EVg4zdaLklLtu9D61h7KuOa1DPuv6Xc0/LtjOqJGqxs7Wu61aW8+95LKs7feycHOo1HwLzG7UsdcItJ4DWjL2p7O3NtpH4tJRe9WcVnoODK+OgstRcOoVO9U28zvs6A1rs1rUsdX9X53kHJofS+Ullpm3Nttm8x1WNnqdoZzqepuNZtjJqaLlFjc+uX/tWtZzVI1IXeOK8/PjNqmt5dezU/cBOZ1iKUEiCEAAAhCAQBMCvh2eyTeF0AcCEIAABCAAAQhAAAIQgAAEIFAAAt6ZgAPAuyJBIQhAAAIQgAAEIAABCEAAAhDIPwH/LMAB4F+ZoBEEIAABCEAAAhCAAAQgAAEI5J2Ah/rjAPCwUFAJAhCAAAQgAAEIQAACEIAABPJNwEftcQD4WCroBAEIQAACEIAABCAAAQhAAAJ5JuCl7jgAvCwWlIIABCAAAQhAAAIQgAAEIACB/BLwU3McAH6WC1pBAAIQgAAEIAABCEAAAhCAQF4JeKo3DgBPCwa1IAABCEAAAhCAAAQgAAEIQCCfBHzVGgeAryWDXhCAAAQgAAEIQAACEIAABCCQRwLe6owDwNuiQTEIQAACEIAABCAAAQhAAAIQyB8BfzXGAeBv2aAZBCAAAQhAAAIQgAAEIAABCOSNgMf64gDwuHBQDQIQgAAEIAABCEAAAhCAAATyRcBnbXEA+Fw66AYBCEAAAhCAAAQgAAEIQAACeSLgta44ALwuHpSDAAQgAAEIQAACEIAABCAAgfwQ8FtTHAB+lw/aQQACEIAABCAAAQhAAAIQgEBeCHiuJw4AzwsI9SAAAQhAAAIQgAAEIAABCEAgHwR81xIHgO8lhH4QgAAEIAABCEAAAhCAAAQgkAcC3uuIA8D7IkJBCEAAAhCAAAQgAAEIQAACEPCfgP8a4gDwv4zQEAIQgAAEIAABCEAAAhCAAAR8J5AD/XAA5KCQUBECEIAABCAAAQhAAAIQgAAE/CaQB+1wAOShlNARAhCAAAQgAAEIQAACEIAABHwmkAvdcADkophQEgIQgAAEIAABCEAAAhCAAAT8JZAPzXAA5KOc0BICEIAABCAAAQhAAAIQgAAEfCWQE71wAOSkoFATAhCAAAQgAAEIQAACEIAABPwkkBetcADkpaTQEwIQgAAEIAABCEAAAhCAAAR8JJAbnXAA5KaoUBQCEIAABCAAAQhAAAIQgAAE/COQH41wAOSnrNAUAhCAAAQgAAEIQAACEIAABHwjkCN9cADkqLBQFQIQgAAEIAABCEAAAhCAAAT8IpAnbXAA5Km00BUCEIAABCAAAQhAAAIQgAAEfCKQK11wAOSquFAWAhCAAAQgAAEIQAACEIAABPwhkC9NcADkq7zQFgIQgAAEIAABCEAAAhCAAAR8IZAzPXAA5KzAUBcCEIAABCAAAQhAAAIQgAAE/CCQNy1wAOStxNAXAhCAAAQgAAEIQAACEIAABHwgkDsdcADkrshQGAIQgAAEIAABCEAAAhCAAASyJ5A/DXAA5K/M0BgCEIAABCAAAQhAAAIQgAAEsiaQw/xxAOSw0FAZAhCAAAQgAAEIQAACEIAABLIlkMfccQDksdTQGQIQgAAEIAABCEAAAhCAAASyJJDLvHEA5LLYUBoCEIAABCAAAQhAAAIQgAAEsiOQz5xxAOSz3NAaAhCAAAQgAAEIQAACEIAABLIikNN8cQDktOBQGwIQgAAEIAABCEAAAhCAAASyIZDXXHEA5LXk0BsCEIAABCAAAQhAAAIQgAAEsiCQ2zxxAOS26FAcAhCAAAQgAAEIQEDVMm4AAAmkSURBVAACEIAABNInkN8ccQDkt+zQHAIQgAAEIAABCEAAAhCAAATSJpDj/HAA5LjwUB0CEIAABCAAAQhAAAIQgAAE0iWQ59xwAOS59NAdAhCAAAQgAAEIQAACEIAABNIkkOu8cADkuvhQHgIQgAAEIAABCEAAAhCAAATSI5DvnHAA5Lv80B4CEIAABCAAAQhAAAIQgAAE0iKQ83xwAOS8AFEfAhCAAAQgAAEIQAACEIAABNIhkPdccADkvQTRHwIQgAAEIAABCEAAAhCAAATSIJD7PHAA5L4IMQACEIAABCAAAQhAAAIQgAAE3BPIfw44APJfhlgAAQhAAAIQgAAEIAABCEAAAq4JFEA+DoACFCImQAACEIAABCAAAQhAAAIQgIBbAkWQjgOgCKWIDRCAAAQgAAEIQAACEIAABCDgkkAhZOMAKEQxYgQEIAABCEAAAhCAAAQgAAEIuCNQDMk4AIpRjlgBAQhAAAIQgAAEIAABCEAAAq4IFEQuDoCCFCRmQAACEIAABCAAAQhAAAIQgIAbAkWRigOgKCWJHRCAAAQgAAEIQAACEIAABCDggkBhZOIAKExRYggEIAABCEAAAhCAAAQgAAEI2CdQHIk4AIpTllgCAQhAAAIQgAAEIAABCEAAArYJFEgeDoACFSamQAACEIAABCAAAQhAAAIQgIBdAkWShgOgSKWJLRCAAAQgAAEIQAACEIAABCBgk0ChZOEAKFRxYgwEIAABCEAAAhCAAAQgAAEI2CNQLEk4AIpVnlgDAQhAAAIQgAAEIAABCEAAArYIFEwODoCCFSjmQAACEIAABCAAAQhAAAIQgIAdAkWTggOgaCWKPRCAAAQgAAEIQAACEIAABCBgg0DhZOAAKFyRYhAEIAABCEAAAhCAAAQgAAEIJCdQPAk4AIpXplgEAQhAAAIQgAAEIAABCEAAAkkJFDA9DoACFiomQQACEIAABCAAAQhAAAIQgEAyAkVMjQOgiKWKTRCAAAQgAAEIQAACEIAABCCQhEAh0+IAKGSxYhQEIAABCEAAAhCAAAQgAAEIxCdQzJQ4AIpZrlgFAQhAAAIQgAAEIAABCEAAAnEJFDQdDoCCFixmQQACEIAABCAAAQhAAAIQgEA8AkVNhQOgqCWLXRCAAAQgAAEIQAACEIAABCAQh0Bh0+AAKGzRYhgEIAABCEAAAhCAAAQgAAEIRCdQ3BQ4AIpbtlgGAQhAAAIQgAAEIAABCEAAAlEJFDg+DoACFy6mQQACEIAABCAAAQhAAAIQgEA0AkWOjQOgyKWLbRCAAAQgAAEIQAACEIAABCAQhUCh4+IAKHTxYhwEIAABCEAAAhCAAAQgAAEIhCdQ7Jg4AIpdvlgHAQhAAAIQgAAEIAABCEAAAmEJFDweDoCCFzDmQQACEIAABCAAAQhAAAIQgEA4AkWPhQOg6CWMfRCAAAQgAAEIQAACEIAABCAQhkDh4+AAKHwRYyAEIAABCEAAAhCAAAQgAAEItCdQ/Bg4AIpfxlgIAQhAAAIQgAAEIAABCEAAAu0IlOA8DoASFDImQgACEIAABCAAAQhAAAIQgEBrAmU4iwOgDKWMjRCAAAQgAAEIQAACEIAABCDQikApzuEAKEUxYyQEIAABCEAAAhCAAAQgAAEINCdQjjM4AMpRzlgJAQhAAAIQgAAEIAABCEAAAs0IlOQ4DoCSFDRmQgACEIAABCAAAQhAAAIQgEBjAmU5igOgLCWNnRCAAAQgAAEIQAACEIAABCDQiEBpjuEAKE1RYygEIAABCEAAAhCAAAQgAAEIdCVQniM4AMpT1lgKAQhAAAIQgAAEIAABCEAAAp0JlOg3DoASFTamQgACEIAABCAAAQhAAAIQgEBHAmX6hQOgTKWNrRCAAAQgAAEIQAACEIAABCBQT6BU33EAlKq4MRYCEIAABCAAAQhAAAIQgAAEviNQrm84AMpV3lgLAQhAAAIQgAAEIAABCEAAAgGBkn3iAChZgWMuBCAAAQhAAAIQgAAEIAABCEwjULa/OADKVuLYCwEIQAACEIAABCAAAQhAAAIiULqAA6B0RY7BEIAABCAAAQhAAAIQgAAEIGBM+RjgAChfmWMxBCAAAQhAAAIQgAAEIAABCJSQAA6AEhY6JkMAAhCAAAQgAAEIQAACECg7gTLajwOgjKWOzRCAAAQgAAEIQAACEIAABMpNoJTW4wAoZbFjNAQgAAEIQAACEIAABCAAgTITKKftOADKWe5YDQEIQAACEIAABCAAAQhAoLwESmo5DoCSFjxmQwACEIAABCAAAQhAAAIQKCuBstqNA6CsJY/dEIAABCAAAQhAAAIQgAAEykmgtFbjACht0WM4BCAAAQhAAAIQgAAEIACBMhIor804AMpb9lgOAQhAAAIQgAAEIAABCECgfARKbDEOgBIXPqZDAAIQgAAEIAABCEAAAhAoG4Ey24sDoMylj+0QgAAEIAABCEAAAhCAAATKRaDU1uIAKHXxYzwEIAABCEAAAhCAAAQgAIEyESi3rTgAyl3+WA8BCEAAAhCAAAQgAAEIQKA8BEpuKQ6AklcAzIcABCAAAQhAAAIQgAAEIFAWAmW3EwdA2WsA9kMAAhCAAAQgAAEIQAACECgHgdJbiQOg9FUAABCAAAQgAAEIQAACEIAABMpAABtxAFAHIAABCEAAAhCAAAQgAAEIQKD4BLDQ4ACgEkAAAhCAAAQgAAEIQAACEIBA4QlgoMEBQCWAAAQgAAEIQAACEIAABCAAgcITwMAqAWYAVCHwHwIQgAAEIAABCEAAAhCAAASKTADbRAAHgCgQIAABCEAAAhCAAAQgAAEIQKC4BLCsRgAHQA0DfyAAAQhAAAIQgAAEIAABCECgqASwaxoBHADTOPAXAhCAAAQgAAEIQAACEIAABIpJAKumE8ABMB0EHxCAAAQgAAEIQAACEIAABCBQRALYFBDAARCQ4BMCEIAABCAAAQhAAAIQgAAEikcAi2YQwAEwAwVfIAABCEAAAhCAAAQgAAEIQKBoBLDnOwI4AL5jwTcIQAACEIAABCAAAQhAAAIQKBYBrKkjgAOgDgZfIQABCEAAAhCAAAQgAAEIQKBIBLClngAOgHoafIcABCAAAQhAAAIQgAAEIACB4hDAkg4EcAB0wMEPCEAAAhCAAAQgAAEIQAACECgKAezoSAAHQEce/IIABCAAAQhAAAIQgAAEIACBYhDAik4EcAB0AsJPCEAAAhCAAAQgAAEIQAACECgCAWzoTAAHQGci/IYABCAAAQhAAAIQgAAEIACB/BPAgi4E/h8AAP//xwteWQAAAAZJREFUAwBsG+hy/00GsAAAAABJRU5ErkJggg=='
};

window._sharePlat = 'apk'; // aktuálisan kiválasztott platform

window.shareNav = function(view, plat) {
  if (plat) window._sharePlat = plat;
  var views = ['shareV1','shareV2','shareV3'];
  views.forEach(function(id, i) {
    var el = document.getElementById(id);
    if (!el) return;
    if (i + 1 === view) {
      el.style.display = 'block';
      el.classList.remove('share-view-in');
      void el.offsetWidth; // reflow
      el.classList.add('share-view-in');
    } else {
      el.style.display = 'none';
    }
  });
  var cfg = window.CHRONOS_SHARE_CONFIG || {};
  var name = window._sharePlat === 'apk' ? 'Android APK' : 'iOS PWA';
  var lbl2 = document.getElementById('shareV2BackLbl');
  var lbl3 = document.getElementById('shareV3BackLbl');
  if (lbl2) lbl2.textContent = name;
  if (lbl3) lbl3.textContent = name;
  // QR kép beállítása animációval (view 3)
  if (view === 3) {
    var img = document.getElementById('shareQrBigImg');
    if (img) {
      var uri = window._sharePlat === 'apk' ? cfg.apkQrDataUri : cfg.pwaQrDataUri;
      img.src = uri || '';
      img.classList.remove('share-qr-pop');
      void img.offsetWidth;
      img.classList.add('share-qr-pop');
    }
  }
};

window.openShareDialog = function() {
  window._sharePlat = 'apk';
  var fb = document.getElementById('shareAppFeedback');
  if (fb) fb.style.display = 'none';
  window.shareNav(1);
  var el = document.getElementById('shareAppOverlay');
  if (el) el.style.display = 'flex';
};

window.closeShareDialog = function() {
  var el = document.getElementById('shareAppOverlay');
  if (el) el.style.display = 'none';
};

window.shareDoLink = async function() {
  var cfg = window.CHRONOS_SHARE_CONFIG || {};
  var url = window._sharePlat === 'apk' ? cfg.apkUrl : cfg.pwaUrl;
  var fb = document.getElementById('shareAppFeedback');
  if (navigator.share) {
    try {
      await navigator.share({ title: cfg.title || 'CHRONOS', text: cfg.text || 'CHRONOS', url: url || '' });
      return;
    } catch(e) {
      if (e && e.name === 'AbortError') return;
    }
  }
  try {
    await navigator.clipboard.writeText(url || cfg.text || 'CHRONOS');
    if (fb) { fb.textContent = '✅ Link vágólapra másolva'; fb.style.display = 'block'; setTimeout(function(){ fb.style.display='none'; }, TIMING.FEEDBACK_HIDE); }
  } catch(e) {
    if (fb) { fb.textContent = '⚠️ Másolás sikertelen'; fb.style.display = 'block'; }
  }
};

// Legacy alias
window.doShareApp = function() { window.doShareLink && window.doShareLink('pwa') || window.shareDoLink(); };
window.doShareCopyLink = window.shareDoLink;

window.toggleImportCard = function() {
  var body  = document.getElementById('importCardBody');
  var title = document.getElementById('importCardTitle');
  if (!body || !title) return;
  var open = body.classList.toggle('open');
  title.classList.toggle('open', open);
};

// Drive szinkron végrehajtás (meglévő chronosDriveSyncManual hívása)
window.doDriveAction = function(action) {
  window.closeDriveDialog();
  const pill = document.getElementById('cloudPillBtn');
  const label = document.getElementById('cloudPillLabel');
  if (pill) { pill.className = 'cloud-pill syncing'; }
  if (label) { label.textContent = '☁'; }

  // A meglévő Drive szinkron logika hívása
  if (typeof window.chronosDriveSyncManual === 'function') {
    window.chronosDriveSyncManual(action);
  }

  // Pill + timestamp frissítése manuális szinkron után
  setTimeout(function() {
    const now = new Date();
    const ts = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
    if (pill) pill.className = 'cloud-pill ok';
    if (label) label.textContent = ts;
    try { localStorage.setItem('chronos_driveLastSync', now.toISOString()); } catch(e) {}
    // Status szöveg frissítése
    const caption = document.getElementById('cloudPillCaption');
    const t = window._chronosTranslations;
    const lang = (window._chronosState && window._chronosState() && window._chronosState().currentLang) || 'de';
    if (caption) {
      const lbl = (t && t[lang] && t[lang]['driveSaveLoad']) || (t && t['de'] && t['de']['driveSaveLoad']) || 'mentés / betöltés';
      caption.textContent = lbl;
    }
  }, 1800);
};

// Cloud pill állapot frissítése az alkalmazás init után
document.addEventListener('DOMContentLoaded', function() {
  // Pill alapállapot beállítása
  const pill = document.getElementById('cloudPillBtn');
  const label = document.getElementById('cloudPillLabel');
  if (pill && label) {
    try {
      const lastSync = localStorage.getItem('chronos_driveLastSync');
      if (lastSync) {
        const d = new Date(lastSync);
        const now = new Date();
        const diffH = (now - d) / 3600000;
        if (!isNaN(d)) {
          const ts = d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
          if (diffH < 1) { pill.className = 'cloud-pill ok'; label.textContent = ts; }
          else if (diffH < 24) { pill.className = 'cloud-pill warn'; label.textContent = Math.round(diffH) + ' órája'; }
          else { pill.className = 'cloud-pill err'; label.textContent = 'Régen!'; }
        }
      } else {
        label.textContent = '–';
      }
    } catch(e) { label.textContent = '–'; }
  }

  // Gmail szinkron állapot visszatöltése (alapból kikapcsolva)
  try {
    const gmailOn = localStorage.getItem('chronos_gmailSyncEnabled') === '1';
    window._applyGmailSyncState(gmailOn);
  } catch(e) {}

  // Profil badge inicializálása
  setTimeout(window.checkProfileBadge, 400);

  // Statisztika prognózis frissítése ha van Grundlohn
  setTimeout(window.updateStatPrognosis, 600);
});

// ── Gmail sync toggle UI ──
window.toggleGmailSyncUI = function() {
  let on = document.getElementById('gmailSyncSwitch').classList.contains('on');
  on = !on;
  window._applyGmailSyncState(on);
  try { localStorage.setItem('chronos_gmailSyncEnabled', on ? '1' : '0'); } catch(e) {}
  if (on && typeof window.ChronosGmailSync !== 'undefined' && window.ChronosGmailSync.start) {
    window.ChronosGmailSync.start();
  }
  // Bekapcsoláskor: ha van név vagy Personal Nr., azonnal fut egy ellenőrzés
  if (on && typeof window.chronosGmailCheckManual === 'function') {
    const st = window._chronosState && window._chronosState();
    const hasName = !!(st && (st.workerName || '').trim());
    const hasPnr  = !!(st && (st.workerPersonalNr || '').trim());
    if (hasName || hasPnr) {
      window.chronosGmailCheckManual();
    }
  }
};

window._applyGmailSyncState = function(on) {
  const sw = document.getElementById('gmailSyncSwitch');
  const wrap = document.getElementById('gmailCheckBtnWrap');
  const caption = document.getElementById('gmailToggleCaption');
  const row = document.getElementById('gmailToggleRow');
  if (!sw) return;
  sw.classList.toggle('on', on);
  if (wrap) wrap.style.display = on ? 'block' : 'none';
  if (row) row.classList.toggle('active', on);
  const t = window._chronosTranslations;
  const lang = (window._chronosState && window._chronosState() && window._chronosState().currentLang) || 'de';
  if (caption) {
    const onLbl  = (t && t[lang] && t[lang]['gmailSyncOn'])  || (t && t['de'] && t['de']['gmailSyncOn'])  || 'Eingeschaltet';
    const offLbl = (t && t[lang] && t[lang]['gmailSyncOff']) || (t && t['de'] && t['de']['gmailSyncOff']) || 'Ausgeschaltet';
    caption.textContent = on ? onLbl : offLbl;
  }
};

// ── Profil accordion ──
window.toggleProfileSettingsAcc = function() {
  const body  = document.getElementById('profileSettingsBody');
  const arrow = document.getElementById('profileSettingsArrow');
  const acc   = document.getElementById('profileSettingsAcc');
  if (!body) return;
  const open = body.classList.toggle('open');
  if (arrow) arrow.classList.toggle('open', open);
  if (acc)   acc.classList.toggle('is-open', open);
};

window.checkProfileBadge = function() {
  const nameVal  = (document.getElementById('settingsWorkerNameInput') || {}).value || '';
  const groupVal = (document.getElementById('settingsShiftGroupInput') || {}).value || '';
  const badge = document.getElementById('profileSettingsBadge');
  const acc   = document.getElementById('profileSettingsAcc');
  if (!badge) return;
  const missing = (!nameVal.trim() ? 1 : 0) + (!groupVal.trim() ? 1 : 0);
  const _t = window._chronosTranslations;
  const _l = (window._chronosState && window._chronosState() && window._chronosState().currentLang) || 'de';
  const _tr = (_t && (_t[_l] || _t['de'])) || {};
  if (missing > 0) {
    badge.className = 'pacc-badge badge-warn';
    const _fn = _tr.profileMissingData;
    badge.textContent = typeof _fn === 'function' ? _fn(missing) : ('⚠ ' + missing);
    if (acc) acc.className = 'profile-acc missing';
  } else {
    badge.className = 'pacc-badge badge-ok';
    badge.textContent = _tr.profileDone || '✓';
    if (acc) acc.className = acc.classList.contains('is-open') ? 'profile-acc is-open' : 'profile-acc';
  }
};

// ── Statisztika: Éves nettó prognózis ──
window.updateStatPrognosis = function() {
  try {
    const st = window._chronosState ? window._chronosState() : null;
    if (!st) return;
    const grundlohn = parseFloat(st.grundlohn || localStorage.getItem('chronos_grundlohn') || 0);
    if (!grundlohn || grundlohn < 100) {
      document.getElementById('raisePrognCard') && (document.getElementById('raisePrognCard').style.display = 'none');
      document.getElementById('zkPrognCard')    && (document.getElementById('zkPrognCard').style.display    = 'none');
      return;
    }

    // Éves nettó prognózis kártya megjelenítése
    const card = document.getElementById('raisePrognCard');
    if (card) { card.style.display = 'block'; window._restoreStatCards && window._restoreStatCards(); }

    // Raise adatok lekérése
    const pending = (function() {
      try { return JSON.parse(localStorage.getItem('chronos_raisePending') || 'null'); } catch(e) { return null; }
    })();
    const history = (function() {
      try { return JSON.parse(localStorage.getItem('chronos_raiseHistory') || '[]'); } catch(e) { return []; }
    })();

    const now = new Date();
    const curMonth = now.getMonth(); // 0-indexed
    const curYear  = now.getFullYear();
    const _spLang = (st && st.currentLang) || 'de';
    const _spTr = (window._chronosTranslations && (window._chronosTranslations[_spLang] || window._chronosTranslations['de'])) || {};
    const _spFullMN = (_spTr.monthNames) || ['január','február','március','április','május','június','július','augusztus','szeptember','október','november','december'];
    const monthNames = _spFullMN.map(function(n){ return n.slice(0,3).toLowerCase(); });

    // Nettó közelítés – fallback ha nincs valódi adat egy hónapra
    const taxClass = parseInt(st.taxClass || 1);
    const netFactor = [0.74, 0.77, 0.82, 0.74, 0.68, 0.62][taxClass - 1] || 0.74;
    const baseNet = Math.round(grundlohn * netFactor);

    // Emelés keresése (aktuális évben)
    let raiseMonth = -1, raiseNet = baseNet, raiseFactor = 1;
    if (pending && pending.year === curYear) {
      raiseMonth = pending.month - 1; // 0-indexed
      raiseFactor = 1 + (parseFloat(pending.pct) || 0) / 100;
      raiseNet = Math.round(grundlohn * raiseFactor * netFactor);
    }

    // Havi nettó értékek – valódi számított adat ahol van, becslés ahol nincs
    const _calcMN = window._chronosCalcMonthNetto;
    const monthlyNets = [];
    for (let i = 0; i < 12; i++) {
      const r = _calcMN ? _calcMN(curYear, i + 1) : null;
      if (r && r.netto > 0) {
        // Valódi adat: kalkulált nettó
        // Ha az emelés ennél a hónapnál vagy utána van, és a pending alapján kell skálázni:
        let net = r.netto;
        if (raiseMonth >= 0 && i >= raiseMonth && raiseFactor > 1) {
          // A calcMonthBruttoFull a jelenlegi grundlohn-t használja;
          // ha az emelés még pending (nem érvényes), skálázzuk
          net = r.netto * raiseFactor;
        }
        monthlyNets.push(Math.round(net));
      } else {
        // Nincs naptáradat (jövő hónap vagy üres hónap): becslés
        monthlyNets.push(raiseMonth >= 0 && i >= raiseMonth ? raiseNet : baseNet);
      }
    }

    // Bar chart
    const chart = document.getElementById('statBarChart');
    const labels = document.getElementById('statBarLabels');
    if (chart && labels) {
      chart.innerHTML = ''; labels.innerHTML = '';
      const minVal = Math.min(...monthlyNets) * 0.97;
      const maxVal = Math.max(...monthlyNets);
      monthlyNets.forEach(function(v, i) {
        const col = document.createElement('div'); col.className = 'bar-col';
        const wrap = document.createElement('div'); wrap.className = 'bar-wrap';
        let cls = i < curMonth ? 'past' : (i === curMonth ? 'current' : 'future');
        if (raiseMonth >= 0 && i === raiseMonth) cls = 'raised';
        wrap.classList.add(cls);
        wrap.style.height = Math.max(8, Math.round((v - minVal) / (maxVal - minVal + 1) * 100)) + '%';
        if (raiseMonth >= 0 && i === raiseMonth) {
          const ind = document.createElement('div'); ind.className = 'bar-indicator';
          const pct = pending && pending.pct ? '+' + parseFloat(pending.pct).toFixed(1) + '%' : '▲';
          ind.textContent = pct; wrap.appendChild(ind);
        }
        col.appendChild(wrap); chart.appendChild(col);
        const xl = document.createElement('span'); xl.textContent = monthNames[i]; labels.appendChild(xl);
      });
    }

    // Badge
    const badge = document.getElementById('raiseBadgeStat');
    if (badge) {
      if (raiseMonth >= 0 && pending) {
        badge.style.display = 'inline-flex';
        badge.textContent = '▲ +' + parseFloat(pending.pct).toFixed(1) + '% ' + (_spTr.raiseTitle || 'Gehaltserhöhung').replace(/[📈\s]+/,'').trim() + ' ' + monthNames[raiseMonth] + '. 1.';
      } else {
        badge.style.display = 'none';
      }
    }

    // Statisztikai értékek
    const earned = monthlyNets.slice(0, curMonth + 1).reduce(function(a,b){return a+b;}, 0);
    const yearlyTotal = monthlyNets.reduce(function(a,b){return a+b;}, 0);
    const monthAvg = Math.round(earned / (curMonth + 1));
    const raiseBonus = raiseMonth >= 0 ? monthlyNets.slice(raiseMonth).reduce(function(a,b){return a+b;},0) - (monthlyNets.length - raiseMonth) * baseNet : 0;

    const fmt = function(n) { return n.toLocaleString('hu-HU') + ' €'; };
    const el = function(id, val) { const e = document.getElementById(id); if (e) e.textContent = val; };
    el('statEarnedSoFar', fmt(earned));
    el('statYearlyTotal', fmt(yearlyTotal));
    el('statMonthAvg', fmt(monthAvg));
    el('statRaiseBonus', raiseBonus > 0 ? '+' + fmt(raiseBonus) : '–');
    const per = document.getElementById('statEarnedPeriod');
    if (per) per.textContent = monthNames[0] + '–' + monthNames[curMonth] + ' · ' + (curMonth + 1) + ' hó';

    // Havi bontás tábla
    window._statMonthData = monthlyNets;
    window._statMonthReal = monthlyNets.map(function(_, i) {
      const r = _calcMN ? _calcMN(curYear, i+1) : null;
      return !!(r && r.netto > 0);
    });

    // Zeitkonto card
    window.updateZkPrognosis(st, curYear, curMonth);

  } catch(err) {
    console.warn('[Chronos] updateStatPrognosis error:', err);
  }
};

// Zeitkonto prognózis kártya
window.updateZkPrognosis = function(st, curYear, curMonth) {
  try {
    const zkCard = document.getElementById('zkPrognCard');
    if (!zkCard) return;

    // Zeitkonto adatok — valódi forrásokból, nem a sosem feltöltött localStorage stub-ból:
    //  1) state.zeusData[yr-mo] .saldo  → a Zeus Monatsjournal import valódi havi záró egyenlege
    //  2) state.zeitkonto.balance       → a Bér fülön karbantartott élő, aktuális egyenleg
    //  3) state.zeitkonto.monthly / monthlyOverrides → havi gyarapodás a jövőbeli hónapok becsléséhez
    const zeusData = (st && st.zeusData) || {};
    const zk = (st && st.zeitkonto) || {};

    // Csoport + célóra
    const shiftGroup = st && st.shiftGroup;
    const targetH = 168; // havi célóra alap

    const hasZeusSaldo = Object.keys(zeusData).some(function(k) {
      return zeusData[k] && zeusData[k].saldo != null;
    });

    // Ha semmilyen ZK adat nincs, elrejtjük
    if (!hasZeusSaldo && !shiftGroup && !zk.enabled) { zkCard.style.display = 'none'; return; }
    zkCard.style.display = 'block';

    // A jelenlegi hónap esetleges Zeus záróegyenlege — ELŐRE definiálva (TDZ fix)
    const curMonthKey = curYear + '-' + (curMonth + 1);
    const curBalance = (zeusData[curMonthKey] && zeusData[curMonthKey].saldo != null)
      ? zeusData[curMonthKey].saldo
      : (zk.balance != null ? zk.balance : 0);
    const zkMax = (zk.maxBalance && zk.maxBalance > 0) ? zk.maxBalance : 0;

    // Fordítások – ELŐRE definiálva, hogy mindenhol elérhetők legyenek
    const _zkLang = (st && st.currentLang) || 'de';
    const _zkTr = (window._chronosTranslations && (window._chronosTranslations[_zkLang] || window._chronosTranslations['de'])) || {};
    const _fullMN = (_zkTr.monthNames) || ['január','február','március','április','május','június','július','augusztus','szeptember','október','november','december'];
    const monthNames = _fullMN.map(function(n){ return n.slice(0,3).toLowerCase(); });

    // Zeitkonto mini egyenleg kártya frissítése
    const zkBalCard = document.getElementById('zkBalanceCard');
    const zkBalVal  = document.getElementById('zkBalanceVal');
    const zkBalBar  = document.getElementById('zkBalanceBar');
    const zkBalPct  = document.getElementById('zkBalancePct');
    const zkBalMax  = document.getElementById('zkBalanceMax');
    const zkBalTitle = document.getElementById('zkBalCardTitle');
    if (zkBalTitle && _zkTr.zkCurrentBalance) zkBalTitle.textContent = '⏱ Zeitkonto – ' + _zkTr.zkCurrentBalance.toUpperCase();
    if (zkBalCard && (zk.enabled || hasZeusSaldo)) {
      const bal = curBalance;
      const max = zkMax > 0 ? zkMax : 0;
      const pct = max > 0 ? Math.min(100, Math.max(0, bal / max * 100)) : 0;
      const sign = bal >= 0 ? '+' : '';
      zkBalCard.style.display = 'block';
      if (zkBalVal) zkBalVal.textContent = sign + bal.toFixed(2) + ' h';
      if (zkBalBar) {
        zkBalBar.style.width = (max > 0 ? pct.toFixed(0) : 0) + '%';
        zkBalBar.style.background = pct >= 90 ? '#f59e0b' : '#a78bfa';
      }
      if (zkBalPct) zkBalPct.textContent = max > 0 ? pct.toFixed(0) + '%' : '';
      if (zkBalMax) zkBalMax.textContent = max > 0 ? max + ' h max' : '';
    } else if (zkBalCard) {
      zkBalCard.style.display = 'none';
    }

    const timeline = document.getElementById('zkTimeline');
    if (!timeline) return;
    timeline.innerHTML = '';

    // Megjeleníti az utóbbi 3 + jelenlegi + 2 jövőbeli hónapot
    for (let offset = -3; offset <= 2; offset++) {
      let mo = curMonth + offset;
      let yr = curYear;
      while (mo < 0) { mo += 12; yr--; }
      while (mo > 11) { mo -= 12; yr++; }

      const item = document.createElement('div');
      const isCurrent = (offset === 0);
      const isFuture  = (offset > 0);
      const isPast    = (offset < 0);

      const monthKey = yr + '-' + (mo + 1);
      let balance = null;

      if (zeusData[monthKey] && zeusData[monthKey].saldo != null) {
        balance = zeusData[monthKey].saldo;
      } else if (isCurrent) {
        balance = curBalance;
      } else if (isFuture && zk.enabled && !zk.saveAllOvertime) {
        const override = (zk.monthlyOverrides || []).find(function(o) { return o.month === monthKey; });
        const monthlyRate = override ? override.hours : (zk.monthly || 0);
        balance = curBalance + monthlyRate * offset;
      }

      item.className = 'zk-item' + (isCurrent ? ' current' : '') + (isFuture ? ' future' : '');

      const monthLabel = yr + '. ' + monthNames[mo];
      const nowTag = isCurrent ? ' <span class="tag-now">' + (_zkTr.zkNow || 'now') + '</span>' : '';
      const futureTag = isFuture ? '<span style="font-size:8px;color:var(--text2)"> ▸ ' + (_zkTr.zkEstimated || 'est.') + '</span>' : '';

      let valCls = balance !== null && balance >= 0 ? (isCurrent ? 'neutral' : 'pos') : '';
      const pulseClass = isCurrent ? ' pulse' : '';

      const balanceText = balance !== null ? (balance >= 0 ? '+' : '') + balance.toFixed(2) + ' h' : '–';
      const descText = isFuture ? (_zkTr.zkExpectedClosing || 'Expected closing') : (isCurrent ? (_zkTr.zkCurrentBalance || 'Current balance') : (_zkTr.zkClosingBalance || 'Closing balance'));

      // Sáv: ha van maxBalance, ahhoz viszonyítunk; különben fix 25h skála
      let barPct = 0;
      let capHtml = '';
      if (balance !== null) {
        if (zkMax > 0) {
          barPct = Math.min(100, Math.max(0, balance / zkMax * 100));
          const pctText = balanceText !== '–' ? ' · ' + barPct.toFixed(0) + '%' : '';
          // Sáv színe: >90% → narancs figyelmeztetés, különben normál
          const barColor = barPct >= 90 ? '#f59e0b' : (isCurrent ? 'var(--accent)' : '#4ade80');
          capHtml = '<div class="zk-bar-row"><div class="zk-bar-bg">' +
            '<div class="zk-bar-fill ' + valCls + '" style="width:' + barPct.toFixed(0) + '%;background:' + barColor + (isFuture ? ';opacity:.6' : '') + '"></div>' +
            '</div>' +
            '<span style="font-size:9px;color:var(--text2);margin-left:6px;white-space:nowrap;">' + barPct.toFixed(0) + '% / ' + zkMax + ' h</span>' +
            '</div>';
        } else {
          barPct = Math.min(100, Math.abs(balance) / 25 * 100);
          capHtml = '<div class="zk-bar-row"><div class="zk-bar-bg"><div class="zk-bar-fill ' + valCls + '" style="width:' + barPct.toFixed(0) + '%' + (isFuture ? ';opacity:.6' : '') + '"></div></div></div>';
        }
      }

      item.innerHTML =
        '<div class="zk-month">' + monthLabel + nowTag + futureTag + '</div>' +
        '<div class="zk-row">' +
          '<div class="zk-desc">' + descText + '</div>' +
          '<div class="zk-val ' + valCls + pulseClass + '">' + balanceText + '</div>' +
        '</div>' +
        capHtml;

      timeline.appendChild(item);
    }

    // Meta info
    const meta = document.getElementById('zkMetaInfo');
    if (meta && shiftGroup) {
      meta.innerHTML =
        '<div class="month-trow"><span class="month-tlabel">Csoport</span><span class="month-tval">' + shiftGroup + '</span></div>' +
        '<div class="month-trow"><span class="month-tlabel">Havi célóra</span><span class="month-tval">' + targetH + ' h</span></div>';
    }
  } catch(e) {
    console.warn('[Chronos] updateZkPrognosis error:', e);
  }
};

// Stat kártya összecsukás/kinyitás
window.toggleStatCard = function(cardId) {
  const card = document.getElementById(cardId);
  if (!card) return;
  const collapsed = card.classList.toggle('sc-collapsed');
  try { localStorage.setItem('chronos_sc_' + cardId, collapsed ? '1' : '0'); } catch(e){}
};
// Kártyák állapotának visszaállítása induláskor
window._restoreStatCards = function() {
  ['raisePrognCard','zkPrognCard'].forEach(function(id) {
    try {
      const val = localStorage.getItem('chronos_sc_' + id);
      const el = document.getElementById(id);
      if (!el) return;
      // null = nincs mentett állapot → alapból csukva (sc-collapsed már rajta van)
      // '1' = felhasználó bezárta → csukva
      // '0' = felhasználó kinyitotta → nyitva
      if (val === '0') {
        el.classList.remove('sc-collapsed');
      } else {
        el.classList.add('sc-collapsed');
      }
    } catch(e){}
  });
};

// Havi bontás toggle
window._statTableOpen = false;
window.toggleStatMonthTable = function() {
  window._statTableOpen = !window._statTableOpen;
  const tbl = document.getElementById('statMonthTable');
  const btn = document.getElementById('statMonthToggleBtn');
  if (!tbl || !window._statMonthData) return;
  tbl.style.display = window._statTableOpen ? 'block' : 'none';
  const _stLang = (window._chronosState && window._chronosState() && window._chronosState().currentLang) || 'de';
  const _stTr = (window._chronosTranslations && (window._chronosTranslations[_stLang] || window._chronosTranslations['de'])) || {};
  const _fullMNst = (_stTr.monthNames) || ['jan','feb','már','ápr','máj','jún','júl','aug','szep','okt','nov','dec'];
  const monthNames = _fullMNst.map(function(n){ return n.slice(0,3).toLowerCase(); });
  if (window._statTableOpen) {
    tbl.innerHTML = window._statMonthData.map(function(v, i) {
      const isReal = window._statMonthReal && window._statMonthReal[i];
      const valStr = v.toLocaleString('de-DE', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' €';
      const tag = isReal ? '' : '<span style="font-size:8px;color:var(--text2);margin-left:4px;">~</span>';
      return '<div class="month-trow"><span class="month-tlabel">' + monthNames[i] + tag + '</span><span class="month-tval" style="color:' + (isReal ? 'var(--accent)' : 'var(--text2)') + '">' + valStr + '</span></div>';
    }).join('');
  }
  if (btn) btn.innerHTML = (window._statTableOpen
    ? '▲ <span>' + (_stTr.hideMonthBreakdown || 'Hide monthly breakdown') + '</span>'
    : '▼ <span>' + (_stTr.showMonthBreakdown || 'Show monthly breakdown') + '</span>');
};

// updateStats hook – meghívja a prognózist is
(function() {
  document.addEventListener('DOMContentLoaded', function() {
    const origUpdateStats = window.updateStats;
    if (typeof origUpdateStats === 'function') {
      window.updateStats = function() {
        origUpdateStats.apply(this, arguments);
        setTimeout(window.updateStatPrognosis, 200);
      };
    }
  });
})();

  //  ════════════════════════════════════════════════════════════════════
  //  A fenti fejléc-komment és az egyes RÉSZ-bannerek a kódot
  //  window.Chronos.App / window.Chronos.AutoRot / window.Chronos.Onboarding /
  //  window.Chronos.PWA / window.Chronos.RaiseWidget / window.RotWidget /
  //  window.ZeusWidget névterekként írják le. Ezek korábban csak a
  //  kommentekben léteztek - futás közben window.Chronos === undefined volt.
  //
  //  Ez a blokk ÉLŐ (get/set) aliasokkal létrehozza ezeket a névtereket,
  //  hogy a dokumentáció állítása valóban igaz legyen:
  //    window.Chronos.App.calculatePayroll === window.calculatePayroll
  //    window.RotWidget.rotGenerate === window.rotGenerate
  //    stb.
  //
  //  FONTOS: ez a blokk CSAK HOZZÁAD, semmit nem vesz el és nem ír át.
  //  Minden korábbi lapos window.<fn> export és minden HTML
  //  onclick/onchange/oninput attribútum PONTOSAN ugyanúgy működik
  //  tovább, mint korábban. A get/set proxy miatt mindkét irányban
  //  élő marad az adat (ha valaki window.calculatePayroll-t írja át,
  //  azt window.Chronos.App.calculatePayroll is azonnal látja, és
  //  fordítva).
  //
  //  Helye nem véletlen: a fájl VÉGÉN van, az utolsó (RÉSZ 10) <script>
  //  blokk UTÁN, hogy minden korábbi window.* export már létezzen,
  //  mire ez lefut.
  (function () {
    function _nsAlias(ns, key) {
      Object.defineProperty(ns, key, {
        configurable: true,
        enumerable: true,
        get: function () { return window[key]; },
        set: function (v) { window[key] = v; }
      });
    }

    window.Chronos = window.Chronos || {};

    // RÉSZ 1 - "⟳ Automatikus felismerés"
    window.Chronos.AutoRot = {};
    ['_arDetectFromSchedule','_arUpdateBtnVisibility','arApply','arUpdatePreview','closeAutoRot','openAutoRot','smartRotConfirm'].forEach(function (k) { _nsAlias(window.Chronos.AutoRot, k); });

    // RÉSZ 3 - első-indítás varázsló
    window.Chronos.Onboarding = {};
    ['_applyObName','_obPendingGroup','_obPendingName','_obPendingSalary','_obWantsBio','_syncSettingsGroupInput','_syncSettingsNameInput','_syncSettingsPersonalNrInput','checkOnboarding','obFinish','obFinishNew','obNext','obSaveProfile','obSelectLang','obSetPinChoice','obSkip','openPinSetup','settingsShiftGroupSave','settingsWorkerNameSave','settingsWorkerPersonalNrSave'].forEach(function (k) { _nsAlias(window.Chronos.Onboarding, k); });

    // RÉSZ 4 - fő alkalmazás (állapot, naptár, bérszámítás, import, PIN, UI)
    window.Chronos.App = {};
    ['_checkSmartRot','_chronosAllShifts','_chronosEnsureSchedules','_chronosIsHoliday','_chronosRender','_chronosSaveState','_chronosSetSchedule','_chronosSetYearMonth','_chronosShiftName','_chronosState','_chronosTranslations','_currentTranslations','_hoursEditMode','_pendingPayrollReveal','_privateModeUnlockCallback','addEZ','addMoreFiles','addOther','addZkMonthlyOverride','addZkWithdrawal','calculatePayroll','cancelHoursEdit','closePdfImport','closeShiftSheet','confirmShiftSheet','delEZ','delOther','delZkMonthlyOverride','delZkWithdrawal','exportSchichtplan','kkChanged','openHoursEditMode','openPdfImport','openShiftEdit','openShiftSheet','pdfDoImport','pdfOverwriteConfirm','pdfSearchName','pdfSelectAll','refreshBmfTax','removeFile','renderCalendar','resetAllHoursOverrides','saveDA','saveDABal','saveHoursEdit','saveWG','saveWGPercent','saveZK','saveZKBal','saveZKSaveAll','selectShiftSheetOpt','setFontSize','setWG','togglePayrollMode','togglePdfNamesAccordion'].forEach(function (k) { _nsAlias(window.Chronos.App, k); });

    // RÉSZ 5 - Service Worker / telepítési banner
    window.Chronos.PWA = {};
    ['_androidInstallPrompt','checkForUpdate'].forEach(function (k) { _nsAlias(window.Chronos.PWA, k); });

    // RÉSZ 10 - Fizetésemelés (v2: pending + history, localStorage-alapú)
    window.Chronos.RaiseWidget = {};
    ['_wgBruttoBonus','_wgMissingMonths','raiseDoAutoApply','raiseSavePending','raiseClearPending','raiseDeleteHistory','raiseEditHistory','raiseFormRecalc','raiseFormRecalcFromPct','raiseFormRecalcFromGrund','toggleRaiseAccordion','toggleRaiseEnabled'].forEach(function (k) { _nsAlias(window.Chronos.RaiseWidget, k); });

    // RÉSZ 7 - Rotáció generátor widget
    window.RotWidget = {};
    ['KNOWN_CYCLES','_pdfNameToGroupMap','_qLoadFromChronos','_rotCalcCycleStartFn','_rotDBSnapshot','_rotGenerateFn','_rotGetDB','_rotGetSelected','_rotSelectGroupById','_rotSetCalRange','_rotShiftOnDateFn','_rotShiftToIdFn','_rwRenderGroupList','closeRotationCreator','nameNorm','openRotationCreator','rotAnalyzePdfTexts','rotCalNext','rotCalPrev','rotCalcPhase','rotGenerate','rotRenderGroups','rotSelectShift'].forEach(function (k) { _nsAlias(window.RotWidget, k); });

    // RÉSZ 8/9 - ZEUS Monatsjournal import widget
    window.ZeusWidget = {};
    ['closeZeusImport','openZeusImport','switchTab','doChronosImport'].forEach(function (k) { _nsAlias(window.ZeusWidget, k); });

  })();
