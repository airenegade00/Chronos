/* Chronos sync — Drive + Gmail Zeus + manuális szinkron gombok (Fázis 1)
   window.ChronosDriveSync, ChronosGmailSync, manuális UI
*/
'use strict';

// ── Google Drive sync ──
(function() {
  var DRIVE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxmv_GkPxGlyHRNhpPfo5TubRI0eT-zyyvL3NGgS0EUCh8fANm09obbhjaN74ibHYaB/exec';
  var _saveTimer = null;
  var _saving = false;
  var _pendingState = null;

  async function _doSave() {
    if (_saving || !_pendingState) return;
    _saving = true;
    var toSave = _pendingState;
    _pendingState = null;
    try {
      var personalNr = toSave && toSave.workerPersonalNr;
      if (!personalNr) return;
      var jsonStr = JSON.stringify(toSave);
      var b64data = btoa(unescape(encodeURIComponent(jsonStr)));
      var result = await appsScriptPost({
        action: 'save',
        personalNr: personalNr,
        data: b64data
      });
      if (result && result.ok) {
        console.log('Chronos Drive: mentve →', result.filename);
      } else {
        console.warn('Chronos Drive save hiba:', result);
      }
    } catch(e) {
      console.warn('Chronos Drive save exception:', e);
    } finally {
      _saving = false;
      if (_pendingState) _doSave(); // ha közben érkezett új mentési igény
    }
  }

  window.ChronosDriveSync = {

    // Mentés Drive-ra — POST-tal küldi a state-et (nincs URL hossz korlát)
    // Debounced 2000ms, queue-alapú: ha POST fut és közben jön új igény, nem vész el
    save: function(stateObj) {
      if (!DRIVE_SCRIPT_URL || DRIVE_SCRIPT_URL.indexOf('PLACEHOLDER') !== -1) return;
      var personalNr = stateObj && stateObj.workerPersonalNr;
      if (!personalNr) return;

      _pendingState = stateObj; // mindig frissítjük a legutóbbi állapottal
      if (_saveTimer) clearTimeout(_saveTimer);
      _saveTimer = setTimeout(function() {
        if (_saving) return; // a finally ága elindítja ha _pendingState van
        _doSave();
      }, 2000);
    },

    // Betöltés Drive-ról — GET, personalNr alapján
    load: async function(personalNr) {
      if (!DRIVE_SCRIPT_URL || DRIVE_SCRIPT_URL.indexOf('PLACEHOLDER') !== -1) return null;
      if (!personalNr) return null;
      try {
        var result = await appsScriptGet({ action: 'load', personalNr: personalNr });
        if (result && result.ok && result.data) {
          return result.data;
        }
        return null;
      } catch(e) {
        console.warn('Chronos Drive load exception:', e);
        return null;
      }
    }
  };

  // ── GET kérés: load + kis payload ──────────────────────────
  async function appsScriptGet(params) {
    var url = DRIVE_SCRIPT_URL + '?' + Object.keys(params).map(function(k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');

    var rawText = null;
    try {
      var capHttp = window.Capacitor &&
                    window.Capacitor.Plugins &&
                    window.Capacitor.Plugins.CapacitorHttp;
      if (capHttp) {
        var capResp = await capHttp.request({
          method: 'GET',
          url: url,
          headers: { 'Accept': 'application/json, text/plain, */*' },
          responseType: 'text'
        });
        if (capResp && capResp.status === 200 && capResp.data) {
          rawText = typeof capResp.data === 'string' ? capResp.data : JSON.stringify(capResp.data);
        }
      }
    } catch(e) { console.warn('CapacitorHttp GET error:', e); }

    if (!rawText) {
      var resp = await fetch(url, { mode: 'cors' });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      rawText = await resp.text();
    }
    return JSON.parse(rawText.trim());
  }

  // ── POST kérés: save (nagy payload) ────────────────────────
  // Apps Script exec URL redirect-et csinál → CapacitorHttp kezeli,
  // fetch() böngészőben CORS miatt nem megy POST-nál, de APK-ban igen.
  async function appsScriptPost(bodyObj) {
    var bodyStr = JSON.stringify(bodyObj);
    var rawText = null;

    try {
      var capHttp = window.Capacitor &&
                    window.Capacitor.Plugins &&
                    window.Capacitor.Plugins.CapacitorHttp;
      if (capHttp) {
        var capResp = await capHttp.request({
          method: 'POST',
          url: DRIVE_SCRIPT_URL,
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          data: bodyStr,
          responseType: 'text'
        });
        if (capResp && capResp.data) {
          rawText = typeof capResp.data === 'string' ? capResp.data : JSON.stringify(capResp.data);
        }
      }
    } catch(e) { console.warn('CapacitorHttp POST error:', e); }

    // Böngésző fallback (PWA / fejlesztés) — fetch no-cors-szal nem ad vissza adatot,
    // ezért itt GET fallback-re térünk vissza kis payload-dal
    if (!rawText) {
      var resp = await fetch(DRIVE_SCRIPT_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: bodyStr
      });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      rawText = await resp.text();
    }

    return JSON.parse(rawText.trim());
  }

})();


// ── Gmail Zeus sync ──
(function() {
  var ZEUS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxL4supT_3R0C0ASUnEk8lEYitAX9FFTcJd3zTH9Xt__SOMHQdGwgQcpTKRb7EBzcIZ/exec';
  var PENDING_KEY = 'chronosZeusPending';

  // base64url → Uint8Array (PDF-ek dekódolásához)
  function b64ToBytes(b64) {
    var std = b64.replace(/-/g, '+').replace(/_/g, '/');
    var bin = atob(std);
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  // Saját toast — a globális showNotification() egy másik <script>-blokk
  // privát IIFE-jében van deklarálva, ezért onnan ide NEM látható
  // (a "typeof showNotification === 'function'" mindig false volt itt,
  // így a korábbi figyelmeztetések/értesítések némán elnyelődtek).
  // Ugyanazt a globális .notification CSS class-t használja, ami a
  // <style> blokkban van definiálva, így vizuálisan ugyanúgy néz ki.
  function _zgNotify(msg, duration, type) {
    try {
      var notif = document.createElement('div');
      notif.className = 'notification' + (type === 'warning' ? ' warning' : '');
      notif.textContent = msg;
      document.body.appendChild(notif);
      setTimeout(function() { notif.remove(); }, duration || TIMING.ZEUS_NOTIF_HIDE);
    } catch(e) {}
  }

  // Ékezet+sorrend-toleráns névegyeztetés
  function _normName(s) {
    return (s || '').toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[,.;\-]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function _nameMatches(a, b) {
    var na = _normName(a), nb = _normName(b);
    if (!na || !nb) return false;
    var parts = na.split(' ').filter(Boolean);
    if (!parts.length) return false;
    if (parts.every(function(w) { return nb.indexOf(w) !== -1; })) return true;
    var rev = parts.slice().reverse();
    return rev.every(function(w) { return nb.indexOf(w) !== -1; });
  }

  // Saját hónapok kiszűrése Personal Nr. vagy név alapján
  function filterOwnMonths() {
    var wn  = (window._chronosState && window._chronosState().workerName) || '';
    var wpn = ((window._chronosState && window._chronosState().workerPersonalNr) || '').trim();
    if (typeof months === 'undefined') return { kept: 0, others: 0, unparsed: 0, keptMonths: [] };
    // FONTOS: ha nincs megadva se név, se Personal Nr., NEM tudjuk megállapítani,
    // kihez tartozik a talált Monatsjournal — ezért biztonsági okból ELVETJÜK
    // az összeset, nem fogadjuk el "saját"-nak. Korábban itt minden hónapot
    // elfogadott, ami miatt a varázsló alatt (még azonosítás előtt) bárki
    // naplója felugorhatott.
    if (!wn.trim() && !wpn) {
      months = [];
      return { kept: 0, others: 0, unparsed: 0, keptMonths: [], unidentified: true };
    }
    var others = 0, unparsed = 0, keptMonths = [];
    months = months.filter(function(mo) {
      if (wpn && mo.personalNr) {
        if (mo.personalNr.trim() === wpn) { keptMonths.push(mo); return true; }
        others++; return false;
      }
      if (!mo.name) { unparsed++; return false; }
      if (wn.trim() && _nameMatches(wn, mo.name)) { keptMonths.push(mo); return true; }
      others++; return false;
    });
    return { kept: months.length, others: others, unparsed: unparsed, keptMonths: keptMonths };
  }

  // Pending gomb frissítése
  window._zgUpdatePendingBtn = function() {
    var btn = document.getElementById('btnGmailZeusPending');
    if (!btn) return;
    var raw = null;
    try { raw = localStorage.getItem(PENDING_KEY); } catch(e) {}
    if (raw) {
      var p = null;
      try { p = JSON.parse(raw); } catch(e) {}
      if (p && p.moStr) {
        btn.style.display = '';
        btn.textContent = ((window._currentTranslations && window._currentTranslations.zeusAutoImportPendingBtn) || '⏳ Függő Zeus import') + ': ' + p.moStr;
        return;
      }
    }
    btn.style.display = 'none';
  };

  // Dialóg megjelenítése és felhasználói döntés visszaadása
  function showImportDialog(moStr, isPending) {
    return new Promise(function(resolve) {
      var ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.75);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
      ov.innerHTML =
        '<div style="background:var(--surface,#1a1f2e);border:1px solid rgba(0,229,160,0.35);border-radius:20px;padding:26px 22px;max-width:340px;width:100%;box-shadow:0 8px 40px rgba(0,0,0,0.7);">' +
          '<div style="font-size:32px;text-align:center;margin-bottom:10px;">' + (isPending ? '⏳' : '📧') + '</div>' +
          '<div style="color:#e8eeff;font-size:15px;font-weight:700;text-align:center;margin-bottom:6px;">' + (isPending ? ((window._currentTranslations&&window._currentTranslations.zeusModalTitlePending)||'Függő Zeus import') : ((window._currentTranslations&&window._currentTranslations.zeusModalTitleNew)||'Zeus Monatsjournal érkezett')) + '</div>' +
          '<div style="color:#00e5a0;font-size:12px;font-family:\'DM Mono\',monospace;text-align:center;margin-bottom:6px;">' + moStr.replace(/</g,'&lt;') + '</div>' +
          '<div style="color:#7a8ab0;font-size:11px;text-align:center;margin-bottom:18px;">' + (isPending ? ((window._currentTranslations&&window._currentTranslations.zeusModalSubPending)||'Korábban elhalasztva. Mit szeretnél?') : ((window._currentTranslations&&window._currentTranslations.zeusModalSubNew)||'A te naplód került azonosításra.')) + '</div>' +
          '<div style="display:flex;flex-direction:column;gap:10px;">' +
            '<button id="_zg_Check" style="padding:14px;border-radius:13px;border:1.5px solid rgba(95,158,247,0.5);background:rgba(95,158,247,0.08);color:#5f9ef7;font-size:14px;font-weight:700;cursor:pointer;">' + ((window._currentTranslations&&window._currentTranslations.zeusModalCheck)||'🔍 Ellenőrzés') + '</button>' +
            '<button id="_zg_Load" style="padding:14px;border-radius:13px;border:none;background:linear-gradient(135deg,#00e5a0,#00b37a);color:#000;font-size:14px;font-weight:700;cursor:pointer;">' + ((window._currentTranslations&&window._currentTranslations.zeusModalLoad)||'⚡ Betöltés') + '</button>' +
            '<button id="_zg_Skip" style="padding:10px;border-radius:13px;border:none;background:transparent;color:#7a8ab0;font-size:12px;cursor:pointer;">' + (isPending ? ((window._currentTranslations&&window._currentTranslations.zeusModalDiscard)||'Elvet') : ((window._currentTranslations&&window._currentTranslations.zeusModalLater)||'Később')) + '</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(ov);
      ov.querySelector('#_zg_Check').addEventListener('click', function() { ov.remove(); resolve('check'); });
      ov.querySelector('#_zg_Load' ).addEventListener('click', function() { ov.remove(); resolve('load');  });
      ov.querySelector('#_zg_Skip' ).addEventListener('click', function() { ov.remove(); resolve('skip');  });
    });
  }

  // Importálás a betöltött months alapján
  function doAutoImport() {
    if (typeof doChronosImport !== 'function' || !window._chronosState || !window._chronosSaveState) return false;
    var _c = document.getElementById('ciOptCalendar'), _s = document.getElementById('ciOptSalary');
    var _cp = _c ? _c.checked : true, _sp = _s ? _s.checked : true;
    if (_c) _c.checked = true; if (_s) _s.checked = true;
    var ok = false;
    try { doChronosImport(); ok = true; } catch(e) { console.error('GmailSync import hiba:', e); }
    if (_c) _c.checked = _cp; if (_s) _s.checked = _sp;
    return ok;
  }

  // Dialóg utáni akciók (check / load / skip)
  function handleChoice(choice, moStr) {
    if (choice === 'check') {
      if (typeof refreshUI === 'function') refreshUI();
      if (typeof window.openZeusImport === 'function') window.openZeusImport();
      if (typeof setStatus === 'function') setStatus('ok', moStr + ((window._currentTranslations && window._currentTranslations.gmailCheckSuffix) || ' – ellenőrzés'));
      try { localStorage.removeItem(PENDING_KEY); } catch(e) {}
      window._zgUpdatePendingBtn();
    } else if (choice === 'load') {
      var ok = doAutoImport();
      var _gtr = window._currentTranslations || {};
      var msg = ok
        ? (typeof _gtr.gmailImportedOk === 'function' ? _gtr.gmailImportedOk(moStr) : ('✅ Importálva: ' + moStr))
        : (_gtr.gmailImportFailed || '⚠️ Import nem sikerült.');
      if (ok) { try { localStorage.removeItem(PENDING_KEY); } catch(e) {} window._zgUpdatePendingBtn(); }
      if (typeof setStatus === 'function') setStatus(ok ? 'ok' : 'err', msg);
      _zgNotify(msg, 6000, ok ? 'success' : 'warning');
    } else { // skip / elvet
      try { localStorage.setItem(PENDING_KEY, JSON.stringify({ months: months, moStr: moStr, savedAt: Date.now() })); } catch(e) {}
      window._zgUpdatePendingBtn();
      if (typeof setStatus === 'function') setStatus('idle', '');
    }
  }

  // Függő import előhívása
  window.ChronosGmailSync = {
    resume: function() {
      var raw = null;
      try { raw = localStorage.getItem(PENDING_KEY); } catch(e) {}
      if (!raw) { alert((window._currentTranslations && window._currentTranslations.gmailNoPending) || 'Nincs mentett függő Zeus import.'); return; }
      var p = null;
      try { p = JSON.parse(raw); } catch(e) {}
      if (!p || !p.months || !p.months.length) { alert((window._currentTranslations && window._currentTranslations.gmailNoData) || 'Nincs érvényes függő adat.'); return; }
      months = p.months;
      if (typeof refreshUI === 'function') refreshUI();
      var moStr = p.moStr || (p.months.length + ' hónap');
      showImportDialog(moStr, true).then(function(choice) {
        if (choice === 'skip') {
          try { localStorage.removeItem(PENDING_KEY); } catch(e) {}
          window._zgUpdatePendingBtn();
          if (typeof setStatus === 'function') setStatus('idle', '');
        } else {
          handleChoice(choice, moStr);
        }
      });
    },

    // ── Fő szinkronizáló — BASIS_PWA Drive sync mintájára ───────────
    // silent=true esetén (háttér auto-szinkron) nem ad figyelmeztetést,
    // ha nincs még azonosítás beállítva — csendben kilép, nem zavarja a
    // felhasználót (pl. a varázsló alatt). Kézi gombnyomásnál (silent
    // nincs megadva) viszont jelez, hogy mit kell előbb beállítani.
    run: async function(silent) {
      // Azonosítás híján (pl. még a varázsló alatt, mielőtt név/Personal Nr.
      // megadásra kerülne) nem tudjuk eldönteni, kihez tartozna a Monatsjournal
      // → ne is induljon el a szinkron, ne kérdezzen rá semmire.
      try {
        var _idSt = window._chronosState && window._chronosState();
        var _wn  = (_idSt && _idSt.workerName) || '';
        var _wpn = ((_idSt && _idSt.workerPersonalNr) || '').trim();
        if (!_wn.trim() && !_wpn) {
          if (!silent) {
            var _idMsg = (window._currentTranslations && window._currentTranslations.zeusNoIdWarning) || 'Add meg a neved vagy Personal Nr.-edet a beállításokban, hogy a Zeus szinkron tudja, kihez tartozik a napló.';
            if (typeof setStatus === 'function') setStatus('idle', '');
            _zgNotify('⚠️ ' + _idMsg, 5000, 'warning');
          }
          return;
        }
      } catch(e) {}

      if (typeof setStatus === 'function') setStatus('busy', (window._currentTranslations&&window._currentTranslations.drvChecking2)||'⏳…');

      // Importált hónapok lekérése a state-ből — ezeket elküldjük az Apps Script-nek
      var importedMonths = [];
      try {
        var st = window._chronosState && window._chronosState();
        importedMonths = (st && st.zeusImportedMonths) || [];
      } catch(e) {}

      // Fetch az Apps Script-re — CapacitorHttp + fallback (WebView CORS/redirect megkerülése)
      var text;
      try {
        // 3b. fázis (terv 6. pont, 1. lépés): name/personalNr is elküldve, hogy
        // az Apps Script `fetch` action-je szerver oldalon tudjon szűrni, és
        // hálózaton csak a kérő saját hónapjai menjenek át (nem mindenkié).
        // MEGJEGYZÉS: ehhez az Apps Script (Code.gs) oldali szűrést is hozzá kell
        // adni — az a kliens forrásából (ez a fájl) nem látható, külön patch kell.
        // Amíg az nincs meg, a válasz nem szűrt (mint eddig), a filterOwnMonths()
        // lent továbbra is kliensoldali védőhálóként szűr.
        var fetchUrl = ZEUS_SCRIPT_URL + '?action=fetch'
                     + '&importedMonths=' + encodeURIComponent(JSON.stringify(importedMonths))
                     + '&name=' + encodeURIComponent((_wn || '').trim())
                     + '&personalNr=' + encodeURIComponent(_wpn || '');
        var rawText = null;

        // CapacitorHttp: natív Android HTTP, megkerüli a WebView CORS-t (redirect-safe)
        try {
          var capHttp = window.Capacitor &&
                        window.Capacitor.Plugins &&
                        window.Capacitor.Plugins.CapacitorHttp;
          if (capHttp) {
            var capResp = await capHttp.request({
              method: 'GET',
              url: fetchUrl,
              headers: { 'Accept': 'application/json, text/plain, */*' },
              responseType: 'text'
            });
            if (capResp && capResp.status === 200 && capResp.data) {
              rawText = typeof capResp.data === 'string' ? capResp.data : JSON.stringify(capResp.data);
            }
          }
        } catch(capErr) {
          console.warn('CapacitorHttp Zeus error:', capErr);
        }

        // Fallback: sima fetch (böngészőben / PWA módban)
        if (!rawText) {
          var resp = await fetch(fetchUrl);
          if (!resp.ok) throw new Error('HTTP ' + resp.status);
          rawText = await resp.text();
        }

        text = rawText.trim();
      } catch (e) {
        if (typeof setStatus === 'function') setStatus('err', ((window._currentTranslations&&window._currentTranslations.gmailSyncFail)||((m)=>'⚠️ Gmail szinkron sikertelen: '+m))(e.message));
        if (!silent) _zgNotify(((window._currentTranslations&&window._currentTranslations.gmailSyncFail)||((m)=>'⚠️ Gmail szinkron sikertelen: '+m))(e.message), 6000, 'warning');
        return;
      }

      // Hibaválaszok kezelése
      if (text === 'NO_MAIL' || text === 'NO_FILE') {
        if (typeof setStatus === 'function') setStatus('ok', (window._currentTranslations&&window._currentTranslations.gmailNoNew)||'Nincs új Zeus napló');
        _zgNotify((window._currentTranslations&&window._currentTranslations.gmailNoNew)||'📭 Nincs új Zeus napló', 4000, 'info');
        return;
      }
      if (text.startsWith('ERROR:')) {
        if (typeof setStatus === 'function') setStatus('err', ((window._currentTranslations&&window._currentTranslations.gmailSyncWarn)||((t)=>'⚠️ Gmail szinkron: '+t))(text));
        if (!silent) _zgNotify(((window._currentTranslations&&window._currentTranslations.gmailSyncWarn)||((t)=>'⚠️ Gmail szinkron: '+t))(text), 6000, 'warning');
        return;
      }

      // JSON parse
      var result;
      try { result = JSON.parse(text); } catch(e) {
        if (typeof setStatus === 'function') setStatus('err', ((window._currentTranslations&&window._currentTranslations.gmailSyncWarn)||((t)=>'⚠️ Gmail szinkron: '+t))('érvénytelen válasz'));
        if (!silent) _zgNotify(((window._currentTranslations&&window._currentTranslations.gmailSyncInvalid)||((t)=>'⚠️ Gmail szinkron: érvénytelen válasz ('+t+')'))(text.slice(0,80)), 6000, 'warning');
        return;
      }
      if (!result.ok) {
        if (typeof setStatus === 'function') setStatus('err', ((window._currentTranslations&&window._currentTranslations.gmailSyncWarn)||((t)=>'⚠️ Gmail szinkron: '+t))(result.error||'Script hiba'));
        if (!silent) _zgNotify(((window._currentTranslations&&window._currentTranslations.gmailSyncScriptErr)||((e)=>'⚠️ Gmail szinkron: '+e))(result.error||'Script hiba'), 6000, 'warning');
        return;
      }

      // Ha nincs új fájl
      if (!result.files || result.files.length === 0) {
        if (typeof setStatus === 'function') setStatus('ok', (window._currentTranslations&&window._currentTranslations.gmailNoNew)||'Nincs új Zeus napló');
        _zgNotify((window._currentTranslations&&window._currentTranslations.gmailNoNew)||'📭 Nincs új Zeus napló', 4000, 'info');
        return;
      }

      // base64 PDF-ek → File objektumok (yearMonth metaadattal)
      var files = (result.files || []).map(function(f) {
        var file = new File([b64ToBytes(f.data)], f.filename, { type: 'application/pdf' });
        file._zeusYearMonth = f.yearMonth || null; // pl. "2026-06"
        return file;
      });

      if (!files.length) {
        if (typeof setStatus === 'function') setStatus('ok', (window._currentTranslations&&window._currentTranslations.gmailNoNew)||'Nincs új Zeus napló');
        _zgNotify((window._currentTranslations&&window._currentTranslations.gmailNoNew)||'📭 Nincs új Zeus napló', 4000, 'info');
        return;
      }

      // PDF feldolgozás + szűrés a saját névre/Personal Nr.-re
      await processFiles(files);
      var stats = filterOwnMonths();

      if (stats.kept === 0) {
        var errMsg = (stats.others || stats.unparsed) ? 'Gmail: nem találtam a te neveddel egyező naplót' : '';
        if (typeof setStatus === 'function') setStatus(errMsg ? 'err' : 'idle', errMsg);
        if (!silent && errMsg) _zgNotify('⚠️ ' + errMsg, 6000, 'warning');
        return;
      }

      // ── Már importált hónapok kiszűrése (kliensoldali biztosíték) ────
      // Ha egy megtalált hónap már szerepel a zeusImportedMonths listában
      // (azaz korábban már be lett töltve a naptárba), ne kérdezzünk rá
      // újra — csak akkor jelezzünk, ha tényleg új hónapot találtunk.
      var newKeptMonths = (stats.keptMonths || []).filter(function(mo) {
        var mi = (typeof ZEUS_MONTH_IDX !== 'undefined') ? ZEUS_MONTH_IDX[mo.month] : undefined;
        if (mi === undefined) return true; // ismeretlen hónapformátum → inkább mutassuk
        var yearMo = mo.year + '-' + String(mi + 1).padStart(2, '0');
        return importedMonths.indexOf(yearMo) === -1;
      });

      if (!newKeptMonths.length) {
        // Minden megtalált hónap már korábban importálva volt
        if (typeof setStatus === 'function') setStatus('ok', 'Nincs új Zeus napló');
        if (!silent) _zgNotify((window._currentTranslations&&window._currentTranslations.gmailNoNew)||'📭 Nincs új Zeus napló', 4000, 'info');
        return;
      }

      months = newKeptMonths;
      stats.keptMonths = newKeptMonths;

      // Hónapok megjelenítése a dialógban
      var moNames = ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
      var moStr = (stats.keptMonths && stats.keptMonths.length)
        ? stats.keptMonths.map(function(mo) {
            var mn = parseInt(mo.month, 10);
            return (mn >= 1 && mn <= 12 ? moNames[mn-1] : mo.month) + ' ' + (mo.year || '');
          }).join(', ')
        : stats.kept + ' hónap';

      var choice = await showImportDialog(moStr, false);
      handleChoice(choice, moStr);
    }
  };
})();


// ── Manuális Drive / Gmail gombok ──
(function() {

  // ── Drive Szinkron gomb logika ──────────────────────────────────────
  window.chronosDriveSyncManual = async function() {
    var statusEl = document.getElementById('driveSyncStatus');

    function setDriveStatus(msg, color) {
      if (statusEl) { statusEl.textContent = msg; statusEl.style.color = color || 'var(--text2)'; }
    }

    if (!window.ChronosDriveSync) {
      setDriveStatus((window._currentTranslations&&window._currentTranslations.drvNotAvail)||'⚠️ Drive szinkron nem elérhető.', '#f87171');
      return;
    }

    var st = window._chronosState && window._chronosState();
    var personalNr = (st && st.workerPersonalNr) ? st.workerPersonalNr.trim() : '';

    if (!personalNr) {
      setDriveStatus((window._currentTranslations&&window._currentTranslations.drvNoPersonalNr)||'⚠️ Add meg a Personal Nr.-t a fenti mezőben!', '#f59e0b');
      var pnrInput = document.getElementById('settingsPersonalNrInput');
      if (pnrInput) pnrInput.focus();
      return;
    }

    // Választó dialóg: Mentés / Betöltés / Mégse
    var choice = await new Promise(function(resolve) {
      var tr = window._currentTranslations || {};
      var ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.75);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
      ov.innerHTML =
        '<div style="background:var(--surface,#1a1f2e);border:1px solid rgba(95,158,247,0.35);border-radius:20px;padding:26px 22px;max-width:320px;width:100%;box-shadow:0 8px 40px rgba(0,0,0,0.7);">' +
          '<div style="font-size:32px;text-align:center;margin-bottom:10px;">&#x2601;&#xFE0F;</div>' +
          '<div style="color:#e8eeff;font-size:15px;font-weight:700;text-align:center;margin-bottom:6px;">' +
            (tr.drvDialogTitle || '&#x2601;&#xFE0F; Drive Szinkron') +
          '</div>' +
          '<div style="color:#7a8ab0;font-size:12px;text-align:center;margin-bottom:18px;">' +
            (tr.drvDialogSub || 'Mit szeretnél csinálni?') +
          '</div>' +
          '<div style="display:flex;flex-direction:column;gap:10px;">' +
            '<button id="_drv_save" style="padding:14px;border-radius:13px;border:1.5px solid rgba(95,158,247,0.5);background:rgba(95,158,247,0.08);color:#5f9ef7;font-size:14px;font-weight:700;cursor:pointer;">' +
              (tr.drvSaveBtn || '&#x1F4BE; Mentés Drive-ra') +
            '</button>' +
            '<button id="_drv_load" style="padding:14px;border-radius:13px;border:none;background:linear-gradient(135deg,#00e5a0,#00b37a);color:#000;font-size:14px;font-weight:700;cursor:pointer;">' +
              (tr.drvLoadBtn || '&#x1F4E5; Betöltés Drive-ról') +
            '</button>' +
            '<button id="_drv_cancel" style="padding:10px;border-radius:13px;border:none;background:transparent;color:#7a8ab0;font-size:12px;cursor:pointer;">' +
              (tr.drvCancelBtn || 'Mégse') +
            '</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(ov);
      ov.querySelector('#_drv_save').addEventListener('click', function() { ov.remove(); resolve('save'); });
      ov.querySelector('#_drv_load').addEventListener('click', function() { ov.remove(); resolve('load'); });
      ov.querySelector('#_drv_cancel').addEventListener('click', function() { ov.remove(); resolve('cancel'); });
      ov.addEventListener('click', function(e) { if (e.target === ov) { ov.remove(); resolve('cancel'); } });
    });

    if (choice === 'cancel') return;

    var btn = document.getElementById('driveSyncBtn');

    // ── MENTÉS Drive-ra ──────────────────────────────────────────────────────
    if (choice === 'save') {
      if (btn) { btn.disabled = true; btn.textContent = (window._currentTranslations&&window._currentTranslations.drvSyncing)||'⏳ Szinkronizálás…'; }
      setDriveStatus((window._currentTranslations&&window._currentTranslations.drvChecking)||'Drive ellenőrzése…', 'var(--text2)');
      try {
        if (window._chronosSaveState) window._chronosSaveState();
        else if (typeof saveState === 'function') saveState();
        setTimeout(function() {
          var tr = window._currentTranslations || {};
          setDriveStatus(((tr.drvSaved)||((nr)=>'✅ Mentve Drive-ra (Personal Nr.: '+nr+')'))(personalNr), '#00e5a0');
          if (btn) { btn.disabled = false; btn.textContent = (window._currentTranslations&&window._currentTranslations.driveSyncBtn)||'☁️ Drive Szinkron'; }
        }, 2500);
      } catch(e) {
        setDriveStatus(((window._currentTranslations&&window._currentTranslations.drvErr)||((m)=>'⚠️ Hiba: '+m))(e.message), '#f87171');
        if (btn) { btn.disabled = false; btn.textContent = (window._currentTranslations&&window._currentTranslations.driveSyncBtn)||'☁️ Drive Szinkron'; }
      }
      return;
    }

    // ── BETÖLTÉS Drive-ról ────────────────────────────────────────────────────
    if (btn) { btn.disabled = true; btn.textContent = (window._currentTranslations&&window._currentTranslations.drvSyncing)||'⏳ Szinkronizálás…'; }
    setDriveStatus((window._currentTranslations&&window._currentTranslations.drvChecking)||'Drive ellenőrzése…', 'var(--text2)');

    try {
      var driveData = await window.ChronosDriveSync.load(personalNr);

      if (!driveData) {
        // Nincs még mentve → ajánljuk a mentést
        setDriveStatus((window._currentTranslations&&window._currentTranslations.drvNoSave)||'Nincs mentés → létrehozás…', 'var(--text2)');
        if (window._chronosSaveState) window._chronosSaveState();
        else if (typeof saveState === 'function') saveState();
        setTimeout(function() {
          setDriveStatus(((window._currentTranslations&&window._currentTranslations.drvCreated)||((nr)=>'✅ Új mentés létrehozva (Personal Nr.: '+nr+')'))(personalNr), '#00e5a0');
          if (btn) { btn.disabled = false; btn.textContent = (window._currentTranslations&&window._currentTranslations.driveSyncBtn)||'☁️ Drive Szinkron'; }
        }, 2500);
        return;
      }

      var parsed = typeof driveData === 'string' ? JSON.parse(driveData) : driveData;
      var driveTs  = parsed.lastSaved || 0;
      var driveDate = driveTs ? new Date(driveTs).toLocaleString('de-DE') : '?';

      if (typeof window.loadStateFromDrive === 'function') {
        await window.loadStateFromDrive();
        setDriveStatus(((window._currentTranslations&&window._currentTranslations.drvLoaded)||((d)=>'✅ Drive adat betöltve ('+d+')'))(driveDate), '#00e5a0');
      } else {
        setDriveStatus((window._currentTranslations&&window._currentTranslations.drvLoadErr)||'⚠️ Betöltési hiba – próbáld újra.', '#f87171');
      }
    } catch(e) {
      setDriveStatus(((window._currentTranslations&&window._currentTranslations.drvErr)||((m)=>'⚠️ Hiba: '+m))(e.message), '#f87171');
      console.warn('chronosDriveSyncManual error:', e);
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = (window._currentTranslations&&window._currentTranslations.driveSyncBtn)||'☁️ Drive Szinkron'; }
    }
  };

  // ── Gmail Zeus manuális ellenőrzés ──────────────────────────────────
  window.chronosGmailCheckManual = function() {
    var btn = document.getElementById('btnGmailZeusCheck');
    if (!window.ChronosGmailSync) {
      alert((window._currentTranslations&&window._currentTranslations.drvNotAvail)||'⚠️ Gmail szinkron nem elérhető.');
      return;
    }
    if (btn) { btn.disabled = true; btn.textContent = (window._currentTranslations&&window._currentTranslations.drvChecking2)||'⏳…'; }
    var origText = (window._currentTranslations && window._currentTranslations.gmailZeusCheckBtn) || '📧 Gmail';
    // silent=false → hibaüzenetet is mutat, minden hónapot betölt Personal Nr. alapján
    Promise.resolve(window.ChronosGmailSync.run(false)).finally(function() {
      if (btn) { btn.disabled = false; btn.textContent = origText; }
    });
  };

})();
