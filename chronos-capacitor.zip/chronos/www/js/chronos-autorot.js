/* Chronos.AutoRot — automatikus rotáció felismerés (Fázis 1)
   window._ar*, openAutoRot, arApply, _arDetectFromSchedule, ...
*/
'use strict';

// ═══════════════════════════════════════════════════════
//  AUTO ROTATION – naptár fejléc ⟳ gomb logika
// ═══════════════════════════════════════════════════════
(function() {

  // ── Segédek ──
  function _getState() { return window._chronosState ? window._chronosState() : null; }
  function _getSavedGroup() {
    // Mentett csoportszám + fázis localStorage-ból
    let groupId = null, cycleStart = null, pattern = null, dept = '';
    try {
      groupId    = localStorage.getItem('chronos_user_shiftGroup') || null;
      // Ha state-ben is el van mentve, az legyen az elsődleges
      if (window._chronosState) {
        const _st = window._chronosState();
        if (_st && _st.shiftGroup) {
          groupId = _st.shiftGroup;
          localStorage.setItem('chronos_user_shiftGroup', groupId);
        }
      }
      const cs   = localStorage.getItem('chronos_cycleStart');
      cycleStart = cs ? new Date(cs) : null;
      const pat  = localStorage.getItem('chronos_groupPattern');
      pattern    = pat ? JSON.parse(pat) : null;
      dept       = localStorage.getItem('chronos_groupDept') || '';
    } catch(e) {}

    if (!groupId) return null;

    // Keresés az elérhető DB-kben (ha betöltve)
    const rotDB = window._rotGetDB ? window._rotGetDB() : {};
    const rwDB  = (typeof DB !== 'undefined') ? DB : {};
    const known = (typeof KNOWN_CYCLES !== 'undefined') ? KNOWN_CYCLES : {};
    let allDB = Object.assign({}, rotDB, rwDB);
    Object.entries(known).forEach(([id, data]) => {
      if (!allDB[id]) allDB[id] = { id, dept: data.dept, pattern: data.pattern, names: [], confidence: 100 };
    });

    let g = allDB[groupId] || Object.values(allDB).find(x => x.id === groupId) || null;

    // Ha nincs a DB-ben (pl. rotWidget még nem töltött), rekonstruáljuk localStorage-ból
    if (!g && pattern && pattern.length) {
      g = { id: groupId, dept: dept, pattern: pattern, names: [], confidence: 100 };
    }

    if (!g) return null;

    // cycleStart beállítása ha hiányzik a memória-objektumból
    if (!g._cycleStart && cycleStart && !isNaN(cycleStart)) {
      g._cycleStart = cycleStart;
    }
    return g;
  }

  function _hasCycleStart(g) {
    return g && g._cycleStart && (g._cycleStart instanceof Date || !isNaN(new Date(g._cycleStart)));
  }

  function _cycleStartDate(g) {
    if (!g || !g._cycleStart) return null;
    const d = g._cycleStart instanceof Date ? g._cycleStart : new Date(g._cycleStart);
    return isNaN(d) ? null : d;
  }

  function _shiftOnDate(pattern, cycleStart, targetDate) {
    const diff = Math.round((targetDate - cycleStart) / 86400000);
    return pattern[((diff % pattern.length) + pattern.length) % pattern.length];
  }

  function _shiftToId(s) {
    if (s === 'F') return 'Früh';
    if (s === 'S') return 'Spät';
    if (s === 'N') return 'Nacht';
    return null;
  }

  function _fmt(d) {
    if (!d) return '–';
    return d.getFullYear() + '. ' +
      ['jan','feb','már','ápr','máj','jún','júl','aug','szep','okt','nov','dec'][d.getMonth()] +
      '. ' + d.getDate() + '.';
  }

  function _shiftColor(s) {
    return {F:'#ffb347', S:'#4dd6f0', N:'#a78bfa', X:'#606070'}[s] || '#888';
  }

  // ── Gomb láthatóság frissítése ──
  // Akkor mutatjuk a ⟳ gombot, ha van mentett csoport + cikluskezdet
  window._arUpdateBtnVisibility = function() {
    const btn = document.getElementById('btnAutoRot');
    if (!btn) return;
    const g = _getSavedGroup();
    btn.style.display = (g && _hasCycleStart(g)) ? 'inline-flex' : 'none';
  };

  // ── Popup megnyitás ──
  window.openAutoRot = function() {};
window.closeAutoRot = function() {};

  // ── Előnézet frissítése ──
  window.arUpdatePreview = function() {};

  // ── Generálás ──
  window.arApply = function() {};

  // Popup backdrop kattintás bezárja
  document.addEventListener('DOMContentLoaded', function() {
    const popup = document.getElementById('autoRotPopup');
    if (popup) popup.addEventListener('click', function(e) {
      if (e.target === popup) window.closeAutoRot();
    });

    // Gomb láthatóság init + renderCalendar hook
    window._arUpdateBtnVisibility();

    // Hook: renderCalendar után is frissítjük
    const _origRender = window.renderCalendar;
    if (typeof _origRender === 'function') {
      window.renderCalendar = function() {
        _origRender.apply(this, arguments);
        window._arUpdateBtnVisibility();
      };
    }

    // Hook: smartRotConfirm után is
    const _origSmartConfirm = window.smartRotConfirm;
    if (typeof _origSmartConfirm === 'function') {
      window.smartRotConfirm = function(yes) {
        _origSmartConfirm.apply(this, arguments);
        setTimeout(window._arUpdateBtnVisibility, TIMING.AR_BTN_AFTER_SAVE);
      };
    }
  });

  // Overwrite checkbox változás → preview frissítés
  document.addEventListener('change', function(e) {
    if (e.target && e.target.id === 'arOverwrite') window.arUpdatePreview();
  });

})();


// ═══════════════════════════════════════════════════════
//  AUTO ROT – naptárból visszafelé ciklus detektálás
//  Ha van ≥7 nap beírva és még nincs mentett cycleStart,
//  megpróbálja felismerni a csoportot és fázist.
// ═══════════════════════════════════════════════════════
window._arDetectFromSchedule = function() {
  // Ha már van mentett cycleStart, nem kell detektálni
  try {
    const existing = localStorage.getItem('chronos_cycleStart');
    if (existing) {
      if (window._arUpdateBtnVisibility) window._arUpdateBtnVisibility();
      return;
    }
  } catch(e) {}

  if (!window._chronosState) return;
  const st = window._chronosState();
  const schedules = st.schedules || {};
  const shiftMap = { 'Früh':'F', 'Spät':'S', 'Nacht':'N' };

  // Összegyűjtjük a beírt műszaknapokat
  const dayEntries = [];
  Object.keys(schedules).forEach(key => {
    const ids = schedules[key] || [];
    const parts = key.split('-');
    if (parts.length < 3) return;
    const y = parseInt(parts[0]), m = parseInt(parts[1]), d = parseInt(parts[2]);
    if (!y || !m || !d) return;
    let code = null;
    for (const id of ids) { if (shiftMap[id]) { code = shiftMap[id]; break; } }
    if (code) dayEntries.push({ date: new Date(y, m-1, d), code });
  });

  if (dayEntries.length < 7) return; // Kevés adat
  dayEntries.sort((a,b) => a.date - b.date);

  // KNOWN_CYCLES: globális window-on keresztül (IIFE-n belül van definiálva)
  const known = window.KNOWN_CYCLES || (typeof KNOWN_CYCLES !== 'undefined' ? KNOWN_CYCLES : {});
  if (!Object.keys(known).length) {
    // Ha még nem töltött be, próbáljuk 2mp múlva újra
    setTimeout(window._arDetectFromSchedule, TIMING.AR_DETECT_RETRY);
    return;
  }

  const refDate = dayEntries[0].date; // Legkorábbi nap mint referencia
  let bestGroup = null, bestScore = 0, bestCycleStart = null;

  Object.entries(known).forEach(([id, data]) => {
    const pattern = data.pattern;
    if (!pattern || !pattern.length) return;
    const L = pattern.length;

    // Ha van beégetett cycleStart, csak azt próbáljuk
    const fixedCS = data.cycleStart instanceof Date ? data.cycleStart :
                    (data.cycleStart ? new Date(data.cycleStart) : null);

    const candidateStarts = [];
    if (fixedCS && !isNaN(fixedCS)) {
      candidateStarts.push(fixedCS);
    } else {
      // Brute-force: próbáljuk az összes lehetséges offsetet (0..L-1)
      // a legelső naptárnap alapján
      for (let offset = 0; offset < L; offset++) {
        const cs = new Date(refDate);
        cs.setDate(cs.getDate() - offset);
        candidateStarts.push(cs);
      }
    }

    candidateStarts.forEach(cs => {
      let matches = 0;
      dayEntries.forEach(({ date, code }) => {
        const diff = Math.round((date - cs) / 86400000);
        const expected = pattern[((diff % L) + L) % L];
        if (expected === code) matches++;
      });
      const score = matches / dayEntries.length;
      if (score > bestScore && score >= 0.80) {
        bestScore = score;
        bestGroup = { id, dept: data.dept || '', pattern };
        bestCycleStart = cs;
      }
    });
  });

  // ── SZABAD DETEKTÁLÁS: ha KNOWN_CYCLES nem illeszkedett ──
  // A rotation IIFE rotDetectCycle algoritmusa közvetlenül fut a naptár-adatokon
  if (!bestGroup || !bestCycleStart) {
    if (dayEntries.length < 10) return; // Kevés adat a szabad detektáláshoz
    const seqCodes = dayEntries.map(e => e.code); // F/S/N sorozat időrendben

    // rotDetectCycle elérése a rotation IIFE publikus API-ján keresztül
    // Egy dummy csoporton keresztül hívjuk a dátum-alapú detektálást
    const det = (function _freeDetect(entries) {
      const SHIFT_VALS = ['F','S','N','X'];
      const clean = entries.map(e => e.code).filter(s => SHIFT_VALS.includes(s));
      if (clean.length < 10) return null;
      const epoch = new Date(2000, 0, 1);

      // Dátum-alapú brute-force (azonos logika mint rotParsePdfGroups-ban)
      const dated = entries
        .filter(e => SHIFT_VALS.includes(e.code))
        .map(e => ({
          dayOffset: Math.round((e.date - epoch) / 86400000),
          shift: e.code
        }));

      const baseOffset = dated[0].dayOffset;
      const presentShifts = ['F','S','N'].filter(s => dated.some(e => e.shift === s));
      let bestDet = null, bestScore = -1;

      for (let clen = 10; clen <= 63; clen++) {
        for (let startOff = 0; startOff < clen; startOff++) {
          const pattern = new Array(clen).fill(null);
          let conflicts = 0;
          for (const e of dated) {
            const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
            if (pattern[idx] === null) pattern[idx] = e.shift;
            else if (pattern[idx] !== e.shift) conflicts++;
          }
          const filled = pattern.filter(x => x !== null).length;
          if (filled < Math.min(clen, dated.length)) continue;
          if (conflicts > dated.length * 0.08) continue;
          if (!presentShifts.every(s => pattern.includes(s))) continue;
          let hits = 0;
          for (const e of dated) {
            const idx = ((e.dayOffset - baseOffset + startOff) % clen + clen) % clen;
            if (pattern[idx] === e.shift) hits++;
          }
          const pct = hits / dated.length;
          if (pct < 0.88) continue;
          const score = pct * clen;
          if (score > bestScore) {
            bestScore = score;
            const csEpoch = new Date(epoch.getTime() + (baseOffset - startOff) * 86400000);
            bestDet = {
              pattern: pattern.map(s => s || 'X'),
              confidence: Math.round(pct * 100),
              _cycleStart: csEpoch
            };
          }
        }
      }
      return bestDet;
    })(dayEntries);

    if (!det || det.confidence < 88) return; // Nem elég megbízható

    bestCycleStart = det._cycleStart;
    bestGroup = {
      id: 'auto-' + det.pattern.length + 'd',
      dept: 'Auto',
      pattern: det.pattern,
      _fromSchedule: true,
      confidence: det.confidence
    };
    bestScore = det.confidence / 100;
  }

  if (!bestGroup || !bestCycleStart) return;

  // Mentés localStorage-ba
  try {
    localStorage.setItem('chronos_cycleStart', bestCycleStart.toISOString());
    localStorage.setItem('chronos_user_shiftGroup', bestGroup.id);
        if (window._chronosState && window._chronosSaveState) {
          window._chronosState().shiftGroup = bestGroup.id;
          window._chronosSaveState();
        }
        const sgInput = document.getElementById('settingsShiftGroupInput');
        if (sgInput) sgInput.value = bestGroup.id;
    localStorage.setItem('chronos_groupPattern', JSON.stringify(bestGroup.pattern));
    localStorage.setItem('chronos_groupDept', bestGroup.dept || '');
  } catch(e) {}

  // Injektálás a Smart Rotation _smartSelectedGroup-ba is
  bestGroup._cycleStart = bestCycleStart;
  try {
    // Ha _smartSelectedGroup null vagy más csoport, felülírjuk a detektált eredménnyel
    if (window._smartSelectedGroupRef !== undefined) {
      // A getter az IIFE belső változóját adja vissza
      // Közvetlenül a showSmartRot-on keresztül állítjuk be
      if (typeof showSmartRot === 'function') {
        showSmartRot(bestGroup, 'auto');
      }
    }
    // rotSelected szinkronizálás
    const rs = window._rotGetSelected ? window._rotGetSelected() : null;
    if (rs) { rs._cycleStart = bestCycleStart; rs.id = bestGroup.id; rs.pattern = bestGroup.pattern; }
  } catch(e) {}

  if (window._arUpdateBtnVisibility) window._arUpdateBtnVisibility();
};

// DOMContentLoaded után futtatjuk (KNOWN_CYCLES már betöltve)
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(window._arDetectFromSchedule, TIMING.AR_DETECT_INIT);
});
