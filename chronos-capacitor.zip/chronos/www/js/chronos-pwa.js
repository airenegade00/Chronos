/* Chronos PWA — Service Worker regisztráció + telepítési banner
   Fázis 1 modularizáció (SZKRIPT C + D)
*/
'use strict';

// ── Service Worker (inline blob) ──
    /* ── Inline Service Worker regisztráció (egyetlen fájlos PWA Netlify-on) ── */
    (function registerInlineSW() {
      if (!('serviceWorker' in navigator)) return;
      const swCode = `
        const CACHE = 'chronos-v3';
        self.addEventListener('install', e => {
          self.skipWaiting();
        });
        self.addEventListener('activate', e => {
          e.waitUntil(
            caches.keys().then(keys =>
              Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
            ).then(() => clients.claim())
          );
        });
        // FONTOS - SZÁNDÉKOS NO-OP CACHE: a CACHE konstans deklarálva van,
        // de soha nincs caches.open(CACHE).put(...) hívás sehol - tehát
        // a caches.match() itt MINDIG undefined-et ad, és a fetch minden
        // kérésnél a hálózatról jön. Ez direkt van így: ha ez a SW
        // valóban cache-elné az index.html-t, az ÜTKÖZNE a CHRONOS OTA
        // frissítési mechanizmusával (ami felülírja az index.html-t a
        // Drive-ról anélkül, hogy az APK-t újratelepítené) - a SW egy
        // régi, cache-elt index.html-t szolgálhatna ki az OTA után.
        // A SW létezésének egyetlen célja itt a PWA-installálhatóság
        // (böngésző csak akkor ajánlja fel a telepítést, ha van
        // regisztrált Service Worker) - NEM a tartalom gyorsítása.
        // Ha valaha valódi offline-cache-t szeretnél, azt csak az OTA
        // verziószámmal együtt invalidálva szabad bevezetni.
        self.addEventListener('fetch', e => {
          e.respondWith(
            caches.match(e.request).then(r => r || fetch(e.request))
          );
        });
      `;
      const blob = new Blob([swCode], { type: 'application/javascript' });
      const swURL = URL.createObjectURL(blob);
      navigator.serviceWorker.register(swURL, { scope: './' })
        .then(reg => {
          if (reg.installing) {
            reg.installing.addEventListener('statechange', function() {
              // SW aktív – Chrome most már tüzelheti a beforeinstallprompt-ot
            });
          }
        })
        .catch(() => { /* SW nem sikerült */ });
    })();


// ── PWA telepítési banner ──
    (function() {
      // Capacitor APK-ban soha ne mutassuk a PWA bannert
      if (window.Capacitor) return;
      // Ha már standalone módban fut (telepítve), soha ne kérdezze
      if (window.navigator.standalone || window.matchMedia('(display-mode: standalone)').matches) {
        localStorage.setItem(LS.pwaInstalled, '1');
        return;
      }

      // Ha session-szinten már elutasította (X gomb), ne mutassuk ebben a munkamenetben
      if (localStorage.getItem(LS.iosInstallSeen)) return;

      const banner     = document.getElementById('pwaInstallBanner');
      const hint       = document.getElementById('pwaInstallHint');
      const installBtn = document.getElementById('pwaInstallBtn');
      const closeBtn   = document.getElementById('pwaCloseBtn');

      const iosModal       = document.getElementById('iosInstallModal');
      const iosModalClose  = document.getElementById('iosModalClose');
      const iosModalDismiss= document.getElementById('iosModalDismiss');
      const safariWarning  = document.getElementById('safariWarning');

      let deferredPrompt = null;
      const isIOS     = /iphone|ipad|ipod/i.test(navigator.userAgent);
      const isAndroid = /android/i.test(navigator.userAgent);
      const isSafari  = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

      /* ── Banner megjelenítés / elrejtés ── */
      function showBanner() {
        banner.style.display = 'flex';
        const navBottom = document.querySelector('.nav-bottom');
        if (navBottom) navBottom.style.bottom = (banner.offsetHeight + 4) + 'px';
      }

      function hideBanner(permanent) {
        banner.style.display = 'none';
        const navBottom = document.querySelector('.nav-bottom');
        if (navBottom) navBottom.style.bottom = '0';
        if (permanent) {
          localStorage.setItem(LS.pwaInstalled, '1');
        } else {
          localStorage.setItem(LS.iosInstallSeen, '1');
        }
      }

      /* ── iOS modal ── */
      function showIOSModal() {
        if (!isSafari) {
          safariWarning.style.display = 'block';
        }
        iosModal.style.display = 'flex';
      }

      function hideIOSModal(permanent) {
        iosModal.style.display = 'none';
        hideBanner(permanent);
      }

      iosModalClose.addEventListener('click',   () => hideIOSModal(false));
      iosModalDismiss.addEventListener('click', () => hideIOSModal(false));
      // Kattintás a modal háttérre
      iosModal.addEventListener('click', (e) => { if (e.target === iosModal) hideIOSModal(false); });

      closeBtn.addEventListener('click', () => hideBanner(false));

      /* ── Onboarding utáni banner megjelenítés ── */
      // A banner csak az onboarding varázsló befejezése után jelenik meg.
      let _bannerPending = false;
      let _bannerPendingDelay = 800;

      function showBannerAfterOnboarding(delay) {
        if (localStorage.getItem(LS.onboardingDone) === '1') {
          setTimeout(showBanner, delay || 600);
        } else {
          _bannerPending = true;
          _bannerPendingDelay = delay || 800;
        }
      }

      // obFinish kiterjesztése: varázsló bezárása után süti el a bannert
      var _origObFinish = window.obFinish;
      window.obFinish = function(setupPin) {
        if (typeof _origObFinish === 'function') _origObFinish(setupPin);
        if (_bannerPending) {
          _bannerPending = false;
          setTimeout(showBanner, _bannerPendingDelay);
        }
      };

      /* ── iOS ── */
      if (isIOS) {
        hint.textContent    = (window._currentTranslations&&window._currentTranslations.pwaInstallSafari)||'Főképernyőre helyezés (Safari)';
        installBtn.textContent = (window._currentTranslations&&window._currentTranslations.pwaInstallBtnText)||'📲 Telepítés';
        installBtn.addEventListener('click', showIOSModal);
        showBannerAfterOnboarding(TIMING.PWA_BANNER_IOS);
      }

      /* ── Android / Chrome ── */
      else if (isAndroid) {
        hint.textContent = (window._currentTranslations&&window._currentTranslations.pwaInstallPrompt)||'Telepítsd az alkalmazást';

        window.addEventListener('beforeinstallprompt', (e) => {
          e.preventDefault();
          deferredPrompt = e;
          window._androidInstallPrompt = e;
          showBannerAfterOnboarding(TIMING.PWA_BANNER_ANDROID);
        });

        installBtn.addEventListener('click', async () => {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            const result = await deferredPrompt.userChoice;
            if (result.outcome === 'accepted') hideBanner(true);
            deferredPrompt = null;
            window._androidInstallPrompt = null;
          } else {
            // Fallback: szöveges útmutató
            showAndroidFallback();
          }
        });

        // Ha 3 mp után sem jött a prompt, mutasd manuálisan
        setTimeout(() => {
          if (!deferredPrompt && banner.style.display !== 'flex') {
            hint.textContent = (window._currentTranslations&&window._currentTranslations.pwaAddToHome)||'Hozzáadás a főképernyőhöz';
            showBannerAfterOnboarding(TIMING.PWA_BANNER_FALLBACK);
          }
        }, TIMING.PWA_BANNER_PROMPT_WAIT);
      }

      /* ── Desktop Chrome / Edge ── */
      else {
        window.addEventListener('beforeinstallprompt', (e) => {
          e.preventDefault();
          deferredPrompt = e;
          hint.textContent = (window._currentTranslations&&window._currentTranslations.pwaInstallDesktop)||'Telepítés az asztalra';
          showBannerAfterOnboarding(TIMING.PWA_BANNER_ANDROID);
        });

        installBtn.addEventListener('click', async () => {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            const result = await deferredPrompt.userChoice;
            if (result.outcome === 'accepted') hideBanner(true);
            deferredPrompt = null;
          }
        });
      }

      /* ── Android fallback modal (inline) ── */
      function showAndroidFallback() {
        const m = document.createElement('div');
        m.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.75);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);display:flex;align-items:flex-end;justify-content:center;';
        m.innerHTML = `
          <div style="background:#1a2340;border-radius:20px 20px 0 0;width:100%;max-width:500px;padding:24px 20px 32px;box-shadow:0 -8px 40px rgba(0,0,0,0.6);border-top:2px solid #5f9ef7;animation:slideUp 0.35s ease;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
              <div style="color:#f0f4ff;font-weight:700;font-size:17px;">📲 CHRONOS telepítése</div>
              <button onclick="this.closest('div[style*=fixed]').remove()" style="background:rgba(255,255,255,0.1);border:none;color:#9aa8cf;font-size:18px;width:32px;height:32px;border-radius:50%;cursor:pointer;">✕</button>
            </div>
            <div style="background:rgba(95,158,247,0.08);border-radius:12px;padding:14px;margin-bottom:12px;display:flex;gap:14px;align-items:flex-start;">
              <div style="background:#5f9ef7;color:#fff;font-weight:700;font-size:14px;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">1</div>
              <div style="color:#9aa8cf;font-size:13px;line-height:1.5;">Koppints a böngésző menüjére <strong style="color:#5f9ef7;">⋮</strong> (jobb felső sarok)</div>
            </div>
            <div style="background:rgba(95,158,247,0.08);border-radius:12px;padding:14px;margin-bottom:12px;display:flex;gap:14px;align-items:flex-start;">
              <div style="background:#5f9ef7;color:#fff;font-weight:700;font-size:14px;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">2</div>
              <div style="color:#9aa8cf;font-size:13px;line-height:1.5;">Válaszd: <strong style="color:#5f9ef7;">„Hozzáadás a főképernyőhöz"</strong></div>
            </div>
            <div style="background:rgba(95,158,247,0.08);border-radius:12px;padding:14px;margin-bottom:20px;display:flex;gap:14px;align-items:flex-start;">
              <div style="background:#5f9ef7;color:#fff;font-weight:700;font-size:14px;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;">3</div>
              <div style="color:#9aa8cf;font-size:13px;line-height:1.5;">Koppints a <strong style="color:#5f9ef7;">„Hozzáadás"</strong> gombra. Kész! 🎉</div>
            </div>
            <button onclick="this.closest('div[style*=fixed]').remove()" style="width:100%;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);color:#9aa8cf;padding:12px;border-radius:12px;font-size:14px;cursor:pointer;">Bezárás</button>
          </div>`;
        document.body.appendChild(m);
        m.addEventListener('click', (e) => { if (e.target === m) m.remove(); });
      }
    })();
