/* Chronos Cloud — Firebase Auth + Firestore (Fázis 1 modularizáció)
   Betöltés: <script type="module" src="js/chronos-cloud.js"></script>
   Előfeltétel: window.CLOUD_BACKEND (inline script a HTML-ben).
*/
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
  import {
    getAuth, onAuthStateChanged, signInWithEmailAndPassword,
    createUserWithEmailAndPassword, signOut, sendPasswordResetEmail,
    sendEmailVerification, setPersistence, browserLocalPersistence,
    deleteUser, GoogleAuthProvider, OAuthProvider,
    signInWithPopup, signInWithRedirect, getRedirectResult, signInWithCredential
  } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
  import {
    initializeFirestore, persistentLocalCache, persistentSingleTabManager,
    doc, getDoc, getDocFromServer, setDoc, deleteDoc
  } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

  // ── ITT KELL BEILLESZTENI A FIREBASE PROJEKT CONFIGJÁT ──────────────
  // Firebase Console → Project settings → General → Your apps → Web app
  // Amíg PLACEHOLDER van benne, a ChronosCloud inaktív marad (nem hibázik,
  // csak nem csinál semmit), és a CLOUD_BACKEND='drive' marad érvényben.
  var FIREBASE_CONFIG = {
    apiKey: "AIzaSyDUQ6GGNRo5Lm3KxxtpXQEes6By96ZveIU",
    authDomain: "chronos-b8002.firebaseapp.com",
    projectId: "chronos-b8002",
    storageBucket: "chronos-b8002.firebasestorage.app",
    messagingSenderId: "107892169338",
    appId: "1:107892169338:web:2cba56eab345e38e1cf9c3"
  };

  var SCHEMA_VERSION = 1;
  // Ezek a mezők sosem kerülnek fel a Firestore-ba (lásd fenti megjegyzés)
  var SECURITY_FIELDS = [
    'pinHash', 'pinEnabled', 'biometricEnabled', 'webauthnCredentialId',
    'biometricOnStart', 'biometricOnAutoLock', 'biometricOnPayroll'
  ];

  // ── Terv 8. pont (kockázat: "State mérete") ──────────────────────────
  // A Firestore dokumentum-limit 1 MiB. Ha a state JSON ezt megközelíti,
  // gzip (CompressionStream) + base64 tömörítéssel mentjük, és a
  // `compressed: true` mezővel jelöljük, hogy load()-nál vissza kell
  // fejteni. Ha a CompressionStream API nem elérhető (régi WebView),
  // tömörítés nélkül mentünk tovább, de figyelmeztetünk a konzolon.
  var COMPRESS_THRESHOLD_BYTES = 700 * 1024; // ~700 KB — biztonsági ráhagyás az 1 MiB előtt

  function _bufToBase64(buf) {
    var bytes = new Uint8Array(buf);
    var chunk = 0x8000, binary = '';
    for (var i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }
  function _base64ToBuf(b64) {
    var binary = atob(b64);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }
  async function _gzipCompress(str) {
    var enc = new TextEncoder().encode(str);
    var cs = new CompressionStream('gzip');
    var writer = cs.writable.getWriter();
    writer.write(enc);
    writer.close();
    var buf = await new Response(cs.readable).arrayBuffer();
    return _bufToBase64(buf);
  }
  async function _gzipDecompress(b64) {
    var buf = _base64ToBuf(b64);
    var ds = new DecompressionStream('gzip');
    var writer = ds.writable.getWriter();
    writer.write(new Uint8Array(buf));
    writer.close();
    var outBuf = await new Response(ds.readable).arrayBuffer();
    return new TextDecoder().decode(outBuf);
  }

  // Közös payload-építő a save()-hez és migrateFromDrive()-hoz: kiszűri a
  // biztonsági mezőket, és szükség esetén tömöríti a state JSON-t.
  async function _buildCloudPayload(stateObj, extra) {
    var safe = _stripSecurityFields(stateObj);
    var now = Date.now();
    if (safe && typeof safe === 'object') safe.lastSaved = now;
    var stateJson = JSON.stringify(safe);
    var payload = Object.assign({
      lastSaved: now,
      rev: now, // monoton növekvő, eszközök közti LWW-hez
      personalNr: stateObj.workerPersonalNr || '',
      appVersion: (window.CHRONOS_APP_VERSION || window.APP_VERSION || ''),
      schemaVersion: SCHEMA_VERSION
    }, extra || {});
    var byteLen = new TextEncoder().encode(stateJson).length;
    if (byteLen > COMPRESS_THRESHOLD_BYTES && typeof CompressionStream !== 'undefined') {
      try {
        payload.stateJson = await _gzipCompress(stateJson);
        payload.compressed = true;
        console.log('Chronos Cloud: state tömörítve mentve (' + byteLen + ' byte → ~' + payload.stateJson.length + ' byte base64).');
      } catch (ce) {
        console.warn('Chronos Cloud: tömörítés sikertelen, tömörítetlenül mentünk:', ce);
        payload.stateJson = stateJson;
        payload.compressed = false;
      }
    } else {
      payload.stateJson = stateJson;
      payload.compressed = false;
      if (byteLen > COMPRESS_THRESHOLD_BYTES) {
        console.warn('Chronos Cloud: a state mérete (' + byteLen + ' byte) meghaladja a tömörítési küszöböt, de a CompressionStream API nem elérhető ezen a platformon.');
      }
    }
    return payload;
  }

  var _app = null, _auth = null, _db = null;
  var _authReady = false;
  var _authCallbacks = [];
  var _currentUser = null;

  function _isConfigured() {
    return !!(FIREBASE_CONFIG.apiKey && FIREBASE_CONFIG.apiKey.indexOf('PLACEHOLDER') === -1);
  }

  function _stripSecurityFields(stateObj) {
    var safe = Object.assign({}, stateObj);
    SECURITY_FIELDS.forEach(function(k) { delete safe[k]; });
    return safe;
  }

  // ── Fázis 3 (terv): Google + Apple bejelentkezés ──────────────────────
  // signInWithPopup asztali/Android böngészőben és Capacitor WebView-ban
  // jól működik. iOS Safari-n a popup gyakran blokkolva van (harmadik
  // féltől függő ablak-korlátozások) — ott signInWithRedirect a
  // megbízhatóbb, de ahhoz kell a getRedirectResult() hívás induláskor,
  // hogy a visszatérés után lezáruljon a bejelentkezés.
  function _isIOSSafari() {
    var ua = navigator.userAgent || '';
    var isIOS = /iPad|iPhone|iPod/.test(ua) && !window.MSStream;
    var isSafari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|Android/.test(ua);
    return isIOS && isSafari;
  }
  function _googleProvider() { return new GoogleAuthProvider(); }
  function _appleProvider() {
    var p = new OAuthProvider('apple.com');
    p.addScope('email');
    p.addScope('name');
    return p;
  }
  // ── Natív (Capacitor APK) Google belépés ─────────────────────────────
  // Az Android WebView-ban (origin: https://app) a signInWithPopup /
  // signInWithRedirect NEM működik: a popup a külső Chrome-ba kerül, ahol a
  // firebaseapp.com/__/auth/handler már nem éri el az appot
  // ("The requested action is invalid."). Ezért APK-ban a natív
  // @capacitor-firebase/authentication plugin kéri el a Google ID tokent
  // (skipNativeAuth), és a web SDK signInWithCredential-lel lépteti be.
  function _isNativeApp() {
    try {
      return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' &&
                window.Capacitor.isNativePlatform());
    } catch (e) { return false; }
  }
  // Bundler nélkül (sima <script>) a Capacitor.Plugins.<név> csak akkor létezik,
  // ha valaki meghívta a registerPlugin('<név>')-t — az npm csomag JS-e ezt
  // csinálná, de itt nem töltődik be. Ezért közvetlenül mi regisztráljuk:
  // a proxy a natív pluginra köt (ha az APK-ban benne van).
  var _faPlugin = null;
  function _nativeAuthPlugin() {
    if (_faPlugin) return _faPlugin;
    var C = window.Capacitor;
    if (!C) return null;
    if (C.Plugins && C.Plugins.FirebaseAuthentication) {
      _faPlugin = C.Plugins.FirebaseAuthentication;
      return _faPlugin;
    }
    if (typeof C.registerPlugin === 'function') {
      try { _faPlugin = C.registerPlugin('FirebaseAuthentication'); } catch (e) {
        console.warn('Chronos Cloud: registerPlugin hiba:', e);
      }
    }
    return _faPlugin;
  }
  function _authError(code, msg) {
    var e = new Error(msg || code);
    e.code = code;
    e.nativeDetail = code + (msg && msg !== code ? ' – ' + msg : '');
    return e;
  }
  async function _nativeGoogleSignIn() {
    var FA = _nativeAuthPlugin();
    if (!FA) throw _authError('auth/native-plugin-missing',
      'a FirebaseAuthentication plugin nincs az APK-ban (npm install + npx cap sync + új build kell)');
    var res;
    try {
      res = await FA.signInWithGoogle({ skipNativeAuth: true });
    } catch (e) {
      console.warn('Chronos Cloud: natív Google belépés hiba:', e);
      // A "cancel" (pl. 12501) gyakran rossz/hiányzó SHA-1 vagy régi
      // google-services.json jele is, ezért NEM nyeljük el némán:
      // a nyers hibakód megjelenik a hibaüzenetben.
      var det = 'Google natív: ' + ((e && e.code) ? e.code + ' ' : '') + ((e && e.message) || e);
      var ne = _authError('auth/native-google-failed', det);
      ne.nativeDetail = det;
      throw ne;
    }
    var idToken = res && res.credential && res.credential.idToken;
    var accessToken = res && res.credential && res.credential.accessToken;
    if (!idToken) throw _authError('auth/missing-id-token', 'A natív Google belépés nem adott ID tokent.');
    var cred = GoogleAuthProvider.credential(idToken, accessToken || undefined);
    var uc = await signInWithCredential(_auth, cred);
    return uc.user;
  }
  // Apple belépés APK-ban nem támogatott (popup-alapú) — a gombokat elrejtjük
  if (_isNativeApp()) {
    try {
      var _st = document.createElement('style');
      _st.textContent = '#obAppleBtn, #acctAppleBtn { display: none !important; }';
      (document.head || document.documentElement).appendChild(_st);
    } catch (e) {}
  }

  async function _signInWithProvider(provider) {
    if (!_auth) throw new Error('Chronos Cloud nincs beállítva (hiányzó Firebase config).');
    if (_isNativeApp()) {
      if (provider && provider.providerId === 'google.com') return await _nativeGoogleSignIn();
      throw _authError('auth/operation-not-supported-in-this-environment',
        'Ez a belépési mód az APK-ban nem támogatott.');
    }
    if (_isIOSSafari()) {
      // Redirect módban a visszatérés után az onAuthStateChanged +
      // getRedirectResult (lásd init blokk) zárja le a folyamatot; itt
      // magát a navigálást indítjuk el, a hívó Promise csak eddig fut.
      await signInWithRedirect(_auth, provider);
      return null;
    }
    var cred = await signInWithPopup(_auth, provider);
    return cred.user;
  }

  if (_isConfigured()) {
    try {
      _app = initializeApp(FIREBASE_CONFIG);
      _auth = getAuth(_app);
      setPersistence(_auth, browserLocalPersistence).catch(function(e) {
        console.warn('Chronos Cloud: persistence beállítás sikertelen:', e);
      });
      _db = initializeFirestore(_app, {
        localCache: persistentLocalCache({ tabManager: persistentSingleTabManager({}) })
      });
      onAuthStateChanged(_auth, function(user) {
        _currentUser = user;
        _authReady = true;
        console.log('Chronos Cloud: auth', user ? ('uid=' + user.uid) : 'null');
        // Bejelentkezés után a várakozó mentés azonnal menjen ki
        if (user && _pendingState) {
          _doSave();
        }
        _authCallbacks.forEach(function(cb) {
          try { cb(user); } catch(e) { console.warn('Chronos Cloud auth callback hiba:', e); }
        });
      });
      // iOS Safari redirect-visszatérés lezárása — ha a signInWithRedirect
      // után jövünk vissza, ez adja vissza a user-t (az onAuthStateChanged
      // amúgy is lefut, ez csak a hibák naplózásához kell).
      if (!_isNativeApp()) {
        getRedirectResult(_auth).catch(function(e) {
          console.warn('Chronos Cloud: redirect bejelentkezés hiba:', e);
        });
      }
    } catch(e) {
      console.warn('Chronos Cloud init hiba:', e);
    }
  } else {
    console.log('Chronos Cloud: FIREBASE_CONFIG még nincs kitöltve — a felhő-backend inaktív.');
  }

  var _saveTimer = null;
  var _saving = false;
  var _pendingState = null;

  async function _doSave() {
    if (_saving || !_pendingState || !_db) return;
    if (!_currentUser) {
      // Auth még nem kész — a state bent marad _pendingState-ben,
      // onAuthStateChanged után újra próbáljuk.
      console.log('Chronos Cloud: mentés vár auth-ra…');
      return;
    }
    _saving = true;
    var toSave = _pendingState;
    _pendingState = null;
    try {
      // Mindig friss timestamp a felhőbe
      if (toSave && typeof toSave === 'object') {
        toSave.lastSaved = Date.now();
      }
      var payload = await _buildCloudPayload(toSave);
      // merge: false helyett merge:true — de a stateJson teljes cseréje kell
      await setDoc(doc(_db, 'chronos_users', _currentUser.uid), payload, { merge: true });
      console.log('Chronos Cloud: mentve uid=' + _currentUser.uid + ' keys=' + Object.keys(toSave.schedules || {}).length);
    } catch(e) {
      console.warn('Chronos Cloud mentési hiba:', e);
      // Hiba esetén tegyük vissza, hogy később újra próbálhassuk
      if (!_pendingState) _pendingState = toSave;
    } finally {
      _saving = false;
      if (_pendingState) _doSave();
    }
  }

  window.ChronosCloud = {
    backend: 'firebase',

    isConfigured: function() { return _isConfigured(); },
    isLoggedIn: function() { return !!_currentUser; },
    isAuthReady: function() { return _authReady; },
    currentUser: function() { return _currentUser; },

    /** Promise: resolve when first onAuthStateChanged has fired */
    whenReady: function() {
      if (_authReady) return Promise.resolve(_currentUser);
      return new Promise(function(resolve) {
        _authCallbacks.push(function(user) {
          resolve(user);
        });
      });
    },

    onAuthChange: function(cb) {
      _authCallbacks.push(cb);
      if (_authReady) {
        try { cb(_currentUser); } catch(e) {}
      }
    },

    register: async function(email, password) {
      if (!_auth) throw new Error('Chronos Cloud nincs beállítva (hiányzó Firebase config).');
      var cred = await createUserWithEmailAndPassword(_auth, email, password);
      try { await sendEmailVerification(cred.user); } catch(e) {
        console.warn('Chronos Cloud: email-megerősítés küldése sikertelen:', e);
      }
      return cred.user;
    },

    login: async function(email, password) {
      if (!_auth) throw new Error('Chronos Cloud nincs beállítva (hiányzó Firebase config).');
      var cred = await signInWithEmailAndPassword(_auth, email, password);
      return cred.user;
    },

    loginWithGoogle: async function() {
      return await _signInWithProvider(_googleProvider());
    },

    loginWithApple: async function() {
      return await _signInWithProvider(_appleProvider());
    },

    logout: async function() {
      if (!_auth) return;
      await signOut(_auth);
    },

    resetPassword: async function(email) {
      if (!_auth) throw new Error('Chronos Cloud nincs beállítva (hiányzó Firebase config).');
      await sendPasswordResetEmail(_auth, email);
    },

    // Mentés — debounce ~3 mp, ugyanaz a queue-mintázat mint a Drive-nál
    save: function(stateObj) {
      if (!_db || !_currentUser) return;
      _pendingState = stateObj;
      if (_saveTimer) clearTimeout(_saveTimer);
      _saveTimer = setTimeout(function() {
        if (_saving) return;
        _doSave();
      }, 400);
    },

    // Azonnali mentés, a debounce kihagyásával. Akkor hívjuk, amikor az
    // app háttérbe kerül/bezáródik (lásd lejjebb a visibilitychange/
    // pagehide/Capacitor 'pause' figyelőket), vagy amikor betöltésnél
    // kiderül, hogy a lokális state frissebb, mint ami a felhőben van
    // (lásd loadStateFromCloud) — enélkül egy 3 mp-es debounce-ablakon
    // belüli bezárás elveszítheti a legutóbbi, még el nem küldött mentést.
    flush: function(stateObj) {
      if (stateObj) _pendingState = stateObj;
      if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
      if (!_pendingState || !_db || !_currentUser) return Promise.resolve();
      return _doSave();
    },

    // Betöltés — a bejelentkezett felhasználó chronos_users/{uid} dokumentuma
    load: async function() {
      if (!_db || !_currentUser) return null;
      try {
        var ref = doc(_db, 'chronos_users', _currentUser.uid);
        // Mindig a szerverről — a persistent cache elavult APK/PWA adatot adhat
        var snap;
        try {
          snap = await getDocFromServer(ref);
        } catch (serverErr) {
          console.warn('Chronos Cloud: getDocFromServer failed, fallback cache', serverErr);
          snap = await getDoc(ref);
        }
        if (!snap.exists()) return null;
        var data = snap.data();
        if (!data || !data.stateJson) return null;
        var raw = data.compressed ? await _gzipDecompress(data.stateJson) : data.stateJson;
        var parsed = JSON.parse(raw);
        // lastSaved: dokumentum-szintű mező az elsődleges (nem a stateJson belseje)
        var docTs = data.lastSaved;
        if (docTs && typeof docTs.toMillis === 'function') docTs = docTs.toMillis();
        parsed.lastSaved = docTs || parsed.lastSaved || 0;
        parsed._cloudRev = data.rev || 0;
        console.log('Chronos Cloud: load ok uid=' + _currentUser.uid + ' lastSaved=' + parsed.lastSaved + ' sched=' + Object.keys(parsed.schedules||{}).length);
        return parsed;
      } catch(e) {
        console.warn('Chronos Cloud betöltési hiba:', e);
        return null;
      }
    },

    // Migráció: a helyi (esetleg Drive-ból korábban betöltött) state
    // feltöltése Firestore-ba, DE csak ha még nincs ott semmi — így nem
    // írjuk felül más eszközök esetleg újabb felhő-mentését.
    migrateFromDrive: async function(localState) {
      if (!_db || !_currentUser || !localState) return false;
      try {
        var existing = await getDoc(doc(_db, 'chronos_users', _currentUser.uid));
        if (existing.exists()) return false;
        var payload = await _buildCloudPayload(localState, { migratedFrom: 'drive' });
        await setDoc(doc(_db, 'chronos_users', _currentUser.uid), payload);
        console.log('Chronos Cloud: sikeres migráció a felhőbe.');
        return true;
      } catch(e) {
        console.warn('Chronos Cloud migrációs hiba:', e);
        return false;
      }
    },

    // Fiók törlése: Firestore-dokumentum + Auth-felhasználó törlése (GDPR/Play Store).
    // Ha a Firebase 'requires-recent-login' hibát ad (régi bejelentkezés),
    // a hívó félnek ki-/bejelentkezésre kell kérnie a felhasználót, majd újra hívni.
    deleteAccount: async function() {
      if (!_db || !_auth || !_currentUser) throw new Error('Chronos Cloud: nincs bejelentkezve.');
      var uid = _currentUser.uid;
      try {
        await deleteDoc(doc(_db, 'chronos_users', uid));
      } catch(e) {
        console.warn('Chronos Cloud: Firestore-dokumentum törlési hiba (folytatjuk az Auth törléssel):', e);
      }
      await deleteUser(_currentUser);
    }
  };

  // ── Azonnali mentés kényszerítése háttérbe kerüléskor/bezáráskor ──────
  // A save() 3 mp-es debounce-ot használ; enélkül egy gyors szerkesztés
  // (pl. egy műszak beírása) utáni azonnali app-bezárás/háttérbe kerülés
  // elveszítheti a mentést, és a következő indításkor a (régebbi) felhő-
  // állapot töltődik be helyette. A visibilitychange/pagehide a böngészőt/
  // PWA-t fedi le; a Capacitor 'pause' esemény az APK-ban megbízhatóbb,
  // mint a WebView visibilitychange-e.
  function _chronosCloudFlushOnHide() {
    try { window.ChronosCloud.flush(); } catch(e) {}
  }
  document.addEventListener('visibilitychange', function() {
    if (document.hidden) _chronosCloudFlushOnHide();
  });
  window.addEventListener('pagehide', _chronosCloudFlushOnHide);
  window.addEventListener('beforeunload', _chronosCloudFlushOnHide);
  try {
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App &&
        typeof window.Capacitor.Plugins.App.addListener === 'function') {
      window.Capacitor.Plugins.App.addListener('pause', _chronosCloudFlushOnHide);
    }
  } catch(e) {}
