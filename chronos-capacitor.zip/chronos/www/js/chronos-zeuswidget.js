/* Chronos ZeusWidget — ZEUS Monatsjournal import (Fázis 1)
   window.openZeusImport, ZeusWidget, ...
*/
'use strict';

// ── PDF.JS WORKER ── (workerSrc Chronos által már beállítva, itt kihagyjuk)

// ── FORDÍTÁSOK ─────────────────────────────────────────────────────────────────
const ZTR = {
  hu: {
    appTitle: 'ZEUS Olvasó',
    appSubtitle: 'MOJO+TASU elszámolás elemző',
    dropTitle: 'ZEUS PDF feltöltése',
    dropDesc: 'Húzd ide a havi elszámolást<br>Több hónap egyszerre is betölthető',
    dropHint: 'Fájl kiválasztása',
    statusIdle: 'Várakozás PDF feltöltésre...',
    statusBusy: (name, i, n) => `Feldolgozás: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `${n} PDF feldolgozása...`,
    statusOk: (n) => `✓ ${n} hónap sikeresen betöltve`,
    statusErr: (ok, err) => `${ok} sikerült, ${err} sikertelen – ellenőrizd a fájlt`,
    monthCount: (n) => `${n} hónap`,
    emptyText: 'Töltsd fel a ZEUS rendszerből<br>exportált havi elszámolást.<br><br>Januártól–Decemberig,<br>akár egyszerre több hónapot.',
    notZeusFormat: 'Nem ZEUS formátum vagy nem olvasható',
    // Kártya fejlécek
    labelDolgozott: 'Dolgozott', labelElvart: 'Elvárt', labelBrutto: 'Bruttó', labelZeitkonto: 'Zeitkonto',
    unitBrArb: 'BrArb óra', unitSoll: 'Soll óra', unitBrutto: 'Brutto óra', unitSaldo: 'egyenleg (Saldo)',
    potlekok: 'Pótlékok összesítve',
    napok: (n) => `Napok · ${n} bejegyzés`,
    legendURL: 'URL', legendKRA: 'KRA', legendNT: 'NT',
    // Pótlék nevek
    potUe25: 'Túlóra pótlék', potN25: 'Éjszakai pótlék', potN40: 'Éjszakai emelt', potSo50: 'Vasárnap/Ünnep', potFt125: 'Ünnepnapi pótlék',
    // Tag-ek
    tagVacation: (e, f, n) => f > 0 && e > 0 ? `${e} egész + ${f}×½ = ${n} nap szabadság` : f > 0 ? `${f}×½ nap = ${n} nap szabadság` : `${e} nap szabadság`,
    tagZA: (e, f, n) => f > 0 && e > 0 ? `${e} egész + ${f}×½ = ${n} nap ZA` : f > 0 ? `${f}×½ nap = ${n} nap ZA` : `${e} nap ZA`,
    tagKrank: (n) => `${n} betegnap`,
    tagNight: (n) => `${n} éjszaka`,
    tagSunday: (n) => `${n} vasárnap`,
    // Napnév térkép
    dayNames: {Mo:'H',Di:'K',Mi:'Sze',Do:'Cs',Fr:'P',Sa:'Szo',So:'V'},
    // Műszak nevek
    shifts: {'320':'Reggel','321':'Délután','322':'Éjszaka','323':'Reggel+','324':'Délután+','325':'Éjszaka+','326':'Reggel (V)','327':'Délután (V)','328':'Éjszaka (V)','71':'Délután Szo','72':'Éjszaka Szo','73':'Reggel V+','74':'Délután V+','75':'Éjszaka V+','76':'Reggel V','77':'Délután Ünn','78':'Éjszaka Ünn','1000':'Ünnepnap','5040':'Szabad','5041':'Szabad (V)'},
    ciTitle: 'Chronos import',
    ciCalLabel: '📅 Naptár – műszakok beírása',
    ciCalHint: 'Reggel / Délután / Éjszaka + Szabadság + Beteg',
    ciSalLabel: '💰 Bér – Feststunden frissítése',
    ciSalHint: 'Elvárt Soll-Stunden → Feststunden mező',
    ciClose: 'Bezárás',
    ciImport: '✅ Importálás Chronosba',
    ciDone: (n) => `✅ ${n} nap importálva`,
    ciErrSelect: '⚠️ Legalább egy opciót jelölj be!',
    ciErrNotAvail: '❌ Chronos nem elérhető.',
    ismeretlen: 'Ismeretlen',
  },
  de: {
    appTitle: 'ZEUS Leser',
    appSubtitle: 'MOJO+TASU Abrechnung Analyse',
    dropTitle: 'ZEUS PDF hochladen',
    dropDesc: 'Ziehe die monatliche Abrechnung hierher<br>Mehrere Monate gleichzeitig möglich',
    dropHint: 'Datei auswählen',
    statusIdle: 'Warte auf PDF-Upload...',
    statusBusy: (name, i, n) => `Verarbeitung: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `${n} PDF werden verarbeitet...`,
    statusOk: (n) => `✓ ${n} Monate erfolgreich geladen`,
    statusErr: (ok, err) => `${ok} erfolgreich, ${err} fehlgeschlagen – Datei prüfen`,
    monthCount: (n) => `${n} Monate`,
    emptyText: 'Lade die aus dem ZEUS-System<br>exportierte Monatsabrechnung hoch.<br><br>Von Januar bis Dezember,<br>auch mehrere Monate gleichzeitig.',
    notZeusFormat: 'Kein ZEUS-Format oder nicht lesbar',
    labelDolgozott: 'Gearbeitet', labelElvart: 'Soll', labelBrutto: 'Brutto', labelZeitkonto: 'Zeitkonto',
    unitBrArb: 'BrArb Std.', unitSoll: 'Soll Std.', unitBrutto: 'Brutto Std.', unitSaldo: 'Saldo',
    potlekok: 'Zuschläge gesamt',
    napok: (n) => `Tage · ${n} Einträge`,
    legendURL: 'URL', legendKRA: 'KRA', legendNT: 'NT',
    potUe25: 'Überstundenzuschlag', potN25: 'Nachtzuschlag', potN40: 'Nachtzuschlag erhöht', potSo50: 'Sonntag/Feiertag', potFt125: 'Feiertagszuschlag 125%',
    tagVacation: (e, f, n) => f > 0 && e > 0 ? `${e} ganz + ${f}×½ = ${n} Tag(e) Urlaub` : f > 0 ? `${f}×½ Tag(e) = ${n} Urlaub` : `${e} Tag(e) Urlaub`,
    tagZA: (e, f, n) => f > 0 && e > 0 ? `${e} ganz + ${f}×½ = ${n} Tag(e) ZA` : f > 0 ? `${f}×½ Tag(e) = ${n} ZA` : `${e} Tag(e) ZA`,
    tagKrank: (n) => `${n} Krankentag(e)`,
    tagNight: (n) => `${n} Nacht`,
    tagSunday: (n) => `${n} Sonntag`,
    dayNames: {Mo:'Mo',Di:'Di',Mi:'Mi',Do:'Do',Fr:'Fr',Sa:'Sa',So:'So'},
    shifts: {'320':'Früh','321':'Spät','322':'Nacht','323':'Früh+','324':'Spät+','325':'Nacht+','326':'Früh (So)','327':'Spät (So)','328':'Nacht (So)','71':'Spät Sa','72':'Nacht Sa','73':'Früh So+','74':'Spät So+','75':'Nacht So+','76':'Früh So','77':'Spät Fei','78':'Nacht Fei','1000':'Feiertag','5040':'Frei','5041':'Frei (So)'},
    ciTitle: 'Chronos Import',
    ciCalLabel: '📅 Kalender – Schichten eintragen',
    ciCalHint: 'Früh / Spät / Nacht + Urlaub + Krank',
    ciSalLabel: '💰 Lohn – Feststunden aktualisieren',
    ciSalHint: 'Soll-Stunden → Feststunden-Feld',
    ciClose: 'Schließen',
    ciImport: '✅ In Chronos importieren',
    ciDone: (n) => `✅ ${n} Tage importiert`,
    ciErrSelect: '⚠️ Bitte mindestens eine Option wählen!',
    ciErrNotAvail: '❌ Chronos nicht verfügbar.',
    ismeretlen: 'Unbekannt',
  },
  en: {
    appTitle: 'ZEUS Reader',
    appSubtitle: 'MOJO+TASU payroll analyser',
    dropTitle: 'Upload ZEUS PDF',
    dropDesc: 'Drag the monthly statement here<br>Multiple months can be loaded at once',
    dropHint: 'Select file',
    statusIdle: 'Waiting for PDF upload...',
    statusBusy: (name, i, n) => `Processing: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Processing ${n} PDF(s)...`,
    statusOk: (n) => `✓ ${n} month(s) loaded successfully`,
    statusErr: (ok, err) => `${ok} succeeded, ${err} failed – check the file`,
    monthCount: (n) => `${n} month(s)`,
    emptyText: 'Upload the monthly statement<br>exported from the ZEUS system.<br><br>From January to December,<br>multiple months at once.',
    notZeusFormat: 'Not ZEUS format or unreadable',
    labelDolgozott: 'Worked', labelElvart: 'Expected', labelBrutto: 'Gross', labelZeitkonto: 'Time account',
    unitBrArb: 'BrArb hrs', unitSoll: 'Soll hrs', unitBrutto: 'Gross hrs', unitSaldo: 'balance (Saldo)',
    potlekok: 'Surcharges total',
    napok: (n) => `Days · ${n} entries`,
    legendURL: 'VAC', legendKRA: 'SICK', legendNT: 'NT',
    potUe25: 'Overtime surcharge', potN25: 'Night surcharge', potN40: 'Night surcharge+', potSo50: 'Sunday/Holiday', potFt125: 'Holiday surcharge 125%',
    tagVacation: (e, f, n) => f > 0 && e > 0 ? `${e} full + ${f}×½ = ${n} day(s) vacation` : f > 0 ? `${f}×½ day(s) vacation` : `${e} day(s) vacation`,
    tagZA: (e, f, n) => f > 0 && e > 0 ? `${e} full + ${f}×½ = ${n} day(s) ZA` : f > 0 ? `${f}×½ day(s) ZA` : `${e} day(s) ZA`,
    tagKrank: (n) => `${n} sick day(s)`,
    tagNight: (n) => `${n} night(s)`,
    tagSunday: (n) => `${n} Sunday(s)`,
    dayNames: {Mo:'Mo',Di:'Tu',Mi:'We',Do:'Th',Fr:'Fr',Sa:'Sa',So:'Su'},
    shifts: {'320':'Morning','321':'Afternoon','322':'Night','323':'Morning+','324':'Afternoon+','325':'Night+','326':'Morning (Su)','327':'Afternoon (Su)','328':'Night (Su)','71':'Afternoon Sa','72':'Night Sa','73':'Morning Su+','74':'Afternoon Su+','75':'Night Su+','76':'Morning Su','77':'Afternoon Hol','78':'Night Hol','1000':'Holiday','5040':'Day off','5041':'Day off (Su)'},
    ciTitle: 'Chronos Import',
    ciCalLabel: '📅 Calendar – add shifts',
    ciCalHint: 'Morning / Afternoon / Night + Vacation + Sick',
    ciSalLabel: '💰 Salary – update Feststunden',
    ciSalHint: 'Target Soll hours → Feststunden field',
    ciClose: 'Close',
    ciImport: '✅ Import to Chronos',
    ciDone: (n) => `✅ ${n} days imported`,
    ciErrSelect: '⚠️ Please select at least one option!',
    ciErrNotAvail: '❌ Chronos not available.',
    ismeretlen: 'Unknown',
  },
  ro: {
    appTitle: 'Cititor ZEUS',
    appSubtitle: 'Analizor MOJO+TASU',
    dropTitle: 'Încarcă PDF ZEUS',
    dropDesc: 'Trage decontul lunar aici<br>Mai multe luni simultan posibil',
    dropHint: 'Selectează fișier',
    statusIdle: 'Așteptând încărcare PDF...',
    statusBusy: (name, i, n) => `Procesare: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Se procesează ${n} PDF...`,
    statusOk: (n) => `✓ ${n} luni încărcate cu succes`,
    statusErr: (ok, err) => `${ok} reușit, ${err} eșuat – verifică fișierul`,
    monthCount: (n) => `${n} luni`,
    emptyText: 'Încarcă decontul lunar<br>exportat din sistemul ZEUS.<br><br>De la Ianuarie la Decembrie,<br>mai multe luni simultan.',
    notZeusFormat: 'Nu este format ZEUS sau nu poate fi citit',
    labelDolgozott: 'Lucrat', labelElvart: 'Așteptat', labelBrutto: 'Brut', labelZeitkonto: 'Cont timp',
    unitBrArb: 'ore BrArb', unitSoll: 'ore Soll', unitBrutto: 'ore brut', unitSaldo: 'sold',
    potlekok: 'Sporuri totale',
    napok: (n) => `Zile · ${n} înregistrări`,
    legendURL: 'CON', legendKRA: 'BOL', legendNT: 'NT',
    potUe25: 'Spor ore suplimentare', potN25: 'Spor nocturn', potN40: 'Spor nocturn+', potSo50: 'Duminică/Sărbătoare', potFt125: 'Spor sărbătoare 125%',
    tagVacation: (e, f, n) => `${n} zi(le) concediu`,
    tagZA: (e, f, n) => `${n} zi(le) ZA`,
    tagKrank: (n) => `${n} zi(le) boală`,
    tagNight: (n) => `${n} noapte(ți)`,
    tagSunday: (n) => `${n} duminică`,
    dayNames: {Mo:'Lu',Di:'Ma',Mi:'Mi',Do:'Jo',Fr:'Vi',Sa:'Sâ',So:'Du'},
    shifts: {'320':'Dimineață','321':'Dupăm.','322':'Noapte','323':'Dimineață+','324':'Dupăm.+','325':'Noapte+','326':'Dim. (Du)','327':'Dup. (Du)','328':'Noapte (Du)','71':'Dup. Sâ','72':'Noapte Sâ','73':'Dim. Du+','74':'Dup. Du+','75':'Noapte Du+','76':'Dim. Du','77':'Dup. Săr','78':'Noapte Săr','1000':'Sărbătoare','5040':'Liber','5041':'Liber (Du)'},
    ciTitle: 'Import Chronos',
    ciCalLabel: '📅 Calendar – adaugă ture',
    ciCalHint: 'Dimineață / După-amiază / Noapte + Concediu + Boală',
    ciSalLabel: '💰 Salariu – actualizare Feststunden',
    ciSalHint: 'Ore Soll → câmpul Feststunden',
    ciClose: 'Închide',
    ciImport: '✅ Importă în Chronos',
    ciDone: (n) => `✅ ${n} zile importate`,
    ciErrSelect: '⚠️ Selectați cel puțin o opțiune!',
    ciErrNotAvail: '❌ Chronos indisponibil.',
    ismeretlen: 'Necunoscut',
  },
  tr: {
    appTitle: 'ZEUS Okuyucu',
    appSubtitle: 'MOJO+TASU bordro analizörü',
    dropTitle: 'ZEUS PDF yükle',
    dropDesc: 'Aylık hesabı buraya sürükle<br>Birden fazla ay aynı anda yüklenebilir',
    dropHint: 'Dosya seç',
    statusIdle: 'PDF yüklenmesi bekleniyor...',
    statusBusy: (name, i, n) => `İşleniyor: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `${n} PDF işleniyor...`,
    statusOk: (n) => `✓ ${n} ay başarıyla yüklendi`,
    statusErr: (ok, err) => `${ok} başarılı, ${err} başarısız – dosyayı kontrol et`,
    monthCount: (n) => `${n} ay`,
    emptyText: 'ZEUS sisteminden dışa aktarılan<br>aylık hesabı yükle.<br><br>Ocak\'tan Aralık\'a,<br>birden fazla ay aynı anda.',
    notZeusFormat: 'ZEUS formatı değil veya okunamıyor',
    labelDolgozott: 'Çalışılan', labelElvart: 'Beklenen', labelBrutto: 'Brüt', labelZeitkonto: 'Zaman hesabı',
    unitBrArb: 'BrArb sa.', unitSoll: 'Soll sa.', unitBrutto: 'Brüt sa.', unitSaldo: 'bakiye',
    potlekok: 'Ek ücretler toplam',
    napok: (n) => `Günler · ${n} kayıt`,
    legendURL: 'İZİN', legendKRA: 'HAST', legendNT: 'GE',
    potUe25: 'Fazla mesai', potN25: 'Gece zammı', potN40: 'Gece zammı+', potSo50: 'Pazar/Tatil', potFt125: 'Tatil primi 125%',
    tagVacation: (e, f, n) => `${n} gün izin`,
    tagZA: (e, f, n) => `${n} gün ZA`,
    tagKrank: (n) => `${n} hastalık günü`,
    tagNight: (n) => `${n} gece`,
    tagSunday: (n) => `${n} pazar`,
    dayNames: {Mo:'Pzt',Di:'Sal',Mi:'Çar',Do:'Per',Fr:'Cum',Sa:'Cmt',So:'Paz'},
    shifts: {'320':'Sabah','321':'Öğleden s.','322':'Gece','323':'Sabah+','324':'Öğleden s.+','325':'Gece+','326':'Sabah (Paz)','327':'Öğle (Paz)','328':'Gece (Paz)','71':'Öğle Cmt','72':'Gece Cmt','73':'Sab Paz+','74':'Öğle Paz+','75':'Gece Paz+','76':'Sab Paz','77':'Öğle Tat','78':'Gece Tat','1000':'Tatil','5040':'Serbest','5041':'Serbest (Paz)'},
    ciTitle: 'Chronos İçe Aktarma',
    ciCalLabel: '📅 Takvim – vardiyaları ekle',
    ciCalHint: 'Sabah / Öğleden Sonra / Gece + İzin + Hasta',
    ciSalLabel: '💰 Maaş – Feststunden güncelle',
    ciSalHint: 'Hedef Soll saatler → Feststunden alanı',
    ciClose: 'Kapat',
    ciImport: "✅ Chronos'a aktar",
    ciDone: (n) => `✅ ${n} gün aktarıldı`,
    ciErrSelect: '⚠️ En az bir seçenek işaretleyin!',
    ciErrNotAvail: '❌ Chronos mevcut değil.',
    ismeretlen: 'Bilinmiyor',
  },
  el: {
    appTitle: 'ZEUS Αναγνώστης',
    appSubtitle: 'Αναλυτής MOJO+TASU',
    dropTitle: 'Ανέβασε PDF ZEUS',
    dropDesc: 'Σύρε την μηνιαία εκκαθάριση εδώ<br>Πολλοί μήνες ταυτόχρονα',
    dropHint: 'Επιλογή αρχείου',
    statusIdle: 'Αναμονή PDF...',
    statusBusy: (name, i, n) => `Επεξεργασία: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Επεξεργασία ${n} PDF...`,
    statusOk: (n) => `✓ ${n} μήνες φορτώθηκαν`,
    statusErr: (ok, err) => `${ok} επιτυχία, ${err} σφάλμα`,
    monthCount: (n) => `${n} μήνες`,
    emptyText: 'Ανέβασε την μηνιαία εκκαθάριση<br>από το σύστημα ZEUS.<br><br>Από Ιανουάριο έως Δεκέμβριο,<br>πολλοί μήνες ταυτόχρονα.',
    notZeusFormat: 'Δεν είναι μορφή ZEUS ή δεν διαβάζεται',
    labelDolgozott: 'Εργάστηκε', labelElvart: 'Αναμενόμενο', labelBrutto: 'Μικτό', labelZeitkonto: 'Χρόνος',
    unitBrArb: 'ώρες BrArb', unitSoll: 'ώρες Soll', unitBrutto: 'μικτές ώρες', unitSaldo: 'υπόλοιπο',
    potlekok: 'Επιδόματα σύνολο',
    napok: (n) => `Ημέρες · ${n} εγγραφές`,
    legendURL: 'ΑΔΕ', legendKRA: 'ΑΡΡ', legendNT: 'ΝΥΧ',
    potUe25: 'Υπερωρία', potN25: 'Νυχτερινό', potN40: 'Νυχτερινό+', potSo50: 'Κυριακή/Αργία', potFt125: 'Αργιεπίδομα 125%',
    tagVacation: (e, f, n) => `${n} ημέρα(ες) άδεια`,
    tagZA: (e, f, n) => `${n} ημέρα(ες) ZA`,
    tagKrank: (n) => `${n} ημέρα(ες) ασθένεια`,
    tagNight: (n) => `${n} νύχτα(ες)`,
    tagSunday: (n) => `${n} Κυριακή`,
    dayNames: {Mo:'Δε',Di:'Τρ',Mi:'Τε',Do:'Πε',Fr:'Πα',Sa:'Σα',So:'Κυ'},
    shifts: {'320':'Πρωί','321':'Απόγ.','322':'Νύχτα','323':'Πρωί+','324':'Απόγ.+','325':'Νύχτα+','326':'Πρωί (Κυ)','327':'Απόγ. (Κυ)','328':'Νύχτα (Κυ)','71':'Απόγ. Σα','72':'Νύχτα Σα','73':'Πρωί Κυ+','74':'Απόγ. Κυ+','75':'Νύχτα Κυ+','76':'Πρωί Κυ','77':'Απόγ. Αρ','78':'Νύχτα Αρ','1000':'Αργία','5040':'Ελεύθερο','5041':'Ελεύθ. (Κυ)'},
    ciTitle: 'Εισαγωγή Chronos',
    ciCalLabel: '📅 Ημερολόγιο – προσθήκη βαρδιών',
    ciCalHint: 'Πρωί / Απόγευμα / Νύχτα + Άδεια + Ασθένεια',
    ciSalLabel: '💰 Μισθός – ενημέρωση Feststunden',
    ciSalHint: 'Ώρες Soll → πεδίο Feststunden',
    ciClose: 'Κλείσιμο',
    ciImport: '✅ Εισαγωγή στο Chronos',
    ciDone: (n) => `✅ ${n} ημέρες εισήχθησαν`,
    ciErrSelect: '⚠️ Επιλέξτε τουλάχιστον μία επιλογή!',
    ciErrNotAvail: '❌ Το Chronos δεν είναι διαθέσιμο.',
    ismeretlen: 'Άγνωστο',
  },
  ru: {
    appTitle: 'ZEUS Читалка',
    appSubtitle: 'Анализатор MOJO+TASU',
    dropTitle: 'Загрузить PDF ZEUS',
    dropDesc: 'Перетащи месячный отчёт сюда<br>Можно несколько месяцев сразу',
    dropHint: 'Выбрать файл',
    statusIdle: 'Ожидание PDF...',
    statusBusy: (name, i, n) => `Обработка: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Обработка ${n} PDF...`,
    statusOk: (n) => `✓ ${n} месяц(ев) загружено`,
    statusErr: (ok, err) => `${ok} успешно, ${err} ошибка`,
    monthCount: (n) => `${n} месяц(ев)`,
    emptyText: 'Загрузи месячный отчёт<br>из системы ZEUS.<br><br>С января по декабрь,<br>несколько месяцев сразу.',
    notZeusFormat: 'Не формат ZEUS или нечитаемо',
    labelDolgozott: 'Отработано', labelElvart: 'Норма', labelBrutto: 'Брутто', labelZeitkonto: 'Учёт времени',
    unitBrArb: 'BrArb ч.', unitSoll: 'Soll ч.', unitBrutto: 'брутто ч.', unitSaldo: 'баланс',
    potlekok: 'Надбавки итого',
    napok: (n) => `Дни · ${n} записей`,
    legendURL: 'ОТП', legendKRA: 'БОЛ', legendNT: 'НОЧ',
    potUe25: 'Сверхурочные', potN25: 'Ночные', potN40: 'Ночные+', potSo50: 'Воскресенье/Праздник', potFt125: 'Праздничная надбавка 125%',
    tagVacation: (e, f, n) => `${n} день(дней) отпуск`,
    tagZA: (e, f, n) => `${n} день(дней) ZA`,
    tagKrank: (n) => `${n} больничный день`,
    tagNight: (n) => `${n} ночь(ей)`,
    tagSunday: (n) => `${n} воскресенье`,
    dayNames: {Mo:'Пн',Di:'Вт',Mi:'Ср',Do:'Чт',Fr:'Пт',Sa:'Сб',So:'Вс'},
    shifts: {'320':'Утро','321':'День','322':'Ночь','323':'Утро+','324':'День+','325':'Ночь+','326':'Утро (Вс)','327':'День (Вс)','328':'Ночь (Вс)','71':'День Сб','72':'Ночь Сб','73':'Утро Вс+','74':'День Вс+','75':'Ночь Вс+','76':'Утро Вс','77':'День Пр','78':'Ночь Пр','1000':'Праздник','5040':'Выходной','5041':'Вых. (Вс)'},
    ciTitle: 'Импорт в Chronos',
    ciCalLabel: '📅 Календарь – добавить смены',
    ciCalHint: 'Утро / День / Ночь + Отпуск + Больничный',
    ciSalLabel: '💰 Зарплата – обновить Feststunden',
    ciSalHint: 'Плановые часы Soll → поле Feststunden',
    ciClose: 'Закрыть',
    ciImport: '✅ Импортировать в Chronos',
    ciDone: (n) => `✅ ${n} дней импортировано`,
    ciErrSelect: '⚠️ Выберите хотя бы один параметр!',
    ciErrNotAvail: '❌ Chronos недоступен.',
    ismeretlen: 'Неизвестно',
  },
  uk: {
    appTitle: 'ZEUS Читач',
    appSubtitle: 'Аналізатор MOJO+TASU',
    dropTitle: 'Завантажити PDF ZEUS',
    dropDesc: 'Перетягни місячний звіт сюди<br>Кілька місяців одночасно',
    dropHint: 'Вибрати файл',
    statusIdle: 'Очікування PDF...',
    statusBusy: (name, i, n) => `Обробка: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Обробка ${n} PDF...`,
    statusOk: (n) => `✓ ${n} місяць(ів) завантажено`,
    statusErr: (ok, err) => `${ok} успішно, ${err} помилка`,
    monthCount: (n) => `${n} місяць(ів)`,
    emptyText: 'Завантаж місячний звіт<br>з системи ZEUS.<br><br>З січня по грудень,<br>кілька місяців одночасно.',
    notZeusFormat: 'Не формат ZEUS або нечитабельно',
    labelDolgozott: 'Відпрацьовано', labelElvart: 'Норма', labelBrutto: 'Брутто', labelZeitkonto: 'Облік часу',
    unitBrArb: 'BrArb год.', unitSoll: 'Soll год.', unitBrutto: 'брутто год.', unitSaldo: 'баланс',
    potlekok: 'Надбавки разом',
    napok: (n) => `Дні · ${n} записів`,
    legendURL: 'ВІД', legendKRA: 'ХВО', legendNT: 'НІЧ',
    potUe25: 'Понаднормові', potN25: 'Нічні', potN40: 'Нічні+', potSo50: 'Неділя/Свято', potFt125: 'Святковий доплата 125%',
    tagVacation: (e, f, n) => `${n} день(дні) відпустка`,
    tagZA: (e, f, n) => `${n} день(дні) ZA`,
    tagKrank: (n) => `${n} лікарняний день`,
    tagNight: (n) => `${n} ніч(ей)`,
    tagSunday: (n) => `${n} неділя`,
    dayNames: {Mo:'Пн',Di:'Вт',Mi:'Ср',Do:'Чт',Fr:'Пт',Sa:'Сб',So:'Нд'},
    shifts: {'320':'Ранок','321':'День','322':'Ніч','323':'Ранок+','324':'День+','325':'Ніч+','326':'Ранок (Нд)','327':'День (Нд)','328':'Ніч (Нд)','71':'День Сб','72':'Ніч Сб','73':'Ранок Нд+','74':'День Нд+','75':'Ніч Нд+','76':'Ранок Нд','77':'День Св','78':'Ніч Св','1000':'Свято','5040':'Вихідний','5041':'Вих. (Нд)'},
    ciTitle: 'Імпорт до Chronos',
    ciCalLabel: '📅 Календар – додати зміни',
    ciCalHint: 'Ранок / День / Ніч + Відпустка + Лікарняний',
    ciSalLabel: '💰 Зарплата – оновити Feststunden',
    ciSalHint: 'Планові години Soll → поле Feststunden',
    ciClose: 'Закрити',
    ciImport: '✅ Імпортувати до Chronos',
    ciDone: (n) => `✅ ${n} днів імпортовано`,
    ciErrSelect: '⚠️ Виберіть принаймні один параметр!',
    ciErrNotAvail: '❌ Chronos недоступний.',
    ismeretlen: 'Невідомо',
  },
  ar: {
    appTitle: 'قارئ ZEUS',
    appSubtitle: 'محلل MOJO+TASU',
    dropTitle: 'رفع PDF ZEUS',
    dropDesc: 'اسحب الكشف الشهري هنا<br>يمكن رفع عدة أشهر دفعة واحدة',
    dropHint: 'اختر ملفاً',
    statusIdle: 'بانتظار PDF...',
    statusBusy: (name, i, n) => `معالجة: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `جاري معالجة ${n} PDF...`,
    statusOk: (n) => `✓ تم تحميل ${n} شهر(اشهر)`,
    statusErr: (ok, err) => `${ok} نجح، ${err} فشل`,
    monthCount: (n) => `${n} شهر`,
    emptyText: 'ارفع الكشف الشهري<br>المصدَّر من نظام ZEUS.<br><br>من يناير إلى ديسمبر،<br>عدة أشهر دفعة واحدة.',
    notZeusFormat: 'ليس بتنسيق ZEUS أو لا يمكن قراءته',
    labelDolgozott: 'عمل', labelElvart: 'متوقع', labelBrutto: 'إجمالي', labelZeitkonto: 'حساب وقت',
    unitBrArb: 'ساعات BrArb', unitSoll: 'ساعات Soll', unitBrutto: 'ساعات إجمالية', unitSaldo: 'الرصيد',
    potlekok: 'العلاوات الإجمالية',
    napok: (n) => `الأيام · ${n} إدخال`,
    legendURL: 'إجازة', legendKRA: 'مرض', legendNT: 'ليل',
    potUe25: 'وقت إضافي', potN25: 'علاوة ليلية', potN40: 'علاوة ليلية+', potSo50: 'الأحد/العطلة', potFt125: 'بدل الأعياد 125%',
    tagVacation: (e, f, n) => `${n} يوم إجازة`,
    tagZA: (e, f, n) => `${n} يوم ZA`,
    tagKrank: (n) => `${n} يوم مرض`,
    tagNight: (n) => `${n} ليلة`,
    tagSunday: (n) => `${n} أحد`,
    dayNames: {Mo:'الأثنين',Di:'الثلاثاء',Mi:'الأربعاء',Do:'الخميس',Fr:'الجمعة',Sa:'السبت',So:'الأحد'},
    shifts: {'320':'صباح','321':'ظهر','322':'ليل','323':'صباح+','324':'ظهر+','325':'ليل+','326':'صباح (أحد)','327':'ظهر (أحد)','328':'ليل (أحد)','71':'ظهر سبت','72':'ليل سبت','73':'صباح أحد+','74':'ظهر أحد+','75':'ليل أحد+','76':'صباح أحد','77':'ظهر عطلة','78':'ليل عطلة','1000':'عطلة','5040':'يوم حر','5041':'حر (أحد)'},
    ciTitle: 'استيراد إلى Chronos',
    ciCalLabel: '📅 التقويم – إضافة الورديات',
    ciCalHint: 'صباح / مساء / ليل + إجازة + مرض',
    ciSalLabel: '💰 الراتب – تحديث Feststunden',
    ciSalHint: 'ساعات Soll المستهدفة → حقل Feststunden',
    ciClose: 'إغلاق',
    ciImport: '✅ استيراد إلى Chronos',
    ciDone: (n) => `✅ ${n} أيام مستوردة`,
    ciErrSelect: '⚠️ يرجى اختيار خيار واحد على الأقل!',
    ciErrNotAvail: '❌ Chronos غير متاح.',
    ismeretlen: 'غير معروف',
  },
  bs: {
    appTitle: 'ZEUS Čitač',
    appSubtitle: 'MOJO+TASU analizator',
    dropTitle: 'Učitaj ZEUS PDF',
    dropDesc: 'Prevuci mjesečni obračun ovdje<br>Više mjeseci odjednom',
    dropHint: 'Odaberi datoteku',
    statusIdle: 'Čekanje PDF-a...',
    statusBusy: (name, i, n) => `Obrada: ${name} (${i}/${n})`,
    statusBusyStart: (n) => `Obrada ${n} PDF-a...`,
    statusOk: (n) => `✓ ${n} mjesec(i) uspješno učitano`,
    statusErr: (ok, err) => `${ok} uspješno, ${err} neuspješno`,
    monthCount: (n) => `${n} mjesec(i)`,
    emptyText: 'Učitaj mjesečni obračun<br>izvezeni iz ZEUS sistema.<br><br>Od januara do decembra,<br>više mjeseci odjednom.',
    notZeusFormat: 'Nije ZEUS format ili nije čitljivo',
    labelDolgozott: 'Odrađeno', labelElvart: 'Očekivano', labelBrutto: 'Bruto', labelZeitkonto: 'Vremenski račun',
    unitBrArb: 'BrArb h', unitSoll: 'Soll h', unitBrutto: 'bruto h', unitSaldo: 'saldo',
    potlekok: 'Dodaci ukupno',
    napok: (n) => `Dani · ${n} unosa`,
    legendURL: 'GOD', legendKRA: 'BOL', legendNT: 'NOĆ',
    potUe25: 'Prekovremeni', potN25: 'Noćni', potN40: 'Noćni+', potSo50: 'Nedjelja/Praznik', potFt125: 'Prazničnı dodatak 125%',
    tagVacation: (e, f, n) => `${n} dan(a) godišnji`,
    tagZA: (e, f, n) => `${n} dan(a) ZA`,
    tagKrank: (n) => `${n} dan(a) bolovanje`,
    tagNight: (n) => `${n} noć(i)`,
    tagSunday: (n) => `${n} nedjelja`,
    dayNames: {Mo:'Po',Di:'Ut',Mi:'Sr',Do:'Če',Fr:'Pe',Sa:'Su',So:'Ne'},
    shifts: {'320':'Jutarnja','321':'Poslijepodnevna','322':'Noćna','323':'Jutarnja+','324':'Poslijepod.+','325':'Noćna+','326':'Jutarnja (Ne)','327':'Poslijepod. (Ne)','328':'Noćna (Ne)','71':'Poslijepod. Su','72':'Noćna Su','73':'Jut. Ne+','74':'Poslijepod. Ne+','75':'Noćna Ne+','76':'Jut. Ne','77':'Poslijepod. Pr','78':'Noćna Pr','1000':'Praznik','5040':'Slobodno','5041':'Slobod. (Ne)'},
    ciTitle: 'Uvoz u Chronos',
    ciCalLabel: '📅 Kalendar – unos smjena',
    ciCalHint: 'Jutarnja / Poslijepodnevna / Noćna + Godišnji + Bolovanje',
    ciSalLabel: '💰 Plaća – ažuriranje Feststunden',
    ciSalHint: 'Ciljani Soll sati → polje Feststunden',
    ciClose: 'Zatvori',
    ciImport: '✅ Uvezi u Chronos',
    ciDone: (n) => `✅ ${n} dana uvezeno`,
    ciErrSelect: '⚠️ Odaberite barem jednu opciju!',
    ciErrNotAvail: '❌ Chronos nije dostupan.',
    ismeretlen: 'Nepoznato',
  },
};

// ── AKTUÁLIS NYELV ──────────────────────────────────────────────────────────────
// currentLang-ot a főmodul setLanguage() hívja postMessage-en keresztül.
// Kezdeti értéket a főmodul state-jéből vesszük, ha elérhető.
let currentLang = (function() {
  try {
    const s = window._chronosState && window._chronosState();
    if (s && s.currentLang) return s.currentLang;
  } catch(_) {}
  return 'hu';
})();

function tr(key, ...args) {
  // 1) ZeusWidget saját ZTR szótára
  const t = ZTR[currentLang] || ZTR.hu;
  if (t[key] !== undefined) {
    const val = t[key];
    return typeof val === 'function' ? val(...args) : val;
  }
  // 2) Fallback: főmodul window._currentTranslations (közös kulcsok)
  const shared = window._currentTranslations;
  if (shared && shared[key] !== undefined) {
    const val = shared[key];
    return typeof val === 'function' ? val(...args) : val;
  }
  // 3) ZTR.hu alap, majd a kulcs maga
  const huVal = ZTR.hu[key];
  if (huVal !== undefined) return typeof huVal === 'function' ? huVal(...args) : huVal;
  return key;
}

function applyLang() {
  const t = ZTR[currentLang] || ZTR.hu;
  document.getElementById('appTitle').textContent   = t.appTitle;
  document.getElementById('appSubtitle').textContent = t.appSubtitle;
  document.getElementById('dropTitle').textContent   = t.dropTitle;
  document.getElementById('dropDesc').innerHTML      = t.dropDesc;
  document.getElementById('dropHint').textContent    = t.dropHint;
  document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.lang = currentLang;
  // Chronos import panel szövegek
  const _ci = t;
  const _s = (id, v) => { const el = document.getElementById(id); if (el && v) el.textContent = v; };
  const _sh = (id, v) => { const el = document.getElementById(id); if (el && v) el.innerHTML = v; };
  _s('ciTitleEl',    _ci.ciTitle);
  _s('ciCalLabelEl', _ci.ciCalLabel);
  _s('ciCalHintEl',  _ci.ciCalHint);
  _s('ciSalLabelEl', _ci.ciSalLabel);
  _s('ciSalHintEl',  _ci.ciSalHint);
  _s('ciCloseBtn',   _ci.ciClose);
  _s('ciImportBtn',  _ci.ciImport);
  // Ha nincs betöltött adat, frissítse az üres állapotot is
  if (months.length === 0) {
    refreshUI();
  } else {
    refreshUI();
  }
  // Státusz szöveg frissítése ha idle
  const dot = document.getElementById('statusDot');
  if (dot.classList.contains('idle')) {
    document.getElementById('statusText').textContent = t.statusIdle;
  }
}

// Chronos postMessage figyelő
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'setLanguage' && ZTR[e.data.lang]) {
    currentLang = e.data.lang;
    applyLang();
  }
});

// ── KONSTANSOK ─────────────────────────────────────────────────────────────────
const MONTHS_DE_HU = {
  'januar':'Január','jänner':'Január','februar':'Február','märz':'Március',
  'april':'Április','mai':'Május','juni':'Június','julius':'Július',
  'juli':'Július','august':'Augusztus','september':'Szeptember',
  'oktober':'Október','november':'November','dezember':'December'
};
const MONTH_ORDER = ['Január','Február','Március','Április','Május','Június',
                     'Július','Augusztus','Szeptember','Október','November','December'];

function getShift(tmCode) {
  const t = ZTR[currentLang] || ZTR.hu;
  return (t.shifts && t.shifts[tmCode]) || `TM${tmCode}`;
}
function getDayHu(dayName) {
  const t = ZTR[currentLang] || ZTR.hu;
  return (t.dayNames && t.dayNames[dayName]) || dayName;
}
const NIGHT_TM  = new Set(['322','325','328','72','75','78']);
const SUNDAY_TM = new Set(['73','74','75','76','326','327','328']);
const FREIWILLIG_TM = new Set(['70','71','72','73','74','75','76','77','78']);
const OFF_TM    = new Set(['5040','5041']);

// ── STATE ──────────────────────────────────────────────────────────────────────
let months = [];   // tömb parsolt hónapokból
let activeIdx = 0;

// ── UI HELPERS ─────────────────────────────────────────────────────────────────
function setStatus(type, text) {
  document.getElementById('statusDot').className = 'status-dot ' + type;
  document.getElementById('statusText').textContent = text;
  if (type === 'idle') {
    document.getElementById('statusText').textContent = tr('statusIdle');
  }
}
function setProgress(pct) {
  const w = document.getElementById('progressWrap');
  const b = document.getElementById('progressBar');
  if (pct < 0) { w.style.display = 'none'; return; }
  w.style.display = 'block';
  b.style.width = pct + '%';
}

// ── PDF SZÖVEGKINYERÉS ─────────────────────────────────────────────────────────
async function extractText(file) {
  const ab = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    // Összefűzzük y-koordináta szerint soronként
    const items = content.items;
    // Egyszerű: minden item szövegét összefűzzük újsorokkal
    let lastY = null;
    for (const item of items) {
      const y = item.transform ? Math.round(item.transform[5]) : 0;
      if (lastY !== null && Math.abs(y - lastY) > 2) text += '\n';
      text += item.str;
      lastY = y;
    }
    text += '\n';
  }
  return text;
}

// ── ZEUS PARSER ────────────────────────────────────────────────────────────────
function parseZeus(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  let name = '', personalNr = '', ausweisNr = '', month = '', year = '';

  // --- Fejléc ---
  for (const line of lines) {
    // Név: "Takacs, Zoltan   Ausweis Nr.: 421" — a PDF-ben gyakran nincs
    // 2+ szóköz a név és az "Ausweis Nr." / "Personal Nr." között (pl. a
    // szövegkinyerés egybefűzheti a tabos elrendezést), ezért explicit
    // megállót adunk ezekre — különben a teljes sorvég ráragadna a névre.
    const nm = line.match(/Name[,\s]+Vorname[:\s]+(.+?)(?:\s*Ausweis\s*Nr|\s*Personal\s*Nr|\s{2,}|$)/i);
    if (nm) name = nm[1].trim().replace(/\s+/g,' ');

    const pnr = line.match(/Personal\s*Nr\.?\s*[:\s]+(\d+)/i);
    if (pnr) personalNr = pnr[1];

    const anr = line.match(/Ausweis\s*Nr\.?\s*[:\s]+(\d+)/i);
    if (anr) ausweisNr = anr[1];

    // Hónap + év: "März 2026" vagy "März2026"
    const mon = line.match(/\b(januar|jänner|februar|m[äa]rz|april|mai|juni|juli|august|september|oktober|november|dezember)\s*(\d{4})\b/i);
    if (mon) {
      month = MONTHS_DE_HU[mon[1].toLowerCase()] || mon[1];
      year  = mon[2];
    }
  }

  // --- Nap sorok ---
  // Fix formátum: "Mo 2 320 | 5:20 - 14:17 | | +8.00 8.00 +0.00 8.00 8.00 +30.30 +0.15"
  // vagy:        "Di 24 320 | 0:00+ *KRA |2:Krank m. LFZ | +0.00 8.00 ..."
  const dayRows = [];

  // Egy nap több sorból állhat (2.HT), ezért gyűjtsük először a nap-blokkokat
  let currentDay = null;

  for (const line of lines) {
    // Fősor: "Mo 2 320 | ..."
    const main = line.match(
      /^(Mo|Di|Mi|Do|Fr|Sa|So)\s+(\d{1,2})\s+(\d{2,5})\s*\|(.*)$/
    );
    if (main) {
      if (currentDay) dayRows.push(currentDay);
      currentDay = {
        dayName: main[1],
        dayNum:  parseInt(main[2]),
        tmCode:  main[3],
        rest:    [main[4]]
      };
      continue;
    }
    // 2.HT sor: "10 322 | 2.HT 8:15+ *URL |1:Urlaub | ..."
    const sub = line.match(/^\d{1,2}\s+\d{2,5}\s*\|\s*2\.HT\s+(.*)$/);
    if (sub && currentDay) {
      currentDay.rest.push('2HT:' + sub[1]);
      continue;
    }
    // Ünnepnap-kiegészítő sor (Feiertag + munkanap kettős sor, 2.HT nélkül):
    // pl. "6 77 | 0:00+ * |5001:Ganzer Feiertag | +8.00 ..."
    // VAGY "25 76 | 0:00+ * |5001:Ganzer Feiertag | ..."
    const ftExtra = line.match(/^(\d{1,2})\s+(\d{2,5})\s*\|(.*)$/);
    if (ftExtra && currentDay && parseInt(ftExtra[1]) === currentDay.dayNum) {
      const extraContent = ftExtra[3];
      if (/5001/i.test(extraContent) || /Feiertag/i.test(extraContent)) {
        currentDay.rest.push('FT_EXTRA:' + extraContent);
      }
      continue;
    }
  }
  if (currentDay) dayRows.push(currentDay);

  // Periodensumme
  let summary = {};
  const pm = text.match(
    /Periodensumme\s+([+-]?[\d.]+)\s+([\d.]+)\s+([+-]?[\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([+-]?[\d.]+)\s+([+-]?[\d.]+)\s+([+-]?[\d.]+)\s+([+-]?[\d.]+)\s+([+-]?[\d.]+)\s*([+-]?[\d.]+)?/
  );
  if (pm) {
    summary = {
      brArb: parseFloat(pm[1]),
      soll:  parseFloat(pm[2]),
      diffNt:parseFloat(pm[3]),
      ntGes: parseFloat(pm[4]),
      brutto:parseFloat(pm[5]),
      saldo: parseFloat(pm[6]),
      ue25:  parseFloat(pm[7])||0,
      n25:   parseFloat(pm[8])||0,
      n40:   parseFloat(pm[9])||0,
      so50:  parseFloat(pm[10])||0,
      ft125: parseFloat(pm[11])||0,
    };
  }
  // Saldo a Periodenabschluss sorból
  const sa = text.match(/Periodenabschluss:\s*Saldo\s*Periode\s*([+-]?[\d.]+)/);
  if (sa) summary.saldo = parseFloat(sa[1]);

  // Urlaub / Krank napok száma a summary táblából
  // (summaryLine / ul regex unused, removed to avoid dead variable)


  const days = dayRows.map(raw => parseDayRow(raw));

  // Szabadság (URL): egész és fél napok
  const urlaubEgesz = days.filter(d => d.type === 'vacation').length;
  const urlaubFel   = days.filter(d => d.type === 'half-vacation-1st' || d.type === 'half-vacation-2nd').length;
  const urlaubNap   = urlaubEgesz + urlaubFel * 0.5;

  // Zeitausgleich (ZA): egész és fél napok
  const zaEgesz = days.filter(d => d.type === 'za').length;
  const zaFel   = days.filter(d => d.type === 'half-za' || d.type === 'half-za-1st' || d.type === 'half-za-2nd').length;
  const zaNap   = zaEgesz + zaFel * 0.5;

  const krankTage = days.filter(d => d.type === 'sick').length;

  // Zeitkonto egyenlege = időszak végi Saldo
  const zeitkonto = summary.saldo != null ? summary.saldo : 0;

  return { name, personalNr, ausweisNr, month, year, days, summary,
           urlaubNap, urlaubEgesz, urlaubFel,
           zaNap, zaEgesz, zaFel,
           zeitkonto, krankTage };
}

function parseDayRow(raw) {
  const { dayName, dayNum, tmCode, rest } = raw;
  const restStr = rest.join(' ');

  // Időpontok kinyerése: "5:20 - 14:17" vagy "21:20 - 6:15+"
  const timeM = restStr.match(/(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2}[+]?)/);
  const start  = timeM ? timeM[1] : null;
  const end    = timeM ? timeM[2].replace('+','') : null;

  // Fél napos ellenőrzés: 2.HT sor tartalmaz *URL/*KRA/*ZA jelölést
  const hasHalfDay = rest.some(r => r.startsWith('2HT:'));
  const halfStr    = rest.filter(r => r.startsWith('2HT:')).join(' ');

  // Speciális jelölések – fősorban VAGY 2.HT sorban
  const fullStr = restStr;
  const mainStr = rest[0] || '';

  const isURL_main = /\*URL/.test(mainStr) || /1:Urlaub/i.test(mainStr);
  const isURL_half = hasHalfDay && (/\*URL/.test(halfStr) || /1:Urlaub/i.test(halfStr));
  const isURL = isURL_main || isURL_half;

  const isZA_main  = /\*ZA/.test(mainStr) || /4:Zeitausgleich/i.test(mainStr);
  const isZA_half  = hasHalfDay && (/\*ZA/.test(halfStr) || /4:Zeitausgleich/i.test(halfStr));
  const isZA = isZA_main || isZA_half;

  const isKRA = /\*KRA/.test(fullStr) || /2:Krank/i.test(fullStr);
  // FT_EXTRA: ünnepnap-kiegészítő sor (kettős sorok: munkanap + Feiertag ugyanazon napon)
  const hasFtExtra = rest.some(r => r.startsWith('FT_EXTRA:'));
  const isFT  = hasFtExtra || (/\*/.test(fullStr) && (/5001:Ganz/i.test(fullStr) || tmCode === '1000'));

  // Fél napos: 2.HT sorban van a jelölés, VAGY fősorban jelölés + tényleges munkaidő
  const hasWork     = timeM !== null;
  const isHalfURL   = isURL && (hasHalfDay || (isURL_main && hasWork));
  const isHalfZA    = isZA  && (hasHalfDay || (isZA_main  && hasWork));

  // Számértékek kinyerése az óra-számításhoz
  const numsAll = [...fullStr.matchAll(/[+-]?\d+\.\d+/g)].map(m => parseFloat(m[0]));
  const _soll  = numsAll[1] ?? 8;
  const _brArb = numsAll[0] ?? 0;

  // Kivett szabadság/ZA órák ezen a napon
  let urlaubOra = 0;
  let zaOra     = 0;
  if (isURL) urlaubOra = isHalfURL ? Math.max(_soll - _brArb, 0) : _soll;
  if (isZA)  zaOra     = isHalfZA  ? Math.max(_soll - _brArb, 0) : _soll;

  let type = 'normal';
  // Fél-vacation: melyik fél szabad?
  // 2HT sorban van *URL → a 2. fél szabad (dolgozik 1. fél, szabad 2. fél) → Urlaub2
  // Fősorban van *URL + van munkaidő → az 1. fél szabad (szabad 1. fél, dolgozik 2. fél) → Urlaub1
  const halfVacIsSecond = isURL_half && hasHalfDay; // 2HT sorban van URL → 2. fél szabad
  const halfVacIsFirst  = isURL_main && hasWork && !hasHalfDay; // fősorban URL + munkaidő → 1. fél szabad

  // Fél-ZA: melyik fél ZA?
  // 2HT sorban van *ZA → a 2. fél ZA → ZK2
  // Fősorban van *ZA + van munkaidő (nincs 2HT) → az 1. fél ZA → ZK1
  const halfZaIsSecond = isZA_half && hasHalfDay; // 2HT sorban van ZA → 2. fél ZA
  const halfZaIsFirst  = isZA_main && hasWork && !hasHalfDay; // fősorban ZA + munkaidő → 1. fél ZA

  // FT_EXTRA + munkaidő = ünnepen ledolgozott nap (pótlékkal, de nem szabad nap)
  const isWorkedHoliday = hasFtExtra && hasWork;
  if (isFT && !isWorkedHoliday) type = 'holiday';
  else if (isKRA)        type = 'sick';
  else if (isURL && isHalfURL && halfVacIsSecond) type = 'half-vacation-2nd'; // dolgozik + Urlaub2
  else if (isURL && isHalfURL && halfVacIsFirst)  type = 'half-vacation-1st'; // Urlaub1 + dolgozik
  else if (isURL && isHalfURL) type = 'half-vacation-1st'; // fallback
  else if (isURL)        type = 'vacation';
  else if (isZA && isHalfZA && halfZaIsSecond) type = 'half-za-2nd'; // dolgozik + ZK2
  else if (isZA && isHalfZA && halfZaIsFirst)  type = 'half-za-1st'; // ZK1 + dolgozik
  else if (isZA && isHalfZA)  type = 'half-za-1st'; // fallback
  else if (isZA)         type = 'za';
  else if (OFF_TM.has(tmCode))           type = 'off';
  else if (dayName === 'So' || dayName === 'Sa') type = 'weekend';

  // Számértékek: "+8.00 8.00 +0.00 8.00 8.00 +30.30 [pótlékok]"
  const nums = [...restStr.matchAll(/[+-]?\d+\.\d+/g)].map(m => parseFloat(m[0]));
  // A sorrend: BrArb Soll DiffNt NtGes Brutto Saldo [UE25 N25 N40 SO50 FT125]
  const brArb  = nums[0] ?? 0;
  const soll   = nums[1] ?? 0;
  const saldo  = nums[5] ?? 0;

  // Pótlékok – ezek az 5 index után jönnek (pozitív számok)
  const pot = {};
  if (nums.length > 6)  pot.ue25  = nums[6]  ?? 0;
  if (nums.length > 7)  pot.n25   = nums[7]  ?? 0;
  if (nums.length > 8)  pot.n40   = nums[8]  ?? 0;
  if (nums.length > 9)  pot.so50  = nums[9]  ?? 0;
  if (nums.length > 10) pot.ft125 = nums[10] ?? 0;

  const isNight      = NIGHT_TM.has(tmCode);
  const isSunday     = SUNDAY_TM.has(tmCode) || dayName === 'So';
  const isFreiwillig = FREIWILLIG_TM.has(tmCode);

  return { dayName, dayNum, tmCode, start, end, type,
           brArb, soll, saldo, pot, isNight, isSunday, isFreiwillig, urlaubOra, zaOra };
}

// ── RENDER ─────────────────────────────────────────────────────────────────────
function renderMonth(data) {
  const { name, personalNr, ausweisNr, month, year, days, summary,
          urlaubNap, urlaubEgesz, urlaubFel,
          zaNap, zaEgesz, zaFel,
          zeitkonto, krankTage } = data;
  const s = summary;

  const saldoPos  = zeitkonto >= 0;
  const saldoStr  = (saldoPos ? '+' : '') + zeitkonto.toFixed(2);
  const saldoCls  = saldoPos ? 'g' : 'r';

  // Tags
  const tags = [];
  if (urlaubNap > 0) tags.push(`<span class="tag tag-b">${tr('tagVacation', urlaubEgesz, urlaubFel, urlaubNap)}</span>`);
  if (zaNap > 0)     tags.push(`<span class="tag tag-g">${tr('tagZA', zaEgesz, zaFel, zaNap)}</span>`);
  if (krankTage > 0) tags.push(`<span class="tag tag-y">${tr('tagKrank', krankTage)}</span>`);
  const nightCnt = days.filter(d => d.isNight && d.type === 'normal').length;
  if (nightCnt > 0)  tags.push(`<span class="tag tag-c">${tr('tagNight', nightCnt)}</span>`);
  const sunCnt = days.filter(d => d.isSunday && d.type !== 'off').length;
  if (sunCnt > 0)    tags.push(`<span class="tag tag-p">${tr('tagSunday', sunCnt)}</span>`);
  if (personalNr)    tags.push(`<span class="tag tag-n">#${personalNr}</span>`);

  // Pótlékok
  const pots = [
    s.ue25  ? { nm:'UE 25%',  desc:tr('potUe25'),  val:s.ue25,  col:'var(--g)', dot:'#00e5a0' } : null,
    s.n25   ? { nm:'N 25%',   desc:tr('potN25'),   val:s.n25,   col:'var(--c)', dot:'#38d9f5' } : null,
    s.n40   ? { nm:'N 40%',   desc:tr('potN40'),   val:s.n40,   col:'var(--b)', dot:'#3b9eff' } : null,
    s.so50  ? { nm:'SO 50%',  desc:tr('potSo50'),  val:s.so50,  col:'var(--p)', dot:'#b87cff' } : null,
    s.ft125 ? { nm:'FT 125%', desc:tr('potFt125'), val:s.ft125, col:'var(--y)', dot:'#fbbf24' } : null,
  ].filter(Boolean);

  // Napok
  let daysHtml = '';
  for (let i = 0; i < days.length; i++) {
    const d = days[i];
    if (d.dayName === 'Mo' || i === 0) {
      if (i > 0) daysHtml += `<div class="week-sep"></div>`;
    }

    const rowCls = d.type === 'off' ? 'off' :
                   d.type === 'sick' ? 'sick' :
                   d.type === 'vacation' || d.type === 'half-vacation-1st' || d.type === 'half-vacation-2nd' ? 'vacation' :
                   d.type === 'holiday' ? 'holiday' :
                   d.type === 'za' || d.type === 'half-za' || d.type === 'half-za-1st' || d.type === 'half-za-2nd' ? 'za' : '';

    const dayHu  = getDayHu(d.dayName);
    const shift  = getShift(d.tmCode);
    const timeStr = d.start ? `${d.start} – ${d.end != null ? d.end : '?'}` : '—';

    const legendURL = tr('legendURL');
    const legendKRA = tr('legendKRA');
    let badge = '';
    if (d.type === 'vacation')                badge = `<span class="day-badge db-url">${legendURL}</span>`;
    else if (d.type === 'half-vacation-1st') badge = `<span class="day-badge db-url">½¹ ${legendURL}</span>`;
    else if (d.type === 'half-vacation-2nd') badge = `<span class="day-badge db-url">½² ${legendURL}</span>`;
    else if (d.type === 'sick')          badge = `<span class="day-badge db-kra">${legendKRA}</span>`;
    else if (d.type === 'holiday')       badge = `<span class="day-badge db-ft">ÜNN</span>`;
    else if (d.type === 'za')            badge = `<span class="day-badge db-za">ZA</span>`;
    else if (d.type === 'half-za')       badge = `<span class="day-badge db-za">½ ZA</span>`;
    else if (d.type === 'half-za-1st')   badge = `<span class="day-badge db-za">½¹ ZA</span>`;
    else if (d.type === 'half-za-2nd')   badge = `<span class="day-badge db-za">½² ZA</span>`;
    else if (d.isFreiwillig && d.isNight)  badge = `<span class="day-badge db-fw">FW NT</span>`;
    else if (d.isFreiwillig)                badge = `<span class="day-badge db-fw">FW</span>`;
    else if (d.isNight)                     badge = `<span class="day-badge db-nt">${tr('legendNT')}</span>`;
    else if (d.isSunday && d.dayName !== 'So') badge = `<span class="day-badge db-so">V</span>`;

    const brArbStr = d.brArb > 0 ? `+${d.brArb.toFixed(2)}` : '—';
    const brArbCls = d.brArb > 0 ? '' : 'zero';

    daysHtml += `
    <div class="day-row ${rowCls}">
      <div class="day-dn">${dayHu}</div>
      <div class="day-num">${d.dayNum}</div>
      <div class="day-mid">
        <div class="day-time">${timeStr}</div>
        <div class="day-shift">${shift}</div>
      </div>
      <div>${badge}</div>
      <div class="day-brarb ${brArbCls}">${brArbStr}</div>
    </div>`;
  }

  return `
  <!-- FEJLÉC CARD -->
  <div class="hcard">
    <div class="hcard-top">
      <div>
        <div class="hcard-name">${name || tr('ismeretlen')}</div>
        <div class="hcard-sub">Personal Nr.: ${personalNr || '—'}</div>
      </div>
      <div class="month-badge">
        <div class="mon">${month}</div>
        <div class="yr">${year}</div>
      </div>
    </div>
    <div class="stat-grid">
      <div class="stat-cell">
        <div class="stat-label">${tr('labelDolgozott')}</div>
        <div class="stat-val g">${(s.brArb != null ? s.brArb : 0).toFixed(2)}</div>
        <div class="stat-unit">${tr('unitBrArb')}</div>
      </div>
      <div class="stat-cell">
        <div class="stat-label">${tr('labelElvart')}</div>
        <div class="stat-val b">${(s.soll != null ? s.soll : 0).toFixed(2)}</div>
        <div class="stat-unit">${tr('unitSoll')}</div>
      </div>
      <div class="stat-cell">
        <div class="stat-label">${tr('labelBrutto')}</div>
        <div class="stat-val">${(s.brutto != null ? s.brutto : 0).toFixed(2)}</div>
        <div class="stat-unit">${tr('unitBrutto')}</div>
      </div>
      <div class="stat-cell">
        <div class="stat-label">${tr('labelZeitkonto')}</div>
        <div class="stat-val ${saldoCls}">${saldoStr}</div>
        <div class="stat-unit">${tr('unitSaldo')}</div>
      </div>
    </div>
    ${tags.length ? `<div class="tags-row">${tags.join('')}</div>` : ''}
  </div>

  <!-- PÓTLÉKOK CARD -->
  ${pots.length ? `
  <div class="potcard">
    <div class="potcard-title">${tr('potlekok')}</div>
    ${pots.map(p => `
    <div class="pot-row">
      <div class="pot-dot" style="background:${p.dot}"></div>
      <div>
        <div class="pot-name">${p.nm}</div>
        <div class="pot-desc">${p.desc}</div>
      </div>
      <div class="pot-val" style="color:${p.col}">+${p.val.toFixed(2)} h</div>
    </div>`).join('')}
  </div>` : ''}

  <!-- NAPOK CARD -->
  <div class="daycard">
    <div class="daycard-title">
      <span>${tr('napok', days.length)}</span>
      <div class="legend">
        <span><span class="legend-dot" style="background:var(--b)"></span>${tr('legendURL')}</span>
        <span><span class="legend-dot" style="background:var(--y)"></span>${tr('legendKRA')}</span>
        <span><span class="legend-dot" style="background:var(--c)"></span>${tr('legendNT')}</span>
      </div>
    </div>
    ${daysHtml}
  </div>`;
}

function refreshUI() {
  const tabsWrap  = document.getElementById('tabsWrap');
  const cards     = document.getElementById('cards');
  const monthCount = document.getElementById('monthCount');

  if (months.length === 0) {
    tabsWrap.classList.remove('visible');
    monthCount.classList.remove('visible');
    cards.innerHTML = `<div class="empty"><span class="empty-icon">🗂️</span>
      <p>${tr('emptyText')}</p></div>`;
    return;
  }

  monthCount.textContent = tr('monthCount', months.length);
  monthCount.classList.add('visible');

  // Rendezés hónap szerint
  months.sort((a, b) =>
    (MONTH_ORDER.indexOf(a.month) + parseInt(a.year)*12) -
    (MONTH_ORDER.indexOf(b.month) + parseInt(b.year)*12)
  );

  if (months.length > 1) {
    tabsWrap.classList.add('visible');
    tabsWrap.innerHTML = months.map((m, i) =>
      `<div class="tab ${i===activeIdx?'active':''}" onclick="switchTab(${i})">${m.month}</div>`
    ).join('');
  } else {
    tabsWrap.classList.remove('visible');
  }

  cards.innerHTML = renderMonth(months[activeIdx]);
}

function switchTab(i) {
  activeIdx = i;
  refreshUI();
  document.getElementById('cards').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── FÁJL FELDOLGOZÁS ───────────────────────────────────────────────────────────
async function processFiles(files) {
  if (!files.length) return;

  setStatus('busy', tr('statusBusyStart', files.length));
  setProgress(0);

  let ok = 0, err = 0;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    setStatus('busy', tr('statusBusy', file.name, i+1, files.length));
    setProgress(Math.round((i / files.length) * 100));
    try {
      const text = await extractText(file);
      const data = parseZeus(text);

      if (!data.month) throw new Error(tr('notZeusFormat'));

      // Duplikátum ellenőrzés (azonos hónap+év)
      const dupIdx = months.findIndex(m => m.month === data.month && m.year === data.year);
      if (dupIdx >= 0) months[dupIdx] = data;
      else months.push(data);

      ok++;
    } catch(e) {
      console.error(file.name, e);
      err++;
    }
  }

  setProgress(100);
  setTimeout(() => setProgress(-1), TIMING.PROGRESS_CLEAR);

  activeIdx = Math.max(0, months.length - 1);
  refreshUI();

  if (err === 0) {
    setStatus('ok', tr('statusOk', ok));
  } else {
    setStatus('err', tr('statusErr', ok, err));
  }

  // Import panel megjelenítése ha van adat
  const ciPanel = document.getElementById('chronosImportPanel');
  if (ciPanel) ciPanel.style.display = months.length > 0 ? 'block' : 'none';
  const ciResult = document.getElementById('ciResult');
  if (ciResult) ciResult.style.display = 'none';
  // Az "Importálás Chronosba" gombot egy korábbi sikeres import elrejtette
  // (doChronosImport) — új fájl(ok) betöltésekor mindig vissza kell hozni,
  // különben a második/további import esetén nem jelenik meg a gomb.
  const ciImportBtnReset = document.getElementById('ciImportBtn');
  if (ciImportBtnReset) ciImportBtnReset.style.display = '';
}

// ── EVENTS ─────────────────────────────────────────────────────────────────────
document.getElementById('fileInput').addEventListener('change', function(e) {
  const files = Array.from(e.target.files);
  if (files.length) processFiles(files);
  e.target.value = '';
});

const dz = document.getElementById('dropZone');
dz.addEventListener('dragover',  e => { e.preventDefault(); dz.classList.add('over'); });
dz.addEventListener('dragleave', () => dz.classList.remove('over'));
dz.addEventListener('drop', e => {
  e.preventDefault();
  dz.classList.remove('over');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf');
  if (files.length) processFiles(files);
});

// ── CHRONOS IMPORT ────────────────────────────────────────────────────────────
const ZEUS_TM_TO_SHIFT = {
  '320':'Früh','323':'Früh','326':'Früh','73':'Früh','76':'Früh',
  '321':'Spät','324':'Spät','327':'Spät','71':'Spät','74':'Spät','77':'Spät',
  '322':'Nacht','325':'Nacht','328':'Nacht','72':'Nacht','75':'Nacht','78':'Nacht'
};

const ZEUS_MONTH_IDX = {
  'Január':0,'Február':1,'Március':2,'Április':3,'Május':4,'Június':5,
  'Július':6,'Augusztus':7,'Szeptember':8,'Október':9,'November':10,'December':11
};

function doChronosImport() {
  if (!months.length) return;
  if (!window._chronosState || !window._chronosSaveState) {
    showCiResult(tr('ciErrNotAvail'), false);
    return;
  }

  const doCalendar = document.getElementById('ciOptCalendar').checked;
  const doSalary   = document.getElementById('ciOptSalary').checked;
  if (!doCalendar && !doSalary) {
    showCiResult(tr('ciErrSelect'), false);
    return;
  }

  const st = window._chronosState();
  if (!st.schedules) st.schedules = {};
  if (!st.zeusData)  st.zeusData  = {};

  let totalImported = 0, totalSkipped = 0;

  months.forEach(function(m) {
    const mi = ZEUS_MONTH_IDX[m.month];
    const yr = parseInt(m.year);
    if (mi === undefined || isNaN(yr)) return;

    // ── 1. NAPTÁR ──
    if (doCalendar) {
      m.days.forEach(function(d) {
        const key = yr + '-' + (mi + 1) + '-' + d.dayNum;

        if (d.type === 'vacation') {
          st.schedules[key] = ['Urlaub']; totalImported++; return;
        }
        if (d.type === 'half-vacation-1st') {
          // 1. fél szabad, 2. fél dolgozik → Urlaub1 + a műszak
          const shiftId = ZEUS_TM_TO_SHIFT[String(d.tmCode)];
          st.schedules[key] = shiftId ? ['Urlaub1', shiftId] : ['Urlaub1'];
          totalImported++; return;
        }
        if (d.type === 'half-vacation-2nd') {
          // 1. fél dolgozik, 2. fél szabad → a műszak + Urlaub2
          const shiftId = ZEUS_TM_TO_SHIFT[String(d.tmCode)];
          st.schedules[key] = shiftId ? [shiftId, 'Urlaub2'] : ['Urlaub2'];
          totalImported++; return;
        }
        if (d.type === 'sick') {
          st.schedules[key] = ['Krank']; totalImported++; return;
        }
        if (d.type === 'za') {
          // Egész napos ZA → ZK
          st.schedules[key] = ['ZK']; totalImported++; return;
        }
        if (d.type === 'half-za-1st') {
          // 1. fél ZA, 2. fél dolgozik → ZK1 + műszak
          const shiftId = ZEUS_TM_TO_SHIFT[String(d.tmCode)];
          st.schedules[key] = shiftId ? ['ZK1', shiftId] : ['ZK1'];
          totalImported++; return;
        }
        if (d.type === 'half-za-2nd') {
          // 1. fél dolgozik, 2. fél ZA → műszak + ZK2
          const shiftId = ZEUS_TM_TO_SHIFT[String(d.tmCode)];
          st.schedules[key] = shiftId ? [shiftId, 'ZK2'] : ['ZK2'];
          totalImported++; return;
        }
        if (d.type === 'holiday' || d.type === 'off') {
          delete st.schedules[key]; return;
        }

        // Normál munkánap
        const shiftId = ZEUS_TM_TO_SHIFT[String(d.tmCode)];
        if (!shiftId) return;
        // Freiwillig: szabadnapon vagy ünnepen önkéntes munka → Ön. Reggeli/Délutáni/Éjszakai
        const FW_TO_CHRONOS = { 'Früh': 'Freiwillig Früh', 'Spät': 'Freiwillig Spät', 'Nacht': 'Freiwillig Nacht' };
        const finalId = d.isFreiwillig ? (FW_TO_CHRONOS[shiftId] || shiftId) : shiftId;
        st.schedules[key] = [finalId];
        totalImported++;
      });
    }

    // ── 2. BÉR – FESTSTUNDEN ──
    if (doSalary && m.summary && m.summary.soll != null) {
      const monthKey = yr + '-' + (mi + 1);
      // hh:mm → decimális konverzió (pl. 62.15 → 62h15m = 62.25 dec)
      function _zeusHhmm(v) {
        if (!v) return 0;
        const h = Math.floor(v);
        const mins = Math.round((v - h) * 100);
        return Math.round((h + mins / 60) * 100) / 100;
      }
      st.zeusData[monthKey] = {
        brArb:  m.summary.brArb  ?? null,
        soll:   m.summary.soll   ?? null,
        brutto: m.summary.brutto ?? null,
        saldo:  m.summary.saldo  ?? null,
        ue25:   m.summary.ue25   || 0,
        n25:    m.summary.n25    || 0,
        n40:    m.summary.n40    || 0,
        so50:   m.summary.so50   || 0,
        importedAt: Date.now()
      };
      // Bér fül manualHours frissítése Zeus adatokkal (hhmm→dec konverzióval)
      // payrollMonth 0-alapú (state.payrollMonth), _mKey = year + '-' + payrollMonth
      const payKey = yr + '-' + mi;
      if (!st.manualHours) st.manualHours = {};
      if (!st.manualHours[payKey]) st.manualHours[payKey] = {};
      const mh = st.manualHours[payKey];
      if (m.summary.brArb  != null) mh['hoursWorked']       = _zeusHhmm(m.summary.brArb);
      if (m.summary.ue25   != null) mh['overtimeHours']     = _zeusHhmm(m.summary.ue25);
      if (m.summary.n25    != null) mh['night25Hours']      = _zeusHhmm(m.summary.n25);
      if (m.summary.n40    != null) mh['night40Hours']      = _zeusHhmm(m.summary.n40);
      if (m.summary.so50   != null) mh['sundayHours']       = _zeusHhmm(m.summary.so50);
      // Feststunden mező mindig fix marad (nem írja felül a Soll-óraszám) ──
      // ── Zeitkonto egyenleg frissítése a PDF Saldo alapján ──
      if (m.summary.saldo != null) {
        if (!st.zeitkonto) st.zeitkonto = { enabled: false, monthly: 0, balance: 0, withdrawals: [] };
        st.zeitkonto.balance = m.summary.saldo;
        const zkBalEl = document.getElementById('zk_balance');
        if (zkBalEl) zkBalEl.value = m.summary.saldo;
      }
    }
  });

  // ── Zeus importált hónapok megjelölése ──────────────────────────────
  // FONTOS: ez korábban hiányzott a Gmail auto-import (doChronosImport)
  // ágából — emiatt a "Zeus Monatsjournal érkezett" popup minden induláskor
  // újra megjelent, mert state.zeusImportedMonths sosem frissült.
  // Ettől függ, hogy a Gmail sync script (és a kliensoldali szűrés is)
  // tudja: ezt a hónapot már ne ajánlja fel újra, csak ha valódi új
  // hónapot talál.
  months.forEach(function(m) {
    const mi = ZEUS_MONTH_IDX[m.month];
    const yr = parseInt(m.year);
    if (mi === undefined || isNaN(yr)) return;
    const yearMo = yr + '-' + String(mi + 1).padStart(2, '0');
    if (!st.zeusImportedMonths) st.zeusImportedMonths = [];
    if (st.zeusImportedMonths.indexOf(yearMo) === -1) {
      st.zeusImportedMonths.push(yearMo);
    }
  });

  window._chronosSaveState();
  if (window._chronosRender) window._chronosRender();

  // Naptár ugrás az első importált hónapra
  if (months.length && window._chronosSetYearMonth) {
    const first = months[0];
    const mi = ZEUS_MONTH_IDX[first.month];
    const yr = parseInt(first.year);
    if (mi !== undefined && !isNaN(yr)) {
      window._chronosSetYearMonth(yr, mi);
      if (window._chronosRender) window._chronosRender();
    }
  }

  const msg = tr('ciDone', totalImported);
  showCiResult(msg, true);
  document.getElementById('ciImportBtn').style.display = 'none';

  setTimeout(function() { window.closeZeusImport(); }, TIMING.ZEUS_AUTO_CLOSE);
}

function showCiResult(msg, ok) {
  const el = document.getElementById('ciResult');
  if (!el) return;
  el.textContent = msg;
  el.style.display = 'block';
  el.style.background = ok ? 'rgba(0,229,160,0.1)' : 'rgba(255,95,87,0.1)';
  el.style.color      = ok ? '#00e5a0'              : '#ff5f57';
  el.style.border     = ok ? '1px solid rgba(0,229,160,0.25)' : '1px solid rgba(255,95,87,0.25)';
}

// Kezdeti szövegek alkalmazása
applyLang();


// ── ZEUS OVERLAY OPEN/CLOSE ────────────────────────────────────────────────────
window.openZeusImport = function() {
  var o = document.getElementById('zeusImportOverlay');
  if (o) { o.style.display = 'block'; document.body.style.overflow = 'hidden'; }
  var lang = (window._chronosState && window._chronosState().currentLang) || 'hu';
  if (typeof currentLang !== 'undefined' && typeof applyLang === 'function') {
    currentLang = lang;
    applyLang();
  }
};

window.closeZeusImport = function() {
  var o = document.getElementById('zeusImportOverlay');
  if (o) { o.style.display = 'none'; document.body.style.overflow = ''; }
};

document.addEventListener('DOMContentLoaded', function() {
  var o = document.getElementById('zeusImportOverlay');
  if (o) o.addEventListener('click', function(e) { if (e.target === o) window.closeZeusImport(); });
  // Pending gomb állapot inicializálása
  if (typeof window._zgUpdatePendingBtn === 'function') window._zgUpdatePendingBtn();

  // Drive szinkron induláskor — 2 mp delay után betölt, ha van frissebb adat
  setTimeout(function() {
    if (typeof loadStateFromDrive === 'function') loadStateFromDrive();
  }, 2000);

  // ── OTA Update ellenőrzés — 5 mp delay, háttérben, csendesen ──────────────
  // Csak APK-ban fut (AndroidBridge.downloadAndInstallUpdate megléte alapján).
  // 4. fázis (terv 6.4 pont): version.json-ból (Netlify) — egy hívás, nem
  // kettő Apps Script action (getVersion + getAppUrl), mint korábban.
  // Ha új verzió van, letölti és újraindítja az appot.
  setTimeout(function() {
    try {
      if (!window.AndroidBridge || typeof window.AndroidBridge.downloadAndInstallUpdate !== 'function') return;
      var VERSION_JSON_URL = 'https://chronos2026.netlify.app/version.json';
      var LS_OTA_VER = 'chronos_ota_version';
      // Futó verzió: előnyben a _chronosState()._version, fallback: localStorage
      var currentVer = (window._chronosState && typeof window._chronosState === 'function'
        ? (window._chronosState()._version || '') : '')
        || localStorage.getItem(LS_OTA_VER) || '0';
      // Inline semver összehasonlító (isNewerVersion ebből a scope-ból nem elérhető)
      function _otaCmpVer(a, b) {
        var av = String(a).split('.').map(Number);
        var bv = String(b).split('.').map(Number);
        for (var i = 0; i < Math.max(av.length, bv.length); i++) {
          var x = av[i]||0, y = bv[i]||0;
          if (x > y) return 1; if (x < y) return -1;
        }
        return 0;
      }

      // version.json lekérése — CapacitorHttp elsőbbséggel, sima fetch fallback
      var capHttp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;
      var otaFetch = capHttp
        ? capHttp.request({
            method: 'GET',
            url: VERSION_JSON_URL,
            headers: { 'Accept': 'application/json' },
            responseType: 'text'
          }).then(function(resp) {
            if (!resp || resp.status !== 200) return null;
            return typeof resp.data === 'string' ? resp.data : JSON.stringify(resp.data);
          })
        : fetch(VERSION_JSON_URL, { cache: 'no-store' }).then(function(r) {
            return r.ok ? r.text() : null;
          });

      otaFetch.then(function(rawText) {
        if (!rawText) return;
        var parsed;
        try { parsed = JSON.parse(rawText); } catch(e) { return; }
        if (!parsed || !parsed.version || !parsed.url) return;
        var remoteVer = parsed.version;
        if (_otaCmpVer(remoteVer, currentVer) <= 0) return; // Nincs újabb verzió

        console.log('Chronos OTA: új verzió elérhető →', remoteVer);

        // Letöltés és telepítés a Kotlin hídon keresztül
        window.AndroidBridge.downloadAndInstallUpdate(
          parsed.url,
          '_chronosOtaCallback'
        );
        window['_chronosOtaCallback'] = function(success, msg) {
          if (success) {
            localStorage.setItem(LS_OTA_VER, remoteVer);
            console.log('Chronos OTA: telepítve →', remoteVer, '— újraindítás…');
          } else {
            console.warn('Chronos OTA: telepítés sikertelen —', msg);
          }
        };
      }).catch(function(e) {
        console.warn('Chronos OTA ellenőrzés sikertelen:', e);
      });
    } catch(e) {
      console.warn('Chronos OTA hiba:', e);
    }
  }, 5000);

  // Auto Gmail szinkron induláskor — 4 mp delay, app teljesen betölt
  setTimeout(function() {
    if (typeof window._zgUpdatePendingBtn === 'function') window._zgUpdatePendingBtn();
    // Csak akkor fut, ha a Gmail szinkron be van kapcsolva
    try { if (localStorage.getItem('chronos_gmailSyncEnabled') !== '1') return; } catch(e) {}
    // Ha van függő import, csak a gombot frissítjük — nem futtatunk dupla szinkront
    try { if (localStorage.getItem('chronosZeusPending')) return; } catch(e) {}
    if (window.ChronosGmailSync) window.ChronosGmailSync.run(true);
  }, 4000);
});
