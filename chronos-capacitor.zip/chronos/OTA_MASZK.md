# Maszk index — régi APK OTA

## Ötlet

A régi APK OTA **egyetlen** `index.html` fájlt tud lecserélni.
A moduláris app viszont sok fájl (`css/`, `js/`).

A **maszk** egy vékony `index.html`, ami:
1. Letölti a teljes appot a Firebase Hostingról (`https://chronos-b8002.web.app/`),
2. `<base href="…">` miatt a CSS/JS a Hostingról töltődik,
3. `document.write`-tal a WebView-ban elindítja a friss appot.

Így a régi OTA-folyamat (MainActivity → egy HTML fájl) **elég** a frissítéshez.
Kell **internet** az első indításkor a maszk után.

## Használat

1. A `www/index-mask.html` tartalmát tedd közzé OTA-ként, mint **`index.html`**
   (Drive / Hosting közvetlen link a `version.json` `htmlUrl` / `url` mezőjében).

2. Példa `version.json`:
```json
{
  "version": "1.0.1.8",
  "htmlUrl": "https://chronos-b8002.web.app/index-mask.html",
  "url": "https://chronos-b8002.web.app/index-mask.html",
  "pwaUrl": "https://chronos-b8002.web.app/",
  "apkUrl": ""
}
```

3. Régi APK bootloader: új verzió → letölti a maszkot → `index.html` helyére írja
   → következő indításkor a maszk fut → Hostingról jön a teljes app.

## Korlátok

| | |
|--|--|
| Internet | Kell a maszk indításához (később a böngésző cache segíthet) |
| Offline-first | Gyengébb, mint a teljesen helyi `www/` |
| Teljes natív APK | Továbbra is jobb hosszú távon (helyi css/js) |

## Teljes APK vs maszk

- **Új felhasználó / ideális:** teljes APK a helyi `www/`-zal (css+js).
- **Régi APK tulajdonos:** maszk OTA → azonnal a friss felhős app.
