# Google belépés az APK-ban (natív)

## Miért nem ment eddig
Az APK a WebView-ban `https://app` origin alatt fut. A `signInWithPopup` ilyenkor
a külső Chrome-ba nyitja a `firebaseapp.com/__/auth/handler` oldalt, ami nem éri el
az appot → "The requested action is invalid." A redirect mód sem működik.

## Megoldás
APK-ban a natív `@capacitor-firebase/authentication` plugin kéri el a Google ID
tokent, a web SDK pedig `signInWithCredential`-lel lépteti be (lásd
`www/js/chronos-cloud.js`). PWA-ban / böngészőben a régi popup marad.
Az Apple gomb APK-ban el van rejtve.

## Egyszeri beállítás (Firebase Console)
1. Project settings → Your apps → **Android app** hozzáadása: package = `com.chronos.app`
2. Add hozzá az APK-t aláíró kulcs **SHA-1 és SHA-256** ujjlenyomatát
   (debug és release kulcs is, ha mindkettővel buildelsz):
   `keytool -list -v -keystore <keystore> -alias <alias>`
   (debug: `~/.android/debug.keystore`, jelszó: `android`)
3. Töltsd le az **új `google-services.json`-t** (az SHA hozzáadása UTÁN!) →
   `android/app/google-services.json`
4. Authentication → Sign-in method → Google: Enabled

## Build lépések
```bash
npm install
npx cap sync android
```
Ellenőrizd, hogy a Gradle-ben megvan a google-services plugin (a Capacitor 6
sablonban benne van):
- `android/build.gradle` → `classpath 'com.google.gms:google-services:4.4.2'`
- `android/app/build.gradle` alján: `apply plugin: 'com.google.gms.google-services'`
  (a sablon csak akkor alkalmazza, ha létezik a `google-services.json`)

Utána Android Studio → Build → új APK. **Új APK kell**, OTA-val nem megy
(natív plugin).

## Hibakeresés
- `auth/native-plugin-missing` → a plugin nincs az APK-ban (npm install + cap sync + új build)
- `10:` / `DEVELOPER_ERROR` / "no credential" → hiányzó/rossz SHA-1, vagy a
  `google-services.json` az SHA hozzáadása előtti
- Play Store-ról telepített build: a Play App Signing kulcs SHA-1-ét is add hozzá
