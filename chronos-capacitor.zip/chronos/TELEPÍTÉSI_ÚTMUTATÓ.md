# CHRONOS Capacitor – Biztonsági mentés javítás

## Mi volt a probléma?
A `window.Capacitor.Plugins.Filesystem` és `.Share` plugin-ek nem voltak telepítve,
ezért az APK-ban az export minden esetben a leglassabb fallback-re esett vagy
csendben sikertelen volt. Egy korábbi javítás a megosztó panelt (Share Intent)
oldotta meg, de az csak "küldést" tett lehetővé, valódi fájlmentést nem.

## Mi változott (jelenlegi verzió)?
1. **`MainActivity.java`** – két natív metódus az `AndroidBridge`-ben:
   - **`saveFileWithPicker(filename, base64data, callbackName)`** ← ÚJ, elsődleges.
     Megnyitja az Android natív **"Mentés másként"** dialógust
     (`Intent.ACTION_CREATE_DOCUMENT`, Storage Access Framework) — a felhasználó
     kiválasztja a mappát és a fájlnevet, pontosan úgy, mint PC-n. A fájl
     közvetlenül a kiválasztott helyre íródik, nincs "küldés" más alkalmazásnak.
   - `shareFile(filename, base64data)` – megmaradt fallback-ként, ha a mentés
     dialógus valamiért nem indítható (pl. nagyon régi Android verzió).
2. **`www/index.html`** – export gomb új sorrendje:
   1. `AndroidBridge.saveFileWithPicker()` – natív mentés dialógus (ÚJ, elsődleges)
   2. `AndroidBridge.shareFile()` – megosztás más appnak (fallback)
   3. Capacitor Filesystem + Share plugin (ha esetleg telepítve van)
   4. Web Share API
   5. Data URI download
   6. Textarea (kézi mentés)
3. **`package.json`** – `@capacitor/filesystem` és `@capacitor/share` dokumentálva
   (opcionális, nem szükséges a működéshez).

## Android projekt teendők (KÖTELEZŐ)

### A. Hozz létre: `android/app/src/main/res/xml/file_paths.xml`
Tartalma: lásd `android-res/xml/file_paths.xml` ebben a csomagban.
(A `shareFile()` fallback-hez kell, a `saveFileWithPicker()`-hez nem.)

### B. `android/app/src/main/AndroidManifest.xml` – `<application>` tagbe:
Lásd `AndroidManifest_provider_snippet.xml` ebben a csomagban.

### C. `android/app/build.gradle` – dependencies:
```gradle
implementation "androidx.biometric:biometric:1.1.0"
implementation "androidx.core:core:1.10.0"
implementation "androidx.activity:activity:1.8.0"
```
(Az utolsó a `registerForActivityResult` / mentés dialógus eredmény-kezeléshez kell.)

### D. `MainActivity.java`
Másold a mellékelt, frissített verziót a megfelelő helyre:
`android/app/src/main/java/com/chronos/app/MainActivity.java`

## Build
```bash
npm install
npx cap sync android
npx cap open android
```

## Tesztelés
1. Telepítsd az APK-t
2. Beállítások → 📄 Biztonsági mentés → adj fájlnevet → OK
3. **Android natív "Mentés másként" dialógus** jelenik meg → válassz mappát
   (pl. Letöltések, Drive, SD kártya) → Mentés
4. A fájl a kiválasztott helyre kerül, nincs küldés/megosztás

