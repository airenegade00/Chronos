# CHRONOS Capacitor – Biztonsági mentés javítás

## Mi volt a probléma?
A `window.Capacitor.Plugins.Filesystem` és `.Share` plugin-ek nem voltak telepítve,
ezért az APK-ban az export minden esetben a leglassabb fallback-re esett vagy
csendben sikertelen volt.

## Mi változott?
1. **`MainActivity.java`** – új `shareFile(filename, base64data)` metódus az
   `AndroidBridge`-ben. Plugin nélkül, natív `Intent.ACTION_SEND` + `FileProvider`.
2. **`www/index.html`** – export gomb most elsőként `AndroidBridge.shareFile()`-t
   próbálja, csak utána a Capacitor plugin-eket / Web Share-t / fallback-eket.
3. **`package.json`** – `@capacitor/filesystem` és `@capacitor/share` hozzáadva
   (dokumentáció / opcionális, nem szükséges a működéshez).

## Android projekt teendők (KÖTELEZŐ)

### A. Hozz létre: `android/app/src/main/res/xml/file_paths.xml`
Tartalma: lásd `android-res/xml/file_paths.xml` ebben a csomagban.

### B. `android/app/src/main/AndroidManifest.xml` – `<application>` tagbe:
Lásd `AndroidManifest_provider_snippet.xml` ebben a csomagban.

### C. `MainActivity.java`
Másold a mellékelt, frissített verziót a megfelelő helyre:
`android/app/src/main/java/com/chronos/app/MainActivity.java`

## Build
```bash
npm install
npx cap sync android
npx cap open android
```

## Tesztelés
1. Telepítsd az APK-t
2. Beállítások → 📄 Biztonsági mentés → adj fájlnevet → OK
3. Android megosztó panel jelenik meg → válassz célalkalmazást
