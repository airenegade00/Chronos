# CHRONOS – Bootloader + OTA APK frissítés

## Hogyan működik?

Az app induláskor a `bootloader.html`-t tölti be (ez az új startPage).
A bootloader:
1. Lekéri a `version.json`-t Google Drive-ról
2. Ha újabb verzió elérhető → letölti az APK-t → Android telepítő intent
3. Ha nincs újabb / nincs net → azonnal indítja az `index.html`-t

A felhasználónak az első frissítésnél engedélyeznie kell az „Ismeretlen forrásból való telepítést"
(ezt Android megjegyzi, utána automatikus).

---

## Drive előkészítés

### 1. `version.json` létrehozása Drive-on
```json
{
  "version": "1.1.0",
  "apkUrl": "https://drive.google.com/uc?export=download&id=APK_FILE_ID",
  "changelog": "- Új funkció X\n- Hibajavítás Y"
}
```
- Töltsd fel Drive-ra
- Jobb klikk → Megosztás → „Bárki, akinek van a link" → Megtekintő
- A link: `https://drive.google.com/file/d/FILE_ID/view`
- Közvetlen letöltési link: `https://drive.google.com/uc?export=download&id=FILE_ID`

### 2. APK feltöltése Drive-ra
- Build az APK-t (GitHub Actions vagy manuálisan)
- Töltsd fel Drive-ra, állítsd be a megosztást (bárki megtekintő)
- Az APK `uc?export=download&id=APK_ID` linkjét add meg a `version.json`-ban

### 3. `bootloader.html` konfigurálása
A `www/bootloader.html` tetején a `CONFIG` objektumban:
```javascript
const CONFIG = {
  versionJsonUrl: "https://drive.google.com/uc?export=download&id=VERZIO_JSON_FILE_ID",
  currentVersion: "1.0.0",   // ← ezt minden buildnél frissíteni kell!
  checkTimeoutMs: 8000,
  mainAppFile: "index.html"
};
```

---

## Android projekt teendők

### A. `android/app/src/main/res/xml/file_paths.xml`
Már megvan (a `shareFile()` miatt) – változtatás nem szükséges.

### B. `AndroidManifest.xml` – engedélyek (manifest szintre, <application> elé)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
```

### C. `AndroidManifest.xml` – `<application>` tagbe
Lásd `AndroidManifest_provider_snippet.xml` (FileProvider – változatlan).

### D. `android/app/build.gradle` – dependencies (változatlan)
```gradle
implementation "androidx.biometric:biometric:1.1.0"
implementation "androidx.core:core:1.10.0"
implementation "androidx.activity:activity:1.8.0"
implementation "com.google.android.gms:play-services-auth:21.2.0"
```

### E. `MainActivity.java` – csere
Másold a mellékelt verziót ide:
`android/app/src/main/java/com/chronos/app/MainActivity.java`
Új metódus: `downloadAndInstallApk(url, callbackName)`

---

## Capacitor startPage

A `capacitor.config.json` automatikusan a `bootloader.html`-t tölti be elsőként
(az `index.html` a bootloader után töltődik be `window.location.href`-fel).

**Ha a `startPage`-et explicit akarod beállítani** a `capacitor.config.json`-ban:
```json
"android": {
  "startPath": "/bootloader.html"
}
```

---

## Verziókezelés – GitHub Actions integráció (opcionális)

A `bootloader.html`-ben a `currentVersion` manuálisan is frissíthető,
de automatizálható a build workflow-ban egy `sed` paranccsal:

```yaml
- name: Set version in bootloader
  run: |
    VERSION=$(cat version.txt)
    sed -i "s/currentVersion: \".*\"/currentVersion: \"$VERSION\"/" www/bootloader.html
```

---

## Tesztelés

1. Telepítsd az APK-t (első alkalommal kézi telepítés szükséges)
2. Töltsd fel a Drive-ra az újabb APK-t és frissítsd a `version.json`-t
3. Indítsd az appot → bootloader megjelenik → „Új verzió érhető el" dialog
4. Frissítés gomb → letöltés → Android telepítő dialog → Telepítés
5. Az app automatikusan az új verzióra frissül

